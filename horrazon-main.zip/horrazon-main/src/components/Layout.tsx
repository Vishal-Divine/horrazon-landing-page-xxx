import { Outlet, Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Eye,
  MessageSquare,
  Zap,
  Plug,
  Settings,
  Wallet,
  Command,
  PanelLeftClose,
  PanelLeft,
  Keyboard,
  ChevronUp,
  LogOut,
  User,
  HelpCircle,
} from 'lucide-react';
import TopNavBar from './topnav/TopNavBar';
import { cn } from '@/lib/utils';
import { useSidebarState } from '@/hooks/use-sidebar-state';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface SubItem {
  name: string;
  path: string;
}
interface NavItem {
  name: string;
  path: string;
  icon: React.ComponentType<{
    className?: string;
  }>;
  subItems?: SubItem[];
}
export default function Layout() {
  const location = useLocation();
  const seeSubItems: SubItem[] = [
    {
      name: 'Outreach',
      path: '/outreach',
    },
    {
      name: 'Attribution',
      path: '/attribution',
    },
    {
      name: 'Pixel Tracking',
      path: '/pixel',
    },
    {
      name: 'Call Tracking',
      path: '/call-tracking',
    },
    {
      name: 'Merchandise',
      path: '/merchandise',
    },
    {
      name: 'CLTV',
      path: '/cltv',
    },
    {
      name: 'Influencer Marketing',
      path: '/influencer-marketing',
    },
    {
      name: 'SEO',
      path: '/seo',
    },
    {
      name: 'Reports',
      path: '/reports',
    },
    {
      name: 'Forecasting',
      path: '/forecasting',
    },
    {
      name: 'Competitor Intel',
      path: '/competitor-intelligence',
    },
    {
      name: 'Budget Management',
      path: '/budget',
    },
    {
      name: 'Goals & KPIs',
      path: '/goals',
    },
    {
      name: 'Experiments',
      path: '/experiments',
    },
    {
      name: 'Segments',
      path: '/segments',
    },
    {
      name: 'Calendar',
      path: '/calendar',
    },
    {
      name: 'Brand Voice & AI',
      path: '/brand-voice',
    },
  ];
  const actSubItems: SubItem[] = [
    {
      name: 'Action Center',
      path: '/actions',
    },
    {
      name: 'Action Log',
      path: '/action-log',
    },
    {
      name: 'Rules',
      path: '/rules',
    },
  ];
  const navItems: NavItem[] = [
    {
      name: 'Daily Pulse',
      path: '/',
      icon: LayoutDashboard,
    },
    {
      name: 'Command Center',
      path: '/command-center',
      icon: Command,
    },
    {
      name: 'Integrations',
      path: '/integrations',
      icon: Plug,
    },
    {
      name: 'Wallet',
      path: '/wallet',
      icon: Wallet,
    },
    {
      name: 'See',
      path: '/outreach',
      icon: Eye,
      subItems: seeSubItems,
    },
    {
      name: 'Ask',
      path: '/ask',
      icon: MessageSquare,
    },
    {
      name: 'Act',
      path: '/actions',
      icon: Zap,
      subItems: actSubItems,
    },
    {
      name: 'Settings',
      path: '/settings',
      icon: Settings,
    },
  ];
  const isPathActive = (path: string, subItems?: SubItem[]) => {
    if (location.pathname === path) return true;
    if (subItems) {
      return subItems.some((sub) => location.pathname === sub.path);
    }
    return false;
  };
  const { isCollapsed: sidebarCollapsed, toggle: toggleSidebar } = useSidebarState(false);
  const isMac = typeof navigator !== 'undefined' && navigator.platform.toUpperCase().indexOf('MAC') >= 0;

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-background to-accent/20 overflow-hidden">
      {/* Top Navigation Bar */}
      <TopNavBar />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Fixed position, doesn't scroll with content */}
        <TooltipProvider delayDuration={100}>
          <nav
            className={cn(
              'h-full border-r bg-card/80 backdrop-blur-xl shadow-xl transition-all duration-300 ease-in-out flex flex-col flex-shrink-0',
              sidebarCollapsed ? 'w-16' : 'w-56',
            )}
          >
            {/* Navigation Items - Scrollable */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-thin scrollbar-thumb-border scrollbar-track-transparent">
              <div className="p-3 space-y-1">
                {navItems.map((item) => (
                  <div
                    key={item.path}
                    className="animate-fade-in"
                    style={{ animationDelay: `${navItems.indexOf(item) * 30}ms` }}
                  >
                    {sidebarCollapsed ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Link
                            to={item.path}
                            className={cn(
                              'group flex items-center justify-center rounded-xl p-2.5 transition-all duration-200 relative',
                              isPathActive(item.path, item.subItems)
                                ? 'bg-gradient-to-r from-primary to-primary/90 text-primary-foreground shadow-lg shadow-primary/25'
                                : 'hover:bg-accent/60 text-muted-foreground hover:text-foreground',
                            )}
                          >
                            <item.icon
                              className={cn(
                                'h-5 w-5 transition-all duration-200',
                                isPathActive(item.path, item.subItems) ? '' : 'group-hover:scale-110',
                              )}
                            />
                            {isPathActive(item.path, item.subItems) && (
                              <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-primary rounded-r-full" />
                            )}
                          </Link>
                        </TooltipTrigger>
                        <TooltipContent side="right" className="font-medium bg-popover/95 backdrop-blur-sm">
                          {item.name}
                        </TooltipContent>
                      </Tooltip>
                    ) : (
                      <Link
                        to={item.path}
                        className={cn(
                          'group flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all duration-200 relative',
                          isPathActive(item.path, item.subItems)
                            ? 'bg-gradient-to-r from-primary to-primary/90 text-primary-foreground shadow-lg shadow-primary/25'
                            : 'hover:bg-accent/60 text-muted-foreground hover:text-foreground hover:translate-x-0.5',
                        )}
                      >
                        {isPathActive(item.path, item.subItems) && (
                          <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-primary-foreground/30 rounded-r-full" />
                        )}
                        <item.icon
                          className={cn(
                            'h-5 w-5 transition-all duration-200 flex-shrink-0',
                            isPathActive(item.path, item.subItems) ? '' : 'group-hover:scale-110',
                          )}
                        />
                        <span className="font-medium text-sm">{item.name}</span>
                      </Link>
                    )}
                    {/* Sub Items with smooth animation */}
                    {!sidebarCollapsed && item.subItems && isPathActive(item.path, item.subItems) && (
                      <div className="mt-1.5 ml-3 pl-3 border-l border-border/50 space-y-0.5 animate-fade-in">
                        {item.subItems.map((subItem, idx) => (
                          <Link
                            key={subItem.path}
                            to={subItem.path}
                            className={cn(
                              'block rounded-lg px-3 py-2 text-sm transition-all duration-200',
                              location.pathname === subItem.path
                                ? 'font-semibold text-primary bg-primary/10'
                                : 'text-muted-foreground hover:text-foreground hover:bg-accent/40 hover:translate-x-0.5',
                            )}
                            style={{ animationDelay: `${idx * 20}ms` }}
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Sidebar Footer - Profile & Toggle */}
            <div className="flex-shrink-0 border-t border-border/40 bg-card/50">
              {sidebarCollapsed ? (
                <div className="p-2 space-y-2">
                  {/* Mini Profile */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Link to="/settings" className="block">
                        <Avatar className="h-9 w-9 mx-auto ring-2 ring-border/50 hover:ring-primary/50 transition-all duration-200 cursor-pointer">
                          <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Profile" />
                          <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">AJ</AvatarFallback>
                        </Avatar>
                      </Link>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="bg-popover/95 backdrop-blur-sm">
                      <p className="font-medium">Alex Johnson</p>
                      <p className="text-xs text-muted-foreground">alex@horrazon.ai</p>
                    </TooltipContent>
                  </Tooltip>

                  {/* Settings Quick Access */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Link to="/settings">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-full h-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/60 transition-all duration-200"
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                      </Link>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="bg-popover/95 backdrop-blur-sm">
                      Settings
                    </TooltipContent>
                  </Tooltip>

                  {/* Toggle Button */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleSidebar}
                        className="w-full h-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/60 transition-all duration-200"
                      >
                        <PanelLeft className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="flex items-center gap-2 bg-popover/95 backdrop-blur-sm">
                      <span>Expand</span>
                      <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
                        {isMac ? '⌘B' : 'Ctrl+B'}
                      </kbd>
                    </TooltipContent>
                  </Tooltip>
                </div>
              ) : (
                <div className="p-3 space-y-3">
                  {/* Profile Section with Dropdown */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-accent/60 transition-all duration-200 group">
                        <Avatar className="h-9 w-9 ring-2 ring-border/50 group-hover:ring-primary/50 transition-all duration-200">
                          <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Profile" />
                          <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">AJ</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 text-left min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">Alex Johnson</p>
                          <p className="text-xs text-muted-foreground truncate">alex@horrazon.ai</p>
                        </div>
                        <ChevronUp className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent side="top" align="start" className="w-52 mb-1">
                      <DropdownMenuItem asChild>
                        <Link to="/settings" className="flex items-center gap-2 cursor-pointer">
                          <User className="h-4 w-4" />
                          <span>Profile</span>
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/settings" className="flex items-center gap-2 cursor-pointer">
                          <Settings className="h-4 w-4" />
                          <span>Settings</span>
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
                        <HelpCircle className="h-4 w-4" />
                        <span>Help & Support</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="flex items-center gap-2 cursor-pointer text-destructive focus:text-destructive">
                        <LogOut className="h-4 w-4" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* Toggle Section */}
                  <div className="flex items-center justify-between px-2">
                    <div className="flex items-center gap-2 text-[11px] text-muted-foreground/70">
                      <Keyboard className="h-3 w-3" />
                      <span>{isMac ? '⌘B' : 'Ctrl+B'}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={toggleSidebar}
                      className="h-7 px-2 gap-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/60 transition-all duration-200"
                    >
                      <PanelLeftClose className="h-3.5 w-3.5" />
                      <span className="text-xs">Collapse</span>
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </nav>
        </TooltipProvider>

        {/* Main Content - Scrolls independently */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
