import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Star, Bell, Clock } from 'lucide-react';
import { SavedQuery, AnalysisCategory } from './types';

interface SaveQueryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  query: string;
  onSave: (savedQuery: Omit<SavedQuery, 'id' | 'lastRun'>) => void;
}

export function SaveQueryDialog({ open, onOpenChange, query, onSave }: SaveQueryDialogProps) {
  const [name, setName] = useState('');
  const [frequency, setFrequency] = useState<SavedQuery['frequency']>('none');
  const [category, setCategory] = useState<AnalysisCategory>('marketing');
  const [pinned, setPinned] = useState(false);

  const handleSave = () => {
    onSave({
      query,
      name: name || query.slice(0, 40),
      frequency,
      category,
      pinned,
    });

    // Reset form
    setName('');
    setFrequency('none');
    setPinned(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-amber-500" />
            Save Query
          </DialogTitle>
          <DialogDescription>
            Save this query for quick access later. You can also schedule automatic runs.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Query Preview */}
          <div className="rounded-lg bg-muted/50 p-3">
            <p className="text-sm text-muted-foreground mb-1">Query</p>
            <p className="text-sm font-medium">{query}</p>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Name (optional)</Label>
            <Input
              id="name"
              placeholder="e.g., Weekly Channel ROAS"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as AnalysisCategory)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="marketing">Marketing Analytics</SelectItem>
                <SelectItem value="customers">Customer Insights</SelectItem>
                <SelectItem value="revenue">Revenue & Sales</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Frequency */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Auto-run Schedule
            </Label>
            <Select value={frequency} onValueChange={(v) => setFrequency(v as SavedQuery['frequency'])}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No automatic runs</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Pin */}
          <div className="flex items-center justify-between rounded-lg border border-border/50 p-3">
            <div className="space-y-0.5">
              <Label className="text-sm font-medium">Pin to quick access</Label>
              <p className="text-xs text-muted-foreground">Show in sidebar for one-click access</p>
            </div>
            <Switch checked={pinned} onCheckedChange={setPinned} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="gap-2">
            <Star className="h-4 w-4" />
            Save Query
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
