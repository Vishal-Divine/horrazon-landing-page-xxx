import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Bot, Plus, Settings2, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { QuickInsight } from './types';

interface QuickInsightsHeaderProps {
  insights: QuickInsight[];
  onNewChat: () => void;
  onSettings: () => void;
}

export function QuickInsightsHeader({ insights, onNewChat, onSettings }: QuickInsightsHeaderProps) {
  return (
    <div className="border-b border-border/50 bg-gradient-to-r from-background via-muted/20 to-background px-8 py-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 via-purple-500 to-fuchsia-500 shadow-lg shadow-purple-500/25">
              <Bot className="h-7 w-7 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-background bg-emerald-500 animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Ask Pogee</h1>
            <p className="text-sm text-muted-foreground">Your AI marketing analyst • Always online</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-muted-foreground hover:text-foreground"
            onClick={onNewChat}
          >
            <Plus className="h-4 w-4" />
            New Chat
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            onClick={onSettings}
          >
            <Settings2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Quick Insights Grid */}
      <div className="mt-6 grid gap-3 md:grid-cols-4">
        {insights.map((insight, i) => {
          const TrendIcon = insight.trend === 'up' ? TrendingUp : insight.trend === 'down' ? TrendingDown : Minus;

          return (
            <div
              key={i}
              className="group flex items-center gap-3 rounded-xl border border-border/50 bg-card/50 p-3 backdrop-blur-sm transition-all hover:border-primary/30 hover:shadow-md cursor-pointer"
            >
              <div className={cn('rounded-lg p-2', insight.bgColor)}>
                <insight.icon className={cn('h-5 w-5', insight.color)} />
              </div>
              <div className="flex-1">
                <p className="font-semibold">{insight.title}</p>
                <p className="text-xs text-muted-foreground">{insight.description}</p>
              </div>
              {insight.change !== undefined && (
                <div
                  className={cn(
                    'flex items-center gap-0.5 text-xs font-medium',
                    insight.trend === 'up'
                      ? 'text-emerald-500'
                      : insight.trend === 'down'
                        ? 'text-destructive'
                        : 'text-muted-foreground',
                  )}
                >
                  <TrendIcon className="h-3 w-3" />
                  <span>
                    {insight.trend === 'down' ? '' : '+'}
                    {insight.change}%
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
