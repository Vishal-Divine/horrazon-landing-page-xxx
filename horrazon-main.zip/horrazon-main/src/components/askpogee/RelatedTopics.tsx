import { Button } from '@/components/ui/button';
import { ChevronRight, Compass, ExternalLink } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RelatedTopicsProps {
  topics: string[];
  onTopicClick: (topic: string) => void;
  currentQuery?: string;
}

export function RelatedTopics({ topics, onTopicClick, currentQuery }: RelatedTopicsProps) {
  if (topics.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
        <Compass className="h-3.5 w-3.5" />
        Related Topics
      </div>

      <div className="flex flex-wrap gap-2">
        {topics.map((topic, i) => (
          <Button
            key={i}
            variant="outline"
            size="sm"
            className={cn(
              'h-8 text-xs gap-1.5',
              'hover:border-primary/50 hover:bg-primary/5 hover:text-primary',
              'transition-all',
            )}
            onClick={() => onTopicClick(`Tell me about ${topic}`)}
          >
            {topic}
            <ChevronRight className="h-3 w-3" />
          </Button>
        ))}
      </div>
    </div>
  );
}
