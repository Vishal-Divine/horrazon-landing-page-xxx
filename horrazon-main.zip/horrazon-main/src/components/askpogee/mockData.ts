import {
  TrendingUp,
  Target,
  DollarSign,
  Users,
  ShoppingCart,
  Percent,
  MousePointer,
  Eye,
  Mail,
  Share2,
  BarChart3,
  PieChart,
  Megaphone,
} from 'lucide-react';
import {
  AnalysisResult,
  SavedQuery,
  ConversationHistory,
  QuickInsight,
  TemplateQuery,
  DataPoint,
  OutputFormat,
} from './types';

// Quick insights for the header
export const quickInsights: QuickInsight[] = [
  {
    icon: TrendingUp,
    title: 'ROAS up 18%',
    description: 'vs last week',
    color: 'text-emerald-500',
    bgColor: 'bg-emerald-500/10',
    change: 18,
    trend: 'up',
  },
  {
    icon: Users,
    title: '2.4K new',
    description: 'customers',
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    change: 12,
    trend: 'up',
  },
  {
    icon: DollarSign,
    title: '$124K',
    description: 'revenue',
    color: 'text-violet-500',
    bgColor: 'bg-violet-500/10',
    change: 8,
    trend: 'up',
  },
  {
    icon: Target,
    title: '4.2% CVR',
    description: '+0.3%',
    color: 'text-amber-500',
    bgColor: 'bg-amber-500/10',
    change: 0.3,
    trend: 'up',
  },
];

// Template queries organized by category
export const templateQueries: TemplateQuery[] = [
  // Marketing Analytics
  {
    id: 'm1',
    text: 'Which campaigns converted the best last week?',
    category: 'marketing',
    icon: TrendingUp,
    description: 'Campaign performance analysis',
    popularity: 95,
  },
  {
    id: 'm2',
    text: 'Show me my top performing Meta Ads by ROAS',
    category: 'marketing',
    icon: Target,
    description: 'Channel optimization',
    popularity: 88,
  },
  {
    id: 'm3',
    text: "What's my average CPC across all channels?",
    category: 'marketing',
    icon: DollarSign,
    description: 'Cost analysis',
    popularity: 82,
  },
  {
    id: 'm4',
    text: 'Compare Google vs Meta performance this month',
    category: 'marketing',
    icon: BarChart3,
    description: 'Channel comparison',
    popularity: 90,
  },
  {
    id: 'm5',
    text: 'Which ad creatives have the highest CTR?',
    category: 'marketing',
    icon: MousePointer,
    description: 'Creative performance',
    popularity: 78,
  },
  {
    id: 'm6',
    text: 'Show email open rates by campaign type',
    category: 'marketing',
    icon: Mail,
    description: 'Email analytics',
    popularity: 72,
  },

  // Customer Insights
  {
    id: 'c1',
    text: "What's my customer acquisition cost trend?",
    category: 'customers',
    icon: Users,
    description: 'CAC analysis',
    popularity: 85,
  },
  {
    id: 'c2',
    text: 'Show me customer segments by lifetime value',
    category: 'customers',
    icon: PieChart,
    description: 'LTV segmentation',
    popularity: 80,
  },
  {
    id: 'c3',
    text: 'Which customer cohort has the best retention?',
    category: 'customers',
    icon: TrendingUp,
    description: 'Cohort analysis',
    popularity: 75,
  },
  {
    id: 'c4',
    text: "What's driving customer churn this quarter?",
    category: 'customers',
    icon: Target,
    description: 'Churn analysis',
    popularity: 70,
  },
  {
    id: 'c5',
    text: 'Show repeat purchase behavior patterns',
    category: 'customers',
    icon: ShoppingCart,
    description: 'Purchase patterns',
    popularity: 68,
  },

  // Revenue & Sales
  {
    id: 'r1',
    text: "What's my revenue by product category?",
    category: 'revenue',
    icon: DollarSign,
    description: 'Revenue breakdown',
    popularity: 92,
  },
  {
    id: 'r2',
    text: 'Show sales forecast for next month',
    category: 'revenue',
    icon: TrendingUp,
    description: 'Sales forecasting',
    popularity: 86,
  },
  {
    id: 'r3',
    text: 'Which products have the highest profit margin?',
    category: 'revenue',
    icon: Percent,
    description: 'Margin analysis',
    popularity: 79,
  },
  {
    id: 'r4',
    text: 'Compare revenue this week vs last week',
    category: 'revenue',
    icon: BarChart3,
    description: 'Weekly comparison',
    popularity: 88,
  },
  {
    id: 'r5',
    text: 'Show average order value trends',
    category: 'revenue',
    icon: ShoppingCart,
    description: 'AOV analysis',
    popularity: 74,
  },
];

// Follow-up question suggestions
export const followUpQuestions = [
  'Break this down by device type',
  'Show me the trend over time',
  "What's driving this change?",
  'How does this compare to last month?',
  'Which segment performs best?',
  'Export this as a report',
];

// Related topics based on query
export const relatedTopics: Record<string, string[]> = {
  campaign: ['Ad spend efficiency', 'Creative performance', 'Audience targeting', 'Conversion paths'],
  revenue: ['Product performance', 'Pricing analysis', 'Seasonal trends', 'Profit margins'],
  customer: ['Segmentation', 'Lifetime value', 'Acquisition cost', 'Retention rates'],
  default: ['Performance overview', 'Trend analysis', 'Comparative insights', 'Optimization suggestions'],
};

// Initial saved queries
export const initialSavedQueries: SavedQuery[] = [
  {
    id: 's1',
    query: 'Weekly ROAS by channel',
    name: 'Weekly Channel ROAS',
    frequency: 'daily',
    lastRun: '2 hours ago',
    category: 'marketing',
    pinned: true,
  },
  {
    id: 's2',
    query: 'Top 10 products by revenue',
    name: 'Top Products',
    frequency: 'weekly',
    lastRun: '1 day ago',
    category: 'revenue',
    pinned: true,
  },
  {
    id: 's3',
    query: 'Customer acquisition cost trend',
    name: 'CAC Trend',
    frequency: 'daily',
    lastRun: '4 hours ago',
    category: 'customers',
    pinned: false,
  },
  {
    id: 's4',
    query: 'Email campaign performance',
    name: 'Email Stats',
    frequency: 'weekly',
    lastRun: '3 days ago',
    category: 'marketing',
    pinned: false,
  },
];

// Initial conversation history
export const initialConversationHistory: ConversationHistory[] = [
  {
    id: 'h1',
    query: "What's my best performing channel?",
    time: '10 min ago',
    response: 'Meta Ads with 6.2x ROAS',
    format: 'bar',
  },
  {
    id: 'h2',
    query: 'Show me CTR by creative type',
    time: '1 hour ago',
    response: 'Video: 3.2%, Image: 1.8%',
    format: 'pie',
  },
  {
    id: 'h3',
    query: 'Compare this week vs last week',
    time: '2 hours ago',
    response: '+12% revenue, -8% CPC',
    format: 'line',
  },
];

// Detect suggested chart format based on query
export function detectSuggestedFormat(query: string): OutputFormat {
  const lower = query.toLowerCase();

  if (lower.includes('region') || lower.includes('country') || lower.includes('geo') || lower.includes('location')) {
    return 'pie';
  }
  if (
    lower.includes('trend') ||
    lower.includes('over time') ||
    lower.includes('daily') ||
    lower.includes('weekly') ||
    lower.includes('monthly')
  ) {
    return 'line';
  }
  if (
    lower.includes('breakdown') ||
    lower.includes('distribution') ||
    lower.includes('share') ||
    lower.includes('by type')
  ) {
    return 'pie';
  }
  if (
    lower.includes('compare') ||
    lower.includes('vs') ||
    lower.includes('top') ||
    lower.includes('best') ||
    lower.includes('ranking')
  ) {
    return 'bar';
  }
  if (lower.includes('growth') || lower.includes('cumulative') || lower.includes('volume')) {
    return 'area';
  }
  if (lower.includes('funnel') || lower.includes('conversion') || lower.includes('journey')) {
    return 'funnel';
  }

  return 'bar';
}

// Generate mock analysis result
export function generateMockAnalysis(query: string): AnalysisResult {
  const isRevenue = query.toLowerCase().includes('revenue') || query.toLowerCase().includes('sales');
  const isCustomer = query.toLowerCase().includes('customer') || query.toLowerCase().includes('user');
  const isCampaign = query.toLowerCase().includes('campaign') || query.toLowerCase().includes('ad');
  const isRegion = query.toLowerCase().includes('region') || query.toLowerCase().includes('country');
  const isTrend =
    query.toLowerCase().includes('trend') ||
    query.toLowerCase().includes('over time') ||
    query.toLowerCase().includes('daily');

  const suggestedFormat = detectSuggestedFormat(query);

  let baseData: DataPoint[];

  if (isRegion) {
    baseData = [
      { name: 'North America', value: 45200, change: 12 },
      { name: 'Europe', value: 38900, change: 8 },
      { name: 'Asia Pacific', value: 29500, change: 18 },
      { name: 'Latin America', value: 12100, change: 15 },
      { name: 'Middle East', value: 8700, change: 22 },
    ];
  } else if (isTrend) {
    baseData = [
      { name: 'Week 1', value: 32000, change: 0 },
      { name: 'Week 2', value: 35400, change: 10.6 },
      { name: 'Week 3', value: 38200, change: 7.9 },
      { name: 'Week 4', value: 41500, change: 8.6 },
      { name: 'Week 5', value: 45800, change: 10.4 },
      { name: 'Week 6', value: 48200, change: 5.2 },
    ];
  } else if (isRevenue) {
    baseData = [
      { name: 'Electronics', value: 45200, change: 12 },
      { name: 'Clothing', value: 38900, change: 8 },
      { name: 'Home & Garden', value: 29500, change: -3 },
      { name: 'Sports', value: 22100, change: 15 },
      { name: 'Beauty', value: 18700, change: 22 },
    ];
  } else if (isCampaign) {
    baseData = [
      { name: 'Summer Sale', value: 342, conversions: 342, rate: '4.2%', roas: '5.8x', spend: 12500 },
      { name: 'Product Launch', value: 287, conversions: 287, rate: '3.8%', roas: '4.9x', spend: 15200 },
      { name: 'Retargeting Q4', value: 193, conversions: 193, rate: '6.1%', roas: '7.2x', spend: 8900 },
      { name: 'Brand Awareness', value: 156, conversions: 156, rate: '2.4%', roas: '3.2x', spend: 18000 },
      { name: 'Holiday Special', value: 134, conversions: 134, rate: '5.2%', roas: '6.1x', spend: 9500 },
    ];
  } else {
    baseData = [
      { name: 'New Visitors', value: 2450, change: 18 },
      { name: 'Returning', value: 1820, change: 5 },
      { name: 'VIP', value: 340, change: 28 },
      { name: 'At Risk', value: 520, change: -12 },
    ];
  }

  return {
    text: `Based on your data analysis, here are the key findings for: "${query}"`,
    data: baseData,
    suggestedFormat,
    insights: [
      {
        text: 'Retargeting campaigns have 2.3x higher conversion rates than acquisition campaigns',
        type: 'positive',
        impact: 'high',
        metric: 'Conversion Rate',
      },
      {
        text: "Consider increasing budget for 'Summer Sale' - highest volume performer",
        type: 'action',
        impact: 'high',
        metric: 'Revenue',
      },
      {
        text: 'Mobile traffic shows 15% lower conversion than desktop - opportunity for optimization',
        type: 'warning',
        impact: 'medium',
        metric: 'Conversion',
      },
      {
        text: 'VIP segment growing 28% faster than average customer base',
        type: 'positive',
        impact: 'medium',
        metric: 'Customer Growth',
      },
    ],
    recommendations: [
      {
        title: 'Increase Retargeting Budget',
        description: 'Allocate 20% more budget to retargeting campaigns based on superior ROAS performance',
        priority: 'high',
        estimatedImpact: '+$12,500 revenue/month',
        actionable: true,
      },
      {
        title: 'Optimize Mobile Experience',
        description: 'Review mobile checkout flow to reduce friction and improve conversion rates',
        priority: 'medium',
        estimatedImpact: '+8% mobile CVR',
        actionable: true,
      },
      {
        title: 'VIP Loyalty Program',
        description: 'Expand VIP benefits to capitalize on high-value segment growth',
        priority: 'medium',
        estimatedImpact: '+15% LTV',
        actionable: true,
      },
    ],
    confidence: Math.floor(Math.random() * 10) + 90, // 90-99%
    sources: ['Meta Ads', 'Google Ads', 'Shopify', 'Google Analytics'],
    metrics: [
      { label: 'Total Conversions', value: '1,112', change: 12.5, trend: 'up' },
      { label: 'Avg. ROAS', value: '5.4x', change: 8.2, trend: 'up' },
      { label: 'CPA', value: '$24.50', change: -5.3, trend: 'down' },
      { label: 'Revenue', value: '$124,500', change: 15.8, trend: 'up' },
    ],
    drilldownAvailable: true,
  };
}

// Smart suggestions based on input
export function getSmartSuggestions(input: string): string[] {
  const lowercaseInput = input.toLowerCase();
  const suggestions: string[] = [];

  if (lowercaseInput.includes('campaign')) {
    suggestions.push(
      'Which campaigns have the highest ROAS?',
      'Compare campaign performance by channel',
      'Show campaign spend vs revenue',
    );
  } else if (lowercaseInput.includes('revenue') || lowercaseInput.includes('sales')) {
    suggestions.push(
      'Revenue by product category',
      'Sales trend over last 30 days',
      'Compare revenue: this month vs last',
    );
  } else if (lowercaseInput.includes('customer')) {
    suggestions.push('Customer acquisition cost trend', 'Customer segments by LTV', 'Churn rate by cohort');
  } else if (lowercaseInput.includes('ad') || lowercaseInput.includes('meta') || lowercaseInput.includes('google')) {
    suggestions.push('Ad performance by creative type', 'Compare Meta vs Google ROAS', 'Top performing ad sets');
  } else {
    suggestions.push(
      'Show weekly performance summary',
      'What metrics need attention?',
      'Compare this week vs last week',
    );
  }

  return suggestions.slice(0, 4);
}
