import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Search, Sparkles, TrendingUp, Users, DollarSign, Star, Flame } from 'lucide-react';
import { TemplateQuery, AnalysisCategory } from './types';
import { cn } from '@/lib/utils';

interface TemplateLibraryProps {
  templates: TemplateQuery[];
  onSelectTemplate: (query: string) => void;
  onClose?: () => void;
}

export function TemplateLibrary({ templates, onSelectTemplate, onClose }: TemplateLibraryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<AnalysisCategory | 'all'>('all');

  const filteredTemplates = templates.filter((t) => {
    const matchesSearch =
      t.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || t.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const popularTemplates = [...templates].sort((a, b) => b.popularity - a.popularity).slice(0, 6);

  const categoryIcons: Record<AnalysisCategory | 'all', React.ReactNode> = {
    all: <Sparkles className="h-4 w-4" />,
    marketing: <TrendingUp className="h-4 w-4" />,
    customers: <Users className="h-4 w-4" />,
    revenue: <DollarSign className="h-4 w-4" />,
  };

  return (
    <Card className="border-border/50 bg-card/95 backdrop-blur-sm shadow-xl">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Sparkles className="h-5 w-5 text-primary" />
            Template Library
          </CardTitle>
          <Badge variant="secondary" className="text-xs">
            {templates.length} templates
          </Badge>
        </div>

        {/* Search */}
        <div className="relative mt-4">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Popular Section */}
        {!searchQuery && activeCategory === 'all' && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Flame className="h-4 w-4 text-orange-500" />
              Popular Queries
            </div>
            <div className="grid gap-2">
              {popularTemplates.slice(0, 3).map((template) => (
                <button
                  key={template.id}
                  onClick={() => onSelectTemplate(template.text)}
                  className="flex items-center gap-3 rounded-lg border border-border/50 bg-muted/30 p-3 text-left transition-all hover:border-primary/50 hover:bg-muted/50 group"
                >
                  <div className="rounded-lg bg-primary/10 p-2 group-hover:bg-primary/20 transition-colors">
                    <template.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{template.text}</p>
                    <p className="text-xs text-muted-foreground">{template.description}</p>
                  </div>
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category Tabs */}
        <Tabs value={activeCategory} onValueChange={(v) => setActiveCategory(v as AnalysisCategory | 'all')}>
          <TabsList className="grid w-full grid-cols-4">
            {(['all', 'marketing', 'customers', 'revenue'] as const).map((cat) => (
              <TabsTrigger key={cat} value={cat} className="flex items-center gap-1.5 text-xs">
                {categoryIcons[cat]}
                <span className="capitalize">{cat}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={activeCategory} className="mt-4">
            <ScrollArea className="h-[300px] pr-4">
              <div className="grid gap-2">
                {filteredTemplates.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => onSelectTemplate(template.text)}
                    className="flex items-start gap-3 rounded-lg border border-border/30 p-3 text-left transition-all hover:border-primary/50 hover:bg-muted/30 group"
                  >
                    <div className="rounded-lg bg-muted/50 p-2 group-hover:bg-primary/10 transition-colors">
                      <template.icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm leading-relaxed">{template.text}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-[10px] capitalize">
                          {template.category}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">{template.popularity}% popular</span>
                      </div>
                    </div>
                  </button>
                ))}

                {filteredTemplates.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <Search className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">No templates found</p>
                    <p className="text-xs text-muted-foreground">Try a different search term</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
