import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Download,
  FileSpreadsheet,
  FileText,
  Image,
  Share2,
  Copy,
  Mail,
  Link2,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ExportOptionsProps {
  onExport: (format: 'csv' | 'pdf' | 'png') => void;
  onShare?: (method: 'link' | 'email') => void;
  onCopy: () => void;
  className?: string;
}

export function ExportOptions({ onExport, onShare, onCopy, className }: ExportOptionsProps) {
  const [isExporting, setIsExporting] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleExport = async (format: 'csv' | 'pdf' | 'png') => {
    setIsExporting(format);

    // Simulate export process
    await new Promise((r) => setTimeout(r, 1000));

    onExport(format);
    setIsExporting(null);
    toast.success(`Exported as ${format.toUpperCase()}`, {
      description: 'Your file is ready for download',
    });
  };

  const handleCopy = () => {
    onCopy();
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (method: 'link' | 'email') => {
    onShare?.(method);
    toast.success(method === 'link' ? 'Link copied!' : 'Sharing via email...', {
      description: method === 'link' ? 'Share this link with your team' : 'Opening email client',
    });
  };

  return (
    <div className={cn('flex items-center gap-1', className)}>
      {/* Copy Button */}
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-muted-foreground hover:text-foreground"
        onClick={handleCopy}
      >
        {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
      </Button>

      {/* Export Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Download className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel className="text-xs text-muted-foreground">Export As</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => handleExport('csv')} disabled={isExporting === 'csv'} className="gap-2">
            {isExporting === 'csv' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FileSpreadsheet className="h-4 w-4 text-emerald-500" />
            )}
            <span>CSV Spreadsheet</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleExport('pdf')} disabled={isExporting === 'pdf'} className="gap-2">
            {isExporting === 'pdf' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FileText className="h-4 w-4 text-destructive" />
            )}
            <span>PDF Report</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleExport('png')} disabled={isExporting === 'png'} className="gap-2">
            {isExporting === 'png' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Image className="h-4 w-4 text-blue-500" />
            )}
            <span>PNG Image</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Share Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Share2 className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel className="text-xs text-muted-foreground">Share</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => handleShare('link')} className="gap-2">
            <Link2 className="h-4 w-4" />
            <span>Copy Share Link</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare('email')} className="gap-2">
            <Mail className="h-4 w-4" />
            <span>Share via Email</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
