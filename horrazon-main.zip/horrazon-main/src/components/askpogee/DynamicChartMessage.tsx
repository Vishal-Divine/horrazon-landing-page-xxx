import { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  ComposedChart,
  Legend,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ScatterChart,
  Scatter,
  ZAxis,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart3,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Map,
  TrendingUp,
  Maximize2,
  Download,
  Share2,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { DataPoint, OutputFormat } from './types';
import { cn } from '@/lib/utils';

interface DynamicChartMessageProps {
  query: string;
  data: DataPoint[];
  suggestedFormat: OutputFormat;
  onFormatChange?: (format: OutputFormat) => void;
  onDrilldown?: (item: DataPoint) => void;
  onFollowUp?: (question: string) => void;
}

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

const tooltipStyle = {
  backgroundColor: 'hsl(var(--popover))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '12px',
  boxShadow: '0 10px 40px -10px rgba(0,0,0,0.3)',
};

// Detect the best chart type based on query context
export function detectChartType(query: string): OutputFormat {
  const lower = query.toLowerCase();

  // Geographic queries suggest map
  if (
    lower.includes('region') ||
    lower.includes('country') ||
    lower.includes('state') ||
    lower.includes('location') ||
    lower.includes('geo')
  ) {
    return 'pie'; // Fallback to pie for geographic distribution
  }

  // Trend/time queries suggest line
  if (
    lower.includes('trend') ||
    lower.includes('over time') ||
    lower.includes('last') ||
    lower.includes('month') ||
    lower.includes('week') ||
    lower.includes('daily')
  ) {
    return 'line';
  }

  // Distribution/breakdown queries suggest pie
  if (
    lower.includes('breakdown') ||
    lower.includes('distribution') ||
    lower.includes('share') ||
    lower.includes('percentage') ||
    lower.includes('portion')
  ) {
    return 'pie';
  }

  // Comparison queries suggest bar
  if (
    lower.includes('compare') ||
    lower.includes('vs') ||
    lower.includes('versus') ||
    lower.includes('top') ||
    lower.includes('best') ||
    lower.includes('ranking')
  ) {
    return 'bar';
  }

  // Volume/growth queries suggest area
  if (lower.includes('growth') || lower.includes('volume') || lower.includes('cumulative')) {
    return 'area';
  }

  // Funnel queries
  if (lower.includes('funnel') || lower.includes('conversion') || lower.includes('journey') || lower.includes('path')) {
    return 'funnel';
  }

  return 'bar'; // Default to bar chart
}

// Generate follow-up suggestions based on chart context
function getFollowUpSuggestions(query: string, format: OutputFormat): string[] {
  const suggestions: string[] = [];

  if (format === 'bar') {
    suggestions.push('Would you like to see how this compares to last month?');
    suggestions.push('Should I identify the top 3 performers?');
  } else if (format === 'line') {
    suggestions.push('Would you like to see a forecast for next week?');
    suggestions.push('Should I highlight any anomalies in this trend?');
  } else if (format === 'pie') {
    suggestions.push('Would you like to see the breakdown by sub-category?');
    suggestions.push('Should I compare this distribution to last period?');
  }

  suggestions.push('Export this visualization as a report?');

  return suggestions.slice(0, 3);
}

export function DynamicChartMessage({
  query,
  data,
  suggestedFormat,
  onFormatChange,
  onDrilldown,
  onFollowUp,
}: DynamicChartMessageProps) {
  const [activeFormat, setActiveFormat] = useState<OutputFormat>(suggestedFormat);
  const [isExpanded, setIsExpanded] = useState(false);

  const followUpSuggestions = getFollowUpSuggestions(query, activeFormat);

  const handleFormatChange = (format: OutputFormat) => {
    setActiveFormat(format);
    onFormatChange?.(format);
  };

  const renderChart = () => {
    const height = isExpanded ? 400 : 280;

    switch (activeFormat) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <defs>
                <linearGradient id="dynamicBarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" />
                  <stop offset="100%" stopColor="hsl(var(--chart-2))" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Bar
                dataKey="value"
                fill="url(#dynamicBarGradient)"
                radius={[6, 6, 0, 0]}
                cursor="pointer"
                onClick={(data) => onDrilldown?.(data)}
              />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'line':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <ComposedChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <defs>
                <linearGradient id="dynamicLineGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Area type="monotone" dataKey="value" fill="url(#dynamicLineGradient)" stroke="transparent" />
              <Line
                type="monotone"
                dataKey="value"
                stroke="hsl(var(--chart-1))"
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--chart-1))', r: 4 }}
                activeDot={{ r: 6, cursor: 'pointer', onClick: (e: any) => onDrilldown?.(e.payload) }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={isExpanded ? 80 : 50}
                outerRadius={isExpanded ? 130 : 90}
                paddingAngle={3}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={{ stroke: 'hsl(var(--muted-foreground))', strokeWidth: 1 }}
                cursor="pointer"
                onClick={(_, index) => onDrilldown?.(data[index])}
              >
                {data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'area':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <AreaChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <defs>
                <linearGradient id="dynamicAreaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Area
                type="monotone"
                dataKey="value"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                fill="url(#dynamicAreaGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        );

      default:
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="value" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <Card className="border-border/50 bg-gradient-to-br from-card/90 to-muted/30 backdrop-blur-sm shadow-lg overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <CardTitle className="text-sm font-semibold">AI-Generated Visualization</CardTitle>
            <Badge variant="secondary" className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              Interactive
            </Badge>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsExpanded(!isExpanded)}>
              <Maximize2 className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Chart Type Selector */}
        <Tabs value={activeFormat} onValueChange={(v) => handleFormatChange(v as OutputFormat)}>
          <TabsList className="grid w-full grid-cols-4 h-9">
            <TabsTrigger value="bar" className="gap-1.5 text-xs">
              <BarChart3 className="h-3.5 w-3.5" />
              Bar
            </TabsTrigger>
            <TabsTrigger value="line" className="gap-1.5 text-xs">
              <LineChartIcon className="h-3.5 w-3.5" />
              Line
            </TabsTrigger>
            <TabsTrigger value="pie" className="gap-1.5 text-xs">
              <PieChartIcon className="h-3.5 w-3.5" />
              Pie
            </TabsTrigger>
            <TabsTrigger value="area" className="gap-1.5 text-xs">
              <TrendingUp className="h-3.5 w-3.5" />
              Area
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Chart */}
        <div className={cn('rounded-xl bg-muted/30 p-3 transition-all', isExpanded && 'p-4')}>{renderChart()}</div>

        {/* Follow-up Suggestions */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
            <RefreshCw className="h-3 w-3" />
            Continue exploring:
          </p>
          <div className="flex flex-wrap gap-2">
            {followUpSuggestions.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="h-7 text-xs hover:bg-primary/10 hover:text-primary hover:border-primary/50"
                onClick={() => onFollowUp?.(suggestion)}
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
