import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart3,
  Table,
  PieChart,
  LineChart,
  AreaChart,
  History,
  Star,
  Clock,
  Trash2,
  Pin,
  MessageSquare,
  BookOpen,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { OutputFormat, SavedQuery, ConversationHistory } from './types';
import { cn } from '@/lib/utils';

interface RightSidebarProps {
  preferredFormat: OutputFormat;
  onFormatChange: (format: OutputFormat) => void;
  conversationHistory: ConversationHistory[];
  savedQueries: SavedQuery[];
  onSelectHistory: (query: string) => void;
  onSelectSaved: (query: string) => void;
  onDeleteHistory: (id: string) => void;
  onDeleteSaved: (id: string) => void;
  onTogglePin: (id: string) => void;
  onOpenTemplates: () => void;
}

const outputFormats: { value: OutputFormat; label: string; icon: React.ReactNode; description: string }[] = [
  { value: 'table', label: 'Table', icon: <Table className="h-4 w-4" />, description: 'Detailed data view' },
  { value: 'bar', label: 'Bar Chart', icon: <BarChart3 className="h-4 w-4" />, description: 'Compare values' },
  { value: 'pie', label: 'Pie Chart', icon: <PieChart className="h-4 w-4" />, description: 'Show proportions' },
  { value: 'line', label: 'Line Chart', icon: <LineChart className="h-4 w-4" />, description: 'Track trends' },
  { value: 'area', label: 'Area Chart', icon: <AreaChart className="h-4 w-4" />, description: 'Cumulative view' },
];

export function RightSidebar({
  preferredFormat,
  onFormatChange,
  conversationHistory,
  savedQueries,
  onSelectHistory,
  onSelectSaved,
  onDeleteHistory,
  onDeleteSaved,
  onTogglePin,
  onOpenTemplates,
}: RightSidebarProps) {
  const [activeTab, setActiveTab] = useState<'format' | 'history' | 'saved'>('format');

  const pinnedQueries = savedQueries.filter((q) => q.pinned);
  const unpinnedQueries = savedQueries.filter((q) => !q.pinned);

  return (
    <div className="w-80 border-l border-border/50 bg-muted/20 overflow-hidden flex flex-col">
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex flex-col h-full">
        <div className="px-4 pt-4 pb-2">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="format" className="text-xs gap-1">
              <BarChart3 className="h-3.5 w-3.5" />
              Format
            </TabsTrigger>
            <TabsTrigger value="history" className="text-xs gap-1">
              <History className="h-3.5 w-3.5" />
              History
            </TabsTrigger>
            <TabsTrigger value="saved" className="text-xs gap-1">
              <Star className="h-3.5 w-3.5" />
              Saved
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="flex-1 px-4 pb-4">
          {/* Format Tab */}
          <TabsContent value="format" className="mt-0 space-y-4">
            {/* Output Format Selection */}
            <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <BarChart3 className="h-4 w-4 text-primary" />
                  Output Format
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                <RadioGroup
                  value={preferredFormat}
                  onValueChange={(val) => onFormatChange(val as OutputFormat)}
                  className="space-y-1"
                >
                  {outputFormats.map((format) => (
                    <div
                      key={format.value}
                      onClick={() => onFormatChange(format.value)}
                      className={cn(
                        'flex items-center space-x-3 rounded-lg px-3 py-2.5 cursor-pointer transition-all',
                        preferredFormat === format.value
                          ? 'bg-primary/10 text-primary border border-primary/20'
                          : 'hover:bg-muted/50 text-muted-foreground hover:text-foreground border border-transparent',
                      )}
                    >
                      <RadioGroupItem value={format.value} id={format.value} />
                      <Label htmlFor={format.value} className="flex items-center gap-2 cursor-pointer flex-1">
                        {format.icon}
                        <div>
                          <span className="text-sm block">{format.label}</span>
                          <span className="text-[10px] text-muted-foreground">{format.description}</span>
                        </div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4 space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start gap-2" onClick={onOpenTemplates}>
                  <BookOpen className="h-4 w-4" />
                  Browse Templates
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Performance Summary
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="mt-0 space-y-4">
            <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <History className="h-4 w-4" />
                  Recent Conversations
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4 space-y-1">
                {conversationHistory.length === 0 ? (
                  <div className="text-center py-6 text-sm text-muted-foreground">
                    <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No conversation history yet</p>
                    <p className="text-xs">Start asking questions!</p>
                  </div>
                ) : (
                  conversationHistory.slice(0, 10).map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onSelectHistory(item.query)}
                      className="group flex items-center gap-2 rounded-lg p-2 cursor-pointer transition-all hover:bg-muted/50"
                    >
                      <MessageSquare className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm truncate">{item.query}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-muted-foreground">{item.time}</span>
                          <Badge variant="outline" className="text-[9px] h-4 px-1">
                            {item.format}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteHistory(item.id);
                          }}
                        >
                          <Trash2 className="h-3 w-3 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Saved Tab */}
          <TabsContent value="saved" className="mt-0 space-y-4">
            {/* Pinned Queries */}
            {pinnedQueries.length > 0 && (
              <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                    <Pin className="h-4 w-4 text-primary" />
                    Pinned
                  </CardTitle>
                </CardHeader>
                <CardContent className="pb-4 space-y-1">
                  {pinnedQueries.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onSelectSaved(item.query)}
                      className="group rounded-lg p-2 cursor-pointer transition-all hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-2">
                        <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500 shrink-0" />
                        <p className="text-sm truncate flex-1">{item.name || item.query}</p>
                      </div>
                      <div className="flex items-center justify-between mt-1 pl-5">
                        <div className="flex items-center gap-2">
                          {item.frequency !== 'none' && (
                            <Badge variant="outline" className="text-[9px] h-4 px-1 gap-0.5">
                              <Clock className="h-2.5 w-2.5" />
                              {item.frequency}
                            </Badge>
                          )}
                          <span className="text-[10px] text-muted-foreground">{item.lastRun}</span>
                        </div>
                        <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-5 w-5"
                            onClick={(e) => {
                              e.stopPropagation();
                              onTogglePin(item.id);
                            }}
                          >
                            <Pin className="h-2.5 w-2.5 text-primary" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-5 w-5"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteSaved(item.id);
                            }}
                          >
                            <Trash2 className="h-2.5 w-2.5 text-muted-foreground hover:text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* All Saved */}
            <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <Star className="h-4 w-4 text-amber-500" />
                  Saved Queries
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4 space-y-1">
                {savedQueries.length === 0 ? (
                  <div className="text-center py-6 text-sm text-muted-foreground">
                    <Star className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No saved queries yet</p>
                    <p className="text-xs">Save queries for quick access</p>
                  </div>
                ) : (
                  unpinnedQueries.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onSelectSaved(item.query)}
                      className="group rounded-lg p-2 cursor-pointer transition-all hover:bg-muted/50"
                    >
                      <p className="text-sm truncate">{item.name || item.query}</p>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex items-center gap-2">
                          {item.frequency !== 'none' && (
                            <Badge variant="outline" className="text-[9px] h-4 px-1 gap-0.5">
                              <Clock className="h-2.5 w-2.5" />
                              {item.frequency}
                            </Badge>
                          )}
                          <span className="text-[10px] text-muted-foreground">{item.lastRun}</span>
                        </div>
                        <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-5 w-5"
                            onClick={(e) => {
                              e.stopPropagation();
                              onTogglePin(item.id);
                            }}
                          >
                            <Pin className="h-2.5 w-2.5" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-5 w-5"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteSaved(item.id);
                            }}
                          >
                            <Trash2 className="h-2.5 w-2.5 text-muted-foreground hover:text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
