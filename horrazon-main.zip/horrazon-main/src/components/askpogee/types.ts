// Ask Pogee Type Definitions

export type OutputFormat =
  | 'table'
  | 'bar'
  | 'pie'
  | 'line'
  | 'area'
  | 'funnel'
  | 'heatmap'
  | 'map'
  | 'radar'
  | 'scatter';

export type AnalysisCategory = 'marketing' | 'customers' | 'revenue' | 'all';

export type DocumentType = 'invoice' | 'report' | 'spreadsheet' | 'other';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  format?: OutputFormat;
  analysis?: AnalysisResult;
  chartData?: ChartMessage;
  documentData?: DocumentMessage;
}

export interface ChartMessage {
  suggestedFormat: OutputFormat;
  data: DataPoint[];
  title?: string;
  followUpSuggestions: string[];
}

export interface DocumentMessage {
  fileName: string;
  extractedData: ExtractedDocumentData;
  mergedInsight?: string;
}

export interface ExtractedDocumentData {
  type: DocumentType;
  title: string;
  date?: string;
  vendor?: string;
  total?: number;
  currency?: string;
  lineItems?: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
  insights?: string[];
  metrics?: Array<{
    label: string;
    value: string;
    change?: number;
    trend?: 'up' | 'down' | 'flat';
  }>;
}

export interface AnalysisResult {
  text: string;
  data: DataPoint[];
  insights: Insight[];
  recommendations: Recommendation[];
  confidence: number;
  sources: string[];
  metrics: MetricSummary[];
  drilldownAvailable: boolean;
  suggestedFormat?: OutputFormat;
}

export interface DataPoint {
  name: string;
  value: number;
  change?: number;
  [key: string]: any;
}

export interface Insight {
  text: string;
  type: 'positive' | 'negative' | 'neutral' | 'action' | 'warning';
  impact?: 'high' | 'medium' | 'low';
  metric?: string;
}

export interface Recommendation {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  estimatedImpact: string;
  actionable: boolean;
}

export interface MetricSummary {
  label: string;
  value: string;
  change: number;
  trend: 'up' | 'down' | 'flat';
}

export interface SavedQuery {
  id: string;
  query: string;
  name?: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'none';
  lastRun: string;
  category: AnalysisCategory;
  pinned: boolean;
}

export interface ConversationHistory {
  id: string;
  query: string;
  time: string;
  response: string;
  format: OutputFormat;
}

export interface QuickInsight {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  color: string;
  bgColor: string;
  change?: number;
  trend?: 'up' | 'down' | 'flat';
}

export interface TemplateQuery {
  id: string;
  text: string;
  category: AnalysisCategory;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  popularity: number;
}
