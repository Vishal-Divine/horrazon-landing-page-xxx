import { useEffect, useState } from 'react';
import { Sparkles, ChevronRight, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getSmartSuggestions } from './mockData';

interface SmartSuggestionsProps {
  input: string;
  onSelect: (suggestion: string) => void;
  visible: boolean;
}

export function SmartSuggestions({ input, onSelect, visible }: SmartSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!input.trim() || input.length < 3) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    const timer = setTimeout(() => {
      setSuggestions(getSmartSuggestions(input));
      setIsLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [input]);

  if (!visible || (!isLoading && suggestions.length === 0)) return null;

  return (
    <div className="absolute bottom-full left-0 right-0 mb-2 z-10">
      <div className="rounded-xl border border-border/50 bg-card/95 backdrop-blur-sm shadow-xl overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-200">
        {/* Header */}
        <div className="flex items-center gap-2 px-4 py-2 bg-muted/50 border-b border-border/30">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-medium text-muted-foreground">Smart Suggestions</span>
          {isLoading && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground ml-auto" />}
        </div>

        {/* Suggestions */}
        <div className="p-2">
          {suggestions.map((suggestion, i) => (
            <button
              key={i}
              onClick={() => onSelect(suggestion)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left',
                'transition-colors hover:bg-muted/50 group',
              )}
            >
              <div className="flex-1 text-sm">{suggestion}</div>
              <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
