import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Lightbulb,
  TrendingUp,
  AlertTriangle,
  Zap,
  Target,
  ChevronRight,
  CheckCircle2,
  XCircle,
  ArrowRight,
} from 'lucide-react';
import { Insight, Recommendation, MetricSummary } from './types';
import { cn } from '@/lib/utils';

interface AIInsightsPanelProps {
  insights: Insight[];
  recommendations: Recommendation[];
  metrics: MetricSummary[];
  onActionClick?: (recommendation: Recommendation) => void;
}

export function AIInsightsPanel({ insights, recommendations, metrics, onActionClick }: AIInsightsPanelProps) {
  const insightIcons: Record<Insight['type'], React.ReactNode> = {
    positive: <TrendingUp className="h-4 w-4" />,
    negative: <XCircle className="h-4 w-4" />,
    neutral: <Target className="h-4 w-4" />,
    action: <Zap className="h-4 w-4" />,
    warning: <AlertTriangle className="h-4 w-4" />,
  };

  const insightStyles: Record<Insight['type'], string> = {
    positive: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20',
    negative: 'bg-destructive/10 text-destructive border-destructive/20',
    neutral: 'bg-muted text-muted-foreground border-border',
    action: 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20',
    warning: 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20',
  };

  const priorityColors: Record<Recommendation['priority'], string> = {
    high: 'bg-destructive/10 text-destructive border-destructive/30',
    medium: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
    low: 'bg-muted text-muted-foreground border-border',
  };

  return (
    <div className="space-y-4">
      {/* Key Metrics Summary */}
      <div className="grid grid-cols-2 gap-3">
        {metrics.map((metric, i) => (
          <div key={i} className="rounded-lg border border-border/50 bg-card/50 p-3 space-y-1">
            <p className="text-xs text-muted-foreground">{metric.label}</p>
            <div className="flex items-baseline justify-between">
              <span className="text-lg font-bold">{metric.value}</span>
              <span
                className={cn(
                  'flex items-center gap-0.5 text-xs font-medium',
                  metric.trend === 'up'
                    ? 'text-emerald-500'
                    : metric.trend === 'down'
                      ? 'text-destructive'
                      : 'text-muted-foreground',
                )}
              >
                {metric.trend === 'up' ? (
                  <TrendingUp className="h-3 w-3" />
                ) : metric.trend === 'down' ? (
                  <TrendingUp className="h-3 w-3 rotate-180" />
                ) : null}
                {metric.change > 0 ? '+' : ''}
                {metric.change}%
              </span>
            </div>
          </div>
        ))}
      </div>

      <Separator />

      {/* AI Insights */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4 text-amber-500" />
          <h4 className="text-sm font-semibold">Key Insights</h4>
        </div>

        <div className="space-y-2">
          {insights.map((insight, i) => (
            <div
              key={i}
              className={cn('flex items-start gap-2 rounded-lg border p-3 text-sm', insightStyles[insight.type])}
            >
              <div className="mt-0.5 shrink-0">{insightIcons[insight.type]}</div>
              <div className="flex-1 space-y-1">
                <p className="leading-relaxed">{insight.text}</p>
                {insight.impact && (
                  <Badge variant="outline" className="text-[10px] capitalize">
                    {insight.impact} impact
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Recommendations */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Target className="h-4 w-4 text-primary" />
          <h4 className="text-sm font-semibold">Recommendations</h4>
        </div>

        <div className="space-y-3">
          {recommendations.map((rec, i) => (
            <Card key={i} className="border-border/50 overflow-hidden">
              <CardContent className="p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h5 className="font-medium text-sm">{rec.title}</h5>
                      <Badge variant="outline" className={cn('text-[10px] capitalize', priorityColors[rec.priority])}>
                        {rec.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{rec.description}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
                    <TrendingUp className="h-3 w-3" />
                    <span>{rec.estimatedImpact}</span>
                  </div>

                  {rec.actionable && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs gap-1 hover:bg-primary/10 hover:text-primary"
                      onClick={() => onActionClick?.(rec)}
                    >
                      Take Action
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
