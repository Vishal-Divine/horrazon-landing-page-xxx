import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart as ReLineChart,
  Line,
} from 'recharts';
import { TrendingUp, TrendingDown, Calendar, Layers, ArrowLeft, Download } from 'lucide-react';
import { DataPoint } from './types';
import { cn } from '@/lib/utils';

interface DrilldownModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: DataPoint | null;
  onDeepDive?: (query: string) => void;
}

// Generate mock drilldown data
function generateDrilldownData(item: DataPoint | null) {
  if (!item) return { breakdown: [], timeline: [], segments: [] };

  return {
    breakdown: [
      { name: 'Mobile', value: Math.round(item.value * 0.45), percent: 45 },
      { name: 'Desktop', value: Math.round(item.value * 0.38), percent: 38 },
      { name: 'Tablet', value: Math.round(item.value * 0.17), percent: 17 },
    ],
    timeline: [
      { name: 'Mon', value: Math.round(item.value * 0.12) },
      { name: 'Tue', value: Math.round(item.value * 0.15) },
      { name: 'Wed', value: Math.round(item.value * 0.18) },
      { name: 'Thu', value: Math.round(item.value * 0.14) },
      { name: 'Fri', value: Math.round(item.value * 0.16) },
      { name: 'Sat', value: Math.round(item.value * 0.13) },
      { name: 'Sun', value: Math.round(item.value * 0.12) },
    ],
    segments: [
      { name: 'New Customers', value: Math.round(item.value * 0.35), change: 12 },
      { name: 'Returning', value: Math.round(item.value * 0.45), change: 8 },
      { name: 'VIP', value: Math.round(item.value * 0.2), change: 24 },
    ],
  };
}

export function DrilldownModal({ open, onOpenChange, item, onDeepDive }: DrilldownModalProps) {
  const [activeTab, setActiveTab] = useState('breakdown');
  const data = generateDrilldownData(item);

  if (!item) return null;

  const tooltipStyle = {
    backgroundColor: 'hsl(var(--popover))',
    border: '1px solid hsl(var(--border))',
    borderRadius: '12px',
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[85vh]">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpenChange(false)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex-1">
              <DialogTitle className="flex items-center gap-2">
                {item.name}
                {(item.change ?? 0) !== 0 && (
                  <Badge
                    variant="secondary"
                    className={cn(
                      'text-xs',
                      (item.change ?? 0) > 0
                        ? 'bg-emerald-500/10 text-emerald-600'
                        : 'bg-destructive/10 text-destructive',
                    )}
                  >
                    {(item.change ?? 0) > 0 ? (
                      <TrendingUp className="h-3 w-3 mr-1" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-1" />
                    )}
                    {(item.change ?? 0) > 0 ? '+' : ''}
                    {item.change}%
                  </Badge>
                )}
              </DialogTitle>
              <DialogDescription>Detailed breakdown and analysis</DialogDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="breakdown" className="gap-1.5">
                <Layers className="h-3.5 w-3.5" />
                Breakdown
              </TabsTrigger>
              <TabsTrigger value="timeline" className="gap-1.5">
                <Calendar className="h-3.5 w-3.5" />
                Timeline
              </TabsTrigger>
              <TabsTrigger value="segments" className="gap-1.5">
                <TrendingUp className="h-3.5 w-3.5" />
                Segments
              </TabsTrigger>
            </TabsList>

            <TabsContent value="breakdown" className="space-y-4">
              <div className="grid gap-3">
                {data.breakdown.map((row, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <div className="w-24 text-sm font-medium">{row.name}</div>
                    <div className="flex-1">
                      <div className="h-6 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-primary to-primary/60 rounded-full transition-all"
                          style={{ width: `${row.percent}%` }}
                        />
                      </div>
                    </div>
                    <div className="w-20 text-right">
                      <span className="text-sm font-semibold">{row.value.toLocaleString()}</span>
                      <span className="text-xs text-muted-foreground ml-1">({row.percent}%)</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="rounded-xl bg-muted/30 p-4">
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={data.breakdown}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Bar dataKey="value" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            <TabsContent value="timeline" className="space-y-4">
              <div className="rounded-xl bg-muted/30 p-4">
                <ResponsiveContainer width="100%" height={220}>
                  <ReLineChart data={data.timeline}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2.5}
                      dot={{ fill: 'hsl(var(--chart-1))', r: 4 }}
                    />
                  </ReLineChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {['Peak Day', 'Lowest Day', 'Avg Daily'].map((label, i) => (
                  <div key={i} className="rounded-lg border border-border/50 p-3 text-center">
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className="text-lg font-bold mt-0.5">
                      {i === 0 ? 'Wed' : i === 1 ? 'Sun' : Math.round(item.value / 7).toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="segments" className="space-y-4">
              <div className="grid gap-3">
                {data.segments.map((segment, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded-lg border border-border/50 p-4 hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => onDeepDive?.(`Show me ${segment.name} details for ${item.name}`)}
                  >
                    <div>
                      <p className="font-medium">{segment.name}</p>
                      <p className="text-sm text-muted-foreground">{segment.value.toLocaleString()} total</p>
                    </div>
                    <Badge
                      variant="secondary"
                      className={cn(
                        'text-xs',
                        segment.change > 0
                          ? 'bg-emerald-500/10 text-emerald-600'
                          : 'bg-destructive/10 text-destructive',
                      )}
                    >
                      {segment.change > 0 ? '+' : ''}
                      {segment.change}%
                    </Badge>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </ScrollArea>

        {/* Deep dive suggestions */}
        <div className="pt-4 border-t border-border/50">
          <p className="text-xs text-muted-foreground mb-2">Ask deeper questions:</p>
          <div className="flex flex-wrap gap-2">
            {[
              `What's driving ${item.name} performance?`,
              `Compare ${item.name} week over week`,
              `Show conversion funnel for ${item.name}`,
            ].map((q, i) => (
              <Button
                key={i}
                variant="outline"
                size="sm"
                className="text-xs h-7"
                onClick={() => {
                  onDeepDive?.(q);
                  onOpenChange(false);
                }}
              >
                {q}
              </Button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
