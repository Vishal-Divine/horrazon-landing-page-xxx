import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  FileText,
  Upload,
  X,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  FileSpreadsheet,
  Receipt,
  FileBarChart,
  Loader2,
  Eye,
  Trash2,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ExtractedData {
  type: 'invoice' | 'report' | 'spreadsheet' | 'other';
  title: string;
  date?: string;
  vendor?: string;
  total?: number;
  currency?: string;
  lineItems?: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
  insights?: string[];
  metrics?: Array<{
    label: string;
    value: string;
    change?: number;
    trend?: 'up' | 'down' | 'flat';
  }>;
}

interface UploadedDocument {
  id: string;
  name: string;
  size: number;
  type: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  extractedData?: ExtractedData;
  error?: string;
}

interface DocumentIntelligenceProps {
  onDataExtracted?: (data: ExtractedData) => void;
  onInsightGenerated?: (insight: string) => void;
}

// Mock extraction based on file type
function mockExtractData(fileName: string): ExtractedData {
  const isInvoice = fileName.toLowerCase().includes('invoice') || fileName.toLowerCase().includes('receipt');
  const isReport = fileName.toLowerCase().includes('report') || fileName.toLowerCase().includes('summary');

  if (isInvoice) {
    return {
      type: 'invoice',
      title: `Invoice - ${fileName}`,
      date: new Date().toLocaleDateString(),
      vendor: 'Acme Supplies Inc.',
      total: 2847.5,
      currency: 'USD',
      lineItems: [
        { description: 'Premium Widget Package', quantity: 50, unitPrice: 45.99, total: 2299.5 },
        { description: 'Shipping & Handling', quantity: 1, unitPrice: 89.0, total: 89.0 },
        { description: 'Insurance', quantity: 1, unitPrice: 125.0, total: 125.0 },
        { description: 'Express Processing', quantity: 1, unitPrice: 334.0, total: 334.0 },
      ],
      insights: [
        'Shipping costs rose 10% compared to last invoice from this vendor',
        'This purchase increased your Q4 supply expenses by 15%',
        'Consider bulk ordering to reduce per-unit costs by ~8%',
      ],
    };
  }

  if (isReport) {
    return {
      type: 'report',
      title: `Analysis - ${fileName}`,
      date: new Date().toLocaleDateString(),
      metrics: [
        { label: 'Total Revenue', value: '$124,500', change: 12.5, trend: 'up' },
        { label: 'Ad Spend', value: '$23,400', change: 8.2, trend: 'up' },
        { label: 'ROAS', value: '5.3x', change: 4.1, trend: 'up' },
        { label: 'Net Profit', value: '$78,200', change: -2.3, trend: 'down' },
      ],
      insights: [
        'Revenue is up but net profit margin decreased due to rising ad costs',
        'ROAS improvement suggests better campaign efficiency',
        'Recommend reviewing cost structure to improve net margins',
      ],
    };
  }

  return {
    type: 'spreadsheet',
    title: `Data - ${fileName}`,
    date: new Date().toLocaleDateString(),
    metrics: [
      { label: 'Total Records', value: '1,247', trend: 'flat' },
      { label: 'Valid Entries', value: '1,198', change: 96, trend: 'up' },
      { label: 'Categories', value: '8', trend: 'flat' },
    ],
    insights: [
      '4% of records have missing or invalid data',
      'Top category accounts for 45% of all entries',
      'Data covers period from Jan 2024 to Dec 2024',
    ],
  };
}

export function DocumentIntelligence({ onDataExtracted, onInsightGenerated }: DocumentIntelligenceProps) {
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  };

  const handleFiles = (files: File[]) => {
    const validTypes = [
      'application/pdf',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
      'image/png',
      'image/jpeg',
    ];

    files.forEach((file) => {
      // Check file type (allow PDFs and images for invoices)
      const isValid = validTypes.some((type) => file.type.includes(type.split('/')[1])) || file.name.endsWith('.pdf');

      if (!isValid) {
        toast.error(`Unsupported file type: ${file.name}`);
        return;
      }

      const newDoc: UploadedDocument = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        size: file.size,
        type: file.type,
        status: 'uploading',
        progress: 0,
      };

      setDocuments((prev) => [...prev, newDoc]);
      simulateProcessing(newDoc.id, file.name);
    });
  };

  const simulateProcessing = (docId: string, fileName: string) => {
    // Simulate upload progress
    let progress = 0;
    const uploadInterval = setInterval(() => {
      progress += Math.random() * 30;
      if (progress >= 100) {
        progress = 100;
        clearInterval(uploadInterval);

        setDocuments((prev) => prev.map((d) => (d.id === docId ? { ...d, status: 'processing', progress: 100 } : d)));

        // Simulate AI processing
        setTimeout(() => {
          const extractedData = mockExtractData(fileName);

          setDocuments((prev) => prev.map((d) => (d.id === docId ? { ...d, status: 'completed', extractedData } : d)));

          onDataExtracted?.(extractedData);

          if (extractedData.insights?.[0]) {
            onInsightGenerated?.(extractedData.insights[0]);
          }

          toast.success(`Extracted data from ${fileName}`, {
            description: `Found ${extractedData.lineItems?.length || extractedData.metrics?.length || 0} items/metrics`,
          });
        }, 1500);
      }

      setDocuments((prev) => prev.map((d) => (d.id === docId ? { ...d, progress } : d)));
    }, 200);
  };

  const removeDocument = (docId: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (type: string, fileName: string) => {
    if (fileName.toLowerCase().includes('invoice') || fileName.toLowerCase().includes('receipt')) {
      return Receipt;
    }
    if (type.includes('pdf')) return FileText;
    if (type.includes('excel') || type.includes('spreadsheet') || type.includes('csv')) return FileSpreadsheet;
    if (fileName.toLowerCase().includes('report')) return FileBarChart;
    return FileText;
  };

  return (
    <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500">
              <FileText className="h-4 w-4 text-white" />
            </div>
            <div>
              <CardTitle className="text-sm font-semibold">Document Intelligence</CardTitle>
              <p className="text-xs text-muted-foreground">Upload PDFs, invoices, or reports for AI analysis</p>
            </div>
          </div>
          <Badge variant="secondary" className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400">
            <Sparkles className="h-3 w-3 mr-1" />
            AI-Powered
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={cn(
            'relative flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-6 transition-all cursor-pointer',
            isDragOver ? 'border-primary bg-primary/5' : 'border-border/50 hover:border-primary/50 hover:bg-muted/30',
          )}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.xlsx,.xls,.csv,.png,.jpg,.jpeg"
            onChange={handleFileSelect}
            className="hidden"
          />
          <div
            className={cn(
              'flex h-12 w-12 items-center justify-center rounded-xl transition-colors',
              isDragOver ? 'bg-primary/10' : 'bg-muted',
            )}
          >
            <Upload className={cn('h-6 w-6', isDragOver ? 'text-primary' : 'text-muted-foreground')} />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium">
              {isDragOver ? 'Drop files here' : 'Drag & drop files or click to browse'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              PDF, Excel, CSV, or images (invoices, reports, data files)
            </p>
          </div>
        </div>

        {/* Uploaded Documents */}
        {documents.length > 0 && (
          <ScrollArea className="max-h-[400px]">
            <div className="space-y-3">
              {documents.map((doc) => {
                const FileIcon = getFileIcon(doc.type, doc.name);

                return (
                  <div key={doc.id} className="rounded-xl border border-border/50 bg-muted/30 overflow-hidden">
                    {/* File Header */}
                    <div className="flex items-center gap-3 p-3">
                      <div
                        className={cn(
                          'flex h-10 w-10 items-center justify-center rounded-lg shrink-0',
                          doc.status === 'completed' ? 'bg-emerald-500/10' : 'bg-muted',
                        )}
                      >
                        <FileIcon
                          className={cn(
                            'h-5 w-5',
                            doc.status === 'completed' ? 'text-emerald-500' : 'text-muted-foreground',
                          )}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{doc.name}</p>
                        <p className="text-xs text-muted-foreground">{formatFileSize(doc.size)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {doc.status === 'uploading' && (
                          <Badge variant="secondary" className="text-[10px]">
                            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            Uploading {Math.round(doc.progress)}%
                          </Badge>
                        )}
                        {doc.status === 'processing' && (
                          <Badge
                            variant="secondary"
                            className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400"
                          >
                            <Sparkles className="h-3 w-3 mr-1 animate-pulse" />
                            AI Processing
                          </Badge>
                        )}
                        {doc.status === 'completed' && (
                          <Badge
                            variant="secondary"
                            className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                          >
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Extracted
                          </Badge>
                        )}
                        {doc.status === 'error' && (
                          <Badge variant="destructive" className="text-[10px]">
                            <AlertTriangle className="h-3 w-3 mr-1" />
                            Error
                          </Badge>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-destructive"
                          onClick={() => removeDocument(doc.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    {(doc.status === 'uploading' || doc.status === 'processing') && (
                      <Progress value={doc.status === 'processing' ? 100 : doc.progress} className="h-1 rounded-none" />
                    )}

                    {/* Extracted Data */}
                    {doc.status === 'completed' && doc.extractedData && (
                      <div className="border-t border-border/50 p-3 space-y-3">
                        {/* Invoice Line Items */}
                        {doc.extractedData.lineItems && (
                          <>
                            <div className="flex items-center justify-between">
                              <p className="text-xs font-medium text-muted-foreground">Extracted Line Items</p>
                              <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                                {doc.extractedData.currency || '$'}
                                {doc.extractedData.total?.toLocaleString()}
                              </p>
                            </div>
                            <div className="space-y-1.5">
                              {doc.extractedData.lineItems.slice(0, 3).map((item, idx) => (
                                <div key={idx} className="flex items-center justify-between text-xs">
                                  <span className="text-muted-foreground truncate flex-1">{item.description}</span>
                                  <span className="font-medium ml-2">${item.total.toLocaleString()}</span>
                                </div>
                              ))}
                              {doc.extractedData.lineItems.length > 3 && (
                                <p className="text-xs text-primary cursor-pointer hover:underline">
                                  +{doc.extractedData.lineItems.length - 3} more items
                                </p>
                              )}
                            </div>
                          </>
                        )}

                        {/* Report Metrics */}
                        {doc.extractedData.metrics && (
                          <>
                            <p className="text-xs font-medium text-muted-foreground">Extracted Metrics</p>
                            <div className="grid grid-cols-2 gap-2">
                              {doc.extractedData.metrics.map((metric, idx) => (
                                <div key={idx} className="rounded-lg bg-background/50 p-2">
                                  <p className="text-[10px] text-muted-foreground">{metric.label}</p>
                                  <div className="flex items-center gap-1">
                                    <p className="text-sm font-semibold">{metric.value}</p>
                                    {metric.change !== undefined && (
                                      <span
                                        className={cn(
                                          'text-[10px] flex items-center',
                                          metric.trend === 'up'
                                            ? 'text-emerald-500'
                                            : metric.trend === 'down'
                                              ? 'text-destructive'
                                              : 'text-muted-foreground',
                                        )}
                                      >
                                        {metric.trend === 'up' ? (
                                          <TrendingUp className="h-3 w-3" />
                                        ) : metric.trend === 'down' ? (
                                          <TrendingDown className="h-3 w-3" />
                                        ) : null}
                                        {metric.change > 0 ? '+' : ''}
                                        {metric.change}%
                                      </span>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </>
                        )}

                        {/* AI Insights */}
                        {doc.extractedData.insights && doc.extractedData.insights.length > 0 && (
                          <>
                            <Separator />
                            <div className="space-y-2">
                              <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                                <Sparkles className="h-3 w-3" />
                                AI Insights
                              </p>
                              {doc.extractedData.insights.map((insight, idx) => (
                                <div
                                  key={idx}
                                  className="flex items-start gap-2 rounded-lg bg-amber-500/10 p-2 text-xs text-amber-700 dark:text-amber-400"
                                >
                                  <ArrowRight className="h-3 w-3 mt-0.5 shrink-0" />
                                  <span>{insight}</span>
                                </div>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}

        {/* Empty State Suggestions */}
        {documents.length === 0 && (
          <div className="grid grid-cols-3 gap-2">
            {[
              { icon: Receipt, label: 'Invoices', desc: 'Track expenses' },
              { icon: FileBarChart, label: 'Reports', desc: 'Import data' },
              { icon: FileSpreadsheet, label: 'Spreadsheets', desc: 'Analyze CSV' },
            ].map((item, idx) => (
              <div key={idx} className="flex flex-col items-center gap-1.5 rounded-lg bg-muted/30 p-3 text-center">
                <item.icon className="h-5 w-5 text-muted-foreground" />
                <p className="text-xs font-medium">{item.label}</p>
                <p className="text-[10px] text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
