import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart as ReLineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  AreaChart as ReAreaChart,
  Area,
  FunnelChart,
  Funnel,
  LabelList,
  Legend,
} from 'recharts';
import { Table, TrendingUp, TrendingDown, Minus, MoreHorizontal, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { OutputFormat, DataPoint } from './types';
import { cn } from '@/lib/utils';

interface ResultVisualizationProps {
  format: OutputFormat;
  data: DataPoint[];
  title?: string;
  onDrilldown?: (item: DataPoint) => void;
}

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

const tooltipStyle = {
  backgroundColor: 'hsl(var(--popover))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '12px',
  boxShadow: '0 10px 40px -10px rgba(0,0,0,0.3)',
};

export function ResultVisualization({ format, data, title, onDrilldown }: ResultVisualizationProps) {
  const renderChart = () => {
    switch (format) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                angle={-15}
                textAnchor="end"
                height={60}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Bar
                dataKey="value"
                fill="url(#barGradient)"
                radius={[6, 6, 0, 0]}
                cursor="pointer"
                onClick={(data) => onDrilldown?.(data)}
              />
              <defs>
                <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" />
                  <stop offset="100%" stopColor="hsl(var(--chart-2))" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={280}>
            <RePieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={3}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={{ stroke: 'hsl(var(--muted-foreground))', strokeWidth: 1 }}
                cursor="pointer"
                onClick={(_, index) => onDrilldown?.(data[index])}
              >
                {data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
            </RePieChart>
          </ResponsiveContainer>
        );

      case 'line':
        return (
          <ResponsiveContainer width="100%" height={280}>
            <ReLineChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Line
                type="monotone"
                dataKey="value"
                stroke="hsl(var(--chart-1))"
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--chart-1))', strokeWidth: 2, r: 5 }}
                activeDot={{
                  r: 7,
                  fill: 'hsl(var(--chart-2))',
                  cursor: 'pointer',
                  onClick: (e: any) => onDrilldown?.(e.payload),
                }}
              />
            </ReLineChart>
          </ResponsiveContainer>
        );

      case 'area':
        return (
          <ResponsiveContainer width="100%" height={280}>
            <ReAreaChart data={data} margin={{ top: 10, right: 10, bottom: 20, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis
                dataKey="name"
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <defs>
                <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="value"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                fill="url(#areaGradient)"
              />
            </ReAreaChart>
          </ResponsiveContainer>
        );

      case 'funnel':
        return (
          <ResponsiveContainer width="100%" height={280}>
            <FunnelChart>
              <Tooltip contentStyle={tooltipStyle} />
              <Funnel dataKey="value" data={data} isAnimationActive>
                <LabelList position="right" fill="hsl(var(--foreground))" stroke="none" dataKey="name" />
                {data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Funnel>
            </FunnelChart>
          </ResponsiveContainer>
        );

      default: // table
        return (
          <div className="overflow-hidden rounded-xl border border-border/50">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50 bg-muted/30">
                  <th className="p-3 text-left font-semibold text-muted-foreground">Name</th>
                  <th className="p-3 text-right font-semibold text-muted-foreground">Value</th>
                  {data[0]?.rate && <th className="p-3 text-right font-semibold text-muted-foreground">Rate</th>}
                  {data[0]?.roas && <th className="p-3 text-right font-semibold text-muted-foreground">ROAS</th>}
                  <th className="p-3 text-right font-semibold text-muted-foreground">Change</th>
                  <th className="p-3 w-10"></th>
                </tr>
              </thead>
              <tbody>
                {data.map((row, j) => {
                  const TrendIcon = (row.change ?? 0) > 0 ? TrendingUp : (row.change ?? 0) < 0 ? TrendingDown : Minus;
                  const trendColor =
                    (row.change ?? 0) > 0
                      ? 'text-emerald-500'
                      : (row.change ?? 0) < 0
                        ? 'text-destructive'
                        : 'text-muted-foreground';

                  return (
                    <tr
                      key={j}
                      className="border-b border-border/30 transition-colors hover:bg-muted/20 cursor-pointer"
                      onClick={() => onDrilldown?.(row)}
                    >
                      <td className="p-3 font-medium">{row.name}</td>
                      <td className="p-3 text-right tabular-nums">
                        {typeof row.value === 'number' ? row.value.toLocaleString() : row.value}
                      </td>
                      {row.rate && <td className="p-3 text-right tabular-nums">{row.rate}</td>}
                      {row.roas && (
                        <td className="p-3 text-right">
                          <Badge
                            variant="secondary"
                            className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold"
                          >
                            {row.roas}
                          </Badge>
                        </td>
                      )}
                      <td className="p-3 text-right">
                        <div className={cn('flex items-center justify-end gap-1', trendColor)}>
                          <TrendIcon className="h-3.5 w-3.5" />
                          <span className="text-xs font-medium">
                            {row.change !== undefined ? `${row.change > 0 ? '+' : ''}${row.change}%` : '-'}
                          </span>
                        </div>
                      </td>
                      <td className="p-3">
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        );
    }
  };

  return (
    <div className="rounded-xl bg-muted/30 p-4">
      {title && (
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-semibold">{title}</h4>
        </div>
      )}
      {renderChart()}
    </div>
  );
}
