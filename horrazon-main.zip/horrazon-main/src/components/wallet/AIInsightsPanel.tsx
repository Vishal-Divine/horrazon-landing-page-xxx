import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Sparkles,
  TrendingUp,
  TrendingDown,
  Target,
  Lightbulb,
  Zap,
  BarChart3,
  PieChart,
  ArrowRight,
  CheckCircle2,
  Clock,
  DollarSign,
  Bot,
  Brain,
  Rocket,
  Shield,
  AlertTriangle,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

interface Insight {
  id: string;
  category: 'optimization' | 'savings' | 'growth' | 'risk';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  potentialValue: number;
  confidence: number;
  actionable: boolean;
  status: 'new' | 'reviewing' | 'applied' | 'dismissed';
}

interface Recommendation {
  id: string;
  type: 'budget' | 'targeting' | 'creative' | 'timing';
  title: string;
  current: string;
  suggested: string;
  expectedImprovement: string;
  priority: number;
}

export default function AIInsightsPanel() {
  const { wallet, campaignSpends } = useApp();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const insights = useMemo<Insight[]>(
    () => [
      {
        id: '1',
        category: 'optimization',
        title: 'Reallocate Meta Ads Budget',
        description: 'Shift 20% of Meta budget to high-performing Reels ads for better engagement rates.',
        impact: 'high',
        potentialValue: 1250,
        confidence: 92,
        actionable: true,
        status: 'new',
      },
      {
        id: '2',
        category: 'savings',
        title: 'Eliminate Wasted Ad Spend',
        description: '5 ad sets are spending without conversions. Pausing them saves $340/week.',
        impact: 'high',
        potentialValue: 1360,
        confidence: 88,
        actionable: true,
        status: 'new',
      },
      {
        id: '3',
        category: 'growth',
        title: 'Expand to TikTok Audience',
        description: 'Your target demographic has 40% lower CPM on TikTok. Consider testing.',
        impact: 'medium',
        potentialValue: 800,
        confidence: 76,
        actionable: true,
        status: 'reviewing',
      },
      {
        id: '4',
        category: 'risk',
        title: 'Q4 Campaign Budget Pacing',
        description: 'Current pace will exhaust budget 8 days early. Recommend daily cap reduction.',
        impact: 'high',
        potentialValue: 2000,
        confidence: 94,
        actionable: true,
        status: 'new',
      },
      {
        id: '5',
        category: 'optimization',
        title: 'Dayparting Opportunity',
        description: 'Disable ads between 2-6 AM to save 8% budget with minimal reach impact.',
        impact: 'medium',
        potentialValue: 520,
        confidence: 85,
        actionable: true,
        status: 'applied',
      },
    ],
    [],
  );

  const recommendations = useMemo<Recommendation[]>(
    () => [
      {
        id: '1',
        type: 'budget',
        title: 'Daily Budget Optimization',
        current: '$500/day on Meta',
        suggested: '$425/day with dayparting',
        expectedImprovement: '+15% ROAS',
        priority: 1,
      },
      {
        id: '2',
        type: 'targeting',
        title: 'Audience Expansion',
        current: '25-44 age group',
        suggested: 'Include 18-24 on TikTok',
        expectedImprovement: '+22% reach, -30% CPM',
        priority: 2,
      },
      {
        id: '3',
        type: 'creative',
        title: 'Video Creative Mix',
        current: '80% static images',
        suggested: '50% video content',
        expectedImprovement: '+45% engagement',
        priority: 3,
      },
      {
        id: '4',
        type: 'timing',
        title: 'Campaign Scheduling',
        current: '24/7 delivery',
        suggested: 'Peak hours only (8AM-11PM)',
        expectedImprovement: '+8% efficiency',
        priority: 4,
      },
    ],
    [],
  );

  const getImpactBadge = (impact: string) => {
    switch (impact) {
      case 'high':
        return <Badge className="bg-emerald-500 text-white">High Impact</Badge>;
      case 'medium':
        return <Badge className="bg-amber-500 text-white">Medium Impact</Badge>;
      default:
        return <Badge variant="secondary">Low Impact</Badge>;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'optimization':
        return <Target className="h-4 w-4" />;
      case 'savings':
        return <DollarSign className="h-4 w-4" />;
      case 'growth':
        return <Rocket className="h-4 w-4" />;
      case 'risk':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Lightbulb className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'optimization':
        return 'text-primary bg-primary/10';
      case 'savings':
        return 'text-emerald-500 bg-emerald-500/10';
      case 'growth':
        return 'text-blue-500 bg-blue-500/10';
      case 'risk':
        return 'text-amber-500 bg-amber-500/10';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return (
          <Badge variant="secondary" className="bg-blue-500/10 text-blue-500 border-blue-500/30">
            New
          </Badge>
        );
      case 'reviewing':
        return (
          <Badge variant="secondary" className="bg-amber-500/10 text-amber-500 border-amber-500/30">
            Reviewing
          </Badge>
        );
      case 'applied':
        return (
          <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30">
            Applied
          </Badge>
        );
      default:
        return <Badge variant="secondary">Dismissed</Badge>;
    }
  };

  const totalPotentialSavings = insights
    .filter((i) => i.status !== 'applied')
    .reduce((sum, i) => sum + i.potentialValue, 0);
  const appliedSavings = insights.filter((i) => i.status === 'applied').reduce((sum, i) => sum + i.potentialValue, 0);
  const averageConfidence = Math.round(insights.reduce((sum, i) => sum + i.confidence, 0) / insights.length);

  return (
    <div className="space-y-6">
      {/* AI Summary Header */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-background to-background">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                  <Brain className="h-7 w-7 text-primary-foreground" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-background flex items-center justify-center">
                  <Zap className="h-3 w-3 text-white" />
                </div>
              </div>
              <div>
                <h2 className="text-xl font-bold flex items-center gap-2">
                  AI-Powered Insights
                  <Badge variant="secondary" className="bg-primary/20 text-primary">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Live Analysis
                  </Badge>
                </h2>
                <p className="text-muted-foreground">
                  Real-time recommendations based on your spending patterns and campaign performance
                </p>
              </div>
            </div>
            <Button className="gap-2">
              <Bot className="h-4 w-4" />
              Ask AI Advisor
            </Button>
          </div>

          <div className="grid grid-cols-4 gap-6 mt-6">
            <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
              <div className="text-2xl font-bold text-emerald-500">{formatCurrency(totalPotentialSavings)}</div>
              <p className="text-sm text-muted-foreground">Potential Monthly Savings</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
              <div className="text-2xl font-bold text-primary">{insights.filter((i) => i.status === 'new').length}</div>
              <p className="text-sm text-muted-foreground">New Insights</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
              <div className="text-2xl font-bold">{averageConfidence}%</div>
              <p className="text-sm text-muted-foreground">Avg. Confidence Score</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
              <div className="text-2xl font-bold text-emerald-500">{formatCurrency(appliedSavings)}</div>
              <p className="text-sm text-muted-foreground">Applied Savings</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="insights" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="insights" className="gap-2">
            <Lightbulb className="h-4 w-4" />
            AI Insights
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="gap-2">
            <Target className="h-4 w-4" />
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="actions" className="gap-2">
            <Zap className="h-4 w-4" />
            Quick Actions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4">
            {insights.map((insight) => (
              <Card key={insight.id} className="hover:shadow-md transition-all">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={cn('p-3 rounded-xl', getCategoryColor(insight.category))}>
                      {getCategoryIcon(insight.category)}
                    </div>

                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold flex items-center gap-2">
                            {insight.title}
                            {getStatusBadge(insight.status)}
                          </h4>
                          <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                        </div>
                        {getImpactBadge(insight.impact)}
                      </div>

                      <div className="flex items-center gap-6 pt-2">
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-emerald-500" />
                          <span className="text-sm">
                            <strong className="text-emerald-500">{formatCurrency(insight.potentialValue)}</strong>
                            <span className="text-muted-foreground"> potential value</span>
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full bg-primary rounded-full"
                              style={{ width: `${insight.confidence}%` }}
                            />
                          </div>
                          <span className="text-sm text-muted-foreground">{insight.confidence}% confidence</span>
                        </div>
                      </div>

                      {insight.actionable && insight.status !== 'applied' && (
                        <div className="flex items-center gap-2 pt-2">
                          <Button size="sm" className="h-8">
                            Apply Insight
                          </Button>
                          <Button size="sm" variant="outline" className="h-8">
                            Learn More
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            {recommendations.map((rec) => (
              <Card key={rec.id} className="hover:shadow-md transition-all">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {rec.priority}
                    </div>
                    <div className="flex-1 space-y-3">
                      <div>
                        <Badge variant="outline" className="mb-2 capitalize">
                          {rec.type}
                        </Badge>
                        <h4 className="font-semibold">{rec.title}</h4>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="p-2 rounded-lg bg-muted/50">
                          <p className="text-xs text-muted-foreground mb-1">Current</p>
                          <p className="font-medium">{rec.current}</p>
                        </div>
                        <div className="p-2 rounded-lg bg-primary/5 border border-primary/20">
                          <p className="text-xs text-primary mb-1">Suggested</p>
                          <p className="font-medium text-primary">{rec.suggested}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2 text-emerald-500">
                          <TrendingUp className="h-4 w-4" />
                          <span className="text-sm font-medium">{rec.expectedImprovement}</span>
                        </div>
                        <Button size="sm" variant="outline" className="h-8">
                          Apply <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="actions" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="hover:shadow-md transition-all cursor-pointer hover:border-primary/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-6 w-6 text-emerald-500" />
                </div>
                <h4 className="font-semibold mb-2">Apply All Savings</h4>
                <p className="text-sm text-muted-foreground mb-4">Implement all recommended cost optimizations</p>
                <Button className="w-full">Save {formatCurrency(totalPotentialSavings)}/mo</Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-all cursor-pointer hover:border-primary/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <h4 className="font-semibold mb-2">Optimize Targeting</h4>
                <p className="text-sm text-muted-foreground mb-4">AI-recommended audience adjustments</p>
                <Button variant="outline" className="w-full">
                  Review Changes
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-all cursor-pointer hover:border-primary/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-blue-500" />
                </div>
                <h4 className="font-semibold mb-2">Enable Autopilot</h4>
                <p className="text-sm text-muted-foreground mb-4">Let AI manage budget optimization</p>
                <Button variant="outline" className="w-full">
                  Configure
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
