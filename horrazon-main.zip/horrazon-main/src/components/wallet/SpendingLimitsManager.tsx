import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  ShieldCheck,
  Plus,
  Edit2,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Zap,
  Target,
  Ban,
  DollarSign,
  Calendar,
  Bell,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface SpendingLimit {
  id: string;
  name: string;
  category: string;
  limitAmount: number;
  currentSpend: number;
  period: 'daily' | 'weekly' | 'monthly';
  isActive: boolean;
  alertThreshold: number;
  action: 'warn' | 'block';
  icon: string;
}

const mockLimits: SpendingLimit[] = [
  {
    id: '1',
    name: 'Meta Ads Budget',
    category: 'Meta',
    limitAmount: 5000,
    currentSpend: 4520,
    period: 'monthly',
    isActive: true,
    alertThreshold: 80,
    action: 'warn',
    icon: '📘',
  },
  {
    id: '2',
    name: 'Google Ads Daily Cap',
    category: 'Google',
    limitAmount: 500,
    currentSpend: 342,
    period: 'daily',
    isActive: true,
    alertThreshold: 90,
    action: 'block',
    icon: '🎯',
  },
  {
    id: '3',
    name: 'TikTok Weekly Limit',
    category: 'TikTok',
    limitAmount: 2000,
    currentSpend: 1250,
    period: 'weekly',
    isActive: true,
    alertThreshold: 75,
    action: 'warn',
    icon: '🎵',
  },
  {
    id: '4',
    name: 'LinkedIn Monthly Budget',
    category: 'LinkedIn',
    limitAmount: 3000,
    currentSpend: 1890,
    period: 'monthly',
    isActive: false,
    alertThreshold: 85,
    action: 'warn',
    icon: '💼',
  },
];

export default function SpendingLimitsManager() {
  const [limits, setLimits] = useState<SpendingLimit[]>(mockLimits);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newLimit, setNewLimit] = useState<{
    name: string;
    category: string;
    limitAmount: number;
    period: 'daily' | 'weekly' | 'monthly';
    alertThreshold: number;
    action: 'warn' | 'block';
  }>({
    name: '',
    category: '',
    limitAmount: 1000,
    period: 'monthly',
    alertThreshold: 80,
    action: 'warn',
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getUsagePercent = (limit: SpendingLimit) => {
    return Math.round((limit.currentSpend / limit.limitAmount) * 100);
  };

  const getStatusColor = (limit: SpendingLimit) => {
    const percent = getUsagePercent(limit);
    if (percent >= 100) return 'text-destructive';
    if (percent >= limit.alertThreshold) return 'text-amber-500';
    return 'text-emerald-500';
  };

  const getProgressColor = (limit: SpendingLimit) => {
    const percent = getUsagePercent(limit);
    if (percent >= 100) return 'bg-destructive';
    if (percent >= limit.alertThreshold) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const toggleLimit = (id: string) => {
    setLimits((prev) => prev.map((l) => (l.id === id ? { ...l, isActive: !l.isActive } : l)));
    toast({
      title: 'Limit Updated',
      description: 'Spending limit status has been changed',
    });
  };

  const deleteLimit = (id: string) => {
    setLimits((prev) => prev.filter((l) => l.id !== id));
    toast({
      title: 'Limit Removed',
      description: 'Spending limit has been deleted',
    });
  };

  const handleAddLimit = () => {
    const newId = (limits.length + 1).toString();
    setLimits((prev) => [
      ...prev,
      {
        id: newId,
        name: newLimit.name,
        category: newLimit.category,
        limitAmount: newLimit.limitAmount,
        currentSpend: 0,
        period: newLimit.period,
        isActive: true,
        alertThreshold: newLimit.alertThreshold,
        action: newLimit.action,
        icon: '📊',
      },
    ]);
    setIsAddDialogOpen(false);
    setNewLimit({
      name: '',
      category: '',
      limitAmount: 1000,
      period: 'monthly',
      alertThreshold: 80,
      action: 'warn',
    });
    toast({
      title: 'Limit Created',
      description: 'New spending limit has been added',
    });
  };

  // Calculate summary stats
  const activeLimits = limits.filter((l) => l.isActive);
  const limitsNearThreshold = limits.filter((l) => l.isActive && getUsagePercent(l) >= l.alertThreshold).length;
  const limitsExceeded = limits.filter((l) => l.isActive && getUsagePercent(l) >= 100).length;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-500/5">
              <ShieldCheck className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <CardTitle className="text-lg">Spending Limits</CardTitle>
              <CardDescription>Budget caps and spending controls</CardDescription>
            </div>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Plus className="h-4 w-4" />
                Add Limit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Spending Limit</DialogTitle>
                <DialogDescription>Set a new budget cap for a category</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Limit Name</Label>
                  <Input
                    placeholder="e.g. Meta Ads Monthly"
                    value={newLimit.name}
                    onChange={(e) => setNewLimit((prev) => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Input
                    placeholder="e.g. Meta, Google, etc."
                    value={newLimit.category}
                    onChange={(e) => setNewLimit((prev) => ({ ...prev, category: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Limit Amount: {formatCurrency(newLimit.limitAmount)}</Label>
                  <Slider
                    value={[newLimit.limitAmount]}
                    onValueChange={([v]) => setNewLimit((prev) => ({ ...prev, limitAmount: v }))}
                    min={100}
                    max={50000}
                    step={100}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Alert Threshold: {newLimit.alertThreshold}%</Label>
                  <Slider
                    value={[newLimit.alertThreshold]}
                    onValueChange={([v]) => setNewLimit((prev) => ({ ...prev, alertThreshold: v }))}
                    min={50}
                    max={100}
                    step={5}
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    <Ban className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Block when exceeded</span>
                  </div>
                  <Switch
                    checked={newLimit.action === 'block'}
                    onCheckedChange={(v) => setNewLimit((prev) => ({ ...prev, action: v ? 'block' : 'warn' }))}
                  />
                </div>
                <Button className="w-full" onClick={handleAddLimit} disabled={!newLimit.name || !newLimit.category}>
                  Create Limit
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20 text-center">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-emerald-500">{activeLimits.length}</p>
            <p className="text-[10px] text-muted-foreground">Active Limits</p>
          </div>
          <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 text-center">
            <AlertTriangle className="h-4 w-4 text-amber-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-amber-500">{limitsNearThreshold}</p>
            <p className="text-[10px] text-muted-foreground">Near Threshold</p>
          </div>
          <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20 text-center">
            <Ban className="h-4 w-4 text-destructive mx-auto mb-1" />
            <p className="text-lg font-bold text-destructive">{limitsExceeded}</p>
            <p className="text-[10px] text-muted-foreground">Exceeded</p>
          </div>
        </div>

        {/* Limits List */}
        <div className="space-y-3">
          {limits.map((limit) => {
            const percent = getUsagePercent(limit);
            return (
              <div
                key={limit.id}
                className={cn(
                  'p-4 rounded-xl border transition-all',
                  limit.isActive ? 'bg-card' : 'bg-muted/30 opacity-60',
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{limit.icon}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{limit.name}</p>
                        {limit.action === 'block' && (
                          <Badge
                            variant="outline"
                            className="text-[9px] bg-destructive/10 text-destructive border-destructive/20"
                          >
                            <Ban className="h-2.5 w-2.5 mr-1" />
                            Auto-block
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <Calendar className="h-3 w-3" />
                        <span className="capitalize">{limit.period}</span>
                        <span>•</span>
                        <Bell className="h-3 w-3" />
                        <span>Alert at {limit.alertThreshold}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={limit.isActive} onCheckedChange={() => toggleLimit(limit.id)} />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:bg-destructive/10"
                      onClick={() => deleteLimit(limit.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className={cn('font-semibold', getStatusColor(limit))}>
                      {formatCurrency(limit.currentSpend)}
                    </span>
                    <span className="text-muted-foreground">of {formatCurrency(limit.limitAmount)}</span>
                  </div>
                  <div className="relative">
                    <Progress value={Math.min(percent, 100)} className="h-2" />
                    {/* Alert threshold marker */}
                    <div
                      className="absolute top-0 h-2 w-0.5 bg-amber-500/50"
                      style={{ left: `${limit.alertThreshold}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className={cn('flex items-center gap-1', getStatusColor(limit))}>
                      {percent >= 100 ? (
                        <>
                          <AlertTriangle className="h-3 w-3" />
                          Exceeded by {formatCurrency(limit.currentSpend - limit.limitAmount)}
                        </>
                      ) : percent >= limit.alertThreshold ? (
                        <>
                          <AlertTriangle className="h-3 w-3" />
                          {percent}% used - approaching limit
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="h-3 w-3" />
                          {percent}% used
                        </>
                      )}
                    </span>
                    <span className="text-muted-foreground">
                      {formatCurrency(limit.limitAmount - limit.currentSpend)} remaining
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {limits.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="p-4 rounded-full bg-muted/50 mb-4">
              <ShieldCheck className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="font-medium">No spending limits set</p>
            <p className="text-sm text-muted-foreground">Create limits to control your budget</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
