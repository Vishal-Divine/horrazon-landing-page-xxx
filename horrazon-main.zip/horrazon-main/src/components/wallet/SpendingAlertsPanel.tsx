import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertTriangle, AlertCircle, TrendingUp, X, ChevronRight, Plus, Bell, CheckCircle2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface SpendingAlertsPanelProps {
  onAddFunds?: () => void;
  compact?: boolean;
}

export default function SpendingAlertsPanel({ onAddFunds, compact = false }: SpendingAlertsPanelProps) {
  const { spendingAlerts, acknowledgeAlert, dismissAllAlerts, setIsAddFundsOpen } = useApp();

  const activeAlerts = spendingAlerts.filter((alert) => !alert.acknowledged);

  if (activeAlerts.length === 0) {
    return compact ? null : (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="p-3 rounded-full bg-success/10 mb-3">
          <CheckCircle2 className="h-6 w-6 text-success" />
        </div>
        <p className="font-medium text-foreground">All Clear!</p>
        <p className="text-sm text-muted-foreground">No spending alerts at this time</p>
      </div>
    );
  }

  const getAlertIcon = (type: string, severity: string) => {
    if (severity === 'critical') {
      return <AlertCircle className="h-4 w-4 text-destructive animate-pulse" />;
    }
    switch (type) {
      case 'low_balance':
      case 'critical_balance':
        return <AlertTriangle className="h-4 w-4 text-warning" />;
      case 'campaign_risk':
      case 'budget_exceeded':
        return <TrendingUp className="h-4 w-4 text-chart-3" />;
      default:
        return <Bell className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const handleAddFunds = () => {
    setIsAddFundsOpen(true);
    onAddFunds?.();
  };

  return (
    <div className={compact ? '' : 'space-y-3'}>
      {!compact && (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <span className="text-sm font-medium">Spending Alerts</span>
            <Badge variant="destructive" className="text-[10px] px-1.5">
              {activeAlerts.length}
            </Badge>
          </div>
          {activeAlerts.length > 1 && (
            <Button variant="ghost" size="sm" className="text-xs h-7" onClick={dismissAllAlerts}>
              Dismiss All
            </Button>
          )}
        </div>
      )}

      <ScrollArea className={compact ? 'max-h-48' : 'max-h-64'}>
        <div className="space-y-2">
          {activeAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3 rounded-lg border transition-all ${
                alert.severity === 'critical'
                  ? 'bg-destructive/5 border-destructive/30 animate-pulse'
                  : 'bg-warning/5 border-warning/30'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">{getAlertIcon(alert.type, alert.severity)}</div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm ${alert.severity === 'critical' ? 'font-semibold' : 'font-medium'}`}>
                    {alert.message}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {formatDistanceToNow(alert.triggeredAt, { addSuffix: true })}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 shrink-0"
                  onClick={() => acknowledgeAlert(alert.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>

              {(alert.type === 'low_balance' || alert.type === 'critical_balance') && (
                <Button
                  size="sm"
                  className="w-full mt-2 gap-1 bg-gradient-to-r from-success to-emerald-500 hover:from-success/90 hover:to-emerald-500/90"
                  onClick={handleAddFunds}
                >
                  <Plus className="h-3 w-3" />
                  Add Funds Now
                </Button>
              )}

              {(alert.type === 'campaign_risk' || alert.type === 'budget_exceeded') && (
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-2 gap-1"
                  onClick={() => acknowledgeAlert(alert.id)}
                >
                  View Campaign
                  <ChevronRight className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
