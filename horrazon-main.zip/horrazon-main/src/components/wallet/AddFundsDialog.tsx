import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CreditCard, DollarSign, Shield, Zap, CheckCircle, Loader2, Plus, Sparkles } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

const presetAmounts = [
  { value: 500, label: '$500', popular: false },
  { value: 1000, label: '$1,000', popular: false },
  { value: 2500, label: '$2,500', popular: true },
  { value: 5000, label: '$5,000', popular: false },
  { value: 10000, label: '$10,000', popular: false },
];

export default function AddFundsDialog() {
  const { isAddFundsOpen, setIsAddFundsOpen, addFunds, isLoading, wallet } = useApp();
  const [amount, setAmount] = useState<number>(2500);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardName, setCardName] = useState('');
  const [step, setStep] = useState<'amount' | 'payment'>('amount');

  const handlePresetClick = (value: number) => {
    setAmount(value);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value: string) => {
    const numValue = value.replace(/[^0-9]/g, '');
    setCustomAmount(numValue);
    if (numValue) {
      setAmount(parseInt(numValue, 10));
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : v;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const handleSubmit = async () => {
    if (step === 'amount') {
      setStep('payment');
      return;
    }

    await addFunds(amount);

    // Reset form
    setStep('amount');
    setCardNumber('');
    setExpiry('');
    setCvv('');
    setCardName('');
    setCustomAmount('');
    setAmount(2500);
  };

  const handleClose = () => {
    setIsAddFundsOpen(false);
    setStep('amount');
  };

  const isValidPayment =
    cardNumber.replace(/\s/g, '').length >= 16 && expiry.length === 5 && cvv.length >= 3 && cardName.length > 0;

  const estimatedDays = Math.round(amount / (wallet.dailySpent || 342.8));

  return (
    <Dialog open={isAddFundsOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-primary/10">
              <DollarSign className="h-5 w-5 text-primary" />
            </div>
            Add Funds to Wallet
          </DialogTitle>
          <DialogDescription>Securely add funds to power your marketing campaigns</DialogDescription>
        </DialogHeader>

        {step === 'amount' ? (
          <div className="space-y-6 pt-4">
            {/* Current Balance Card */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 border border-primary/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Current Balance</p>
                  <p className="text-2xl font-bold text-primary">
                    ${wallet.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Avg Daily Spend</p>
                  <p className="text-sm font-semibold">
                    ${wallet.dailySpent.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
            </div>

            {/* Preset Amounts */}
            <div className="space-y-3">
              <Label>Select Amount</Label>
              <div className="grid grid-cols-5 gap-2">
                {presetAmounts.map((preset) => (
                  <Button
                    key={preset.value}
                    type="button"
                    variant={amount === preset.value && !customAmount ? 'default' : 'outline'}
                    className={cn(
                      'relative h-14 flex-col gap-0.5 transition-all',
                      amount === preset.value && !customAmount && 'ring-2 ring-primary ring-offset-2',
                    )}
                    onClick={() => handlePresetClick(preset.value)}
                  >
                    {preset.popular && (
                      <Badge className="absolute -top-2 right-0 text-[8px] px-1 py-0 bg-gradient-to-r from-primary to-chart-3">
                        Popular
                      </Badge>
                    )}
                    <span className="text-sm font-bold">{preset.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div className="space-y-2">
              <Label htmlFor="custom-amount">Or enter custom amount</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="custom-amount"
                  placeholder="Enter amount"
                  value={customAmount}
                  onChange={(e) => handleCustomAmountChange(e.target.value)}
                  className="pl-9 text-lg font-semibold h-12"
                />
              </div>
            </div>

            <Separator />

            {/* Summary */}
            <div className="space-y-3 p-4 rounded-lg bg-muted/50">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Amount to add</span>
                <span className="font-bold text-lg">${amount.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">New balance</span>
                <span className="font-semibold text-success">
                  ${(wallet.balance + amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  Est. campaign runway
                </span>
                <span className="font-medium text-primary">{estimatedDays} days</span>
              </div>
            </div>

            <Button
              onClick={handleSubmit}
              className="w-full h-12 text-base gap-2 bg-gradient-to-r from-primary to-primary/80"
            >
              Continue to Payment
              <CreditCard className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="space-y-6 pt-4">
            {/* Amount Summary */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-primary/5 border border-primary/20">
              <span className="text-sm">Adding to wallet</span>
              <span className="font-bold text-lg text-primary">${amount.toLocaleString()}</span>
            </div>

            {/* Payment Form */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="card-name">Name on Card</Label>
                <Input
                  id="card-name"
                  placeholder="John Doe"
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="card-number">Card Number</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="card-number"
                    placeholder="4242 4242 4242 4242"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                    maxLength={19}
                    className="pl-9"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    value={expiry}
                    onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                    maxLength={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                    maxLength={4}
                    type="password"
                  />
                </div>
              </div>
            </div>

            {/* Security Badge */}
            <div className="flex items-center gap-2 p-3 rounded-lg bg-success/5 border border-success/20 text-success">
              <Shield className="h-4 w-4" />
              <span className="text-xs">256-bit SSL encrypted payment</span>
              <CheckCircle className="h-3 w-3 ml-auto" />
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep('amount')} className="flex-1" disabled={isLoading}>
                Back
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={!isValidPayment || isLoading}
                className="flex-[2] gap-2 bg-gradient-to-r from-success to-emerald-500 hover:from-success/90 hover:to-emerald-500/90"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4" />
                    Add ${amount.toLocaleString()}
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
