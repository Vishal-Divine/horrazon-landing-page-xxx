import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Target,
  Sparkles,
  ChevronRight,
  Eye,
  BarChart3,
  ArrowRight,
  Clock,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, addDays, subDays, eachDayOfInterval, isToday } from 'date-fns';
import { useApp } from '@/contexts/AppContext';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface ForecastDay {
  date: Date;
  label: string;
  fullDate: string;
  projectedBalance: number;
  projectedSpend: number;
  projectedIncome: number;
  confidence: number;
  isHistorical: boolean;
  events: string[];
}

export default function CashFlowPredictor() {
  const { wallet } = useApp();
  const [forecastDays, setForecastDays] = useState(14);

  const forecastData = useMemo(() => {
    const today = new Date();
    const avgDailySpend = wallet.monthlySpent / 30;
    const avgDailyIncome = (wallet.balance + wallet.monthlySpent) / 60; // Rough estimate

    const days: ForecastDay[] = [];
    let runningBalance = wallet.balance;

    // Historical data (last 7 days)
    for (let i = 6; i >= 0; i--) {
      const date = subDays(today, i);
      const dailySpend = avgDailySpend * (0.7 + Math.random() * 0.6);
      const dailyIncome = i % 7 === 0 ? avgDailyIncome * 3 : avgDailyIncome * 0.2;

      days.push({
        date,
        label: format(date, 'EEE'),
        fullDate: format(date, 'MMM d'),
        projectedBalance: runningBalance + dailyIncome - dailySpend,
        projectedSpend: dailySpend,
        projectedIncome: dailyIncome,
        confidence: 100,
        isHistorical: true,
        events: [],
      });
    }

    // Set current balance
    runningBalance = wallet.balance;

    // Future predictions
    for (let i = 1; i <= forecastDays; i++) {
      const date = addDays(today, i);
      const weekday = date.getDay();

      // Spending patterns: higher on weekdays, lower on weekends
      let spendMultiplier = weekday === 0 || weekday === 6 ? 0.6 : 1.2;

      // Add some variance
      spendMultiplier *= 0.8 + Math.random() * 0.4;

      const dailySpend = avgDailySpend * spendMultiplier;

      // Income: weekly deposits on Mondays
      const dailyIncome = weekday === 1 ? avgDailyIncome * 5 : 0;

      runningBalance = runningBalance + dailyIncome - dailySpend;

      // Confidence decreases over time
      const confidence = Math.max(60, 95 - i * 2);

      // Events
      const events: string[] = [];
      if (weekday === 1) events.push('Weekly deposit expected');
      if (i === 7) events.push('Meta Ads auto-charge');
      if (runningBalance < wallet.lowBalanceThreshold) events.push('Low balance warning');

      days.push({
        date,
        label: format(date, 'EEE'),
        fullDate: format(date, 'MMM d'),
        projectedBalance: Math.max(0, runningBalance),
        projectedSpend: dailySpend,
        projectedIncome: dailyIncome,
        confidence,
        isHistorical: false,
        events,
      });
    }

    return days;
  }, [wallet, forecastDays]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const projectedEndBalance = forecastData[forecastData.length - 1]?.projectedBalance || 0;
  const balanceChange = projectedEndBalance - wallet.balance;
  const lowestPoint = Math.min(...forecastData.filter((d) => !d.isHistorical).map((d) => d.projectedBalance));
  const lowBalanceDay = forecastData.find((d) => !d.isHistorical && d.projectedBalance < wallet.lowBalanceThreshold);
  const daysUntilLow = lowBalanceDay
    ? Math.ceil((lowBalanceDay.date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null;

  const chartData = forecastData.map((d) => ({
    ...d,
    date: d.fullDate,
    balance: d.projectedBalance,
  }));

  return (
    <Card className="overflow-hidden lg:col-span-2">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-violet-500 to-purple-500">
              <Target className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                Cash Flow Predictor
                <Badge className="bg-violet-500/10 text-violet-600 border-violet-500/30">
                  <Sparkles className="h-3 w-3 mr-1" />
                  AI Powered
                </Badge>
              </CardTitle>
              <CardDescription>Forecast your wallet balance</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-muted/50 rounded-lg p-0.5">
              {[7, 14, 30].map((days) => (
                <Button
                  key={days}
                  variant={forecastDays === days ? 'secondary' : 'ghost'}
                  size="sm"
                  className="text-xs h-7 px-2.5"
                  onClick={() => setForecastDays(days)}
                >
                  {days}d
                </Button>
              ))}
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Forecast Summary */}
        <div className="grid grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Current</span>
            </div>
            <p className="text-xl font-bold text-primary">{formatCurrency(wallet.balance)}</p>
          </div>

          <div
            className={cn(
              'p-4 rounded-xl border',
              balanceChange >= 0
                ? 'bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/20'
                : 'bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-amber-500/20',
            )}
          >
            <div className="flex items-center gap-2 mb-2">
              {balanceChange >= 0 ? (
                <TrendingUp className="h-4 w-4 text-emerald-500" />
              ) : (
                <TrendingDown className="h-4 w-4 text-amber-500" />
              )}
              <span className="text-xs text-muted-foreground">Projected</span>
            </div>
            <p className={cn('text-xl font-bold', balanceChange >= 0 ? 'text-emerald-600' : 'text-amber-600')}>
              {formatCurrency(projectedEndBalance)}
            </p>
            <p className="text-[10px] text-muted-foreground">
              {balanceChange >= 0 ? '+' : ''}
              {formatCurrency(balanceChange)} in {forecastDays}d
            </p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-violet-500/5 border border-violet-500/20">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="h-4 w-4 text-violet-500" />
              <span className="text-xs text-muted-foreground">Lowest Point</span>
            </div>
            <p className="text-xl font-bold text-violet-600">{formatCurrency(lowestPoint)}</p>
            <p className="text-[10px] text-muted-foreground">Minimum balance</p>
          </div>

          <div
            className={cn(
              'p-4 rounded-xl border',
              daysUntilLow
                ? 'bg-gradient-to-br from-destructive/10 to-destructive/5 border-destructive/20'
                : 'bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/20',
            )}
          >
            <div className="flex items-center gap-2 mb-2">
              {daysUntilLow ? (
                <AlertTriangle className="h-4 w-4 text-destructive" />
              ) : (
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              )}
              <span className="text-xs text-muted-foreground">Runway</span>
            </div>
            <p className={cn('text-xl font-bold', daysUntilLow ? 'text-destructive' : 'text-emerald-600')}>
              {daysUntilLow ? `${daysUntilLow}d` : 'Safe'}
            </p>
            <p className="text-[10px] text-muted-foreground">{daysUntilLow ? 'Until low balance' : 'No alerts'}</p>
          </div>
        </div>

        {/* Chart */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="forecastGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '12px',
                  boxShadow: '0 10px 30px -10px hsl(var(--foreground) / 0.1)',
                }}
                formatter={(value: number, name: string) => [formatCurrency(value), 'Balance']}
                labelFormatter={(label) => `${label}`}
              />
              <ReferenceLine
                y={wallet.lowBalanceThreshold}
                stroke="hsl(var(--destructive))"
                strokeDasharray="5 5"
                strokeOpacity={0.5}
              />
              <Area
                type="monotone"
                dataKey="balance"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#balanceGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Legend & Actions */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-6 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-primary rounded" />
              <span className="text-muted-foreground">Projected Balance</span>
            </div>
            <div className="flex items-center gap-2">
              <div
                className="w-3 h-0.5 bg-destructive rounded opacity-50"
                style={{
                  backgroundImage:
                    'repeating-linear-gradient(90deg, transparent, transparent 2px, currentColor 2px, currentColor 4px)',
                }}
              />
              <span className="text-muted-foreground">Low Balance Threshold</span>
            </div>
          </div>
          <Button variant="outline" size="sm" className="text-xs gap-1">
            <Eye className="h-3.5 w-3.5" />
            View Details
            <ChevronRight className="h-3 w-3" />
          </Button>
        </div>

        {/* Alerts & Recommendations */}
        {daysUntilLow && (
          <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-500/5 border border-amber-500/20">
            <div className="p-2 rounded-lg bg-amber-500/20 flex-shrink-0">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Low Balance Alert</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Based on current spending patterns, your balance may drop below the threshold in {daysUntilLow} days.
                Consider adding funds or adjusting campaign budgets.
              </p>
            </div>
            <Button size="sm" className="text-xs gap-1 flex-shrink-0">
              Add Funds
              <ArrowRight className="h-3 w-3" />
            </Button>
          </div>
        )}

        {/* Confidence Indicator */}
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Zap className="h-3.5 w-3.5 text-violet-500" />
          <span>AI confidence decreases over time • Based on 90-day spending patterns</span>
        </div>
      </CardContent>
    </Card>
  );
}
