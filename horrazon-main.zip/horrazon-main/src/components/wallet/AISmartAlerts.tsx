import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Bell,
  BellRing,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Zap,
  Shield,
  DollarSign,
  Clock,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Sparkles,
  Target,
  BarChart3,
  Activity,
  AlertCircle,
  Bot,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface SmartAlert {
  id: string;
  type: 'spending' | 'budget' | 'performance' | 'opportunity' | 'risk';
  severity: 'info' | 'warning' | 'critical' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  aiInsight?: string;
  actions?: { label: string; primary?: boolean }[];
  dismissed: boolean;
}

interface AlertRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  threshold?: number;
  icon: React.ReactNode;
}

export default function AISmartAlerts() {
  const { wallet, campaignSpends, spendingAlerts } = useApp();

  const [alerts] = useState<SmartAlert[]>([
    {
      id: '1',
      type: 'spending',
      severity: 'warning',
      title: 'Unusual Spending Pattern Detected',
      message: "Your Meta Ads spend increased by 45% compared to last week's average.",
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      aiInsight: 'AI suggests reviewing your bid strategy. Similar patterns have led to 20% budget overruns.',
      actions: [{ label: 'Review Campaign', primary: true }, { label: 'Adjust Budget' }],
      dismissed: false,
    },
    {
      id: '2',
      type: 'opportunity',
      severity: 'success',
      title: 'Cost Reduction Opportunity',
      message: 'Shifting 15% budget from LinkedIn to TikTok could save $420/month.',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      aiInsight: 'Based on your audience demographics, TikTok shows 2.3x better engagement rates.',
      actions: [{ label: 'Apply Changes', primary: true }, { label: 'Learn More' }],
      dismissed: false,
    },
    {
      id: '3',
      type: 'risk',
      severity: 'critical',
      title: 'Budget Exhaustion Warning',
      message: 'Q4 Lead Generation campaign will exhaust budget in 3 days at current pace.',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      aiInsight: 'Consider pausing low-converting ad sets or adding $500 to extend campaign.',
      actions: [{ label: 'Add Funds', primary: true }, { label: 'Pause Campaign' }],
      dismissed: false,
    },
    {
      id: '4',
      type: 'performance',
      severity: 'info',
      title: 'Performance Milestone Reached',
      message: 'Your ROAS improved by 18% this week across all platforms.',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      aiInsight: "Keep current strategy. Top performing creative: 'Summer Sale Banner v2'.",
      dismissed: false,
    },
  ]);

  const [alertRules, setAlertRules] = useState<AlertRule[]>([
    {
      id: '1',
      name: 'Low Balance Alert',
      description: 'Alert when balance drops below threshold',
      enabled: true,
      threshold: 5000,
      icon: <DollarSign className="h-4 w-4" />,
    },
    {
      id: '2',
      name: 'Spending Spike Detection',
      description: 'AI monitors for unusual spending patterns',
      enabled: true,
      icon: <TrendingUp className="h-4 w-4" />,
    },
    {
      id: '3',
      name: 'Campaign Risk Alert',
      description: 'Alert on high-risk campaign conditions',
      enabled: true,
      icon: <AlertTriangle className="h-4 w-4" />,
    },
    {
      id: '4',
      name: 'ROI Opportunities',
      description: 'AI identifies optimization opportunities',
      enabled: true,
      icon: <Target className="h-4 w-4" />,
    },
    {
      id: '5',
      name: 'Budget Pacing Alerts',
      description: 'Track budget utilization against schedule',
      enabled: false,
      icon: <Clock className="h-4 w-4" />,
    },
    {
      id: '6',
      name: 'Competitor Activity',
      description: 'Notify on competitor bid changes',
      enabled: false,
      icon: <Activity className="h-4 w-4" />,
    },
  ]);

  const getSeverityStyles = (severity: string) => {
    switch (severity) {
      case 'critical':
        return {
          bg: 'bg-destructive/10',
          border: 'border-destructive/50',
          icon: 'text-destructive',
          badge: 'bg-destructive text-destructive-foreground',
        };
      case 'warning':
        return {
          bg: 'bg-amber-500/10',
          border: 'border-amber-500/50',
          icon: 'text-amber-500',
          badge: 'bg-amber-500 text-white',
        };
      case 'success':
        return {
          bg: 'bg-emerald-500/10',
          border: 'border-emerald-500/50',
          icon: 'text-emerald-500',
          badge: 'bg-emerald-500 text-white',
        };
      default:
        return {
          bg: 'bg-primary/10',
          border: 'border-primary/50',
          icon: 'text-primary',
          badge: 'bg-primary text-primary-foreground',
        };
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'spending':
        return <TrendingUp className="h-4 w-4" />;
      case 'budget':
        return <DollarSign className="h-4 w-4" />;
      case 'performance':
        return <BarChart3 className="h-4 w-4" />;
      case 'opportunity':
        return <Zap className="h-4 w-4" />;
      case 'risk':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const toggleRule = (ruleId: string) => {
    setAlertRules((prev) => prev.map((rule) => (rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule)));
  };

  const activeAlerts = alerts.filter((a) => !a.dismissed);

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      {/* Active Alerts */}
      <div className="lg:col-span-3 space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-primary/10">
                  <BellRing className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    Smart Alerts
                    <Badge variant="secondary" className="text-xs">
                      {activeAlerts.length} Active
                    </Badge>
                  </CardTitle>
                  <CardDescription>AI-powered notifications and recommendations</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm">
                Mark All Read
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-4">
                {activeAlerts.map((alert) => {
                  const styles = getSeverityStyles(alert.severity);
                  return (
                    <div
                      key={alert.id}
                      className={cn('rounded-xl border p-4 transition-all hover:shadow-md', styles.bg, styles.border)}
                    >
                      <div className="flex items-start gap-4">
                        <div className={cn('p-2 rounded-lg', styles.bg)}>
                          <div className={styles.icon}>{getTypeIcon(alert.type)}</div>
                        </div>

                        <div className="flex-1 space-y-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-semibold flex items-center gap-2">
                                {alert.title}
                                <Badge className={cn('text-xs', styles.badge)}>{alert.severity}</Badge>
                              </h4>
                              <p className="text-sm text-muted-foreground mt-0.5">{alert.message}</p>
                            </div>
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {format(alert.timestamp, 'h:mm a')}
                            </span>
                          </div>

                          {/* AI Insight */}
                          {alert.aiInsight && (
                            <div className="flex items-start gap-2 p-2 rounded-lg bg-background/50 border border-border/50">
                              <Bot className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                              <p className="text-xs text-muted-foreground">
                                <span className="font-medium text-primary">AI Insight:</span> {alert.aiInsight}
                              </p>
                            </div>
                          )}

                          {/* Actions */}
                          {alert.actions && (
                            <div className="flex items-center gap-2 pt-2">
                              {alert.actions.map((action, idx) => (
                                <Button
                                  key={idx}
                                  size="sm"
                                  variant={action.primary ? 'default' : 'outline'}
                                  className="h-7 text-xs"
                                >
                                  {action.label}
                                </Button>
                              ))}
                              <Button variant="ghost" size="sm" className="h-7 text-xs ml-auto">
                                Dismiss
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Alert Configuration */}
      <div className="lg:col-span-2 space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-primary/10">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-lg">Alert Rules</CardTitle>
                <CardDescription>Configure AI-powered alert triggers</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {alertRules.map((rule) => (
                <div
                  key={rule.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        'p-2 rounded-lg',
                        rule.enabled ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground',
                      )}
                    >
                      {rule.icon}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{rule.name}</p>
                      <p className="text-xs text-muted-foreground">{rule.description}</p>
                    </div>
                  </div>
                  <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            {/* Threshold Settings */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium">Alert Thresholds</h4>

              <div className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Low Balance Threshold</span>
                    <span className="text-sm font-medium">${wallet.lowBalanceThreshold.toLocaleString()}</span>
                  </div>
                  <Slider defaultValue={[wallet.lowBalanceThreshold]} max={10000} step={500} />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Spending Spike Detection</span>
                    <span className="text-sm font-medium">+30%</span>
                  </div>
                  <Slider defaultValue={[30]} max={100} step={5} />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Budget Warning Level</span>
                    <span className="text-sm font-medium">80%</span>
                  </div>
                  <Slider defaultValue={[80]} max={100} step={5} />
                </div>
              </div>
            </div>

            <Button className="w-full mt-4" variant="outline">
              <Shield className="h-4 w-4 mr-2" />
              Save Alert Settings
            </Button>
          </CardContent>
        </Card>

        {/* AI Summary */}
        <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-background">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <span className="text-sm font-medium">AI Alert Summary</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Based on your current spending patterns, I predict{' '}
              <strong className="text-foreground">2 potential budget alerts</strong> in the next 7 days. Consider adding
              funds or adjusting campaign pacing to prevent interruptions.
            </p>
            <Button size="sm" className="mt-3 w-full" variant="secondary">
              View Predictions <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
