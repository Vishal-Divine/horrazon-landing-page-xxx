import { useState } from 'react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link2, Webhook, Key, RefreshCw, Database, Bot, Bell, Shield, TrendingUp, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeatureTab {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

interface WalletFeatureTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const featureTabs: FeatureTab[] = [
  { id: 'connections', label: 'Connections', icon: <Link2 className="h-4 w-4" /> },
  { id: 'ai-advisor', label: 'AI Advisor', icon: <Bot className="h-4 w-4" />, badge: 'New' },
  { id: 'alerts', label: 'Smart Alerts', icon: <Bell className="h-4 w-4" /> },
  { id: 'sync-logs', label: 'Sync Logs', icon: <RefreshCw className="h-4 w-4" /> },
  { id: 'data-mapping', label: 'Data Mapping', icon: <Database className="h-4 w-4" /> },
  { id: 'security', label: 'Security', icon: <Shield className="h-4 w-4" /> },
  { id: 'insights', label: 'AI Insights', icon: <TrendingUp className="h-4 w-4" /> },
  { id: 'api-keys', label: 'API Keys', icon: <Key className="h-4 w-4" /> },
  { id: 'webhooks', label: 'Webhooks', icon: <Webhook className="h-4 w-4" /> },
  { id: 'settings', label: 'Settings', icon: <Settings className="h-4 w-4" /> },
];

export default function WalletFeatureTabs({ activeTab, onTabChange }: WalletFeatureTabsProps) {
  return (
    <div className="w-full overflow-x-auto scrollbar-thin">
      <Tabs value={activeTab} onValueChange={onTabChange}>
        <TabsList className="h-12 w-full justify-start gap-1 bg-muted/30 p-1.5 rounded-xl border border-border/50">
          {featureTabs.map((tab) => (
            <TabsTrigger
              key={tab.id}
              value={tab.id}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200',
                'data-[state=active]:bg-background data-[state=active]:shadow-sm',
                'data-[state=active]:text-primary',
                'hover:bg-background/50',
              )}
            >
              {tab.icon}
              <span className="text-sm font-medium">{tab.label}</span>
              {tab.badge && (
                <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-primary/20 text-primary rounded-full">
                  {tab.badge}
                </span>
              )}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
    </div>
  );
}
