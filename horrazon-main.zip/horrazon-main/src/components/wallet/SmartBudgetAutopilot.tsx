import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import {
  Brain,
  Zap,
  Settings,
  Play,
  Pause,
  TrendingUp,
  Target,
  Sparkles,
  ChevronRight,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  BarChart3,
  Lightbulb,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface AutopilotRule {
  id: string;
  name: string;
  description: string;
  category: 'allocation' | 'optimization' | 'protection' | 'growth';
  isEnabled: boolean;
  impact: 'high' | 'medium' | 'low';
  savings: number;
  lastTriggered?: Date;
}

const mockRules: AutopilotRule[] = [
  {
    id: '1',
    name: 'Smart Budget Rebalancing',
    description: 'Auto-reallocate funds from underperforming to top campaigns',
    category: 'optimization',
    isEnabled: true,
    impact: 'high',
    savings: 2340,
    lastTriggered: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: '2',
    name: 'Low Balance Protection',
    description: 'Pause campaigns when balance drops below threshold',
    category: 'protection',
    isEnabled: true,
    impact: 'high',
    savings: 1580,
  },
  {
    id: '3',
    name: 'Peak Hour Boosting',
    description: 'Increase spend during high-conversion time windows',
    category: 'growth',
    isEnabled: false,
    impact: 'medium',
    savings: 890,
  },
  {
    id: '4',
    name: 'Seasonal Budget Adjustment',
    description: 'Adapt allocations based on seasonal performance data',
    category: 'allocation',
    isEnabled: true,
    impact: 'medium',
    savings: 1120,
  },
];

const getCategoryStyles = (category: string) => {
  switch (category) {
    case 'optimization':
      return { bg: 'bg-primary/10', text: 'text-primary', border: 'border-primary/30' };
    case 'protection':
      return { bg: 'bg-amber-500/10', text: 'text-amber-600', border: 'border-amber-500/30' };
    case 'growth':
      return { bg: 'bg-emerald-500/10', text: 'text-emerald-600', border: 'border-emerald-500/30' };
    case 'allocation':
      return { bg: 'bg-violet-500/10', text: 'text-violet-600', border: 'border-violet-500/30' };
    default:
      return { bg: 'bg-muted', text: 'text-muted-foreground', border: 'border-border' };
  }
};

const getImpactBadge = (impact: string) => {
  switch (impact) {
    case 'high':
      return { label: 'High Impact', className: 'bg-emerald-500/10 text-emerald-600' };
    case 'medium':
      return { label: 'Medium', className: 'bg-amber-500/10 text-amber-600' };
    case 'low':
      return { label: 'Low', className: 'bg-muted text-muted-foreground' };
    default:
      return { label: '', className: '' };
  }
};

export default function SmartBudgetAutopilot() {
  const [rules, setRules] = useState(mockRules);
  const [autopilotEnabled, setAutopilotEnabled] = useState(true);
  const [aggressiveness, setAggressiveness] = useState([50]);

  const toggleRule = (ruleId: string) => {
    setRules((prev) =>
      prev.map((rule) => {
        if (rule.id === ruleId) {
          const newState = !rule.isEnabled;
          toast({
            title: newState ? 'Rule Enabled' : 'Rule Disabled',
            description: `${rule.name} is now ${newState ? 'active' : 'paused'}.`,
          });
          return { ...rule, isEnabled: newState };
        }
        return rule;
      }),
    );
  };

  const totalSavings = rules.filter((r) => r.isEnabled).reduce((sum, r) => sum + r.savings, 0);
  const activeRules = rules.filter((r) => r.isEnabled).length;
  const automationScore = Math.round((activeRules / rules.length) * 100);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatTimeAgo = (date?: Date) => {
    if (!date) return 'Never';
    const hours = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                'p-2.5 rounded-xl bg-gradient-to-br',
                autopilotEnabled ? 'from-primary to-blue-500' : 'from-muted-foreground to-muted',
              )}
            >
              <Brain className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                Budget Autopilot
                {autopilotEnabled && (
                  <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Active
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>AI-powered budget automation</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Autopilot</span>
            <Switch checked={autopilotEnabled} onCheckedChange={setAutopilotEnabled} />
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* AI Performance Summary */}
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">Total Savings</span>
            </div>
            <p className="text-2xl font-bold text-primary">{formatCurrency(totalSavings)}</p>
            <p className="text-xs text-muted-foreground mt-1">This month</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-emerald-500" />
              <span className="text-sm text-muted-foreground">Active Rules</span>
            </div>
            <p className="text-2xl font-bold text-emerald-600">
              {activeRules}/{rules.length}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Rules running</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-violet-500/5 border border-violet-500/20">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="h-4 w-4 text-violet-500" />
              <span className="text-sm text-muted-foreground">Automation</span>
            </div>
            <p className="text-2xl font-bold text-violet-600">{automationScore}%</p>
            <p className="text-xs text-muted-foreground mt-1">Score</p>
          </div>
        </div>

        {/* Aggressiveness Slider */}
        <div className="p-4 rounded-xl bg-muted/50 border border-border/50">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Settings className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium text-sm">Optimization Aggressiveness</span>
            </div>
            <Badge variant="outline">{aggressiveness[0]}%</Badge>
          </div>
          <Slider value={aggressiveness} onValueChange={setAggressiveness} max={100} step={5} className="w-full" />
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>Conservative</span>
            <span>Balanced</span>
            <span>Aggressive</span>
          </div>
        </div>

        {/* Automation Rules */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-amber-500" />
              Smart Rules
            </h4>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              <RefreshCw className="h-3 w-3" />
              Sync
            </Button>
          </div>

          {rules.map((rule) => {
            const categoryStyles = getCategoryStyles(rule.category);
            const impactBadge = getImpactBadge(rule.impact);

            return (
              <div
                key={rule.id}
                className={cn(
                  'group p-4 rounded-xl border transition-all duration-200',
                  rule.isEnabled
                    ? 'bg-card hover:bg-muted/30 border-border'
                    : 'bg-muted/30 border-border/50 opacity-70',
                )}
              >
                <div className="flex items-start gap-4">
                  {/* Status Icon */}
                  <div className={cn('p-2.5 rounded-xl', categoryStyles.bg)}>
                    {rule.isEnabled ? (
                      <Play className={cn('h-4 w-4', categoryStyles.text)} />
                    ) : (
                      <Pause className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h5 className="font-medium text-sm">{rule.name}</h5>
                      <Badge variant="outline" className={cn('text-[10px]', impactBadge.className)}>
                        {impactBadge.label}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{rule.description}</p>

                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1 text-emerald-600">
                        <TrendingUp className="h-3 w-3" />
                        <span>{formatCurrency(rule.savings)} saved</span>
                      </div>
                      {rule.lastTriggered && (
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <RefreshCw className="h-3 w-3" />
                          <span>Last run: {formatTimeAgo(rule.lastTriggered)}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Toggle */}
                  <Switch
                    checked={rule.isEnabled}
                    onCheckedChange={() => toggleRule(rule.id)}
                    disabled={!autopilotEnabled}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* AI Suggestion */}
        <div className="flex items-start gap-3 p-4 rounded-xl bg-gradient-to-r from-primary/5 via-primary/10 to-transparent border border-primary/20">
          <div className="p-2 rounded-lg bg-primary/20 flex-shrink-0">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">AI Recommendation</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Enable "Peak Hour Boosting" to potentially save an additional $890/month based on your campaign patterns.
            </p>
          </div>
          <Button variant="outline" size="sm" className="text-xs gap-1 flex-shrink-0">
            Enable
            <ChevronRight className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
