import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import {
  Link2,
  Unlink,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Plus,
  Settings,
  ExternalLink,
  Shield,
  Zap,
  Clock,
  Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface Connection {
  id: string;
  name: string;
  icon: string;
  status: 'connected' | 'disconnected' | 'error' | 'syncing';
  lastSync?: Date;
  accountName?: string;
  dataPoints?: number;
  enabled: boolean;
}

const connections: Connection[] = [
  {
    id: 'meta',
    name: 'Meta Ads',
    icon: '📘',
    status: 'connected',
    lastSync: new Date(Date.now() - 5 * 60 * 1000),
    accountName: 'Brand Marketing',
    dataPoints: 1250,
    enabled: true,
  },
  {
    id: 'google',
    name: 'Google Ads',
    icon: '🎯',
    status: 'connected',
    lastSync: new Date(Date.now() - 15 * 60 * 1000),
    accountName: 'Main Account',
    dataPoints: 890,
    enabled: true,
  },
  {
    id: 'tiktok',
    name: 'TikTok Ads',
    icon: '🎵',
    status: 'syncing',
    lastSync: new Date(Date.now() - 30 * 60 * 1000),
    accountName: 'GenZ Campaigns',
    dataPoints: 456,
    enabled: true,
  },
  {
    id: 'linkedin',
    name: 'LinkedIn Ads',
    icon: '💼',
    status: 'connected',
    lastSync: new Date(Date.now() - 60 * 60 * 1000),
    accountName: 'B2B Marketing',
    dataPoints: 234,
    enabled: true,
  },
  {
    id: 'stripe',
    name: 'Stripe',
    icon: '💳',
    status: 'connected',
    lastSync: new Date(Date.now() - 2 * 60 * 60 * 1000),
    accountName: 'Primary',
    dataPoints: 5420,
    enabled: true,
  },
  { id: 'shopify', name: 'Shopify', icon: '🛒', status: 'disconnected', enabled: false },
  {
    id: 'hubspot',
    name: 'HubSpot',
    icon: '🧲',
    status: 'error',
    lastSync: new Date(Date.now() - 24 * 60 * 60 * 1000),
    accountName: 'CRM Account',
    enabled: true,
  },
  {
    id: 'analytics',
    name: 'Google Analytics',
    icon: '📊',
    status: 'connected',
    lastSync: new Date(Date.now() - 10 * 60 * 1000),
    accountName: 'GA4 Property',
    dataPoints: 12500,
    enabled: true,
  },
];

export default function WalletConnectionsPanel() {
  const [connectionsList, setConnectionsList] = useState(connections);
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return (
          <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Connected
          </Badge>
        );
      case 'syncing':
        return (
          <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/30">
            <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
            Syncing
          </Badge>
        );
      case 'error':
        return (
          <Badge className="bg-destructive/10 text-destructive border-destructive/30">
            <XCircle className="h-3 w-3 mr-1" />
            Error
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary">
            <Unlink className="h-3 w-3 mr-1" />
            Disconnected
          </Badge>
        );
    }
  };

  const toggleConnection = (id: string) => {
    setConnectionsList((prev) =>
      prev.map((conn) =>
        conn.id === id
          ? { ...conn, enabled: !conn.enabled, status: conn.enabled ? 'disconnected' : 'connected' }
          : conn,
      ),
    );
  };

  const filteredConnections = connectionsList.filter((conn) =>
    conn.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const connectedCount = connectionsList.filter((c) => c.status === 'connected' || c.status === 'syncing').length;
  const totalDataPoints = connectionsList.reduce((sum, c) => sum + (c.dataPoints || 0), 0);

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <Link2 className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{connectedCount}</p>
                <p className="text-sm text-muted-foreground">Active Connections</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalDataPoints.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Data Points Synced</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">5 min</p>
                <p className="text-sm text-muted-foreground">Last Sync</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Shield className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{connectionsList.filter((c) => c.status === 'error').length}</p>
                <p className="text-sm text-muted-foreground">Needs Attention</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Connections List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Link2 className="h-5 w-5" />
                Data Connections
              </CardTitle>
              <CardDescription>Manage your connected platforms and data sources</CardDescription>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Search connections..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Connection
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredConnections.map((conn) => (
              <div
                key={conn.id}
                className={cn(
                  'flex items-center justify-between p-4 rounded-xl border transition-all',
                  conn.status === 'error'
                    ? 'border-destructive/50 bg-destructive/5'
                    : conn.enabled
                      ? 'border-border hover:border-primary/50 hover:shadow-sm'
                      : 'border-border/50 bg-muted/30',
                )}
              >
                <div className="flex items-center gap-4">
                  <div className="text-3xl">{conn.icon}</div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{conn.name}</h4>
                      {getStatusBadge(conn.status)}
                    </div>
                    {conn.accountName && (
                      <p className="text-sm text-muted-foreground">
                        {conn.accountName}
                        {conn.lastSync && <span className="ml-2">• Last synced {format(conn.lastSync, 'h:mm a')}</span>}
                      </p>
                    )}
                    {conn.dataPoints && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {conn.dataPoints.toLocaleString()} data points
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {conn.status === 'error' && (
                    <Button variant="destructive" size="sm">
                      Reconnect
                    </Button>
                  )}
                  {conn.status === 'syncing' && (
                    <Button variant="outline" size="sm" disabled>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Syncing...
                    </Button>
                  )}
                  {conn.status === 'connected' && (
                    <Button variant="outline" size="sm">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Sync Now
                    </Button>
                  )}
                  {conn.status === 'disconnected' && (
                    <Button size="sm">
                      <Link2 className="h-4 w-4 mr-2" />
                      Connect
                    </Button>
                  )}
                  <Button variant="ghost" size="icon">
                    <Settings className="h-4 w-4" />
                  </Button>
                  <Switch checked={conn.enabled} onCheckedChange={() => toggleConnection(conn.id)} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
