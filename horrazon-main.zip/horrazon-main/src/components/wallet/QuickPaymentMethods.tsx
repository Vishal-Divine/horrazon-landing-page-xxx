import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Plus, Check, Building2, Wallet, Shield, ChevronRight, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PaymentMethod {
  id: string;
  type: 'card' | 'bank' | 'wallet';
  name: string;
  last4?: string;
  expiry?: string;
  brand?: string;
  isDefault: boolean;
  icon?: string;
}

const mockPaymentMethods: PaymentMethod[] = [
  { id: '1', type: 'card', name: 'Visa', last4: '4242', expiry: '12/26', brand: 'visa', isDefault: true },
  { id: '2', type: 'card', name: 'Mastercard', last4: '8888', expiry: '03/25', brand: 'mastercard', isDefault: false },
  { id: '3', type: 'bank', name: 'Chase Business', last4: '7890', isDefault: false },
];

interface QuickPaymentMethodsProps {
  onSelectMethod?: (methodId: string) => void;
  onAddNew?: () => void;
  selectedMethodId?: string;
  compact?: boolean;
}

export default function QuickPaymentMethods({
  onSelectMethod,
  onAddNew,
  selectedMethodId,
  compact = false,
}: QuickPaymentMethodsProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case 'card':
        return CreditCard;
      case 'bank':
        return Building2;
      case 'wallet':
        return Wallet;
      default:
        return CreditCard;
    }
  };

  const getBrandColor = (brand?: string) => {
    switch (brand) {
      case 'visa':
        return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      case 'mastercard':
        return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'amex':
        return 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (compact) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">Payment Method</p>
          <Button variant="ghost" size="sm" className="h-6 text-xs gap-1" onClick={onAddNew}>
            <Plus className="h-3 w-3" />
            Add
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {mockPaymentMethods.slice(0, 2).map((method) => {
            const Icon = getIcon(method.type);
            const isSelected = selectedMethodId === method.id || (!selectedMethodId && method.isDefault);

            return (
              <button
                key={method.id}
                onClick={() => onSelectMethod?.(method.id)}
                className={cn(
                  'flex items-center gap-2 p-2.5 rounded-lg border transition-all text-left',
                  isSelected
                    ? 'border-primary bg-primary/5 ring-1 ring-primary'
                    : 'hover:bg-muted/50 hover:border-muted-foreground/20',
                )}
              >
                <div className={cn('p-1.5 rounded-md', getBrandColor(method.brand))}>
                  <Icon className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    {method.name} •••• {method.last4}
                  </p>
                  {method.expiry && <p className="text-[10px] text-muted-foreground">{method.expiry}</p>}
                </div>
                {isSelected && <Check className="h-3.5 w-3.5 text-primary shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <div className="p-1.5 rounded-lg bg-muted">
              <CreditCard className="h-4 w-4" />
            </div>
            Payment Methods
          </CardTitle>
          <Button variant="outline" size="sm" className="gap-1" onClick={onAddNew}>
            <Plus className="h-3.5 w-3.5" />
            Add New
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {mockPaymentMethods.map((method) => {
          const Icon = getIcon(method.type);
          const isSelected = selectedMethodId === method.id;

          return (
            <button
              key={method.id}
              onClick={() => onSelectMethod?.(method.id)}
              className={cn(
                'w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left',
                isSelected
                  ? 'border-primary bg-primary/5 ring-1 ring-primary'
                  : 'hover:bg-muted/50 hover:border-muted-foreground/20',
                method.isDefault && !isSelected && 'border-primary/30 bg-primary/5',
              )}
            >
              <div className={cn('p-2 rounded-lg', getBrandColor(method.brand))}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm">
                    {method.name} •••• {method.last4}
                  </p>
                  {method.isDefault && (
                    <Badge variant="outline" className="text-[9px] px-1.5 py-0 gap-0.5">
                      <Star className="h-2 w-2" />
                      Default
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {method.type === 'card' && method.expiry
                    ? `Expires ${method.expiry}`
                    : method.type === 'bank'
                      ? 'Bank Account'
                      : ''}
                </p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          );
        })}

        {/* Security Badge */}
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/20 mt-3">
          <Shield className="h-4 w-4 text-emerald-500" />
          <p className="text-xs text-emerald-600">All payment methods are encrypted and secure</p>
        </div>
      </CardContent>
    </Card>
  );
}
