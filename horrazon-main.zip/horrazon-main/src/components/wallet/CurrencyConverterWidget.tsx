import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Globe,
  ArrowRightLeft,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  DollarSign,
  Euro,
  PoundSterling,
  Info,
  Sparkles,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface Currency {
  code: string;
  name: string;
  symbol: string;
  rate: number;
  change24h: number;
  icon: React.ReactNode;
}

const currencies: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1, change24h: 0, icon: <DollarSign className="h-4 w-4" /> },
  { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.92, change24h: -0.15, icon: <Euro className="h-4 w-4" /> },
  {
    code: 'GBP',
    name: 'British Pound',
    symbol: '£',
    rate: 0.79,
    change24h: 0.22,
    icon: <PoundSterling className="h-4 w-4" />,
  },
  {
    code: 'CAD',
    name: 'Canadian Dollar',
    symbol: 'C$',
    rate: 1.36,
    change24h: -0.08,
    icon: <DollarSign className="h-4 w-4" />,
  },
  {
    code: 'AUD',
    name: 'Australian Dollar',
    symbol: 'A$',
    rate: 1.53,
    change24h: 0.31,
    icon: <DollarSign className="h-4 w-4" />,
  },
  {
    code: 'JPY',
    name: 'Japanese Yen',
    symbol: '¥',
    rate: 149.5,
    change24h: 0.45,
    icon: <span className="text-sm font-medium">¥</span>,
  },
  {
    code: 'INR',
    name: 'Indian Rupee',
    symbol: '₹',
    rate: 83.12,
    change24h: -0.12,
    icon: <span className="text-sm font-medium">₹</span>,
  },
  {
    code: 'SGD',
    name: 'Singapore Dollar',
    symbol: 'S$',
    rate: 1.34,
    change24h: 0.05,
    icon: <DollarSign className="h-4 w-4" />,
  },
];

export default function CurrencyConverterWidget() {
  const [fromCurrency, setFromCurrency] = useState<string>('USD');
  const [toCurrency, setToCurrency] = useState<string>('EUR');
  const [amount, setAmount] = useState<string>('1000');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated] = useState(new Date());

  const fromCurrencyData = currencies.find((c) => c.code === fromCurrency) || currencies[0];
  const toCurrencyData = currencies.find((c) => c.code === toCurrency) || currencies[1];

  const convertedAmount = (parseFloat(amount || '0') / fromCurrencyData.rate) * toCurrencyData.rate;
  const conversionRate = toCurrencyData.rate / fromCurrencyData.rate;

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const formatAmount = (value: number, currency: Currency) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.code,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-chart-2/20 to-chart-2/5">
              <Globe className="h-5 w-5 text-chart-2" />
            </div>
            <div>
              <CardTitle className="text-lg">Currency Converter</CardTitle>
              <CardDescription>Real-time exchange rates</CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={cn('h-4 w-4', isRefreshing && 'animate-spin')} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Converter Interface */}
        <div className="space-y-3">
          {/* From Currency */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">From</span>
              <Select value={fromCurrency} onValueChange={setFromCurrency}>
                <SelectTrigger className="w-[140px] h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      <div className="flex items-center gap-2">
                        {currency.icon}
                        <span>{currency.code}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl text-muted-foreground">{fromCurrencyData.symbol}</span>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="border-0 bg-transparent text-3xl font-bold p-0 h-auto focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="0"
              />
            </div>
          </div>

          {/* Swap Button */}
          <div className="flex justify-center -my-1">
            <Button
              variant="outline"
              size="icon"
              className="h-10 w-10 rounded-full bg-background shadow-md border-2 hover:bg-primary/10 hover:border-primary transition-all"
              onClick={swapCurrencies}
            >
              <ArrowRightLeft className="h-4 w-4 rotate-90" />
            </Button>
          </div>

          {/* To Currency */}
          <div className="p-4 rounded-xl bg-muted/50 border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">To</span>
              <Select value={toCurrency} onValueChange={setToCurrency}>
                <SelectTrigger className="w-[140px] h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      <div className="flex items-center gap-2">
                        {currency.icon}
                        <span>{currency.code}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl text-muted-foreground">{toCurrencyData.symbol}</span>
              <span className="text-3xl font-bold text-chart-2">
                {convertedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        {/* Exchange Rate Info */}
        <div className="p-3 rounded-lg bg-muted/30 border">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              <span className="text-muted-foreground">Exchange Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium">
                1 {fromCurrency} = {conversionRate.toFixed(4)} {toCurrency}
              </span>
              <Badge
                variant="outline"
                className={cn(
                  'text-[10px]',
                  toCurrencyData.change24h >= 0
                    ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                    : 'bg-destructive/10 text-destructive border-destructive/20',
                )}
              >
                {toCurrencyData.change24h >= 0 ? (
                  <TrendingUp className="h-2.5 w-2.5 mr-1" />
                ) : (
                  <TrendingDown className="h-2.5 w-2.5 mr-1" />
                )}
                {Math.abs(toCurrencyData.change24h)}%
              </Badge>
            </div>
          </div>
        </div>

        {/* Popular Currencies Quick View */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Popular Rates (vs USD)</p>
          <div className="grid grid-cols-4 gap-2">
            {currencies.slice(1, 5).map((currency) => (
              <div
                key={currency.code}
                className="p-2 rounded-lg bg-muted/30 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => setToCurrency(currency.code)}
              >
                <p className="text-xs font-medium">{currency.code}</p>
                <p className="text-[10px] text-muted-foreground">{currency.rate.toFixed(2)}</p>
                <div
                  className={cn(
                    'text-[9px] flex items-center justify-center gap-0.5',
                    currency.change24h >= 0 ? 'text-emerald-500' : 'text-destructive',
                  )}
                >
                  {currency.change24h >= 0 ? '↑' : '↓'}
                  {Math.abs(currency.change24h)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-2 border-t">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Updated {format(lastUpdated, 'h:mm a')}
          </div>
          <div className="flex items-center gap-1">
            <Info className="h-3 w-3" />
            Rates for reference only
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
