import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown, Calendar, AlertTriangle, CheckCircle2, Target, Sparkles } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { format, addDays, differenceInDays } from 'date-fns';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
} from 'recharts';

export default function BudgetForecastCard() {
  const { wallet, campaignSpends } = useApp();

  const avgDailySpend = wallet.dailySpent || 342.8;
  const runwayDays = Math.floor(wallet.balance / avgDailySpend);
  const depletionDate = addDays(new Date(), runwayDays);

  // Generate forecast data
  const forecastData = Array.from({ length: Math.min(runwayDays + 10, 30) }, (_, i) => {
    const projectedBalance = Math.max(0, wallet.balance - avgDailySpend * i);
    const optimisticBalance = Math.max(0, wallet.balance - avgDailySpend * 0.8 * i);
    const pessimisticBalance = Math.max(0, wallet.balance - avgDailySpend * 1.3 * i);

    return {
      day: i,
      date: format(addDays(new Date(), i), 'MMM d'),
      balance: projectedBalance,
      optimistic: optimisticBalance,
      pessimistic: pessimisticBalance,
      threshold: wallet.lowBalanceThreshold,
      critical: wallet.criticalBalanceThreshold,
    };
  });

  // Calculate campaign impact
  const totalDailyBudget = campaignSpends
    .filter((c) => c.status === 'active')
    .reduce((sum, c) => sum + c.dailyBudget, 0);

  const budgetUtilization = (avgDailySpend / totalDailyBudget) * 100;

  // Forecast insights
  const insights = [];

  if (runwayDays < 7) {
    insights.push({ type: 'critical', message: `Balance depletes in ${runwayDays} days`, icon: AlertTriangle });
  } else if (runwayDays < 14) {
    insights.push({ type: 'warning', message: `Low runway - ${runwayDays} days remaining`, icon: AlertTriangle });
  } else {
    insights.push({ type: 'success', message: `Healthy runway of ${runwayDays} days`, icon: CheckCircle2 });
  }

  if (budgetUtilization > 100) {
    insights.push({
      type: 'warning',
      message: `Spending ${(budgetUtilization - 100).toFixed(0)}% over daily budget`,
      icon: TrendingUp,
    });
  } else if (budgetUtilization < 80) {
    insights.push({
      type: 'info',
      message: `Underspending by ${(100 - budgetUtilization).toFixed(0)}%`,
      icon: TrendingDown,
    });
  }

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'critical':
        return 'text-destructive bg-destructive/10';
      case 'warning':
        return 'text-amber-500 bg-amber-500/10';
      case 'success':
        return 'text-emerald-500 bg-emerald-500/10';
      default:
        return 'text-primary bg-primary/10';
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-1.5 rounded-lg bg-chart-2/10">
                <Target className="h-4 w-4 text-chart-2" />
              </div>
              Budget Forecast
            </CardTitle>
            <CardDescription>Projected balance over the next {Math.min(runwayDays + 10, 30)} days</CardDescription>
          </div>
          <Badge
            variant="outline"
            className={
              runwayDays < 7
                ? 'border-destructive text-destructive'
                : runwayDays < 14
                  ? 'border-amber-500 text-amber-500'
                  : 'border-emerald-500 text-emerald-500'
            }
          >
            {runwayDays} days runway
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Forecast Chart */}
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={forecastData}>
              <defs>
                <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="date" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} />
              <YAxis
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => [
                  `$${value.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
                  name === 'balance' ? 'Projected' : name === 'optimistic' ? 'Best Case' : 'Worst Case',
                ]}
              />
              <ReferenceLine
                y={wallet.lowBalanceThreshold}
                stroke="hsl(var(--chart-3))"
                strokeDasharray="5 5"
                label={{ value: 'Low Balance', fontSize: 10, fill: 'hsl(var(--chart-3))' }}
              />
              <ReferenceLine
                y={wallet.criticalBalanceThreshold}
                stroke="hsl(var(--destructive))"
                strokeDasharray="5 5"
                label={{ value: 'Critical', fontSize: 10, fill: 'hsl(var(--destructive))' }}
              />
              <Area
                type="monotone"
                dataKey="optimistic"
                fill="none"
                stroke="hsl(var(--chart-4))"
                strokeDasharray="3 3"
                strokeWidth={1}
              />
              <Area
                type="monotone"
                dataKey="pessimistic"
                fill="none"
                stroke="hsl(var(--chart-3))"
                strokeDasharray="3 3"
                strokeWidth={1}
              />
              <Area
                type="monotone"
                dataKey="balance"
                fill="url(#balanceGradient)"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-muted/50 text-center">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Depletion Date</p>
            <p className="font-semibold text-sm">{format(depletionDate, 'MMM d')}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/50 text-center">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Avg Daily</p>
            <p className="font-semibold text-sm">${avgDailySpend.toFixed(0)}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/50 text-center">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Utilization</p>
            <p className="font-semibold text-sm">{budgetUtilization.toFixed(0)}%</p>
          </div>
        </div>

        {/* Insights */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
            <Sparkles className="h-3 w-3" />
            AI Insights
          </p>
          <div className="space-y-1.5">
            {insights.map((insight, i) => (
              <div key={i} className={`flex items-center gap-2 p-2 rounded-lg ${getInsightColor(insight.type)}`}>
                <insight.icon className="h-3.5 w-3.5 shrink-0" />
                <span className="text-xs font-medium">{insight.message}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
