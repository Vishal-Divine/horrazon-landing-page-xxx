import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Database,
  ArrowRight,
  Plus,
  Trash2,
  Settings,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  GitBranch,
  Layers,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DataMapping {
  id: string;
  sourcePlatform: string;
  sourceIcon: string;
  sourceField: string;
  targetField: string;
  transformation?: string;
  enabled: boolean;
  validated: boolean;
}

interface MappingGroup {
  id: string;
  name: string;
  description: string;
  mappings: DataMapping[];
  status: 'active' | 'draft' | 'error';
}

const mappingGroups: MappingGroup[] = [
  {
    id: '1',
    name: 'Meta Ads → Analytics',
    description: 'Map Meta campaign data to unified analytics schema',
    status: 'active',
    mappings: [
      {
        id: 'm1',
        sourcePlatform: 'Meta',
        sourceIcon: '📘',
        sourceField: 'campaign_name',
        targetField: 'campaign_title',
        enabled: true,
        validated: true,
      },
      {
        id: 'm2',
        sourcePlatform: 'Meta',
        sourceIcon: '📘',
        sourceField: 'spend',
        targetField: 'cost',
        transformation: 'currency_convert',
        enabled: true,
        validated: true,
      },
      {
        id: 'm3',
        sourcePlatform: 'Meta',
        sourceIcon: '📘',
        sourceField: 'impressions',
        targetField: 'impressions',
        enabled: true,
        validated: true,
      },
      {
        id: 'm4',
        sourcePlatform: 'Meta',
        sourceIcon: '📘',
        sourceField: 'link_clicks',
        targetField: 'clicks',
        enabled: true,
        validated: true,
      },
    ],
  },
  {
    id: '2',
    name: 'Google Ads → Analytics',
    description: 'Map Google campaign metrics to unified schema',
    status: 'active',
    mappings: [
      {
        id: 'g1',
        sourcePlatform: 'Google',
        sourceIcon: '🎯',
        sourceField: 'campaign',
        targetField: 'campaign_title',
        enabled: true,
        validated: true,
      },
      {
        id: 'g2',
        sourcePlatform: 'Google',
        sourceIcon: '🎯',
        sourceField: 'cost_micros',
        targetField: 'cost',
        transformation: 'divide_by_million',
        enabled: true,
        validated: true,
      },
      {
        id: 'g3',
        sourcePlatform: 'Google',
        sourceIcon: '🎯',
        sourceField: 'clicks',
        targetField: 'clicks',
        enabled: true,
        validated: true,
      },
    ],
  },
  {
    id: '3',
    name: 'Transaction Mapping',
    description: 'Map payment data from Stripe to wallet records',
    status: 'active',
    mappings: [
      {
        id: 's1',
        sourcePlatform: 'Stripe',
        sourceIcon: '💳',
        sourceField: 'amount',
        targetField: 'transaction_amount',
        transformation: 'cents_to_dollars',
        enabled: true,
        validated: true,
      },
      {
        id: 's2',
        sourcePlatform: 'Stripe',
        sourceIcon: '💳',
        sourceField: 'created',
        targetField: 'transaction_date',
        transformation: 'unix_to_date',
        enabled: true,
        validated: true,
      },
      {
        id: 's3',
        sourcePlatform: 'Stripe',
        sourceIcon: '💳',
        sourceField: 'status',
        targetField: 'payment_status',
        enabled: true,
        validated: false,
      },
    ],
  },
];

export default function WalletDataMapping() {
  const [groups, setGroups] = useState(mappingGroups);
  const [selectedGroup, setSelectedGroup] = useState<string | null>('1');

  const currentGroup = groups.find((g) => g.id === selectedGroup);

  const toggleMapping = (groupId: string, mappingId: string) => {
    setGroups((prev) =>
      prev.map((group) => {
        if (group.id === groupId) {
          return {
            ...group,
            mappings: group.mappings.map((m) => (m.id === mappingId ? { ...m, enabled: !m.enabled } : m)),
          };
        }
        return group;
      }),
    );
  };

  const totalMappings = groups.reduce((sum, g) => sum + g.mappings.length, 0);
  const activeMappings = groups.reduce((sum, g) => sum + g.mappings.filter((m) => m.enabled).length, 0);
  const validatedMappings = groups.reduce((sum, g) => sum + g.mappings.filter((m) => m.validated).length, 0);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <GitBranch className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{groups.length}</p>
                <p className="text-sm text-muted-foreground">Mapping Groups</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <Layers className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalMappings}</p>
                <p className="text-sm text-muted-foreground">Total Mappings</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <CheckCircle2 className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeMappings}</p>
                <p className="text-sm text-muted-foreground">Active Mappings</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalMappings - validatedMappings}</p>
                <p className="text-sm text-muted-foreground">Needs Validation</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Mapping Groups List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Mapping Groups</CardTitle>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {groups.map((group) => (
              <div
                key={group.id}
                onClick={() => setSelectedGroup(group.id)}
                className={cn(
                  'p-4 rounded-lg border cursor-pointer transition-all hover:shadow-sm',
                  selectedGroup === group.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50',
                )}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-sm">{group.name}</h4>
                  <Badge variant={group.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                    {group.status}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">{group.description}</p>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <span>{group.mappings.length} mappings</span>
                  <span>•</span>
                  <span>{group.mappings.filter((m) => m.enabled).length} active</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Mapping Details */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  {currentGroup?.name || 'Select a Group'}
                </CardTitle>
                <CardDescription>
                  {currentGroup?.description || 'Choose a mapping group to view details'}
                </CardDescription>
              </div>
              {currentGroup && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Auto-Map
                  </Button>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Field
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {currentGroup ? (
              <div className="space-y-3">
                {currentGroup.mappings.map((mapping) => (
                  <div
                    key={mapping.id}
                    className={cn(
                      'flex items-center gap-4 p-4 rounded-lg border transition-all',
                      mapping.enabled ? 'border-border' : 'border-border/50 bg-muted/30 opacity-60',
                    )}
                  >
                    {/* Source */}
                    <div className="flex items-center gap-2 min-w-[180px]">
                      <span className="text-xl">{mapping.sourceIcon}</span>
                      <div>
                        <p className="text-xs text-muted-foreground">{mapping.sourcePlatform}</p>
                        <p className="font-mono text-sm">{mapping.sourceField}</p>
                      </div>
                    </div>

                    {/* Arrow with transformation */}
                    <div className="flex-1 flex items-center justify-center gap-2">
                      <div className="h-px flex-1 bg-border" />
                      {mapping.transformation ? (
                        <Badge variant="outline" className="text-xs font-mono">
                          {mapping.transformation}
                        </Badge>
                      ) : (
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      )}
                      <div className="h-px flex-1 bg-border" />
                    </div>

                    {/* Target */}
                    <div className="min-w-[140px]">
                      <p className="text-xs text-muted-foreground">Target Field</p>
                      <p className="font-mono text-sm">{mapping.targetField}</p>
                    </div>

                    {/* Status */}
                    <div className="flex items-center gap-3">
                      {mapping.validated ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                      )}
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Settings className="h-4 w-4" />
                      </Button>
                      <Switch
                        checked={mapping.enabled}
                        onCheckedChange={() => toggleMapping(currentGroup.id, mapping.id)}
                      />
                    </div>
                  </div>
                ))}

                <Button variant="outline" className="w-full mt-4">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Validate All Mappings
                </Button>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Database className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select a mapping group to view and edit field mappings</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
