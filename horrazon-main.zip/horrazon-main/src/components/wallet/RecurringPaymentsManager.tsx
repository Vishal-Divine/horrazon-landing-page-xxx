import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import {
  Calendar,
  Plus,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Pause,
  Play,
  Edit,
  Trash2,
  ChevronRight,
  CreditCard,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  CalendarDays,
  Bell,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, addDays, differenceInDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import { toast } from '@/hooks/use-toast';

interface RecurringPayment {
  id: string;
  name: string;
  amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  nextPayment: Date;
  category: 'subscription' | 'advertising' | 'service' | 'utility';
  status: 'active' | 'paused' | 'failed';
  icon: string;
  color: string;
  lastPayment?: Date;
  totalPaid: number;
}

const mockPayments: RecurringPayment[] = [
  {
    id: '1',
    name: 'Meta Ads Auto-charge',
    amount: 2500,
    frequency: 'weekly',
    nextPayment: addDays(new Date(), 3),
    category: 'advertising',
    status: 'active',
    icon: '📘',
    color: 'from-blue-500 to-indigo-500',
    lastPayment: addDays(new Date(), -4),
    totalPaid: 32500,
  },
  {
    id: '2',
    name: 'Google Ads Budget',
    amount: 1500,
    frequency: 'weekly',
    nextPayment: addDays(new Date(), 5),
    category: 'advertising',
    status: 'active',
    icon: '🎯',
    color: 'from-emerald-500 to-teal-500',
    lastPayment: addDays(new Date(), -2),
    totalPaid: 24000,
  },
  {
    id: '3',
    name: 'Analytics Pro Plan',
    amount: 299,
    frequency: 'monthly',
    nextPayment: addDays(new Date(), 12),
    category: 'subscription',
    status: 'active',
    icon: '📊',
    color: 'from-violet-500 to-purple-500',
    lastPayment: addDays(new Date(), -18),
    totalPaid: 2990,
  },
  {
    id: '4',
    name: 'TikTok Ads Credit',
    amount: 800,
    frequency: 'monthly',
    nextPayment: addDays(new Date(), 8),
    category: 'advertising',
    status: 'paused',
    icon: '🎵',
    color: 'from-rose-500 to-pink-500',
    lastPayment: addDays(new Date(), -22),
    totalPaid: 4800,
  },
];

const getFrequencyLabel = (frequency: string) => {
  switch (frequency) {
    case 'daily':
      return 'Daily';
    case 'weekly':
      return 'Weekly';
    case 'monthly':
      return 'Monthly';
    case 'quarterly':
      return 'Quarterly';
    default:
      return frequency;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'advertising':
      return 'bg-primary/10 text-primary border-primary/30';
    case 'subscription':
      return 'bg-violet-500/10 text-violet-600 border-violet-500/30';
    case 'service':
      return 'bg-amber-500/10 text-amber-600 border-amber-500/30';
    case 'utility':
      return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

export default function RecurringPaymentsManager() {
  const [payments, setPayments] = useState(mockPayments);
  const [selectedView, setSelectedView] = useState<'list' | 'calendar'>('list');

  const togglePayment = (paymentId: string) => {
    setPayments((prev) =>
      prev.map((payment) => {
        if (payment.id === paymentId) {
          const newStatus = payment.status === 'active' ? 'paused' : 'active';
          toast({
            title: newStatus === 'active' ? 'Payment Resumed' : 'Payment Paused',
            description: `${payment.name} is now ${newStatus}.`,
          });
          return { ...payment, status: newStatus as 'active' | 'paused' };
        }
        return payment;
      }),
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const totalMonthlySpend = payments
    .filter((p) => p.status === 'active')
    .reduce((sum, p) => {
      switch (p.frequency) {
        case 'daily':
          return sum + p.amount * 30;
        case 'weekly':
          return sum + p.amount * 4;
        case 'monthly':
          return sum + p.amount;
        case 'quarterly':
          return sum + p.amount / 3;
        default:
          return sum;
      }
    }, 0);

  const upcomingPayments = [...payments]
    .filter((p) => p.status === 'active')
    .sort((a, b) => a.nextPayment.getTime() - b.nextPayment.getTime())
    .slice(0, 3);

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(new Date()),
    end: endOfMonth(new Date()),
  });

  const getPaymentsOnDay = (day: Date) => {
    return payments.filter((p) => isSameDay(p.nextPayment, day));
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500">
              <RefreshCw className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Recurring Payments</CardTitle>
              <CardDescription>Manage subscriptions & auto-charges</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-muted/50 rounded-lg p-0.5">
              <Button
                variant={selectedView === 'list' ? 'secondary' : 'ghost'}
                size="sm"
                className="text-xs h-7 px-2"
                onClick={() => setSelectedView('list')}
              >
                List
              </Button>
              <Button
                variant={selectedView === 'calendar' ? 'secondary' : 'ghost'}
                size="sm"
                className="text-xs h-7 px-2"
                onClick={() => setSelectedView('calendar')}
              >
                Calendar
              </Button>
            </div>
            <Button variant="outline" size="sm" className="gap-1">
              <Plus className="h-3.5 w-3.5" />
              Add
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Monthly Summary */}
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Monthly Total</span>
            </div>
            <p className="text-xl font-bold text-primary">{formatCurrency(totalMonthlySpend)}</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span className="text-xs text-muted-foreground">Active</span>
            </div>
            <p className="text-xl font-bold text-emerald-600">{payments.filter((p) => p.status === 'active').length}</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 to-amber-500/5 border border-amber-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-amber-500" />
              <span className="text-xs text-muted-foreground">Next 7 days</span>
            </div>
            <p className="text-xl font-bold text-amber-600">
              {formatCurrency(upcomingPayments.reduce((sum, p) => sum + p.amount, 0))}
            </p>
          </div>
        </div>

        {/* Upcoming Payments Alert */}
        {upcomingPayments.length > 0 && (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/20">
            <Bell className="h-5 w-5 text-amber-500 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium">
                {upcomingPayments[0].name} due in {differenceInDays(upcomingPayments[0].nextPayment, new Date())} days
              </p>
              <p className="text-xs text-muted-foreground">
                {formatCurrency(upcomingPayments[0].amount)} on {format(upcomingPayments[0].nextPayment, 'MMM d')}
              </p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
        )}

        {selectedView === 'list' ? (
          /* Payments List */
          <div className="space-y-3">
            {payments.map((payment) => {
              const daysUntil = differenceInDays(payment.nextPayment, new Date());

              return (
                <div
                  key={payment.id}
                  className={cn(
                    'group p-4 rounded-xl border transition-all duration-200',
                    payment.status === 'active'
                      ? 'bg-card hover:bg-muted/30 border-border'
                      : 'bg-muted/30 border-border/50 opacity-70',
                  )}
                >
                  <div className="flex items-center gap-4">
                    {/* Icon */}
                    <div
                      className={cn('p-3 rounded-xl bg-gradient-to-br text-xl flex-shrink-0', payment.color + '/10')}
                    >
                      {payment.icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h5 className="font-medium text-sm">{payment.name}</h5>
                        <Badge variant="outline" className={cn('text-[10px]', getCategoryColor(payment.category))}>
                          {getFrequencyLabel(payment.frequency)}
                        </Badge>
                        {payment.status === 'paused' && (
                          <Badge variant="secondary" className="text-[10px] bg-muted">
                            Paused
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {payment.status === 'active'
                            ? `Next: ${format(payment.nextPayment, 'MMM d')} (${daysUntil}d)`
                            : 'Paused'}
                        </span>
                        <span className="flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          Total: {formatCurrency(payment.totalPaid)}
                        </span>
                      </div>
                    </div>

                    {/* Amount */}
                    <div className="text-right">
                      <p className="font-semibold text-foreground">{formatCurrency(payment.amount)}</p>
                      <p className="text-xs text-muted-foreground">/{payment.frequency}</p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => togglePayment(payment.id)}>
                        {payment.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* Calendar View */
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-sm flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-muted-foreground" />
                {format(new Date(), 'MMMM yyyy')}
              </h4>
            </div>

            <div className="grid grid-cols-7 gap-1">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}

              {daysInMonth.map((day, index) => {
                const paymentsOnDay = getPaymentsOnDay(day);
                const isToday = isSameDay(day, new Date());
                const dayOfWeek = day.getDay();

                return (
                  <div
                    key={index}
                    className={cn(
                      'aspect-square p-1 rounded-lg border transition-colors',
                      isToday ? 'bg-primary/10 border-primary/30' : 'border-transparent hover:bg-muted/50',
                      paymentsOnDay.length > 0 && 'bg-amber-500/5 border-amber-500/20',
                    )}
                  >
                    <div
                      className={cn(
                        'text-xs text-center mb-0.5',
                        isToday ? 'font-bold text-primary' : 'text-muted-foreground',
                      )}
                    >
                      {format(day, 'd')}
                    </div>
                    {paymentsOnDay.length > 0 && (
                      <div className="flex justify-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border/50">
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            <CreditCard className="h-3.5 w-3.5" />
            Manage Payment Methods
          </Button>
          <Button variant="outline" size="sm" className="text-xs gap-1">
            View All Transactions
            <ChevronRight className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
