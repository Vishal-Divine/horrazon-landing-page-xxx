import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  RefreshCw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Download,
  Filter,
  Search,
  Activity,
  Database,
  ArrowDownUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface SyncLog {
  id: string;
  source: string;
  sourceIcon: string;
  action: string;
  status: 'success' | 'error' | 'warning' | 'pending';
  timestamp: Date;
  duration: number;
  recordsProcessed?: number;
  details?: string;
}

const syncLogs: SyncLog[] = [
  {
    id: '1',
    source: 'Meta Ads',
    sourceIcon: '📘',
    action: 'Full data sync',
    status: 'success',
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    duration: 12.4,
    recordsProcessed: 1250,
  },
  {
    id: '2',
    source: 'Google Ads',
    sourceIcon: '🎯',
    action: 'Incremental update',
    status: 'success',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    duration: 3.2,
    recordsProcessed: 89,
  },
  {
    id: '3',
    source: 'Stripe',
    sourceIcon: '💳',
    action: 'Transaction sync',
    status: 'success',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    duration: 8.7,
    recordsProcessed: 456,
  },
  {
    id: '4',
    source: 'HubSpot',
    sourceIcon: '🧲',
    action: 'Contact sync',
    status: 'error',
    timestamp: new Date(Date.now() - 45 * 60 * 1000),
    duration: 0,
    details: 'Authentication token expired',
  },
  {
    id: '5',
    source: 'TikTok Ads',
    sourceIcon: '🎵',
    action: 'Campaign data sync',
    status: 'pending',
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    duration: 0,
  },
  {
    id: '6',
    source: 'LinkedIn Ads',
    sourceIcon: '💼',
    action: 'Analytics fetch',
    status: 'warning',
    timestamp: new Date(Date.now() - 90 * 60 * 1000),
    duration: 45.3,
    recordsProcessed: 234,
    details: 'Partial data retrieved',
  },
  {
    id: '7',
    source: 'Google Analytics',
    sourceIcon: '📊',
    action: 'Full data sync',
    status: 'success',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    duration: 25.1,
    recordsProcessed: 5420,
  },
  {
    id: '8',
    source: 'Meta Ads',
    sourceIcon: '📘',
    action: 'Creative performance sync',
    status: 'success',
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    duration: 18.9,
    recordsProcessed: 892,
  },
];

export default function WalletSyncLogs() {
  const [logs] = useState(syncLogs);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'pending':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30">Success</Badge>;
      case 'error':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/30">Error</Badge>;
      case 'warning':
        return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/30">Warning</Badge>;
      case 'pending':
        return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/30">In Progress</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const filteredLogs = logs.filter((log) => {
    const matchesFilter = filter === 'all' || log.status === filter;
    const matchesSearch =
      log.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const successRate = Math.round((logs.filter((l) => l.status === 'success').length / logs.length) * 100);
  const totalRecords = logs.reduce((sum, l) => sum + (l.recordsProcessed || 0), 0);
  const avgDuration =
    logs.filter((l) => l.duration > 0).reduce((sum, l) => sum + l.duration, 0) /
    logs.filter((l) => l.duration > 0).length;

  return (
    <div className="space-y-6">
      {/* Stats Row */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{successRate}%</p>
                <p className="text-sm text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Database className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalRecords.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Records Synced</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{avgDuration.toFixed(1)}s</p>
                <p className="text-sm text-muted-foreground">Avg. Duration</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{logs.filter((l) => l.status === 'error').length}</p>
                <p className="text-sm text-muted-foreground">Failed Syncs</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Sync Activity Log
              </CardTitle>
              <CardDescription>Real-time synchronization history and status</CardDescription>
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 w-64"
                />
              </div>
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-40">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-2">
              {filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className={cn(
                    'flex items-center justify-between p-4 rounded-lg border transition-all hover:shadow-sm',
                    log.status === 'error' && 'border-destructive/30 bg-destructive/5',
                    log.status === 'warning' && 'border-amber-500/30 bg-amber-500/5',
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-muted/50 text-xl">
                      {log.sourceIcon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{log.source}</h4>
                        {getStatusBadge(log.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {log.action}
                        {log.details && <span className="ml-2 text-xs">• {log.details}</span>}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 text-sm">
                    {log.recordsProcessed && (
                      <div className="text-right">
                        <p className="font-medium">{log.recordsProcessed.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">records</p>
                      </div>
                    )}
                    {log.duration > 0 && (
                      <div className="text-right">
                        <p className="font-medium">{log.duration.toFixed(1)}s</p>
                        <p className="text-xs text-muted-foreground">duration</p>
                      </div>
                    )}
                    <div className="text-right min-w-[100px]">
                      <p className="font-medium">{format(log.timestamp, 'h:mm a')}</p>
                      <p className="text-xs text-muted-foreground">{format(log.timestamp, 'MMM d')}</p>
                    </div>
                    <div className="w-8 flex justify-center">{getStatusIcon(log.status)}</div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
