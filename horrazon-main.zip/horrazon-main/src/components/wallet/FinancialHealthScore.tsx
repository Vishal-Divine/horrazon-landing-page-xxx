import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Heart,
  TrendingUp,
  TrendingDown,
  Shield,
  Zap,
  Target,
  AlertTriangle,
  CheckCircle2,
  Info,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/contexts/AppContext';
import { useMemo } from 'react';

interface HealthMetric {
  id: string;
  label: string;
  value: number;
  maxValue: number;
  status: 'excellent' | 'good' | 'warning' | 'critical';
  icon: React.ElementType;
  description: string;
}

const getScoreColor = (score: number) => {
  if (score >= 80) return 'text-emerald-500';
  if (score >= 60) return 'text-amber-500';
  if (score >= 40) return 'text-orange-500';
  return 'text-destructive';
};

const getScoreGradient = (score: number) => {
  if (score >= 80) return 'from-emerald-500 to-teal-500';
  if (score >= 60) return 'from-amber-500 to-yellow-500';
  if (score >= 40) return 'from-orange-500 to-amber-500';
  return 'from-destructive to-red-400';
};

const getScoreLabel = (score: number) => {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Needs Attention';
  return 'Critical';
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'excellent':
      return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30';
    case 'good':
      return 'bg-primary/10 text-primary border-primary/30';
    case 'warning':
      return 'bg-amber-500/10 text-amber-500 border-amber-500/30';
    case 'critical':
      return 'bg-destructive/10 text-destructive border-destructive/30';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

export default function FinancialHealthScore() {
  const { wallet, campaignSpends, transactions } = useApp();

  const healthData = useMemo(() => {
    // Calculate various health metrics
    const avgDailySpend = wallet.monthlySpent / 30;
    const runwayDays = Math.floor(wallet.balance / (avgDailySpend || 1));
    const balanceUtilization = Math.min(100, (wallet.balance / (wallet.totalSpent || 1)) * 100);

    // Budget adherence
    const totalBudget = campaignSpends.reduce((sum, c) => sum + c.budget, 0);
    const totalSpent = campaignSpends.reduce((sum, c) => sum + c.spent, 0);
    const budgetAdherence =
      totalBudget > 0 ? Math.min(100, 100 - Math.abs((totalSpent / totalBudget) * 100 - 100)) : 100;

    // Risk score (inverse of high-risk campaigns)
    const highRiskCampaigns = campaignSpends.filter((c) => c.riskLevel === 'critical' || c.riskLevel === 'high').length;
    const riskScore = Math.max(0, 100 - highRiskCampaigns * 25);

    // Consistency score based on spending pattern
    const consistencyScore = runwayDays > 30 ? 90 : runwayDays > 14 ? 70 : runwayDays > 7 ? 50 : 30;

    // Overall health score (weighted average)
    const overallScore = Math.round(
      balanceUtilization * 0.2 + budgetAdherence * 0.3 + riskScore * 0.25 + consistencyScore * 0.25,
    );

    const metrics: HealthMetric[] = [
      {
        id: 'runway',
        label: 'Runway Health',
        value: consistencyScore,
        maxValue: 100,
        status:
          consistencyScore >= 70
            ? 'excellent'
            : consistencyScore >= 50
              ? 'good'
              : consistencyScore >= 30
                ? 'warning'
                : 'critical',
        icon: Shield,
        description: `${runwayDays} days of runway remaining`,
      },
      {
        id: 'budget',
        label: 'Budget Adherence',
        value: Math.round(budgetAdherence),
        maxValue: 100,
        status:
          budgetAdherence >= 80
            ? 'excellent'
            : budgetAdherence >= 60
              ? 'good'
              : budgetAdherence >= 40
                ? 'warning'
                : 'critical',
        icon: Target,
        description: 'Staying within campaign budgets',
      },
      {
        id: 'risk',
        label: 'Risk Level',
        value: Math.round(riskScore),
        maxValue: 100,
        status: riskScore >= 80 ? 'excellent' : riskScore >= 60 ? 'good' : riskScore >= 40 ? 'warning' : 'critical',
        icon: AlertTriangle,
        description: `${highRiskCampaigns} campaign${highRiskCampaigns !== 1 ? 's' : ''} at risk`,
      },
      {
        id: 'efficiency',
        label: 'Spend Efficiency',
        value: Math.round(balanceUtilization),
        maxValue: 100,
        status:
          balanceUtilization >= 70
            ? 'excellent'
            : balanceUtilization >= 50
              ? 'good'
              : balanceUtilization >= 30
                ? 'warning'
                : 'critical',
        icon: Zap,
        description: 'Optimal fund utilization',
      },
    ];

    return { overallScore, metrics, runwayDays };
  }, [wallet, campaignSpends, transactions]);

  const { overallScore, metrics, runwayDays } = healthData;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn('p-2.5 rounded-xl bg-gradient-to-br', getScoreGradient(overallScore))}>
              <Heart className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Financial Health</CardTitle>
              <CardDescription>Your wallet wellness score</CardDescription>
            </div>
          </div>
          <Badge
            variant="outline"
            className={cn(
              'font-semibold',
              getStatusColor(
                overallScore >= 80
                  ? 'excellent'
                  : overallScore >= 60
                    ? 'good'
                    : overallScore >= 40
                      ? 'warning'
                      : 'critical',
              ),
            )}
          >
            {getScoreLabel(overallScore)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Main Score Display */}
        <div className="flex items-center gap-6 p-4 rounded-2xl bg-gradient-to-br from-muted/50 to-muted/20">
          {/* Circular Score */}
          <div className="relative flex-shrink-0">
            <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
              {/* Background Circle */}
              <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
              {/* Progress Circle */}
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="url(#scoreGradient)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${overallScore * 2.64} 264`}
                className="transition-all duration-1000 ease-out"
              />
              <defs>
                <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor={overallScore >= 60 ? '#10b981' : '#ef4444'} />
                  <stop offset="100%" stopColor={overallScore >= 60 ? '#14b8a6' : '#f97316'} />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={cn('text-3xl font-bold', getScoreColor(overallScore))}>{overallScore}</span>
              <span className="text-xs text-muted-foreground">/ 100</span>
            </div>
          </div>

          {/* Score Breakdown Summary */}
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-2">
              {overallScore >= 60 ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-amber-500" />
              )}
              <span className="font-medium">
                {overallScore >= 80
                  ? 'Your wallet is in great shape!'
                  : overallScore >= 60
                    ? 'Good performance with room for improvement'
                    : 'Action needed to optimize your wallet'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-muted-foreground">{runwayDays}d runway</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-muted-foreground">
                  {metrics.filter((m) => m.status === 'excellent').length}/4 metrics optimal
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Metrics */}
        <div className="space-y-3">
          {metrics.map((metric) => {
            const Icon = metric.icon;
            return (
              <div
                key={metric.id}
                className="group flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors cursor-pointer"
              >
                <div className={cn('p-2 rounded-lg', getStatusColor(metric.status))}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-sm">{metric.label}</span>
                    <span className={cn('text-sm font-semibold', getScoreColor(metric.value))}>{metric.value}%</span>
                  </div>
                  <Progress value={metric.value} className="h-1.5 bg-muted" />
                  <p className="text-xs text-muted-foreground mt-1">{metric.description}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        {overallScore < 80 && (
          <Button variant="outline" className="w-full gap-2">
            <Info className="h-4 w-4" />
            Get Personalized Recommendations
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
