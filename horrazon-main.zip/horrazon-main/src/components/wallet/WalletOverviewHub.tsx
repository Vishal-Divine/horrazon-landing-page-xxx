import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Clock,
  Shield,
  Zap,
  PiggyBank,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  RefreshCw,
  CircleDollarSign,
  BarChart3,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export default function WalletOverviewHub() {
  const { wallet, transactions, refreshWallet, isLoading, setIsAddFundsOpen } = useApp();
  const [showBalance, setShowBalance] = useState(true);
  const [activeView, setActiveView] = useState<'overview' | 'analytics' | 'security'>('overview');

  const formatCurrency = (amount: number) => {
    if (!showBalance) return '••••••';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  // Calculate trends
  const avgDailySpend = wallet.monthlySpent / 30;
  const runwayDays = Math.floor(wallet.balance / (avgDailySpend || 1));
  const spendingTrend = wallet.dailySpent > avgDailySpend ? 'up' : 'down';
  const trendPercent = Math.abs(((wallet.dailySpent - avgDailySpend) / avgDailySpend) * 100);

  // Recent activity
  const recentTransactions = transactions.slice(0, 3);
  const todaySpend = wallet.dailySpent;
  const weekSpend = wallet.monthlySpent * (7 / 30);

  // Health score calculation
  const balanceHealth =
    wallet.balance > wallet.lowBalanceThreshold * 2 ? 100 : wallet.balance > wallet.lowBalanceThreshold ? 70 : 40;
  const spendingHealth = trendPercent < 20 ? 100 : trendPercent < 50 ? 70 : 40;
  const overallHealth = Math.round((balanceHealth + spendingHealth) / 2);

  return (
    <Card className="overflow-hidden border-0 shadow-xl bg-gradient-to-br from-background via-background to-primary/5">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-inner">
              <Wallet className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl flex items-center gap-2">
                Wallet Command Center
                <Badge variant="outline" className="text-[10px] font-normal bg-primary/5">
                  <Sparkles className="h-3 w-3 mr-1" />
                  Live
                </Badge>
              </CardTitle>
              <CardDescription>Real-time financial intelligence</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowBalance(!showBalance)}>
              {showBalance ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => refreshWallet()}
              disabled={isLoading}
            >
              <RefreshCw className={cn('h-4 w-4', isLoading && 'animate-spin')} />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Primary Balance Display */}
        <div className="relative p-6 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-chart-2/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />

          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground flex items-center gap-1.5 mb-1">
                  <CircleDollarSign className="h-4 w-4" />
                  Available Balance
                </p>
                <p className="text-4xl font-bold tracking-tight text-primary">{formatCurrency(wallet.balance)}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge
                    variant="secondary"
                    className={cn(
                      'text-xs',
                      wallet.balance < wallet.lowBalanceThreshold
                        ? 'bg-amber-500/10 text-amber-500'
                        : 'bg-emerald-500/10 text-emerald-500',
                    )}
                  >
                    <Clock className="h-3 w-3 mr-1" />
                    {runwayDays} days runway
                  </Badge>
                </div>
              </div>
              <div className="text-right space-y-2">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Pending</p>
                  <p className="text-lg font-semibold text-chart-3">{formatCurrency(wallet.pendingCharges)}</p>
                </div>
                <div
                  className={cn(
                    'flex items-center gap-1 text-xs font-medium',
                    spendingTrend === 'up' ? 'text-amber-500' : 'text-emerald-500',
                  )}
                >
                  {spendingTrend === 'up' ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {trendPercent.toFixed(0)}% vs avg
                </div>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-4 gap-2">
              <div className="p-3 rounded-xl bg-background/60 backdrop-blur-sm text-center border border-border/50">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Today</p>
                <p className="text-sm font-bold">{formatCurrency(todaySpend)}</p>
              </div>
              <div className="p-3 rounded-xl bg-background/60 backdrop-blur-sm text-center border border-border/50">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">This Week</p>
                <p className="text-sm font-bold">{formatCurrency(weekSpend)}</p>
              </div>
              <div className="p-3 rounded-xl bg-background/60 backdrop-blur-sm text-center border border-border/50">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">This Month</p>
                <p className="text-sm font-bold">{formatCurrency(wallet.monthlySpent)}</p>
              </div>
              <div className="p-3 rounded-xl bg-background/60 backdrop-blur-sm text-center border border-border/50">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">All Time</p>
                <p className="text-sm font-bold">{formatCurrency(wallet.totalSpent)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Metrics Row */}
        <div className="grid grid-cols-3 gap-3">
          {/* Health Score */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20">
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-emerald-500/20">
                <Shield className="h-4 w-4 text-emerald-500" />
              </div>
              <span
                className={cn(
                  'text-2xl font-bold',
                  overallHealth >= 70
                    ? 'text-emerald-500'
                    : overallHealth >= 50
                      ? 'text-amber-500'
                      : 'text-destructive',
                )}
              >
                {overallHealth}
              </span>
            </div>
            <p className="text-xs font-medium">Financial Health</p>
            <Progress value={overallHealth} className="h-1.5 mt-2" />
          </div>

          {/* Savings Rate */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-primary/20">
                <PiggyBank className="h-4 w-4 text-primary" />
              </div>
              <span className="text-2xl font-bold text-primary">
                {Math.round((1 - wallet.monthlySpent / (wallet.balance + wallet.monthlySpent)) * 100)}%
              </span>
            </div>
            <p className="text-xs font-medium">Efficiency Rate</p>
            <Progress
              value={(1 - wallet.monthlySpent / (wallet.balance + wallet.monthlySpent)) * 100}
              className="h-1.5 mt-2"
            />
          </div>

          {/* Quick Action */}
          <div
            className="p-4 rounded-xl bg-gradient-to-br from-chart-2/10 to-chart-2/5 border border-chart-2/20 cursor-pointer hover:border-chart-2/40 transition-all group"
            onClick={() => setIsAddFundsOpen(true)}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-chart-2/20">
                <Zap className="h-4 w-4 text-chart-2" />
              </div>
              <ArrowUpRight className="h-4 w-4 text-chart-2 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
            <p className="text-xs font-medium">Quick Top-Up</p>
            <p className="text-[10px] text-muted-foreground mt-1">Add funds instantly</p>
          </div>
        </div>

        {/* Recent Activity Preview */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
              <BarChart3 className="h-3.5 w-3.5" />
              Recent Activity
            </p>
            <p className="text-[10px] text-muted-foreground">Updated {format(wallet.lastUpdated, 'h:mm a')}</p>
          </div>
          <div className="space-y-1.5">
            {recentTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-2.5 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <div className={cn('p-1.5 rounded-lg', tx.type === 'credit' ? 'bg-emerald-500/10' : 'bg-primary/10')}>
                    {tx.type === 'credit' ? (
                      <ArrowDownRight className="h-3.5 w-3.5 text-emerald-500" />
                    ) : (
                      <ArrowUpRight className="h-3.5 w-3.5 text-primary" />
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-medium">{tx.description}</p>
                    <p className="text-[10px] text-muted-foreground">{format(tx.date, 'MMM d, h:mm a')}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p
                    className={cn(
                      'text-sm font-semibold',
                      tx.type === 'credit' ? 'text-emerald-500' : 'text-foreground',
                    )}
                  >
                    {tx.type === 'credit' ? '+' : '-'}
                    {formatCurrency(tx.amount)}
                  </p>
                  <Badge variant="outline" className="text-[9px]">
                    {tx.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
