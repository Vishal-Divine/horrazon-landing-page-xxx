import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Target,
  Plus,
  Trophy,
  Flame,
  Star,
  TrendingUp,
  Calendar,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, differenceInDays, addDays } from 'date-fns';

interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: Date;
  category: 'campaign' | 'reserve' | 'growth' | 'emergency';
  icon: string;
  color: string;
  milestones: number[];
}

const mockGoals: SavingsGoal[] = [
  {
    id: '1',
    name: 'Q1 Campaign Reserve',
    targetAmount: 25000,
    currentAmount: 18500,
    deadline: addDays(new Date(), 45),
    category: 'campaign',
    icon: '🎯',
    color: 'from-primary to-blue-500',
    milestones: [25, 50, 75, 100],
  },
  {
    id: '2',
    name: 'Emergency Fund',
    targetAmount: 10000,
    currentAmount: 7200,
    deadline: addDays(new Date(), 90),
    category: 'emergency',
    icon: '🛡️',
    color: 'from-emerald-500 to-teal-500',
    milestones: [25, 50, 75, 100],
  },
  {
    id: '3',
    name: 'Platform Expansion',
    targetAmount: 15000,
    currentAmount: 4500,
    deadline: addDays(new Date(), 120),
    category: 'growth',
    icon: '🚀',
    color: 'from-violet-500 to-purple-500',
    milestones: [25, 50, 75, 100],
  },
];

const getCategoryBadge = (category: string) => {
  switch (category) {
    case 'campaign':
      return { label: 'Campaign', className: 'bg-primary/10 text-primary border-primary/30' };
    case 'reserve':
      return { label: 'Reserve', className: 'bg-amber-500/10 text-amber-600 border-amber-500/30' };
    case 'growth':
      return { label: 'Growth', className: 'bg-violet-500/10 text-violet-600 border-violet-500/30' };
    case 'emergency':
      return { label: 'Emergency', className: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30' };
    default:
      return { label: 'Other', className: 'bg-muted text-muted-foreground' };
  }
};

export default function SavingsGoalsCard() {
  const [expandedGoal, setExpandedGoal] = useState<string | null>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const totalProgress =
    mockGoals.reduce((acc, goal) => {
      return acc + (goal.currentAmount / goal.targetAmount) * 100;
    }, 0) / mockGoals.length;

  const completedMilestones = mockGoals.reduce((acc, goal) => {
    const progress = (goal.currentAmount / goal.targetAmount) * 100;
    return acc + goal.milestones.filter((m) => progress >= m).length;
  }, 0);

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500">
              <Target className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Savings Goals</CardTitle>
              <CardDescription>Track your budget targets</CardDescription>
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            <Plus className="h-3.5 w-3.5" />
            New Goal
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-5">
        {/* Achievement Summary */}
        <div className="flex items-center gap-4 p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/20">
          <div className="p-3 rounded-full bg-amber-500/20">
            <Trophy className="h-6 w-6 text-amber-500" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-foreground">{completedMilestones} Milestones Reached</span>
              <Flame className="h-4 w-4 text-orange-500" />
            </div>
            <p className="text-sm text-muted-foreground">
              {Math.round(totalProgress)}% overall progress across {mockGoals.length} goals
            </p>
          </div>
          <div className="flex items-center gap-1">
            {[1, 2, 3].map((star) => (
              <Star
                key={star}
                className={cn(
                  'h-5 w-5 transition-colors',
                  completedMilestones >= star * 3 ? 'text-amber-400 fill-amber-400' : 'text-muted-foreground/30',
                )}
              />
            ))}
          </div>
        </div>

        {/* Goals List */}
        <div className="space-y-3">
          {mockGoals.map((goal) => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            const daysRemaining = differenceInDays(goal.deadline, new Date());
            const isExpanded = expandedGoal === goal.id;
            const categoryBadge = getCategoryBadge(goal.category);
            const reachedMilestones = goal.milestones.filter((m) => progress >= m);
            const nextMilestone = goal.milestones.find((m) => progress < m) || 100;

            return (
              <div
                key={goal.id}
                className={cn(
                  'group rounded-xl border transition-all duration-300 cursor-pointer',
                  isExpanded ? 'bg-muted/50 border-primary/30 shadow-lg' : 'hover:bg-muted/30 border-border/50',
                )}
                onClick={() => setExpandedGoal(isExpanded ? null : goal.id)}
              >
                <div className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Icon */}
                    <div
                      className={cn(
                        'p-3 rounded-xl bg-gradient-to-br text-2xl flex-shrink-0',
                        goal.color.replace('from-', 'from-').replace('to-', 'to-') + '/10',
                      )}
                    >
                      {goal.icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-foreground">{goal.name}</h4>
                          <Badge variant="outline" className={cn('text-[10px]', categoryBadge.className)}>
                            {categoryBadge.label}
                          </Badge>
                        </div>
                        <ChevronRight
                          className={cn(
                            'h-4 w-4 text-muted-foreground transition-transform',
                            isExpanded && 'rotate-90',
                          )}
                        />
                      </div>

                      {/* Progress Info */}
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-muted-foreground">
                          <span className="font-semibold text-foreground">{formatCurrency(goal.currentAmount)}</span> of{' '}
                          {formatCurrency(goal.targetAmount)}
                        </span>
                        <span
                          className={cn(
                            'font-medium',
                            progress >= 100
                              ? 'text-emerald-500'
                              : progress >= 75
                                ? 'text-primary'
                                : 'text-muted-foreground',
                          )}
                        >
                          {Math.round(progress)}%
                        </span>
                      </div>

                      {/* Progress Bar with Milestones */}
                      <div className="relative">
                        <Progress value={progress} className="h-2.5 bg-muted" />
                        {/* Milestone Markers */}
                        <div className="absolute inset-0 flex items-center">
                          {goal.milestones.slice(0, -1).map((milestone) => (
                            <div
                              key={milestone}
                              className="absolute h-4 w-0.5 bg-background"
                              style={{ left: `${milestone}%` }}
                            />
                          ))}
                        </div>
                      </div>

                      {/* Time Remaining */}
                      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>
                            {daysRemaining > 0
                              ? `${daysRemaining} days remaining`
                              : daysRemaining === 0
                                ? 'Due today'
                                : `${Math.abs(daysRemaining)} days overdue`}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>{format(goal.deadline, 'MMM d, yyyy')}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-border/50 space-y-4 animate-in slide-in-from-top-2 duration-200">
                      {/* Milestones */}
                      <div>
                        <p className="text-sm font-medium mb-3 flex items-center gap-2">
                          <Sparkles className="h-4 w-4 text-primary" />
                          Milestones
                        </p>
                        <div className="flex items-center gap-2">
                          {goal.milestones.map((milestone) => {
                            const isReached = progress >= milestone;
                            return (
                              <div
                                key={milestone}
                                className={cn(
                                  'flex-1 flex flex-col items-center gap-1 p-2 rounded-lg transition-colors',
                                  isReached ? 'bg-emerald-500/10' : 'bg-muted/50',
                                )}
                              >
                                <div
                                  className={cn(
                                    'p-1.5 rounded-full',
                                    isReached ? 'bg-emerald-500' : 'bg-muted-foreground/20',
                                  )}
                                >
                                  {isReached ? (
                                    <CheckCircle2 className="h-3.5 w-3.5 text-white" />
                                  ) : (
                                    <Target className="h-3.5 w-3.5 text-muted-foreground" />
                                  )}
                                </div>
                                <span
                                  className={cn(
                                    'text-xs font-medium',
                                    isReached ? 'text-emerald-600' : 'text-muted-foreground',
                                  )}
                                >
                                  {milestone}%
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Next Milestone Info */}
                      {progress < 100 && (
                        <div className="flex items-center justify-between p-3 rounded-lg bg-primary/5 border border-primary/20">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="h-4 w-4 text-primary" />
                            <span className="text-sm">
                              Next milestone at <span className="font-semibold">{nextMilestone}%</span>
                            </span>
                          </div>
                          <span className="text-sm font-medium text-primary">
                            {formatCurrency((goal.targetAmount * nextMilestone) / 100 - goal.currentAmount)} to go
                          </span>
                        </div>
                      )}

                      {/* Quick Actions */}
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          Edit Goal
                        </Button>
                        <Button size="sm" className="flex-1 gap-1">
                          <Plus className="h-3.5 w-3.5" />
                          Add Funds
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Overall Progress */}
        <div className="pt-4 border-t border-border/50">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Overall Progress</span>
            <span className="font-semibold">{Math.round(totalProgress)}%</span>
          </div>
          <Progress value={totalProgress} className="h-2 bg-muted" />
        </div>
      </CardContent>
    </Card>
  );
}
