import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  Smartphone,
  Monitor,
  Tablet,
  Key,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Eye,
  EyeOff,
  Fingerprint,
  MapPin,
  RefreshCw,
  Settings,
  Bell,
  XCircle,
  Globe,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';
import { toast } from '@/hooks/use-toast';

interface SecurityDevice {
  id: string;
  name: string;
  type: 'mobile' | 'desktop' | 'tablet';
  location: string;
  lastActive: Date;
  isTrusted: boolean;
  isCurrent: boolean;
}

interface SecurityAlert {
  id: string;
  type: 'login_attempt' | 'password_change' | 'new_device' | 'suspicious_activity';
  message: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high';
  resolved: boolean;
}

const mockDevices: SecurityDevice[] = [
  {
    id: '1',
    name: 'MacBook Pro',
    type: 'desktop',
    location: 'San Francisco, CA',
    lastActive: new Date(),
    isTrusted: true,
    isCurrent: true,
  },
  {
    id: '2',
    name: 'iPhone 15 Pro',
    type: 'mobile',
    location: 'San Francisco, CA',
    lastActive: new Date(Date.now() - 3600000),
    isTrusted: true,
    isCurrent: false,
  },
  {
    id: '3',
    name: 'iPad Air',
    type: 'tablet',
    location: 'New York, NY',
    lastActive: new Date(Date.now() - 86400000),
    isTrusted: false,
    isCurrent: false,
  },
];

const mockAlerts: SecurityAlert[] = [
  {
    id: '1',
    type: 'login_attempt',
    message: 'Failed login attempt from unknown IP',
    timestamp: new Date(Date.now() - 3600000),
    severity: 'medium',
    resolved: false,
  },
  {
    id: '2',
    type: 'new_device',
    message: 'New device added: iPad Air',
    timestamp: new Date(Date.now() - 86400000),
    severity: 'low',
    resolved: true,
  },
];

export default function PaymentSecurityCenter() {
  const [devices] = useState<SecurityDevice[]>(mockDevices);
  const [alerts, setAlerts] = useState<SecurityAlert[]>(mockAlerts);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [transactionAlerts, setTransactionAlerts] = useState(true);
  const [loginNotifications, setLoginNotifications] = useState(true);

  // Calculate security score
  const securityScore = (() => {
    let score = 40; // Base score
    if (twoFactorEnabled) score += 25;
    if (biometricEnabled) score += 15;
    if (transactionAlerts) score += 10;
    if (loginNotifications) score += 10;
    return score;
  })();

  const getScoreColor = () => {
    if (securityScore >= 80) return 'text-emerald-500';
    if (securityScore >= 60) return 'text-amber-500';
    return 'text-destructive';
  };

  const getScoreLabel = () => {
    if (securityScore >= 80) return 'Excellent';
    if (securityScore >= 60) return 'Good';
    if (securityScore >= 40) return 'Fair';
    return 'Needs Attention';
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'desktop':
        return <Monitor className="h-4 w-4" />;
      case 'tablet':
        return <Tablet className="h-4 w-4" />;
      default:
        return <Monitor className="h-4 w-4" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'medium':
        return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const resolveAlert = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, resolved: true } : a)));
    toast({ title: 'Alert Resolved', description: 'Security alert has been marked as resolved' });
  };

  const unresolvedAlerts = alerts.filter((a) => !a.resolved);
  const trustedDevices = devices.filter((d) => d.isTrusted);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-500/5">
              <Shield className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <CardTitle className="text-lg">Payment Security</CardTitle>
              <CardDescription>Protect your wallet & transactions</CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="gap-1.5">
            <Settings className="h-4 w-4" />
            Settings
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Security Score */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-background to-muted/30 border">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-emerald-500" />
              <span className="font-medium">Security Score</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn('text-3xl font-bold', getScoreColor())}>{securityScore}</span>
              <span className="text-sm text-muted-foreground">/100</span>
            </div>
          </div>
          <Progress value={securityScore} className="h-2 mb-2" />
          <div className="flex items-center justify-between text-xs">
            <Badge variant="outline" className={cn(getScoreColor(), 'bg-transparent border-current/20')}>
              {getScoreLabel()}
            </Badge>
            {securityScore < 80 && (
              <span className="text-muted-foreground flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Enable more features to improve
              </span>
            )}
          </div>
        </div>

        {/* Security Settings Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div
            className={cn(
              'p-3 rounded-xl border transition-all',
              twoFactorEnabled ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-muted/30',
            )}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-emerald-500/20">
                <Key className="h-4 w-4 text-emerald-500" />
              </div>
              <Switch checked={twoFactorEnabled} onCheckedChange={setTwoFactorEnabled} />
            </div>
            <p className="text-sm font-medium">Two-Factor Auth</p>
            <p className="text-[10px] text-muted-foreground">Extra security layer</p>
          </div>

          <div
            className={cn(
              'p-3 rounded-xl border transition-all',
              biometricEnabled ? 'bg-primary/5 border-primary/20' : 'bg-muted/30',
            )}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-primary/20">
                <Fingerprint className="h-4 w-4 text-primary" />
              </div>
              <Switch checked={biometricEnabled} onCheckedChange={setBiometricEnabled} />
            </div>
            <p className="text-sm font-medium">Biometric Login</p>
            <p className="text-[10px] text-muted-foreground">Face ID / Touch ID</p>
          </div>

          <div
            className={cn(
              'p-3 rounded-xl border transition-all',
              transactionAlerts ? 'bg-chart-2/5 border-chart-2/20' : 'bg-muted/30',
            )}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-chart-2/20">
                <Bell className="h-4 w-4 text-chart-2" />
              </div>
              <Switch checked={transactionAlerts} onCheckedChange={setTransactionAlerts} />
            </div>
            <p className="text-sm font-medium">Transaction Alerts</p>
            <p className="text-[10px] text-muted-foreground">Instant notifications</p>
          </div>

          <div
            className={cn(
              'p-3 rounded-xl border transition-all',
              loginNotifications ? 'bg-amber-500/5 border-amber-500/20' : 'bg-muted/30',
            )}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-1.5 rounded-lg bg-amber-500/20">
                <Globe className="h-4 w-4 text-amber-500" />
              </div>
              <Switch checked={loginNotifications} onCheckedChange={setLoginNotifications} />
            </div>
            <p className="text-sm font-medium">Login Alerts</p>
            <p className="text-[10px] text-muted-foreground">New device alerts</p>
          </div>
        </div>

        {/* Security Alerts */}
        {unresolvedAlerts.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                <ShieldAlert className="h-3.5 w-3.5" />
                Recent Alerts
              </p>
              <Badge variant="destructive" className="text-[10px]">
                {unresolvedAlerts.length} unresolved
              </Badge>
            </div>
            {unresolvedAlerts.map((alert) => (
              <div
                key={alert.id}
                className={cn(
                  'p-3 rounded-lg border flex items-center justify-between',
                  getSeverityColor(alert.severity),
                )}
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  <div>
                    <p className="text-xs font-medium">{alert.message}</p>
                    <p className="text-[10px] opacity-70">
                      {formatDistanceToNow(alert.timestamp, { addSuffix: true })}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => resolveAlert(alert.id)}>
                  Resolve
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* Trusted Devices */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
            <Monitor className="h-3.5 w-3.5" />
            Trusted Devices ({trustedDevices.length})
          </p>
          <div className="space-y-2">
            {devices.slice(0, 3).map((device) => (
              <div key={device.id} className="p-3 rounded-lg border bg-card flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn('p-2 rounded-lg', device.isTrusted ? 'bg-emerald-500/10' : 'bg-muted')}>
                    {getDeviceIcon(device.type)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{device.name}</p>
                      {device.isCurrent && (
                        <Badge variant="outline" className="text-[9px] bg-primary/10 text-primary border-primary/20">
                          Current
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{device.location}</span>
                      <span>•</span>
                      <Clock className="h-3 w-3" />
                      <span>{formatDistanceToNow(device.lastActive, { addSuffix: true })}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {device.isTrusted ? (
                    <Badge
                      variant="outline"
                      className="text-[10px] bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                    >
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Trusted
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-[10px]">
                      Unverified
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t">
          <Button variant="outline" size="sm" className="text-xs gap-1.5">
            <RefreshCw className="h-3.5 w-3.5" />
            Reset Password
          </Button>
          <Button variant="outline" size="sm" className="text-xs gap-1.5">
            <Lock className="h-3.5 w-3.5" />
            Lock Wallet
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
