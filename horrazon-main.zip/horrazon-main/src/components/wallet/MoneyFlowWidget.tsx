import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowUpRight, ArrowDownLeft, TrendingUp, TrendingDown, Wallet, BarChart3 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/contexts/AppContext';
import { useMemo } from 'react';
import { format, subDays, isWithinInterval } from 'date-fns';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function MoneyFlowWidget() {
  const { transactions, wallet } = useApp();

  const flowData = useMemo(() => {
    // Calculate last 7 days flow
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      const dayTransactions = transactions.filter((tx) =>
        isWithinInterval(tx.date, {
          start: new Date(date.setHours(0, 0, 0, 0)),
          end: new Date(date.setHours(23, 59, 59, 999)),
        }),
      );

      const inflow = dayTransactions.filter((tx) => tx.type === 'credit').reduce((sum, tx) => sum + tx.amount, 0);

      const outflow = dayTransactions.filter((tx) => tx.type === 'debit').reduce((sum, tx) => sum + tx.amount, 0);

      return {
        date: format(date, 'EEE'),
        fullDate: format(date, 'MMM d'),
        inflow,
        outflow,
        net: inflow - outflow,
      };
    });

    // Calculate totals
    const totalInflow = transactions.filter((tx) => tx.type === 'credit').reduce((sum, tx) => sum + tx.amount, 0);

    const totalOutflow = transactions.filter((tx) => tx.type === 'debit').reduce((sum, tx) => sum + tx.amount, 0);

    // Week over week change
    const thisWeekInflow = last7Days.reduce((sum, d) => sum + d.inflow, 0);
    const thisWeekOutflow = last7Days.reduce((sum, d) => sum + d.outflow, 0);

    // Mock previous week for comparison
    const prevWeekInflow = thisWeekInflow * 0.85;
    const prevWeekOutflow = thisWeekOutflow * 1.1;

    const inflowChange = prevWeekInflow > 0 ? ((thisWeekInflow - prevWeekInflow) / prevWeekInflow) * 100 : 0;
    const outflowChange = prevWeekOutflow > 0 ? ((thisWeekOutflow - prevWeekOutflow) / prevWeekOutflow) * 100 : 0;

    return {
      chartData: last7Days,
      totalInflow,
      totalOutflow,
      thisWeekInflow,
      thisWeekOutflow,
      inflowChange,
      outflowChange,
      netFlow: thisWeekInflow - thisWeekOutflow,
    };
  }, [transactions]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatCompact = (amount: number) => {
    if (Math.abs(amount) >= 1000) {
      return `${amount > 0 ? '+' : ''}$${(amount / 1000).toFixed(1)}K`;
    }
    return `${amount > 0 ? '+' : ''}$${amount.toFixed(0)}`;
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-chart-1 to-blue-500">
              <BarChart3 className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Money Flow</CardTitle>
              <CardDescription>7-day inflow vs outflow</CardDescription>
            </div>
          </div>
          <Badge
            variant="outline"
            className={cn(
              'gap-1',
              flowData.netFlow >= 0
                ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30'
                : 'bg-destructive/10 text-destructive border-destructive/30',
            )}
          >
            {flowData.netFlow >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {formatCompact(flowData.netFlow)} net
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Flow Stats */}
        <div className="grid grid-cols-2 gap-4">
          {/* Inflow */}
          <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-emerald-500/20">
                <ArrowDownLeft className="h-4 w-4 text-emerald-500" />
              </div>
              <span className="text-sm font-medium text-muted-foreground">Inflow</span>
            </div>
            <p className="text-2xl font-bold text-emerald-600">{formatCurrency(flowData.thisWeekInflow)}</p>
            <div className="flex items-center gap-1 mt-1">
              {flowData.inflowChange >= 0 ? (
                <TrendingUp className="h-3 w-3 text-emerald-500" />
              ) : (
                <TrendingDown className="h-3 w-3 text-destructive" />
              )}
              <span
                className={cn(
                  'text-xs font-medium',
                  flowData.inflowChange >= 0 ? 'text-emerald-500' : 'text-destructive',
                )}
              >
                {flowData.inflowChange >= 0 ? '+' : ''}
                {flowData.inflowChange.toFixed(1)}%
              </span>
              <span className="text-xs text-muted-foreground">vs last week</span>
            </div>
          </div>

          {/* Outflow */}
          <div className="p-4 rounded-xl bg-chart-3/5 border border-chart-3/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-chart-3/20">
                <ArrowUpRight className="h-4 w-4 text-chart-3" />
              </div>
              <span className="text-sm font-medium text-muted-foreground">Outflow</span>
            </div>
            <p className="text-2xl font-bold text-chart-3">{formatCurrency(flowData.thisWeekOutflow)}</p>
            <div className="flex items-center gap-1 mt-1">
              {flowData.outflowChange <= 0 ? (
                <TrendingDown className="h-3 w-3 text-emerald-500" />
              ) : (
                <TrendingUp className="h-3 w-3 text-destructive" />
              )}
              <span
                className={cn(
                  'text-xs font-medium',
                  flowData.outflowChange <= 0 ? 'text-emerald-500' : 'text-destructive',
                )}
              >
                {flowData.outflowChange >= 0 ? '+' : ''}
                {flowData.outflowChange.toFixed(1)}%
              </span>
              <span className="text-xs text-muted-foreground">vs last week</span>
            </div>
          </div>
        </div>

        {/* Flow Chart */}
        <div className="h-44">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={flowData.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="inflowGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="outflowGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-3))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--chart-3))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '12px',
                  boxShadow: '0 10px 30px -10px hsl(var(--foreground) / 0.1)',
                }}
                formatter={(value: number, name: string) => [
                  formatCurrency(value),
                  name === 'inflow' ? 'Inflow' : 'Outflow',
                ]}
                labelFormatter={(label) => flowData.chartData.find((d) => d.date === label)?.fullDate}
              />
              <Area type="monotone" dataKey="inflow" stroke="#10b981" strokeWidth={2} fill="url(#inflowGradient)" />
              <Area
                type="monotone"
                dataKey="outflow"
                stroke="hsl(var(--chart-3))"
                strokeWidth={2}
                fill="url(#outflowGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-500" />
            <span className="text-muted-foreground">Inflow</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-chart-3" />
            <span className="text-muted-foreground">Outflow</span>
          </div>
        </div>

        {/* Current Balance */}
        <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Wallet className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Current Balance</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(wallet.balance)}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Healthy runway</p>
            <p className="text-sm font-semibold text-emerald-500">
              {Math.floor(wallet.balance / (wallet.monthlySpent / 30))} days
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
