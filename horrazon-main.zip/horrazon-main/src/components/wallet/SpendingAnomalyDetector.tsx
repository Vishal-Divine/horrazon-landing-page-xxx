import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Shield,
  Eye,
  Bell,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  ChevronRight,
  ArrowUpRight,
  Activity,
  Zap,
  BarChart3,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, subHours } from 'date-fns';
import { toast } from '@/hooks/use-toast';

interface Anomaly {
  id: string;
  type: 'spike' | 'unusual' | 'fraud' | 'pattern';
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  amount: number;
  deviation: number;
  timestamp: Date;
  status: 'active' | 'investigating' | 'resolved' | 'dismissed';
  platform?: string;
  recommendation: string;
}

const mockAnomalies: Anomaly[] = [
  {
    id: '1',
    type: 'spike',
    severity: 'high',
    title: 'Unusual Spending Spike',
    description: 'Meta Ads spend increased 340% compared to daily average',
    amount: 4520,
    deviation: 340,
    timestamp: subHours(new Date(), 2),
    status: 'active',
    platform: 'Meta',
    recommendation: 'Review recent campaign changes or pause high-spend ads',
  },
  {
    id: '2',
    type: 'pattern',
    severity: 'medium',
    title: 'Off-hours Activity',
    description: 'Multiple transactions detected during unusual hours (2-4 AM)',
    amount: 1250,
    deviation: 85,
    timestamp: subHours(new Date(), 6),
    status: 'investigating',
    platform: 'Google',
    recommendation: 'Verify these were automated scheduled payments',
  },
  {
    id: '3',
    type: 'unusual',
    severity: 'low',
    title: 'New Vendor Payment',
    description: 'First-time payment to unrecognized advertising platform',
    amount: 500,
    deviation: 0,
    timestamp: subHours(new Date(), 12),
    status: 'active',
    platform: 'TikTok',
    recommendation: 'Confirm this is an authorized new platform integration',
  },
];

const getSeverityStyles = (severity: string) => {
  switch (severity) {
    case 'critical':
      return {
        bg: 'bg-destructive/10',
        text: 'text-destructive',
        border: 'border-destructive/30',
        gradient: 'from-destructive to-red-400',
      };
    case 'high':
      return {
        bg: 'bg-orange-500/10',
        text: 'text-orange-600',
        border: 'border-orange-500/30',
        gradient: 'from-orange-500 to-amber-500',
      };
    case 'medium':
      return {
        bg: 'bg-amber-500/10',
        text: 'text-amber-600',
        border: 'border-amber-500/30',
        gradient: 'from-amber-500 to-yellow-500',
      };
    case 'low':
      return {
        bg: 'bg-primary/10',
        text: 'text-primary',
        border: 'border-primary/30',
        gradient: 'from-primary to-blue-500',
      };
    default:
      return {
        bg: 'bg-muted',
        text: 'text-muted-foreground',
        border: 'border-border',
        gradient: 'from-muted to-muted',
      };
  }
};

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'spike':
      return TrendingUp;
    case 'unusual':
      return Eye;
    case 'fraud':
      return Shield;
    case 'pattern':
      return Activity;
    default:
      return AlertTriangle;
  }
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'active':
      return { label: 'Active', className: 'bg-amber-500/10 text-amber-600 border-amber-500/30' };
    case 'investigating':
      return { label: 'Investigating', className: 'bg-primary/10 text-primary border-primary/30' };
    case 'resolved':
      return { label: 'Resolved', className: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30' };
    case 'dismissed':
      return { label: 'Dismissed', className: 'bg-muted text-muted-foreground' };
    default:
      return { label: status, className: 'bg-muted text-muted-foreground' };
  }
};

export default function SpendingAnomalyDetector() {
  const [anomalies, setAnomalies] = useState(mockAnomalies);
  const [selectedAnomaly, setSelectedAnomaly] = useState<string | null>(null);

  const resolveAnomaly = (anomalyId: string) => {
    setAnomalies((prev) =>
      prev.map((a) => {
        if (a.id === anomalyId) {
          toast({
            title: 'Anomaly Resolved',
            description: 'This alert has been marked as resolved.',
          });
          return { ...a, status: 'resolved' as const };
        }
        return a;
      }),
    );
  };

  const dismissAnomaly = (anomalyId: string) => {
    setAnomalies((prev) =>
      prev.map((a) => {
        if (a.id === anomalyId) {
          toast({
            title: 'Anomaly Dismissed',
            description: 'This alert has been dismissed.',
          });
          return { ...a, status: 'dismissed' as const };
        }
        return a;
      }),
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const activeAnomalies = anomalies.filter((a) => a.status === 'active' || a.status === 'investigating');
  const criticalCount = anomalies.filter((a) => a.severity === 'critical' && a.status === 'active').length;
  const highCount = anomalies.filter((a) => a.severity === 'high' && a.status === 'active').length;

  // Calculate security score (inverse of active anomalies)
  const securityScore = Math.max(0, 100 - criticalCount * 30 - highCount * 15 - activeAnomalies.length * 5);

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                'p-2.5 rounded-xl bg-gradient-to-br',
                activeAnomalies.length > 0 ? 'from-amber-500 to-orange-500' : 'from-emerald-500 to-teal-500',
              )}
            >
              <Shield className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                Anomaly Detection
                {activeAnomalies.length > 0 && (
                  <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/30 gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                    {activeAnomalies.length} Active
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>AI-powered spending protection</CardDescription>
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            <Bell className="h-3.5 w-3.5" />
            Settings
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Security Score */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-muted/50 to-muted/20">
          <div className="flex items-center gap-6">
            {/* Circular Score */}
            <div className="relative flex-shrink-0">
              <svg className="w-24 h-24 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke={securityScore >= 70 ? '#10b981' : securityScore >= 40 ? '#f59e0b' : '#ef4444'}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${securityScore * 2.64} 264`}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span
                  className={cn(
                    'text-2xl font-bold',
                    securityScore >= 70
                      ? 'text-emerald-500'
                      : securityScore >= 40
                        ? 'text-amber-500'
                        : 'text-destructive',
                  )}
                >
                  {securityScore}
                </span>
                <span className="text-[10px] text-muted-foreground">SCORE</span>
              </div>
            </div>

            {/* Score Details */}
            <div className="flex-1 space-y-3">
              <div>
                <h4 className="font-medium text-foreground">
                  {securityScore >= 70
                    ? 'Spending looks healthy'
                    : securityScore >= 40
                      ? 'Some alerts need attention'
                      : 'Critical issues detected'}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {activeAnomalies.length === 0
                    ? 'No active anomalies detected'
                    : `${activeAnomalies.length} anomal${activeAnomalies.length > 1 ? 'ies' : 'y'} require your attention`}
                </p>
              </div>

              <div className="flex gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-muted-foreground">Protected: $45.2K</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-amber-500" />
                  <span className="text-muted-foreground">
                    Flagged: {formatCurrency(activeAnomalies.reduce((sum, a) => sum + a.amount, 0))}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Anomaly List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-500" />
              Recent Alerts
            </h4>
            <Button variant="ghost" size="sm" className="text-xs">
              View All
            </Button>
          </div>

          {anomalies.map((anomaly) => {
            const severityStyles = getSeverityStyles(anomaly.severity);
            const TypeIcon = getTypeIcon(anomaly.type);
            const statusBadge = getStatusBadge(anomaly.status);
            const isExpanded = selectedAnomaly === anomaly.id;

            return (
              <div
                key={anomaly.id}
                className={cn(
                  'rounded-xl border transition-all duration-200 cursor-pointer',
                  anomaly.status === 'resolved' || anomaly.status === 'dismissed'
                    ? 'bg-muted/30 border-border/50 opacity-60'
                    : 'bg-card hover:bg-muted/30 border-border',
                  isExpanded && 'ring-2 ring-primary/20',
                )}
                onClick={() => setSelectedAnomaly(isExpanded ? null : anomaly.id)}
              >
                <div className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Icon */}
                    <div className={cn('p-2.5 rounded-xl bg-gradient-to-br', severityStyles.gradient)}>
                      <TypeIcon className="h-4 w-4 text-white" />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h5 className="font-medium text-sm">{anomaly.title}</h5>
                        <Badge variant="outline" className={cn('text-[10px]', statusBadge.className)}>
                          {statusBadge.label}
                        </Badge>
                      </div>

                      <p className="text-xs text-muted-foreground mb-2">{anomaly.description}</p>

                      <div className="flex items-center gap-4 text-xs">
                        <span className={cn('font-semibold', severityStyles.text)}>
                          {formatCurrency(anomaly.amount)}
                        </span>
                        {anomaly.deviation > 0 && (
                          <span className="flex items-center gap-1 text-muted-foreground">
                            <ArrowUpRight className="h-3 w-3 text-destructive" />+{anomaly.deviation}% deviation
                          </span>
                        )}
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {format(anomaly.timestamp, 'h:mm a')}
                        </span>
                      </div>
                    </div>

                    {/* Severity Badge */}
                    <Badge
                      variant="outline"
                      className={cn(
                        'capitalize text-[10px]',
                        severityStyles.bg,
                        severityStyles.text,
                        severityStyles.border,
                      )}
                    >
                      {anomaly.severity}
                    </Badge>
                  </div>

                  {/* Expanded Content */}
                  {isExpanded && anomaly.status !== 'resolved' && anomaly.status !== 'dismissed' && (
                    <div className="mt-4 pt-4 border-t border-border/50 space-y-4 animate-in slide-in-from-top-2 duration-200">
                      {/* Recommendation */}
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20">
                        <Sparkles className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-medium text-foreground">AI Recommendation</p>
                          <p className="text-xs text-muted-foreground">{anomaly.recommendation}</p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 text-xs gap-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            dismissAnomaly(anomaly.id);
                          }}
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          Dismiss
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 text-xs gap-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            resolveAnomaly(anomaly.id);
                          }}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Resolve
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Protection Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span className="text-xs font-medium">This Month</span>
            </div>
            <p className="text-lg font-bold text-emerald-600 mt-1">$8,450</p>
            <p className="text-[10px] text-muted-foreground">Protected from fraud</p>
          </div>
          <div className="p-3 rounded-xl bg-primary/5 border border-primary/20">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              <span className="text-xs font-medium">Detection Rate</span>
            </div>
            <p className="text-lg font-bold text-primary mt-1">99.7%</p>
            <p className="text-[10px] text-muted-foreground">Accuracy score</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
