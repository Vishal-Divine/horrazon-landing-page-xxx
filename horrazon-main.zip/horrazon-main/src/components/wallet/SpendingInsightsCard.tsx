import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  Zap,
  Target,
  DollarSign,
  Clock,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

interface Insight {
  id: string;
  type: 'optimization' | 'warning' | 'success' | 'tip';
  title: string;
  description: string;
  impact?: string;
  action?: string;
  priority: 'high' | 'medium' | 'low';
}

export default function SpendingInsightsCard() {
  const { wallet, campaignSpends, transactions } = useApp();

  // Calculate spending patterns
  const avgDailySpend = wallet.dailySpent || 342.8;
  const weeklySpendRate = avgDailySpend * 7;
  const monthlyProjection = avgDailySpend * 30;

  // Analyze campaign performance
  const activeCampaigns = campaignSpends.filter((c) => c.status === 'active');
  const highRiskCampaigns = activeCampaigns.filter((c) => c.riskLevel === 'critical' || c.riskLevel === 'high');
  const overspendingCampaigns = activeCampaigns.filter((c) => c.spent / c.budget > 0.8);

  // Calculate efficiency metrics
  const totalBudget = activeCampaigns.reduce((sum, c) => sum + c.budget, 0);
  const totalSpent = activeCampaigns.reduce((sum, c) => sum + c.spent, 0);
  const overallEfficiency = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  // Generate AI insights
  const insights: Insight[] = [];

  // Budget efficiency insight
  if (overallEfficiency > 85) {
    insights.push({
      id: 'efficiency-high',
      type: 'warning',
      title: 'High Budget Utilization',
      description: `You've used ${overallEfficiency.toFixed(0)}% of total campaign budgets. Consider increasing budgets to maintain momentum.`,
      impact: 'Campaigns may pause soon',
      action: 'Review Budgets',
      priority: 'high',
    });
  } else if (overallEfficiency < 40) {
    insights.push({
      id: 'efficiency-low',
      type: 'tip',
      title: 'Underutilized Budget',
      description: `Only ${overallEfficiency.toFixed(0)}% budget utilization. You may be missing opportunities for growth.`,
      impact: 'Potential +${(totalBudget * 0.2).toFixed(0)} impact',
      action: 'Optimize Spend',
      priority: 'medium',
    });
  }

  // High-risk campaign warning
  if (highRiskCampaigns.length > 0) {
    insights.push({
      id: 'risk-campaigns',
      type: 'warning',
      title: `${highRiskCampaigns.length} Campaign${highRiskCampaigns.length > 1 ? 's' : ''} At Risk`,
      description: `${highRiskCampaigns.map((c) => c.name).join(', ')} ${highRiskCampaigns.length > 1 ? 'are' : 'is'} running low on budget with active spend.`,
      impact: 'May affect conversions',
      action: 'Add Funds',
      priority: 'high',
    });
  }

  // Spending trend insight
  const spendingTrend = ((wallet.monthlySpent - wallet.totalSpent * 0.1) / (wallet.totalSpent * 0.1)) * 100;
  if (spendingTrend > 20) {
    insights.push({
      id: 'trend-up',
      type: 'optimization',
      title: 'Spending Trend Increasing',
      description: `Your spending is up ${spendingTrend.toFixed(0)}% compared to average. Verify this aligns with your goals.`,
      impact: '+$' + (avgDailySpend * 30 * 0.2).toFixed(0) + ' projected',
      action: 'Review Trends',
      priority: 'medium',
    });
  }

  // Platform optimization
  const platformSpend = activeCampaigns.reduce(
    (acc, c) => {
      acc[c.platform] = (acc[c.platform] || 0) + c.spent;
      return acc;
    },
    {} as Record<string, number>,
  );

  const topPlatform = Object.entries(platformSpend).sort((a, b) => b[1] - a[1])[0];
  if (topPlatform) {
    insights.push({
      id: 'platform-focus',
      type: 'success',
      title: `${topPlatform[0]} Leading Performance`,
      description: `${topPlatform[0]} accounts for ${((topPlatform[1] / totalSpent) * 100).toFixed(0)}% of your spend. Consider allocating more budget here.`,
      impact: 'Best performing channel',
      action: 'View Analytics',
      priority: 'low',
    });
  }

  // Wallet health check
  if (wallet.balance < wallet.lowBalanceThreshold * 1.5) {
    insights.push({
      id: 'wallet-health',
      type: 'warning',
      title: 'Low Balance Warning',
      description: `Balance approaching threshold. Add funds to maintain uninterrupted campaigns.`,
      impact: `${Math.floor(wallet.balance / avgDailySpend)} days runway`,
      action: 'Add Funds',
      priority: 'high',
    });
  }

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'optimization':
        return Zap;
      case 'warning':
        return AlertTriangle;
      case 'success':
        return CheckCircle2;
      default:
        return Lightbulb;
    }
  };

  const getInsightColors = (type: string) => {
    switch (type) {
      case 'optimization':
        return 'border-chart-2/30 bg-chart-2/5';
      case 'warning':
        return 'border-amber-500/30 bg-amber-500/5';
      case 'success':
        return 'border-emerald-500/30 bg-emerald-500/5';
      default:
        return 'border-primary/30 bg-primary/5';
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case 'optimization':
        return 'text-chart-2 bg-chart-2/10';
      case 'warning':
        return 'text-amber-500 bg-amber-500/10';
      case 'success':
        return 'text-emerald-500 bg-emerald-500/10';
      default:
        return 'text-primary bg-primary/10';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'medium':
        return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-1.5 rounded-lg bg-gradient-to-br from-primary/20 to-chart-2/20">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              AI Spending Insights
            </CardTitle>
            <CardDescription>Smart recommendations to optimize your ad spend</CardDescription>
          </div>
          <Badge variant="outline" className="gap-1">
            <Zap className="h-3 w-3" />
            {insights.filter((i) => i.priority === 'high').length} urgent
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {insights.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="p-3 rounded-full bg-emerald-500/10 mb-3">
              <CheckCircle2 className="h-6 w-6 text-emerald-500" />
            </div>
            <p className="font-medium">All Optimized!</p>
            <p className="text-sm text-muted-foreground">Your campaigns are running efficiently</p>
          </div>
        ) : (
          insights.slice(0, 4).map((insight) => {
            const Icon = getInsightIcon(insight.type);
            return (
              <div
                key={insight.id}
                className={cn('p-3 rounded-lg border transition-all hover:shadow-sm', getInsightColors(insight.type))}
              >
                <div className="flex items-start gap-3">
                  <div className={cn('p-1.5 rounded-lg shrink-0', getIconColor(insight.type))}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-sm">{insight.title}</p>
                      <Badge
                        variant="outline"
                        className={cn('text-[9px] px-1.5 py-0', getPriorityBadge(insight.priority))}
                      >
                        {insight.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{insight.description}</p>
                    {insight.impact && (
                      <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                        <Target className="h-2.5 w-2.5" />
                        {insight.impact}
                      </p>
                    )}
                  </div>
                  {insight.action && (
                    <Button variant="ghost" size="sm" className="shrink-0 h-7 text-xs gap-1">
                      {insight.action}
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t">
          <div className="text-center p-2 rounded-lg bg-muted/30">
            <div className="flex items-center justify-center gap-1 mb-1">
              <DollarSign className="h-3 w-3 text-muted-foreground" />
            </div>
            <p className="text-xs font-semibold">${avgDailySpend.toFixed(0)}</p>
            <p className="text-[9px] text-muted-foreground">Daily Avg</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted/30">
            <div className="flex items-center justify-center gap-1 mb-1">
              <TrendingUp className="h-3 w-3 text-muted-foreground" />
            </div>
            <p className="text-xs font-semibold">${monthlyProjection.toFixed(0)}</p>
            <p className="text-[9px] text-muted-foreground">Projected</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted/30">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Target className="h-3 w-3 text-muted-foreground" />
            </div>
            <p className="text-xs font-semibold">{overallEfficiency.toFixed(0)}%</p>
            <p className="text-[9px] text-muted-foreground">Efficiency</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted/30">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock className="h-3 w-3 text-muted-foreground" />
            </div>
            <p className="text-xs font-semibold">{activeCampaigns.length}</p>
            <p className="text-[9px] text-muted-foreground">Active</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
