import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Send, QrCode, ArrowLeftRight, Zap, Wallet, TrendingUp, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WalletQuickActionsProps {
  onAddFunds: () => void;
  onTransfer?: () => void;
  onScan?: () => void;
  onSend?: () => void;
  pendingAmount?: number;
  recentActivityCount?: number;
}

const quickActions = [
  {
    id: 'add',
    label: 'Add Funds',
    icon: Plus,
    gradient: 'from-emerald-500 to-teal-500',
    bgGlow: 'group-hover:shadow-emerald-500/25',
    description: 'Top up wallet',
  },
  {
    id: 'send',
    label: 'Send',
    icon: Send,
    gradient: 'from-primary to-blue-500',
    bgGlow: 'group-hover:shadow-primary/25',
    description: 'Transfer funds',
  },
  {
    id: 'scan',
    label: 'Scan QR',
    icon: QrCode,
    gradient: 'from-violet-500 to-purple-500',
    bgGlow: 'group-hover:shadow-violet-500/25',
    description: 'Quick pay',
  },
  {
    id: 'transfer',
    label: 'Allocate',
    icon: ArrowLeftRight,
    gradient: 'from-amber-500 to-orange-500',
    bgGlow: 'group-hover:shadow-amber-500/25',
    description: 'To campaigns',
  },
];

export default function WalletQuickActions({
  onAddFunds,
  onTransfer,
  onScan,
  onSend,
  pendingAmount = 0,
  recentActivityCount = 0,
}: WalletQuickActionsProps) {
  const handleAction = (actionId: string) => {
    switch (actionId) {
      case 'add':
        onAddFunds();
        break;
      case 'send':
        onSend?.();
        break;
      case 'scan':
        onScan?.();
        break;
      case 'transfer':
        onTransfer?.();
        break;
    }
  };

  return (
    <Card className="overflow-hidden border-0 bg-gradient-to-br from-card via-card to-muted/30">
      <CardContent className="p-6">
        {/* Header with Status Indicators */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Quick Actions</h3>
              <p className="text-xs text-muted-foreground">One-tap wallet operations</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {pendingAmount > 0 && (
              <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30 gap-1">
                <Clock className="h-3 w-3" />${pendingAmount.toLocaleString()} pending
              </Badge>
            )}
            {recentActivityCount > 0 && (
              <Badge variant="secondary" className="gap-1">
                <TrendingUp className="h-3 w-3" />
                {recentActivityCount} new
              </Badge>
            )}
          </div>
        </div>

        {/* Quick Action Buttons Grid */}
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={() => handleAction(action.id)}
                className={cn(
                  'group relative flex flex-col items-center gap-3 p-4 rounded-2xl',
                  'bg-gradient-to-br from-background to-muted/50',
                  'border border-border/50 hover:border-border',
                  'transition-all duration-300 ease-out',
                  'hover:-translate-y-1 hover:shadow-xl',
                  action.bgGlow,
                )}
              >
                {/* Icon Container with Gradient */}
                <div
                  className={cn(
                    'relative p-3.5 rounded-xl',
                    'bg-gradient-to-br',
                    action.gradient,
                    'shadow-lg',
                    'group-hover:scale-110 transition-transform duration-300',
                  )}
                >
                  <Icon className="h-5 w-5 text-white" />

                  {/* Glow Effect */}
                  <div
                    className={cn(
                      'absolute inset-0 rounded-xl opacity-0 group-hover:opacity-50',
                      'bg-gradient-to-br',
                      action.gradient,
                      'blur-xl transition-opacity duration-300',
                    )}
                  />
                </div>

                {/* Label */}
                <div className="text-center">
                  <p className="font-medium text-sm text-foreground">{action.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{action.description}</p>
                </div>

                {/* Hover Ring */}
                <div className="absolute inset-0 rounded-2xl ring-2 ring-primary/0 group-hover:ring-primary/20 transition-all duration-300" />
              </button>
            );
          })}
        </div>

        {/* Bottom Quick Stats */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-border/50">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-muted-foreground">Real-time sync</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Wallet className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Multi-platform ready</span>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-xs text-muted-foreground hover:text-foreground gap-1">
            View all actions
            <TrendingUp className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
