import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import {
  CreditCard,
  Plus,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Settings,
  Copy,
  CheckCircle2,
  AlertTriangle,
  Fingerprint,
  Shield,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface VirtualCard {
  id: string;
  name: string;
  lastFour: string;
  brand: 'visa' | 'mastercard' | 'amex';
  type: 'virtual' | 'physical';
  status: 'active' | 'frozen' | 'expired';
  balance: number;
  limit: number;
  expiryDate: string;
  color: string;
}

const mockCards: VirtualCard[] = [
  {
    id: '1',
    name: 'Meta Ads Card',
    lastFour: '4242',
    brand: 'visa',
    type: 'virtual',
    status: 'active',
    balance: 2500,
    limit: 10000,
    expiryDate: '12/26',
    color: 'from-blue-600 via-blue-500 to-indigo-500',
  },
  {
    id: '2',
    name: 'Google Ads Card',
    lastFour: '8888',
    brand: 'mastercard',
    type: 'virtual',
    status: 'active',
    balance: 1800,
    limit: 5000,
    expiryDate: '06/25',
    color: 'from-emerald-600 via-teal-500 to-cyan-500',
  },
  {
    id: '3',
    name: 'Main Business Card',
    lastFour: '1234',
    brand: 'visa',
    type: 'physical',
    status: 'frozen',
    balance: 0,
    limit: 25000,
    expiryDate: '03/27',
    color: 'from-slate-700 via-slate-600 to-slate-500',
  },
];

const getBrandLogo = (brand: string) => {
  switch (brand) {
    case 'visa':
      return 'VISA';
    case 'mastercard':
      return 'MC';
    case 'amex':
      return 'AMEX';
    default:
      return '';
  }
};

export default function VirtualCardsManager() {
  const [cards, setCards] = useState(mockCards);
  const [showDetails, setShowDetails] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleCardFreeze = (cardId: string) => {
    setCards((prev) =>
      prev.map((card) => {
        if (card.id === cardId) {
          const newStatus = card.status === 'frozen' ? 'active' : 'frozen';
          toast({
            title: newStatus === 'frozen' ? 'Card Frozen' : 'Card Unfrozen',
            description: `${card.name} has been ${newStatus === 'frozen' ? 'frozen' : 'unfrozen'}.`,
          });
          return { ...card, status: newStatus as 'active' | 'frozen' };
        }
        return card;
      }),
    );
  };

  const toggleShowDetails = (cardId: string) => {
    setShowDetails((prev) => ({ ...prev, [cardId]: !prev[cardId] }));
  };

  const copyCardNumber = (cardId: string) => {
    // Mock copy action
    navigator.clipboard.writeText(`**** **** **** ${mockCards.find((c) => c.id === cardId)?.lastFour}`);
    setCopiedId(cardId);
    toast({ title: 'Copied', description: 'Card number copied to clipboard' });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const activeCards = cards.filter((c) => c.status === 'active').length;
  const frozenCards = cards.filter((c) => c.status === 'frozen').length;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-violet-500 to-purple-500">
              <CreditCard className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Payment Cards</CardTitle>
              <CardDescription>Manage your virtual & physical cards</CardDescription>
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            <Plus className="h-3.5 w-3.5" />
            New Card
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-5">
        {/* Card Stats */}
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="gap-1.5 bg-emerald-500/10 text-emerald-600 border-emerald-500/30">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            {activeCards} Active
          </Badge>
          <Badge variant="secondary" className="gap-1.5 bg-muted text-muted-foreground">
            <Lock className="h-3 w-3" />
            {frozenCards} Frozen
          </Badge>
          <Badge variant="secondary" className="gap-1.5 bg-primary/10 text-primary">
            <Sparkles className="h-3 w-3" />
            {cards.filter((c) => c.type === 'virtual').length} Virtual
          </Badge>
        </div>

        {/* Cards List */}
        <div className="space-y-4">
          {cards.map((card) => (
            <div
              key={card.id}
              className={cn(
                'relative rounded-2xl overflow-hidden transition-all duration-300',
                card.status === 'frozen' && 'opacity-75',
              )}
            >
              {/* Card Visual */}
              <div
                className={cn(
                  'relative p-5 bg-gradient-to-br text-white',
                  card.color,
                  card.status === 'frozen' && 'grayscale',
                )}
              >
                {/* Frosted overlay for frozen cards */}
                {card.status === 'frozen' && (
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="flex items-center gap-2 bg-black/30 px-4 py-2 rounded-full">
                      <Lock className="h-4 w-4" />
                      <span className="text-sm font-medium">Card Frozen</span>
                    </div>
                  </div>
                )}

                {/* Card Header */}
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <p className="text-white/70 text-xs mb-1">
                      {card.type === 'virtual' ? 'Virtual Card' : 'Physical Card'}
                    </p>
                    <p className="font-semibold">{card.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg tracking-wider">{getBrandLogo(card.brand)}</p>
                  </div>
                </div>

                {/* Card Number */}
                <div className="mb-4">
                  <p className="text-white/70 text-xs mb-1">Card Number</p>
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-lg tracking-widest">
                      {showDetails[card.id] ? `4532 8219 7634 ${card.lastFour}` : `•••• •••• •••• ${card.lastFour}`}
                    </p>
                    <button
                      onClick={() => copyCardNumber(card.id)}
                      className="p-1 rounded hover:bg-white/10 transition-colors"
                    >
                      {copiedId === card.id ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {/* Card Footer */}
                <div className="flex items-end justify-between">
                  <div className="flex gap-6">
                    <div>
                      <p className="text-white/70 text-xs">Expires</p>
                      <p className="font-medium">{card.expiryDate}</p>
                    </div>
                    <div>
                      <p className="text-white/70 text-xs">CVV</p>
                      <p className="font-medium">{showDetails[card.id] ? '847' : '•••'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {card.type === 'virtual' && (
                      <div className="flex items-center gap-1 text-xs bg-white/20 px-2 py-1 rounded-full">
                        <Sparkles className="h-3 w-3" />
                        Virtual
                      </div>
                    )}
                  </div>
                </div>

                {/* Balance Bar */}
                <div className="mt-4 pt-3 border-t border-white/20">
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="text-white/70">Balance Used</span>
                    <span className="font-medium">
                      {formatCurrency(card.balance)} / {formatCurrency(card.limit)}
                    </span>
                  </div>
                  <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-white rounded-full transition-all duration-500"
                      style={{ width: `${(card.balance / card.limit) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Card Actions */}
              <div className="flex items-center justify-between p-3 bg-muted/50 border-t border-border">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="gap-1.5 h-8" onClick={() => toggleShowDetails(card.id)}>
                    {showDetails[card.id] ? (
                      <>
                        <EyeOff className="h-3.5 w-3.5" />
                        Hide
                      </>
                    ) : (
                      <>
                        <Fingerprint className="h-3.5 w-3.5" />
                        Reveal
                      </>
                    )}
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-1.5 h-8">
                    <Settings className="h-3.5 w-3.5" />
                    Settings
                  </Button>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">
                      {card.status === 'frozen' ? 'Frozen' : 'Active'}
                    </span>
                    <Switch checked={card.status === 'active'} onCheckedChange={() => toggleCardFreeze(card.id)} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Security Info */}
        <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
          <Shield className="h-5 w-5 text-emerald-500 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">All cards protected with 3D Secure</p>
            <p className="text-xs text-muted-foreground">Real-time fraud monitoring enabled</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}
