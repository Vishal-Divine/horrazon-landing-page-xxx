import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Bot,
  Send,
  Sparkles,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PiggyBank,
  AlertTriangle,
  Lightbulb,
  RefreshCw,
  ThumbsUp,
  ThumbsDown,
  Copy,
  MoreHorizontal,
  Zap,
  Target,
  Shield,
  BarChart3,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  metrics?: {
    label: string;
    value: string;
    trend?: 'up' | 'down' | 'neutral';
  }[];
  actions?: {
    label: string;
    action: () => void;
  }[];
}

const quickPrompts = [
  {
    icon: <TrendingUp className="h-4 w-4" />,
    label: 'Analyze my spending',
    prompt: 'Analyze my current spending patterns and identify areas for optimization.',
  },
  {
    icon: <PiggyBank className="h-4 w-4" />,
    label: 'Budget recommendations',
    prompt: 'Give me personalized budget recommendations based on my campaign performance.',
  },
  {
    icon: <Target className="h-4 w-4" />,
    label: 'Optimize ROI',
    prompt: 'How can I optimize my ROI across all advertising platforms?',
  },
  {
    icon: <AlertTriangle className="h-4 w-4" />,
    label: 'Risk assessment',
    prompt: 'What are the current risks in my advertising spend and how can I mitigate them?',
  },
];

export default function AIFinancialAdvisor() {
  const { wallet, campaignSpends, transactions } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content:
        "👋 Hello! I'm your AI Financial Advisor. I can help you optimize your advertising budget, analyze spending patterns, and provide personalized recommendations. What would you like to know?",
      timestamp: new Date(),
      suggestions: ['Analyze my spending patterns', 'Optimize my campaign budgets', 'Show me savings opportunities'],
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const generateAIResponse = (userMessage: string): ChatMessage => {
    const lowerMessage = userMessage.toLowerCase();

    // Spending analysis
    if (lowerMessage.includes('spending') || lowerMessage.includes('analyze')) {
      const avgDaily = wallet.monthlySpent / 30;
      const topPlatform = campaignSpends.reduce((a, b) => (a.spent > b.spent ? a : b));

      return {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `📊 **Spending Analysis Summary**\n\nI've analyzed your spending patterns across all platforms. Here's what I found:\n\n**Key Insights:**\n• Your average daily spend is **${formatCurrency(avgDaily)}**\n• **${topPlatform.platform}** accounts for the highest spend (${Math.round((topPlatform.spent / wallet.monthlySpent) * 100)}% of total)\n• You have **${formatCurrency(wallet.balance)}** remaining in your wallet\n\n**Recommendations:**\n1. Consider reallocating 15% from ${topPlatform.platform} to lower-cost channels\n2. Set up automated budget alerts at 80% spend threshold\n3. Review underperforming campaigns for budget optimization`,
        timestamp: new Date(),
        metrics: [
          { label: 'Daily Avg', value: formatCurrency(avgDaily), trend: 'neutral' },
          { label: 'Monthly Total', value: formatCurrency(wallet.monthlySpent), trend: 'up' },
          {
            label: 'Runway',
            value: `${Math.floor(wallet.balance / avgDaily)} days`,
            trend: wallet.balance / avgDaily < 14 ? 'down' : 'up',
          },
        ],
        suggestions: ['Show me optimization tips', 'Compare platform performance', 'Set budget alerts'],
      };
    }

    // Budget recommendations
    if (lowerMessage.includes('budget') || lowerMessage.includes('recommend')) {
      return {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `💡 **Budget Recommendations**\n\nBased on your current performance data, here are my personalized recommendations:\n\n**Immediate Actions:**\n• Reduce LinkedIn spend by 20% - current CPL is 40% above benchmark\n• Increase Meta budget by 15% - showing 2.3x ROAS potential\n• Pause low-performing Google keywords to save ${formatCurrency(wallet.monthlySpent * 0.08)}/month\n\n**Strategic Suggestions:**\n• Implement dayparting to reduce wasted spend by ~12%\n• Test TikTok for younger demographics (estimated 30% lower CPA)\n• Set up automated bid adjustments based on conversion data`,
        timestamp: new Date(),
        metrics: [
          { label: 'Potential Savings', value: formatCurrency(wallet.monthlySpent * 0.15), trend: 'up' },
          { label: 'Est. ROI Increase', value: '+23%', trend: 'up' },
        ],
        actions: [
          { label: 'Apply Recommendations', action: () => console.log('Apply') },
          { label: 'Schedule Review', action: () => console.log('Schedule') },
        ],
      };
    }

    // ROI optimization
    if (lowerMessage.includes('roi') || lowerMessage.includes('optimize')) {
      return {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `🎯 **ROI Optimization Strategy**\n\nHere's a data-driven approach to maximize your return on ad spend:\n\n**High-Impact Opportunities:**\n1. **Audience Refinement** - Narrow targeting to high-converting segments could improve ROAS by 35%\n2. **Creative Testing** - A/B test 3 new ad variants (estimated 20% CTR improvement)\n3. **Bid Strategy** - Switch to target CPA bidding on mature campaigns\n\n**Platform-Specific Tips:**\n• **Meta**: Focus budget on Reels - 2x engagement vs feed ads\n• **Google**: Expand exact match keywords with proven conversion history\n• **TikTok**: Leverage Spark Ads for authentic engagement`,
        timestamp: new Date(),
        suggestions: ['Create optimization plan', 'Show projected improvements', 'Compare to industry benchmarks'],
      };
    }

    // Risk assessment
    if (lowerMessage.includes('risk')) {
      const criticalCampaigns = campaignSpends.filter((c) => c.riskLevel === 'critical' || c.riskLevel === 'high');

      return {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `⚠️ **Risk Assessment Report**\n\nI've identified ${criticalCampaigns.length} areas requiring attention:\n\n**High Priority Risks:**\n${criticalCampaigns.map((c) => `• **${c.name}** - ${c.daysRemaining} days remaining, ${Math.round((c.spent / c.budget) * 100)}% budget used`).join('\n')}\n\n**Mitigation Strategies:**\n1. Increase wallet balance to maintain 14-day runway\n2. Set up automatic budget caps on underperforming campaigns\n3. Enable spend alerts at 75% threshold\n\n**Health Score:** ${wallet.balance > 5000 ? 'Good ✅' : wallet.balance > 2000 ? 'Moderate ⚠️' : 'Critical 🔴'}`,
        timestamp: new Date(),
        metrics: [
          {
            label: 'Risk Score',
            value: criticalCampaigns.length > 2 ? 'High' : 'Moderate',
            trend: criticalCampaigns.length > 2 ? 'down' : 'neutral',
          },
          { label: 'At-Risk Campaigns', value: String(criticalCampaigns.length), trend: 'down' },
        ],
      };
    }

    // Default response
    return {
      id: `msg-${Date.now()}`,
      role: 'assistant',
      content: `I understand you're asking about "${userMessage}". Let me analyze your data...\n\n**Current Status:**\n• Wallet Balance: ${formatCurrency(wallet.balance)}\n• Monthly Spend: ${formatCurrency(wallet.monthlySpent)}\n• Active Campaigns: ${campaignSpends.filter((c) => c.status === 'active').length}\n\nWould you like me to dive deeper into any specific aspect of your financial data?`,
      timestamp: new Date(),
      suggestions: ['Analyze spending', 'Budget recommendations', 'Risk assessment', 'Optimize ROI'],
    };
  };

  const handleSend = async (message: string = inputValue) => {
    if (!message.trim()) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: message,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI thinking
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const aiResponse = generateAIResponse(message);
    setMessages((prev) => [...prev, aiResponse]);
    setIsTyping(false);
  };

  return (
    <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-background to-background">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <Bot className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-background flex items-center justify-center">
                <Zap className="h-2 w-2 text-white" />
              </div>
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                AI Financial Advisor
                <Badge variant="secondary" className="bg-primary/20 text-primary text-xs">
                  <Sparkles className="h-3 w-3 mr-1" />
                  Powered by AI
                </Badge>
              </CardTitle>
              <CardDescription>Personalized budget recommendations & spending insights</CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Quick Prompts */}
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((prompt, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="text-xs gap-1.5 hover:bg-primary/10 hover:border-primary/50"
              onClick={() => handleSend(prompt.prompt)}
            >
              {prompt.icon}
              {prompt.label}
            </Button>
          ))}
        </div>

        {/* Chat Messages */}
        <ScrollArea className="h-[400px] pr-4" ref={scrollRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn('flex gap-3', message.role === 'user' ? 'justify-end' : 'justify-start')}
              >
                {message.role === 'assistant' && (
                  <Avatar className="h-8 w-8 border border-primary/20">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}

                <div className={cn('max-w-[80%] space-y-3', message.role === 'user' ? 'items-end' : 'items-start')}>
                  <div
                    className={cn(
                      'rounded-2xl px-4 py-3',
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted/50 border border-border/50',
                    )}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  </div>

                  {/* Metrics */}
                  {message.metrics && (
                    <div className="flex flex-wrap gap-2">
                      {message.metrics.map((metric, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-background border border-border/50"
                        >
                          {metric.trend === 'up' && <TrendingUp className="h-3 w-3 text-emerald-500" />}
                          {metric.trend === 'down' && <TrendingDown className="h-3 w-3 text-red-500" />}
                          <span className="text-xs text-muted-foreground">{metric.label}:</span>
                          <span className="text-xs font-semibold">{metric.value}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Suggestions */}
                  {message.suggestions && (
                    <div className="flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, idx) => (
                        <Button
                          key={idx}
                          variant="ghost"
                          size="sm"
                          className="text-xs h-7 px-2 hover:bg-primary/10"
                          onClick={() => handleSend(suggestion)}
                        >
                          <Lightbulb className="h-3 w-3 mr-1 text-amber-500" />
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}

                  {/* Actions */}
                  {message.actions && (
                    <div className="flex gap-2">
                      {message.actions.map((action, idx) => (
                        <Button
                          key={idx}
                          size="sm"
                          variant={idx === 0 ? 'default' : 'outline'}
                          className="text-xs"
                          onClick={action.action}
                        >
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  )}

                  {/* Message Actions */}
                  {message.role === 'assistant' && message.id !== 'welcome' && (
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <ThumbsUp className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <ThumbsDown className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <Copy className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <RefreshCw className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>

                {message.role === 'user' && (
                  <Avatar className="h-8 w-8 border">
                    <AvatarFallback className="bg-primary/10 text-sm">U</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3">
                <Avatar className="h-8 w-8 border border-primary/20">
                  <AvatarFallback className="bg-primary/10 text-primary">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted/50 border border-border/50 rounded-2xl px-4 py-3">
                  <div className="flex gap-1">
                    <span
                      className="w-2 h-2 rounded-full bg-primary/60 animate-bounce"
                      style={{ animationDelay: '0ms' }}
                    />
                    <span
                      className="w-2 h-2 rounded-full bg-primary/60 animate-bounce"
                      style={{ animationDelay: '150ms' }}
                    />
                    <span
                      className="w-2 h-2 rounded-full bg-primary/60 animate-bounce"
                      style={{ animationDelay: '300ms' }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask about your budget, spending, or get recommendations..."
            className="flex-1"
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button onClick={() => handleSend()} disabled={!inputValue.trim() || isTyping}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
