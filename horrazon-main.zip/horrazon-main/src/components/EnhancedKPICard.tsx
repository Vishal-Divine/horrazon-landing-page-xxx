import { LucideIcon } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';

interface SparklineData {
  value: number;
}

interface EnhancedKPICardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: LucideIcon;
  sparklineData: SparklineData[];
  goal?: number;
  current?: number;
  anomaly?: 'critical' | 'warning' | null;
  comparisonPeriod?: string;
}

export default function EnhancedKPICard({
  title,
  value,
  change,
  trend,
  icon: Icon,
  sparklineData,
  goal,
  current,
  anomaly,
  comparisonPeriod = 'vs last period',
}: EnhancedKPICardProps) {
  const isPositive = trend === 'up';
  const goalProgress = goal && current ? (current / goal) * 100 : undefined;

  return (
    <Card className="group relative overflow-hidden p-6 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-0.5 border-border/50">
      {/* Anomaly Badge */}
      {anomaly && (
        <Badge
          variant={anomaly === 'critical' ? 'destructive' : 'secondary'}
          className={cn(
            'absolute top-3 right-3 flex items-center gap-1 text-xs font-semibold',
            anomaly === 'critical' ? 'animate-pulse' : '',
          )}
        >
          <AlertCircle className="h-3 w-3" />
          {anomaly === 'critical' ? 'Critical' : 'Warning'}
        </Badge>
      )}

      <div className="flex items-start justify-between">
        <div className="flex-1 space-y-3">
          <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
          <p className="text-4xl font-bold tracking-tight bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text">
            {value}
          </p>

          {/* Trend Badge */}
          <div className="flex items-center gap-2">
            <div
              className={cn(
                'flex items-center gap-1 text-sm font-semibold px-2.5 py-1 rounded-md',
                isPositive ? 'text-success bg-success/10' : 'text-destructive bg-destructive/10',
              )}
            >
              {isPositive ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
              {change}
            </div>
            <span className="text-xs text-muted-foreground/80">{comparisonPeriod}</span>
          </div>

          {/* Sparkline */}
          <div className="h-12 w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sparklineData}>
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={isPositive ? 'hsl(var(--success))' : 'hsl(var(--chart-1))'}
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Goal Progress */}
          {goal && current && goalProgress !== undefined && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground font-medium">Goal Progress</span>
                <span className="font-semibold text-foreground">
                  {current.toLocaleString()} / {goal.toLocaleString()}
                </span>
              </div>
              <Progress value={goalProgress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {goalProgress >= 100 ? (
                  <span className="text-success font-semibold">🎉 Goal achieved!</span>
                ) : (
                  <span>{(100 - goalProgress).toFixed(0)}% to goal</span>
                )}
              </p>
            </div>
          )}
        </div>

        {/* Icon */}
        <div
          className={cn(
            'rounded-xl p-3.5 transition-all duration-300 group-hover:scale-110',
            isPositive
              ? 'bg-gradient-to-br from-success/10 to-success/5 ring-1 ring-success/20'
              : 'bg-gradient-to-br from-primary/10 to-primary/5 ring-1 ring-primary/20',
          )}
        >
          <Icon
            className={cn(
              'h-6 w-6 transition-transform duration-300 group-hover:rotate-12',
              isPositive ? 'text-success' : 'text-primary',
            )}
          />
        </div>
      </div>
    </Card>
  );
}
