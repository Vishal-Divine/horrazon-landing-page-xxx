import { useState } from 'react';
import { Search, Sparkles, Command, ArrowRight, TrendingUp, Zap, FileText, Users } from 'lucide-react';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface SearchResult {
  id: string;
  type: 'action' | 'report' | 'campaign' | 'segment' | 'insight';
  title: string;
  description: string;
  path: string;
}

const recentSearches = ['Campaign performance last week', 'Top converting segments', 'Budget optimization suggestions'];

const quickActions = [
  { icon: TrendingUp, label: 'View Analytics', path: '/outreach' },
  { icon: Zap, label: 'Action Center', path: '/actions' },
  { icon: FileText, label: 'Generate Report', path: '/reports' },
  { icon: Users, label: 'Customer Segments', path: '/segments' },
];

const aiSuggestions = [
  'Which campaigns need immediate attention?',
  'Show me underperforming ad groups',
  "Predict next month's revenue",
  'Find high-value customer segments',
];

export default function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="flex items-center gap-3 bg-muted/50 hover:bg-muted/80 border border-border/50 rounded-xl px-4 py-2.5 transition-all duration-200 min-w-[400px] group">
          <Search className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground flex-1 text-left">
            Ask AI, search campaigns, or run actions...
          </span>
          <div className="flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-primary" />
            <kbd className="hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border bg-background px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
              <Command className="h-3 w-3" />K
            </kbd>
          </div>
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] p-0 gap-0 overflow-hidden">
        <div className="border-b p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <Input
              placeholder="Ask anything or search..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="border-0 focus-visible:ring-0 text-base"
              autoFocus
            />
          </div>
        </div>

        <div className="max-h-[400px] overflow-y-auto">
          {/* AI Suggestions */}
          <div className="p-4 border-b">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                AI Suggestions
              </span>
            </div>
            <div className="space-y-2">
              {aiSuggestions.map((suggestion, i) => (
                <button
                  key={i}
                  className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors text-left group"
                  onClick={() => setQuery(suggestion)}
                >
                  <span className="text-sm">{suggestion}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="p-4 border-b">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="h-4 w-4 text-amber-500" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Quick Actions</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {quickActions.map((action, i) => (
                <button
                  key={i}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors text-left"
                  onClick={() => setOpen(false)}
                >
                  <div className="p-2 rounded-lg bg-muted">
                    <action.icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium">{action.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Recent Searches */}
          <div className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Search className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Recent Searches
              </span>
            </div>
            <div className="space-y-1">
              {recentSearches.map((search, i) => (
                <button
                  key={i}
                  className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors text-left"
                  onClick={() => setQuery(search)}
                >
                  <Search className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{search}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-3 border-t bg-muted/30 flex items-center justify-between">
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-background border text-[10px]">↵</kbd>
              to search
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-background border text-[10px]">esc</kbd>
              to close
            </span>
          </div>
          <Badge variant="secondary" className="text-xs">
            Powered by AI
          </Badge>
        </div>
      </DialogContent>
    </Dialog>
  );
}
