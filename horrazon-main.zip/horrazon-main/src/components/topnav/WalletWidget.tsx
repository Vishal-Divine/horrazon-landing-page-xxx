import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  CreditCard,
  History,
  AlertTriangle,
  Sparkles,
  Target,
  RefreshCw,
  ChevronRight,
  AlertCircle,
  Bell,
  Settings,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/contexts/AppContext';
import SpendingAlertsPanel from '@/components/wallet/SpendingAlertsPanel';
import { formatDistanceToNow } from 'date-fns';

export default function WalletWidget() {
  const {
    wallet,
    transactions,
    campaignSpends,
    spendingAlerts,
    refreshWallet,
    updateAutoRecharge,
    setIsAddFundsOpen,
    isLoading,
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: wallet.currency,
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (date: Date) => {
    return formatDistanceToNow(date, { addSuffix: true });
  };

  const isLowBalance = wallet.balance < wallet.lowBalanceThreshold;
  const isCriticalBalance = wallet.balance < wallet.criticalBalanceThreshold;
  const activeAlerts = spendingAlerts.filter((a) => !a.acknowledged);
  const hasAlerts = activeAlerts.length > 0;

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'meta':
        return 'bg-blue-500';
      case 'google':
        return 'bg-red-500';
      case 'tiktok':
        return 'bg-pink-500';
      case 'linkedin':
        return 'bg-sky-600';
      default:
        return 'bg-gray-500';
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'critical':
        return (
          <Badge variant="destructive" className="text-[10px] px-1">
            Critical
          </Badge>
        );
      case 'high':
        return <Badge className="bg-chart-3/20 text-chart-3 text-[10px] px-1">High</Badge>;
      case 'medium':
        return (
          <Badge variant="secondary" className="text-[10px] px-1">
            Medium
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="text-[10px] px-1">
            Low
          </Badge>
        );
    }
  };

  return (
    <TooltipProvider delayDuration={200}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className={`gap-2 transition-all duration-300 relative ${
                  isCriticalBalance
                    ? 'text-destructive hover:text-destructive hover:bg-destructive/10 animate-pulse'
                    : isLowBalance
                      ? 'text-warning hover:text-warning hover:bg-warning/10'
                      : 'text-success hover:text-success hover:bg-success/10'
                }`}
              >
                <div className="relative">
                  <Wallet className="h-4 w-4" />
                  {(hasAlerts || isLowBalance) && (
                    <span
                      className={`absolute -top-1 -right-1 h-2 w-2 rounded-full ${isCriticalBalance ? 'bg-destructive' : 'bg-warning'} animate-pulse`}
                    />
                  )}
                </div>
                <span className="hidden lg:inline text-sm font-semibold">{formatCurrency(wallet.balance)}</span>
                {isCriticalBalance && (
                  <Badge variant="destructive" className="ml-1 px-1.5 py-0 text-[10px] animate-pulse">
                    CRITICAL
                  </Badge>
                )}
                {isLowBalance && !isCriticalBalance && (
                  <Badge className="ml-1 px-1.5 py-0 text-[10px] bg-warning text-warning-foreground">LOW</Badge>
                )}
                {hasAlerts && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-destructive text-[10px] text-white flex items-center justify-center font-bold">
                    {activeAlerts.length}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent>
            <p>Wallet Balance - Click to view details</p>
          </TooltipContent>
        </Tooltip>

        <PopoverContent className="w-[420px] p-0" align="end">
          {/* Header with Balance */}
          <div
            className={`p-4 ${
              isCriticalBalance
                ? 'bg-gradient-to-r from-destructive/10 to-destructive/5'
                : isLowBalance
                  ? 'bg-gradient-to-r from-warning/10 to-warning/5'
                  : 'bg-gradient-to-r from-success/10 to-emerald-500/5'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div
                  className={`p-2 rounded-lg ${
                    isCriticalBalance ? 'bg-destructive/10' : isLowBalance ? 'bg-warning/10' : 'bg-success/10'
                  }`}
                >
                  <Wallet
                    className={`h-5 w-5 ${
                      isCriticalBalance ? 'text-destructive' : isLowBalance ? 'text-warning' : 'text-success'
                    }`}
                  />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Available Balance</p>
                  <p
                    className={`text-2xl font-bold ${
                      isCriticalBalance ? 'text-destructive' : isLowBalance ? 'text-warning' : 'text-success'
                    }`}
                  >
                    {formatCurrency(wallet.balance)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={refreshWallet} disabled={isLoading}>
                  <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                </Button>
                <Button
                  size="sm"
                  className="gap-1 bg-gradient-to-r from-success to-emerald-500 hover:from-success/90 hover:to-emerald-500/90 text-white"
                  onClick={() => setIsAddFundsOpen(true)}
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add Funds
                </Button>
              </div>
            </div>

            {/* Critical Balance Alert */}
            {isCriticalBalance && (
              <div className="flex items-center gap-2 p-2 rounded-lg bg-destructive/10 border border-destructive/30 animate-pulse">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <p className="text-xs text-destructive font-medium">
                  CRITICAL! Campaigns will pause soon. Add funds immediately!
                </p>
              </div>
            )}

            {/* Low Balance Warning */}
            {isLowBalance && !isCriticalBalance && (
              <div className="flex items-center gap-2 p-2 rounded-lg bg-warning/10 border border-warning/30">
                <AlertTriangle className="h-4 w-4 text-warning" />
                <p className="text-xs text-warning">Low balance! Add funds to avoid campaign interruptions.</p>
              </div>
            )}

            {/* Pending Charges */}
            {wallet.pendingCharges > 0 && (
              <div className="flex items-center justify-between mt-2 p-2 rounded-lg bg-chart-3/10 border border-chart-3/20">
                <div className="flex items-center gap-2">
                  <History className="h-4 w-4 text-chart-3" />
                  <span className="text-xs text-chart-3">Pending Charges</span>
                </div>
                <span className="text-xs font-semibold text-chart-3">{formatCurrency(wallet.pendingCharges)}</span>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-2 p-3 border-b">
            <div className="text-center p-2 rounded-lg bg-muted/50">
              <p className="text-[10px] text-muted-foreground uppercase">Today</p>
              <p className="text-sm font-semibold text-foreground flex items-center justify-center gap-1">
                <ArrowUpRight className="h-3 w-3 text-destructive" />
                {formatCurrency(wallet.dailySpent)}
              </p>
            </div>
            <div className="text-center p-2 rounded-lg bg-muted/50">
              <p className="text-[10px] text-muted-foreground uppercase">This Month</p>
              <p className="text-sm font-semibold text-foreground flex items-center justify-center gap-1">
                <TrendingUp className="h-3 w-3 text-chart-3" />
                {formatCurrency(wallet.monthlySpent)}
              </p>
            </div>
            <div className="text-center p-2 rounded-lg bg-muted/50">
              <p className="text-[10px] text-muted-foreground uppercase">All Time</p>
              <p className="text-sm font-semibold text-foreground">{formatCurrency(wallet.totalSpent)}</p>
            </div>
          </div>

          {/* Tabs for Campaigns, Transactions, and Alerts */}
          <Tabs defaultValue={hasAlerts ? 'alerts' : 'campaigns'} className="w-full">
            <TabsList className="w-full grid grid-cols-3 h-9 p-1 mx-0 rounded-none border-b">
              <TabsTrigger value="campaigns" className="text-xs gap-1.5 data-[state=active]:shadow-none">
                <Target className="h-3.5 w-3.5" />
                Campaigns
              </TabsTrigger>
              <TabsTrigger value="transactions" className="text-xs gap-1.5 data-[state=active]:shadow-none">
                <History className="h-3.5 w-3.5" />
                History
              </TabsTrigger>
              <TabsTrigger value="alerts" className="text-xs gap-1.5 data-[state=active]:shadow-none relative">
                <Bell className="h-3.5 w-3.5" />
                Alerts
                {hasAlerts && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-1 -right-1 h-4 w-4 p-0 text-[10px] flex items-center justify-center"
                  >
                    {activeAlerts.length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="campaigns" className="m-0">
              <ScrollArea className="h-52">
                <div className="divide-y">
                  {campaignSpends.map((campaign) => (
                    <div key={campaign.id} className="p-3 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <div className={`h-2 w-2 rounded-full ${getPlatformColor(campaign.platform)}`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{campaign.name}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {campaign.platform} • {campaign.daysRemaining} days left
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {getRiskBadge(campaign.riskLevel)}
                          <Badge
                            variant={campaign.status === 'active' ? 'default' : 'secondary'}
                            className="text-[10px] px-1.5 py-0"
                          >
                            {campaign.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">
                            {formatCurrency(campaign.spent)} / {formatCurrency(campaign.budget)}
                          </span>
                          <span
                            className={`font-medium ${
                              campaign.riskLevel === 'critical'
                                ? 'text-destructive'
                                : campaign.riskLevel === 'high'
                                  ? 'text-chart-3'
                                  : ''
                            }`}
                          >
                            {Math.round((campaign.spent / campaign.budget) * 100)}%
                          </span>
                        </div>
                        <Progress
                          value={(campaign.spent / campaign.budget) * 100}
                          className={`h-1.5 ${
                            campaign.riskLevel === 'critical'
                              ? '[&>div]:bg-destructive'
                              : campaign.riskLevel === 'high'
                                ? '[&>div]:bg-chart-3'
                                : ''
                          }`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="transactions" className="m-0">
              <ScrollArea className="h-52">
                <div className="divide-y">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="p-3 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div
                          className={`p-1.5 rounded-full ${
                            tx.type === 'credit' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                          }`}
                        >
                          {tx.type === 'credit' ? (
                            <ArrowDownLeft className="h-3.5 w-3.5" />
                          ) : (
                            <ArrowUpRight className="h-3.5 w-3.5" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-medium truncate">{tx.description}</p>
                              {tx.campaign && <p className="text-[10px] text-muted-foreground">{tx.campaign}</p>}
                            </div>
                            <p
                              className={`text-sm font-semibold whitespace-nowrap ${
                                tx.type === 'credit' ? 'text-success' : 'text-destructive'
                              }`}
                            >
                              {tx.type === 'credit' ? '+' : '-'}
                              {formatCurrency(tx.amount)}
                            </p>
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[10px] text-muted-foreground">{formatDate(tx.date)}</span>
                            <Badge
                              variant={
                                tx.status === 'completed'
                                  ? 'secondary'
                                  : tx.status === 'pending'
                                    ? 'outline'
                                    : 'destructive'
                              }
                              className="text-[10px] px-1.5 py-0"
                            >
                              {tx.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="alerts" className="m-0 p-3">
              <SpendingAlertsPanel compact />
            </TabsContent>
          </Tabs>

          {/* Footer Actions */}
          <div className="p-2 border-t bg-muted/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2">
                <Switch
                  checked={wallet.autoRechargeEnabled}
                  onCheckedChange={(checked) => updateAutoRecharge(checked)}
                  className="h-4 w-7 [&>span]:h-3 [&>span]:w-3"
                />
                <span className="text-[10px] text-muted-foreground">
                  Auto-recharge {wallet.autoRechargeEnabled ? 'ON' : 'OFF'}
                </span>
              </div>
              {wallet.autoRechargeEnabled && (
                <Badge variant="outline" className="text-[10px] gap-1">
                  <Sparkles className="h-3 w-3" />${wallet.autoRechargeAmount.toLocaleString()}
                </Badge>
              )}
            </div>
            <Link to="/settings/billing">
              <Button variant="ghost" size="sm" className="text-xs gap-1">
                <Settings className="h-3 w-3" />
                Billing
              </Button>
            </Link>
          </div>
        </PopoverContent>
      </Popover>
    </TooltipProvider>
  );
}
