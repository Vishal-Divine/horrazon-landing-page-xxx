import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  History,
  Search,
  Filter,
  Download,
  Bot,
  User,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Sparkles,
  DollarSign,
  Layers,
  Users,
  TrendingUp,
  ExternalLink,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AuditEntry {
  id: string;
  timestamp: Date;
  actor: 'ai' | 'user';
  actorName: string;
  action: string;
  category: 'budget' | 'creative' | 'audience' | 'bidding' | 'rule' | 'system';
  status: 'success' | 'failed' | 'pending' | 'reverted';
  details: string;
  impact?: string;
  platform?: string;
  campaignName?: string;
}

const auditLogData: AuditEntry[] = [
  {
    id: '1',
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
    actor: 'ai',
    actorName: 'Pogee AI',
    action: 'Budget increased by 20%',
    category: 'budget',
    status: 'success',
    details: 'Automatic budget increase triggered by ROAS > 4.0 rule',
    impact: '+$120/day',
    platform: 'Meta',
    campaignName: 'Summer_Sale_TOF',
  },
  {
    id: '2',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    actor: 'ai',
    actorName: 'Pogee AI',
    action: 'Campaign paused',
    category: 'bidding',
    status: 'success',
    details: 'Low ROAS protection rule triggered - ROAS dropped to 0.6',
    impact: 'Saved $340',
    platform: 'Google',
    campaignName: 'Brand_Search_US',
  },
  {
    id: '3',
    timestamp: new Date(Date.now() - 1000 * 60 * 32),
    actor: 'user',
    actorName: 'John D.',
    action: 'Creative fatigue alert dismissed',
    category: 'creative',
    status: 'success',
    details: 'User chose to continue running Summer_Hero_V3 despite CTR decline',
    platform: 'Meta',
    campaignName: 'Summer_Hero_V3',
  },
  {
    id: '4',
    timestamp: new Date(Date.now() - 1000 * 60 * 45),
    actor: 'ai',
    actorName: 'Pogee AI',
    action: 'Audience expanded',
    category: 'audience',
    status: 'success',
    details: 'Frequency cap exceeded, automatically expanded lookalike from 1% to 2%',
    impact: '+500K reach',
    platform: 'Meta',
    campaignName: 'Retarget_30d',
  },
  {
    id: '5',
    timestamp: new Date(Date.now() - 1000 * 60 * 60),
    actor: 'ai',
    actorName: 'Pogee AI',
    action: 'Bid adjustment failed',
    category: 'bidding',
    status: 'failed',
    details: 'API rate limit exceeded when attempting to adjust Google Ads bid',
    platform: 'Google',
    campaignName: 'TOF_Broad_Match',
  },
  {
    id: '6',
    timestamp: new Date(Date.now() - 1000 * 60 * 90),
    actor: 'user',
    actorName: 'Sarah M.',
    action: 'AI recommendation approved',
    category: 'budget',
    status: 'success',
    details: 'Approved weekend budget boost recommendation (+25% Sat-Sun)',
    impact: '+$1,800 est.',
    platform: 'TikTok',
    campaignName: 'Weekend_Push',
  },
  {
    id: '7',
    timestamp: new Date(Date.now() - 1000 * 60 * 120),
    actor: 'ai',
    actorName: 'Pogee AI',
    action: 'Rule created automatically',
    category: 'rule',
    status: 'success',
    details: 'Created new rule: Pause campaigns with CPC > $6 after detecting pattern',
  },
  {
    id: '8',
    timestamp: new Date(Date.now() - 1000 * 60 * 180),
    actor: 'user',
    actorName: 'John D.',
    action: 'Action reverted',
    category: 'budget',
    status: 'reverted',
    details: 'Manually reverted AI budget increase from $600 back to $500',
    platform: 'Meta',
    campaignName: 'Summer_Sale_TOF',
  },
];

const categoryIcons = {
  budget: DollarSign,
  creative: Layers,
  audience: Users,
  bidding: TrendingUp,
  rule: Sparkles,
  system: AlertTriangle,
};

const categoryColors = {
  budget: 'bg-success/10 text-success',
  creative: 'bg-chart-1/10 text-chart-1',
  audience: 'bg-chart-2/10 text-chart-2',
  bidding: 'bg-chart-3/10 text-chart-3',
  rule: 'bg-primary/10 text-primary',
  system: 'bg-warning/10 text-warning',
};

const statusColors = {
  success: 'bg-success/10 text-success border-success/30',
  failed: 'bg-destructive/10 text-destructive border-destructive/30',
  pending: 'bg-warning/10 text-warning border-warning/30',
  reverted: 'bg-muted text-muted-foreground border-border',
};

const statusIcons = {
  success: CheckCircle2,
  failed: XCircle,
  pending: Clock,
  reverted: History,
};

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return date.toLocaleDateString();
}

interface AuditLogProps {
  trigger?: React.ReactNode;
}

export function AuditLog({ trigger }: AuditLogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterActor, setFilterActor] = useState<string>('all');

  const filteredLogs = auditLogData.filter((entry) => {
    const matchesSearch =
      entry.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.campaignName?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = filterCategory === 'all' || entry.category === filterCategory;
    const matchesActor = filterActor === 'all' || entry.actor === filterActor;

    return matchesSearch && matchesCategory && matchesActor;
  });

  const aiActions = auditLogData.filter((e) => e.actor === 'ai').length;
  const userActions = auditLogData.filter((e) => e.actor === 'user').length;
  const successRate = Math.round(
    (auditLogData.filter((e) => e.status === 'success').length / auditLogData.length) * 100,
  );

  return (
    <Sheet>
      <SheetTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="gap-2">
            <History className="h-4 w-4" />
            Audit Log
          </Button>
        )}
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Audit Log
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-4">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg bg-primary/10 p-3 text-center">
              <p className="text-lg font-bold">{aiActions}</p>
              <p className="text-xs text-muted-foreground">AI Actions</p>
            </div>
            <div className="rounded-lg bg-chart-2/10 p-3 text-center">
              <p className="text-lg font-bold">{userActions}</p>
              <p className="text-xs text-muted-foreground">User Actions</p>
            </div>
            <div className="rounded-lg bg-success/10 p-3 text-center">
              <p className="text-lg font-bold">{successRate}%</p>
              <p className="text-xs text-muted-foreground">Success Rate</p>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search actions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline" size="icon">
              <Download className="h-4 w-4" />
            </Button>
          </div>

          {/* Filter Tabs */}
          <Tabs value={filterActor} onValueChange={setFilterActor}>
            <TabsList className="w-full">
              <TabsTrigger value="all" className="flex-1">
                All
              </TabsTrigger>
              <TabsTrigger value="ai" className="flex-1 gap-1">
                <Bot className="h-3 w-3" />
                AI
              </TabsTrigger>
              <TabsTrigger value="user" className="flex-1 gap-1">
                <User className="h-3 w-3" />
                User
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Log Entries */}
          <ScrollArea className="h-[calc(100vh-320px)]">
            <div className="space-y-3 pr-4">
              {filteredLogs.map((entry) => {
                const CategoryIcon = categoryIcons[entry.category];
                const StatusIcon = statusIcons[entry.status];

                return (
                  <div
                    key={entry.id}
                    className={cn(
                      'rounded-lg border p-4 transition-colors hover:bg-muted/50',
                      entry.actor === 'ai' ? 'border-primary/20' : 'border-border',
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
                          entry.actor === 'ai' ? 'bg-gradient-to-br from-primary/20 to-primary/10' : 'bg-muted',
                        )}
                      >
                        {entry.actor === 'ai' ? (
                          <Bot className="h-5 w-5 text-primary" />
                        ) : (
                          <User className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{entry.actorName}</span>
                          <span className="text-xs text-muted-foreground">{formatTimeAgo(entry.timestamp)}</span>
                        </div>

                        <p className="font-semibold mb-1">{entry.action}</p>
                        <p className="text-sm text-muted-foreground mb-2">{entry.details}</p>

                        <div className="flex flex-wrap items-center gap-2">
                          <Badge className={cn('text-[10px]', statusColors[entry.status])}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {entry.status}
                          </Badge>
                          <Badge variant="outline" className={cn('text-[10px]', categoryColors[entry.category])}>
                            <CategoryIcon className="h-3 w-3 mr-1" />
                            {entry.category}
                          </Badge>
                          {entry.platform && (
                            <Badge variant="outline" className="text-[10px]">
                              {entry.platform}
                            </Badge>
                          )}
                          {entry.impact && (
                            <Badge className="bg-success/10 text-success text-[10px]">{entry.impact}</Badge>
                          )}
                        </div>

                        {entry.campaignName && (
                          <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                            <span>Campaign:</span>
                            <Button variant="link" className="h-auto p-0 text-xs gap-1">
                              {entry.campaignName}
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}
