import { useState } from 'react';
import { Sun, Moon, Gift, Rocket, Star, TrendingUp, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import WalletWidget from './WalletWidget';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface WhatsNewItem {
  id: string;
  type: 'feature' | 'improvement' | 'announcement';
  title: string;
  description: string;
  date: string;
  isNew: boolean;
  link?: string;
}

const whatsNewItems: WhatsNewItem[] = [
  {
    id: '1',
    type: 'feature',
    title: 'AI-Powered Insights',
    description: 'Get intelligent recommendations based on your campaign performance data.',
    date: 'Today',
    isNew: true,
  },
  {
    id: '2',
    type: 'feature',
    title: 'Advanced Attribution Models',
    description: 'New multi-touch attribution models for better ROI tracking.',
    date: 'Yesterday',
    isNew: true,
  },
  {
    id: '3',
    type: 'improvement',
    title: 'Faster Dashboard Loading',
    description: '50% improvement in dashboard load times with optimized queries.',
    date: '2 days ago',
    isNew: false,
  },
  {
    id: '4',
    type: 'announcement',
    title: 'New Integrations Available',
    description: 'Connect with Shopify, WooCommerce, and 10+ new platforms.',
    date: 'This week',
    isNew: false,
    link: '/integrations',
  },
];

export default function QuickActions() {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return document.documentElement.classList.contains('dark');
  });

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const newItemsCount = whatsNewItems.filter((item) => item.isNew).length;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'feature':
        return <Rocket className="h-4 w-4 text-primary" />;
      case 'improvement':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'announcement':
        return <Star className="h-4 w-4 text-yellow-500" />;
      default:
        return <Gift className="h-4 w-4" />;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'feature':
        return <Badge className="bg-primary/10 text-primary text-[10px] px-1.5">Feature</Badge>;
      case 'improvement':
        return <Badge className="bg-green-500/10 text-green-600 text-[10px] px-1.5">Improvement</Badge>;
      case 'announcement':
        return <Badge className="bg-yellow-500/10 text-yellow-600 text-[10px] px-1.5">Announcement</Badge>;
      default:
        return null;
    }
  };

  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex items-center gap-1">
        {/* What's New */}
        <Popover>
          <Tooltip>
            <TooltipTrigger asChild>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 relative hover:bg-primary/10">
                  <Gift className="h-4 w-4" />
                  {newItemsCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-destructive text-[10px] text-white flex items-center justify-center font-medium animate-pulse">
                      {newItemsCount}
                    </span>
                  )}
                </Button>
              </PopoverTrigger>
            </TooltipTrigger>
            <TooltipContent>
              <p>What's New</p>
            </TooltipContent>
          </Tooltip>
          <PopoverContent className="w-80 p-0" align="end">
            <div className="p-3 border-b bg-gradient-to-r from-primary/5 to-primary/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Gift className="h-4 w-4 text-primary" />
                  <h3 className="font-semibold text-sm">What's New</h3>
                </div>
                {newItemsCount > 0 && (
                  <Badge variant="secondary" className="text-[10px]">
                    {newItemsCount} new
                  </Badge>
                )}
              </div>
            </div>
            <ScrollArea className="h-72">
              <div className="divide-y">
                {whatsNewItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 hover:bg-muted/50 transition-colors cursor-pointer ${item.isNew ? 'bg-primary/5' : ''}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">{getTypeIcon(item.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className={`text-sm ${item.isNew ? 'font-semibold' : 'font-medium'}`}>{item.title}</p>
                          {item.isNew && (
                            <Badge className="bg-destructive/10 text-destructive text-[10px] px-1">NEW</Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{item.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-[10px] text-muted-foreground">{item.date}</span>
                          <div className="flex items-center gap-2">
                            {getTypeBadge(item.type)}
                            {item.link && (
                              <Button variant="ghost" size="sm" className="h-5 px-1.5 text-[10px]">
                                <ExternalLink className="h-3 w-3 mr-1" />
                                View
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-2 border-t">
              <Button variant="ghost" size="sm" className="w-full text-xs">
                View All Updates
              </Button>
            </div>
          </PopoverContent>
        </Popover>

        {/* Wallet Widget */}
        <WalletWidget />

        {/* Theme Toggle */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="h-9 w-9 relative overflow-hidden hover:bg-primary/10"
            >
              <Sun
                className={`h-4 w-4 absolute transition-all duration-300 ${isDarkMode ? 'rotate-90 scale-0' : 'rotate-0 scale-100'}`}
              />
              <Moon
                className={`h-4 w-4 absolute transition-all duration-300 ${isDarkMode ? 'rotate-0 scale-100' : '-rotate-90 scale-0'}`}
              />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{isDarkMode ? 'Light' : 'Dark'} Mode</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
