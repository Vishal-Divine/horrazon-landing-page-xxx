import { Crown, Sparkles, ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

const proFeatures = [
  'Unlimited AI-powered insights',
  'Advanced predictive analytics',
  'Custom automation rules',
  'Priority support 24/7',
  'Multi-channel attribution',
  'Team collaboration tools',
];

export default function UpgradeButton() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          className="gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/20 transition-all duration-300 hover:shadow-primary/30 hover:scale-[1.02]"
          size="sm"
        >
          <Crown className="h-4 w-4" />
          <span className="hidden sm:inline">Upgrade Pro</span>
          <Sparkles className="h-3.5 w-3.5 animate-pulse" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary to-primary/60 text-primary-foreground">
              <Crown className="h-6 w-6" />
            </div>
            <div>
              <DialogTitle className="text-xl">Upgrade to Pro</DialogTitle>
              <DialogDescription>Unlock the full power of Horrazon.ai</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-4">
          <div className="flex items-baseline gap-2 mb-6">
            <span className="text-4xl font-bold">$99</span>
            <span className="text-muted-foreground">/month</span>
            <Badge variant="secondary" className="ml-2">
              Save 20% annually
            </Badge>
          </div>

          <div className="space-y-3 mb-6">
            {proFeatures.map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="p-1 rounded-full bg-success/10">
                  <Check className="h-4 w-4 text-success" />
                </div>
                <span className="text-sm">{feature}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-3">
            <Button className="w-full gap-2" size="lg">
              Start 14-Day Free Trial
              <ArrowRight className="h-4 w-4" />
            </Button>
            <p className="text-xs text-center text-muted-foreground">No credit card required • Cancel anytime</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
