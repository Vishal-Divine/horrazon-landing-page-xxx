import { Link } from 'react-router-dom';
import { Sparkles, Plus, History, Zap } from 'lucide-react';
import logoImage from '@/assets/logo.png';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import GlobalSearch from './GlobalSearch';
import QuickActions from './QuickActions';
import UpgradeButton from './UpgradeButton';
import UserProfile from './UserProfile';
import NotificationCenter from '@/components/NotificationCenter';
import { WorkspaceSwitcher } from './WorkspaceSwitcher';
import { AuditLog } from './AuditLog';

export default function TopNavBar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur-xl supports-[backdrop-filter]:bg-background/80">
      <div className="flex h-14 items-center justify-between px-3 lg:px-4">
        {/* Left Section - Logo & Sidebar Toggle */}
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="relative">
              <div className="h-8 w-8 rounded-lg overflow-hidden shadow-md shadow-primary/10 group-hover:shadow-primary/20 transition-all duration-300 ring-1 ring-primary/20 group-hover:ring-primary/40">
                <img src={logoImage} alt="Horrazon.ai Logo" className="h-full w-full object-cover" />
              </div>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-base font-semibold text-foreground tracking-tight">
                Horrazon<span className="text-primary">.ai</span>
              </h1>
            </div>
          </Link>

          <div className="hidden sm:block h-5 w-px bg-border/60" />

          <WorkspaceSwitcher />
        </div>

        {/* Center Section - Global Search */}
        <div className="hidden md:flex flex-1 justify-center max-w-xl mx-6">
          <GlobalSearch />
        </div>

        {/* Right Section - Actions & Profile */}
        <div className="flex items-center gap-1">
          {/* Quick Create Button */}
          <DropdownMenu>
            <TooltipProvider delayDuration={200}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <DropdownMenuTrigger asChild>
                    <Button
                      size="sm"
                      className="h-8 gap-1.5 px-3 bg-primary hover:bg-primary/90 text-primary-foreground shadow-sm"
                    >
                      <Plus className="h-4 w-4" />
                      <span className="hidden lg:inline text-sm">Create</span>
                    </Button>
                  </DropdownMenuTrigger>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Quick Create</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel className="text-xs text-muted-foreground font-normal">Quick Actions</DropdownMenuLabel>
              <DropdownMenuItem className="gap-2.5 py-2">
                <div className="h-7 w-7 rounded-md bg-blue-500/10 flex items-center justify-center">
                  <Sparkles className="h-3.5 w-3.5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New Campaign</p>
                  <p className="text-[11px] text-muted-foreground">Create marketing campaign</p>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2.5 py-2">
                <div className="h-7 w-7 rounded-md bg-green-500/10 flex items-center justify-center">
                  <Zap className="h-3.5 w-3.5 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New Report</p>
                  <p className="text-[11px] text-muted-foreground">Generate analytics report</p>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2.5 py-2">
                <div className="h-7 w-7 rounded-md bg-purple-500/10 flex items-center justify-center">
                  <Sparkles className="h-3.5 w-3.5 text-purple-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New Experiment</p>
                  <p className="text-[11px] text-muted-foreground">Start A/B test</p>
                </div>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2.5 py-2">
                <div className="h-7 w-7 rounded-md bg-orange-500/10 flex items-center justify-center">
                  <Sparkles className="h-3.5 w-3.5 text-orange-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New Rule</p>
                  <p className="text-[11px] text-muted-foreground">Automate actions</p>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="hidden sm:block h-5 w-px bg-border/60 mx-1" />

          <QuickActions />

          <div className="hidden sm:block h-5 w-px bg-border/60 mx-1" />

          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <span>
                  <NotificationCenter />
                </span>
              </TooltipTrigger>
              <TooltipContent>
                <p>Notifications</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <AuditLog
            trigger={
              <TooltipProvider delayDuration={200}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-foreground hover:bg-muted/60"
                    >
                      <History className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Audit Log</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            }
          />

          <div className="hidden sm:block h-5 w-px bg-border/60 mx-1" />

          <UpgradeButton />

          <UserProfile />
        </div>
      </div>
    </header>
  );
}
