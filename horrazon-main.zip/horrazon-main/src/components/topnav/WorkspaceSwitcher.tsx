import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Building2, ChevronDown, Plus, Settings, Check, Users, Briefcase, Sparkles, Crown } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface Workspace {
  id: string;
  name: string;
  type: 'agency' | 'brand' | 'personal';
  logo?: string;
  role: 'owner' | 'admin' | 'member';
  plan: 'free' | 'pro' | 'enterprise';
  activeCampaigns: number;
  monthlySpend: number;
}

const workspacesData: Workspace[] = [
  {
    id: '1',
    name: 'Acme Marketing Agency',
    type: 'agency',
    role: 'owner',
    plan: 'enterprise',
    activeCampaigns: 24,
    monthlySpend: 145000,
  },
  {
    id: '2',
    name: 'Client A - Fashion Brand',
    type: 'brand',
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop',
    role: 'admin',
    plan: 'pro',
    activeCampaigns: 8,
    monthlySpend: 42000,
  },
  {
    id: '3',
    name: 'Client B - Tech Startup',
    type: 'brand',
    role: 'member',
    plan: 'pro',
    activeCampaigns: 5,
    monthlySpend: 28000,
  },
  {
    id: '4',
    name: 'Personal Projects',
    type: 'personal',
    role: 'owner',
    plan: 'free',
    activeCampaigns: 2,
    monthlySpend: 1200,
  },
];

const typeIcons = {
  agency: Building2,
  brand: Briefcase,
  personal: Users,
};

const planColors = {
  free: 'bg-muted text-muted-foreground',
  pro: 'bg-chart-1/10 text-chart-1',
  enterprise: 'bg-primary/10 text-primary',
};

const roleColors = {
  owner: 'bg-warning/10 text-warning',
  admin: 'bg-chart-2/10 text-chart-2',
  member: 'bg-muted text-muted-foreground',
};

export function WorkspaceSwitcher() {
  const [currentWorkspace, setCurrentWorkspace] = useState(workspacesData[0]);

  const handleSwitch = (workspace: Workspace) => {
    setCurrentWorkspace(workspace);
    toast({
      title: 'Workspace Switched',
      description: `Now viewing ${workspace.name}`,
    });
  };

  const TypeIcon = typeIcons[currentWorkspace.type];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="gap-2 px-2">
          <Avatar className="h-7 w-7">
            {currentWorkspace.logo ? <AvatarImage src={currentWorkspace.logo} alt={currentWorkspace.name} /> : null}
            <AvatarFallback className="bg-primary/10 text-primary text-xs">
              <TypeIcon className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col items-start">
            <span className="text-sm font-medium max-w-[120px] truncate">{currentWorkspace.name}</span>
            <span className="text-[10px] text-muted-foreground">{currentWorkspace.activeCampaigns} campaigns</span>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="start" className="w-80">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>Workspaces</span>
          <Badge variant="outline" className="text-[10px]">
            {workspacesData.length} total
          </Badge>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        {workspacesData.map((workspace) => {
          const Icon = typeIcons[workspace.type];
          const isActive = workspace.id === currentWorkspace.id;

          return (
            <DropdownMenuItem
              key={workspace.id}
              className={cn('flex items-start gap-3 p-3 cursor-pointer', isActive && 'bg-primary/5')}
              onClick={() => handleSwitch(workspace)}
            >
              <Avatar className="h-10 w-10 shrink-0">
                {workspace.logo ? <AvatarImage src={workspace.logo} alt={workspace.name} /> : null}
                <AvatarFallback
                  className={cn(
                    'text-sm',
                    workspace.type === 'agency'
                      ? 'bg-primary/10 text-primary'
                      : workspace.type === 'brand'
                        ? 'bg-chart-1/10 text-chart-1'
                        : 'bg-muted text-muted-foreground',
                  )}
                >
                  <Icon className="h-5 w-5" />
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm truncate">{workspace.name}</span>
                  {isActive && <Check className="h-4 w-4 text-primary shrink-0" />}
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  <Badge className={cn('text-[10px]', planColors[workspace.plan])}>
                    {workspace.plan === 'enterprise' && <Crown className="h-3 w-3 mr-0.5" />}
                    {workspace.plan}
                  </Badge>
                  <Badge variant="outline" className={cn('text-[10px]', roleColors[workspace.role])}>
                    {workspace.role}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                  <span>{workspace.activeCampaigns} campaigns</span>
                  <span>${(workspace.monthlySpend / 1000).toFixed(0)}K/mo spend</span>
                </div>
              </div>
            </DropdownMenuItem>
          );
        })}

        <DropdownMenuSeparator />

        <DropdownMenuItem className="gap-2 text-primary cursor-pointer">
          <Plus className="h-4 w-4" />
          Create New Workspace
        </DropdownMenuItem>
        <DropdownMenuItem className="gap-2 cursor-pointer">
          <Settings className="h-4 w-4" />
          Manage Workspaces
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
