import { useState } from 'react';
import { Bell, X, AlertTriangle, TrendingUp, TrendingDown, Zap, CheckCircle2, Info, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';

interface Notification {
  id: string;
  type: 'anomaly' | 'alert' | 'success' | 'info' | 'action';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  priority: 'high' | 'medium' | 'low';
  actionUrl?: string;
  metric?: {
    name: string;
    value: string;
    change: number;
  };
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'anomaly',
    title: 'Revenue Anomaly Detected',
    message: 'Revenue dropped 28% in the last hour compared to the same time yesterday',
    timestamp: '2 min ago',
    read: false,
    priority: 'high',
    metric: { name: 'Revenue', value: '$2,840', change: -28 },
  },
  {
    id: '2',
    type: 'alert',
    title: 'Budget Overspend Warning',
    message: "Meta Ads campaign 'Summer Sale' is projected to exceed budget by $1,200",
    timestamp: '15 min ago',
    read: false,
    priority: 'high',
    actionUrl: '/budget',
  },
  {
    id: '3',
    type: 'success',
    title: 'Campaign Goal Achieved',
    message: 'Google Search campaign reached 10,000 conversions milestone',
    timestamp: '1 hour ago',
    read: false,
    priority: 'medium',
  },
  {
    id: '4',
    type: 'action',
    title: 'AI Recommendation Ready',
    message: 'New optimization opportunity: Shift $4,800 from LinkedIn to TikTok for +$12,400 projected revenue',
    timestamp: '2 hours ago',
    read: true,
    priority: 'medium',
    actionUrl: '/actions',
  },
  {
    id: '5',
    type: 'info',
    title: 'Weekly Report Available',
    message: 'Your performance report for Week 23 is ready to view',
    timestamp: '3 hours ago',
    read: true,
    priority: 'low',
    actionUrl: '/reports',
  },
  {
    id: '6',
    type: 'anomaly',
    title: 'CTR Spike Detected',
    message: 'TikTok Ads CTR increased 45% - investigate for potential viral content',
    timestamp: '4 hours ago',
    read: true,
    priority: 'medium',
    metric: { name: 'CTR', value: '4.8%', change: 45 },
  },
  {
    id: '7',
    type: 'alert',
    title: 'Low Inventory Alert',
    message: "SKU-4521 'Summer Dress Blue' projected stockout in 3 days",
    timestamp: '5 hours ago',
    read: true,
    priority: 'high',
    actionUrl: '/merchandise',
  },
];

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [isOpen, setIsOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const highPriorityCount = notifications.filter((n) => !n.read && n.priority === 'high').length;

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'anomaly':
        return <AlertTriangle className="h-4 w-4 text-warning" />;
      case 'alert':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      case 'success':
        return <CheckCircle2 className="h-4 w-4 text-success" />;
      case 'action':
        return <Zap className="h-4 w-4 text-chart-1" />;
      default:
        return <Info className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span
              className={`absolute -top-1 -right-1 h-5 w-5 rounded-full text-xs flex items-center justify-center text-white ${
                highPriorityCount > 0 ? 'bg-destructive animate-pulse' : 'bg-primary'
              }`}
            >
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold">Notifications</h3>
            {unreadCount > 0 && <Badge variant="secondary">{unreadCount} new</Badge>}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowSettings(!showSettings)}>
              <Settings className="h-4 w-4" />
            </Button>
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                Mark all read
              </Button>
            )}
          </div>
        </div>

        {showSettings ? (
          <div className="p-4 space-y-4">
            <h4 className="text-sm font-medium">Notification Settings</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Anomaly Detection</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Budget Alerts</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">AI Recommendations</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Performance Reports</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Inventory Alerts</span>
                <Switch defaultChecked />
              </div>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm">Push Notifications</span>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Email Digest</span>
              <Switch defaultChecked />
            </div>
          </div>
        ) : (
          <ScrollArea className="h-96">
            <div className="divide-y">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No notifications</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 hover:bg-muted/50 transition-colors cursor-pointer ${
                      !notification.read ? 'bg-primary/5' : ''
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-1">{getIcon(notification.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className={`text-sm ${!notification.read ? 'font-semibold' : 'font-medium'}`}>
                              {notification.title}
                            </p>
                            <p className="text-xs text-muted-foreground mt-0.5">{notification.message}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 shrink-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              dismissNotification(notification.id);
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>

                        {notification.metric && (
                          <div className="flex items-center gap-2 mt-2 p-2 rounded-md bg-muted/50">
                            <span className="text-xs text-muted-foreground">{notification.metric.name}:</span>
                            <span className="text-sm font-medium">{notification.metric.value}</span>
                            <span
                              className={`text-xs flex items-center ${
                                notification.metric.change > 0 ? 'text-success' : 'text-destructive'
                              }`}
                            >
                              {notification.metric.change > 0 ? (
                                <TrendingUp className="h-3 w-3 mr-0.5" />
                              ) : (
                                <TrendingDown className="h-3 w-3 mr-0.5" />
                              )}
                              {Math.abs(notification.metric.change)}%
                            </span>
                          </div>
                        )}

                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-muted-foreground">{notification.timestamp}</span>
                          <div className="flex items-center gap-2">
                            <Badge
                              variant={
                                notification.priority === 'high'
                                  ? 'destructive'
                                  : notification.priority === 'medium'
                                    ? 'default'
                                    : 'secondary'
                              }
                              className="text-[10px] px-1.5 py-0"
                            >
                              {notification.priority}
                            </Badge>
                            {notification.actionUrl && (
                              <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                                View →
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        )}

        <div className="p-3 border-t">
          <Button variant="outline" className="w-full" size="sm">
            View All Notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
