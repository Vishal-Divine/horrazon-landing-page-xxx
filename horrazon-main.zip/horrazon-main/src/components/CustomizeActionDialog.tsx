import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

interface CustomizeActionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  insight: string;
}

export default function CustomizeActionDialog({ open, onOpenChange, insight }: CustomizeActionDialogProps) {
  const [amount, setAmount] = useState('');
  const [fromCampaign, setFromCampaign] = useState('');
  const [toCampaign, setToCampaign] = useState('');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Customize Action</DialogTitle>
          <DialogDescription>{insight}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Shift Budget</Label>
            <Input type="number" placeholder="Amount ($)" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>From Campaign</Label>
            <Select value={fromCampaign} onValueChange={setFromCampaign}>
              <SelectTrigger>
                <SelectValue placeholder="Select campaign" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="summer">Summer Collection</SelectItem>
                <SelectItem value="brand">Brand Terms</SelectItem>
                <SelectItem value="retarget">Retargeting Q4</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>To Campaign</Label>
            <Select value={toCampaign} onValueChange={setToCampaign}>
              <SelectTrigger>
                <SelectValue placeholder="Select campaign" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="summer">Summer Collection</SelectItem>
                <SelectItem value="brand">Brand Terms</SelectItem>
                <SelectItem value="retarget">Retargeting Q4</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button className="flex-1" onClick={() => onOpenChange(false)}>
              Apply Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
