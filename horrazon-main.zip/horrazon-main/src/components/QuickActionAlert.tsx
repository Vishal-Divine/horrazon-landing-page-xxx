import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle2, Info, Play, Pause, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QuickActionAlertProps {
  severity: 'warning' | 'info' | 'success';
  message: string;
  action?: {
    label: string;
    icon?: 'play' | 'pause' | 'optimize';
    onClick: () => void;
  };
}

export default function QuickActionAlert({ severity, message, action }: QuickActionAlertProps) {
  const getIcon = () => {
    switch (severity) {
      case 'warning':
        return (
          <AlertTriangle
            className="h-5 w-5 mt-0.5 text-destructive transition-transform group-hover:scale-110"
            strokeWidth={2.5}
          />
        );
      case 'success':
        return (
          <CheckCircle2
            className="h-5 w-5 mt-0.5 text-success transition-transform group-hover:scale-110"
            strokeWidth={2.5}
          />
        );
      case 'info':
        return (
          <Info className="h-5 w-5 mt-0.5 text-primary transition-transform group-hover:scale-110" strokeWidth={2.5} />
        );
    }
  };

  const getActionIcon = () => {
    if (!action?.icon) return null;
    switch (action.icon) {
      case 'play':
        return <Play className="h-3.5 w-3.5" />;
      case 'pause':
        return <Pause className="h-3.5 w-3.5" />;
      case 'optimize':
        return <TrendingUp className="h-3.5 w-3.5" />;
    }
  };

  return (
    <div
      className={cn(
        'group flex items-start gap-3 rounded-lg border p-4 transition-all',
        'hover:shadow-md bg-card',
        severity === 'warning' && 'border-destructive/30 hover:border-destructive/50 bg-destructive/5',
        severity === 'success' && 'border-success/30 hover:border-success/50 bg-success/5',
        severity === 'info' && 'border-primary/30 hover:border-primary/50 bg-primary/5',
      )}
    >
      {getIcon()}
      <div className="flex-1 space-y-2">
        <p className="text-sm leading-relaxed text-foreground">{message}</p>
        {action && (
          <Button
            size="sm"
            variant={severity === 'warning' ? 'destructive' : 'default'}
            onClick={action.onClick}
            className="h-7 text-xs"
          >
            {getActionIcon()}
            {action.label}
          </Button>
        )}
      </div>
    </div>
  );
}
