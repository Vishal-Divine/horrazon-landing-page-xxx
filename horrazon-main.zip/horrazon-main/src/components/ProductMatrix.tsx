import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Product {
  name: string;
  growth: number;
  marketShare: number;
  category: 'star' | 'cash-cow' | 'question-mark' | 'dog';
}

const products: Product[] = [
  { name: 'Summer Dress', growth: 85, marketShare: 78, category: 'star' },
  { name: 'Running Shoes', growth: 45, marketShare: 82, category: 'cash-cow' },
  { name: 'Wireless Headphones', growth: 92, marketShare: 68, category: 'star' },
  { name: 'Yoga Mat', growth: 72, marketShare: 35, category: 'question-mark' },
  { name: 'Water Bottle', growth: 28, marketShare: 85, category: 'cash-cow' },
  { name: 'Fitness Tracker', growth: 15, marketShare: 22, category: 'dog' },
  { name: 'Protein Powder', growth: 88, marketShare: 45, category: 'question-mark' },
];

const categoryColors = {
  star: 'hsl(var(--success))',
  'cash-cow': 'hsl(var(--chart-1))',
  'question-mark': 'hsl(var(--chart-3))',
  dog: 'hsl(var(--muted-foreground))',
};

const categoryLabels = {
  star: '⭐ Stars',
  'cash-cow': '💰 Cash Cows',
  'question-mark': '❓ Question Marks',
  dog: '📉 Dogs',
};

export default function ProductMatrix() {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-3">
          <CardTitle>Product Performance Matrix (BCG)</CardTitle>
          <div className="flex flex-wrap gap-2">
            {Object.entries(categoryLabels).map(([key, label]) => (
              <Badge
                key={key}
                variant="outline"
                style={{ borderColor: categoryColors[key as keyof typeof categoryColors] }}
              >
                {label}
              </Badge>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <ScatterChart margin={{ top: 20, right: 20, bottom: 60, left: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              type="number"
              dataKey="marketShare"
              name="Market Share"
              stroke="hsl(var(--muted-foreground))"
              label={{ value: 'Market Share →', position: 'bottom', offset: 40 }}
            />
            <YAxis
              type="number"
              dataKey="growth"
              name="Growth Rate"
              stroke="hsl(var(--muted-foreground))"
              label={{ value: 'Growth Rate ↑', angle: -90, position: 'left', offset: 40 }}
            />
            <Tooltip
              cursor={{ strokeDasharray: '3 3' }}
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
                      <p className="font-semibold text-sm mb-1">{data.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Growth: {data.growth}% | Share: {data.marketShare}%
                      </p>
                      <Badge variant="outline" className="mt-1 text-xs">
                        {categoryLabels[data.category as keyof typeof categoryLabels]}
                      </Badge>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Scatter name="Products" data={products}>
              {products.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={categoryColors[entry.category]} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
