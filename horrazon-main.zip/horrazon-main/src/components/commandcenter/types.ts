import { LucideIcon } from 'lucide-react';

// Data Unification Types
export interface DataSource {
  id: string;
  name: string;
  icon: LucideIcon;
  status: 'connected' | 'syncing' | 'error' | 'disconnected';
  lastSync: Date;
  recordCount: number;
  healthScore: number;
  dataQuality: number;
  missingFields: string[];
  duplicateRate: number;
}

export interface UnifiedCustomerProfile {
  id: string;
  email: string;
  name: string;
  sources: string[];
  completeness: number;
  lastActivity: Date;
  ltv: number;
  riskScore: number;
  segments: string[];
}

export interface DataHealthMetric {
  category: string;
  score: number;
  issues: number;
  trend: 'up' | 'down' | 'stable';
  description: string;
}

// Discovery Gap Types
export interface DiscoveryWorkflow {
  id: string;
  name: string;
  phase: 'discovery' | 'planning' | 'implementation' | 'optimization';
  status: 'not_started' | 'in_progress' | 'completed' | 'at_risk';
  progress: number;
  owner: string;
  dueDate: Date;
  blockers: string[];
}

export interface DiscoveryAudit {
  id: string;
  area: string;
  status: 'audited' | 'pending' | 'skipped';
  findings: number;
  priority: 'high' | 'medium' | 'low';
  recommendation: string;
}

// Technical Debt Types
export interface TechnicalDebtItem {
  id: string;
  name: string;
  category: 'customization' | 'integration' | 'data' | 'workflow';
  severity: 'critical' | 'high' | 'medium' | 'low';
  estimatedCost: number;
  impact: string;
  createdDate: Date;
  affectedSystems: string[];
}

export interface DebtTrend {
  date: string;
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
}

// Follow-Up Automation Types
export interface UnworkedLead {
  id: string;
  name: string;
  email: string;
  source: string;
  score: number;
  createdAt: Date;
  lastContactAttempt: Date | null;
  assignedTo: string | null;
  status: 'hot' | 'warm' | 'cold';
  daysSinceCreation: number;
  estimatedValue: number;
}

export interface FollowUpRule {
  id: string;
  name: string;
  trigger: {
    type: 'time_based' | 'score_based' | 'behavior_based';
    condition: string;
    value: number;
  };
  action: {
    type: 'email' | 'sms' | 'call' | 'reassign' | 'notify';
    template?: string;
    assignee?: string;
  };
  enabled: boolean;
  lastTriggered?: Date;
  successRate: number;
}

export interface AccountabilityMetric {
  userId: string;
  userName: string;
  avatar?: string;
  leadsAssigned: number;
  leadsWorked: number;
  responseTime: number; // in hours
  conversionRate: number;
  trend: 'up' | 'down' | 'stable';
}

// Change Management Types
export interface AdoptionMetric {
  feature: string;
  adoptionRate: number;
  activeUsers: number;
  totalUsers: number;
  trend: 'up' | 'down' | 'stable';
  lastWeekChange: number;
}

export interface ChangeResistanceIndicator {
  team: string;
  indicator: string;
  severity: 'high' | 'medium' | 'low';
  suggestedAction: string;
}
