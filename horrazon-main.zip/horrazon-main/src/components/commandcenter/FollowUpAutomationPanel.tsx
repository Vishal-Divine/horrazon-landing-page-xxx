import { useState } from 'react';
import {
  UserX,
  Clock,
  Zap,
  AlertTriangle,
  Mail,
  Phone,
  MessageSquare,
  ArrowUpRight,
  Users,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Target,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { unworkedLeads, followUpRules, accountabilityMetrics } from './mockData';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { toast } from '@/hooks/use-toast';

export function FollowUpAutomationPanel() {
  const [rules, setRules] = useState(followUpRules);

  const totalUnworked = unworkedLeads.length;
  const hotLeads = unworkedLeads.filter((l) => l.status === 'hot').length;
  const totalValue = unworkedLeads.reduce((acc, l) => acc + l.estimatedValue, 0);
  const avgResponseTime =
    accountabilityMetrics.reduce((acc, m) => acc + m.responseTime, 0) / accountabilityMetrics.length;

  const toggleRule = (ruleId: string) => {
    setRules((prev) => prev.map((r) => (r.id === ruleId ? { ...r, enabled: !r.enabled } : r)));
    toast({
      title: 'Rule Updated',
      description: 'Follow-up rule status has been changed',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'hot':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20 animate-pulse">🔥 Hot</Badge>;
      case 'warm':
        return <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">Warm</Badge>;
      default:
        return <Badge className="bg-muted text-muted-foreground">Cold</Badge>;
    }
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'call':
        return <Phone className="h-4 w-4" />;
      case 'sms':
        return <MessageSquare className="h-4 w-4" />;
      default:
        return <Zap className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Follow-Up Failure Warning */}
      {hotLeads > 0 && (
        <Card className="border-destructive/50 bg-gradient-to-r from-destructive/5 to-orange-500/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center shrink-0 animate-pulse">
                <UserX className="h-6 w-6 text-destructive" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-destructive">Follow-Up Failure Alert</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  According to Salesforce 2025 research, unworked leads are the #1 revenue killer. You have
                  purchase-ready leads going cold.
                </p>
                <div className="mt-3 flex flex-wrap gap-3">
                  <Badge variant="destructive" className="gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    {hotLeads} hot leads uncontacted
                  </Badge>
                  <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">
                    ${(totalValue / 1000).toFixed(0)}K potential revenue at risk
                  </Badge>
                </div>
              </div>
              <Button variant="destructive" size="sm" className="gap-2">
                <Zap className="h-4 w-4" />
                Auto-Assign Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-destructive/30 bg-gradient-to-br from-card to-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unworked Leads</p>
                <p className="text-3xl font-bold text-destructive">{totalUnworked}</p>
              </div>
              <UserX className="h-10 w-10 text-destructive/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {hotLeads} hot, {unworkedLeads.filter((l) => l.status === 'warm').length} warm
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-amber-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">At-Risk Revenue</p>
                <p className="text-3xl font-bold text-amber-600">${(totalValue / 1000).toFixed(0)}K</p>
              </div>
              <Target className="h-10 w-10 text-amber-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">From unworked leads</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Response Time</p>
                <p className="text-3xl font-bold text-foreground">{avgResponseTime.toFixed(1)}h</p>
              </div>
              <Clock className="h-10 w-10 text-primary/30" />
            </div>
            <p className={cn('text-xs mt-3', avgResponseTime > 4 ? 'text-destructive' : 'text-emerald-500')}>
              {avgResponseTime > 4 ? '⚠️ Above 4h target' : '✓ Within target'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-emerald-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Rules</p>
                <p className="text-3xl font-bold text-emerald-500">{rules.filter((r) => r.enabled).length}</p>
              </div>
              <Zap className="h-10 w-10 text-emerald-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">of {rules.length} configured</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leads" className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="leads">Unworked Leads</TabsTrigger>
          <TabsTrigger value="rules">Automation Rules</TabsTrigger>
          <TabsTrigger value="accountability">Team Accountability</TabsTrigger>
        </TabsList>

        <TabsContent value="leads">
          <Card className="border-border/50">
            <CardHeader className="border-b border-border/50">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <UserX className="h-5 w-5 text-destructive" />
                  Purchase-Ready Leads Needing Attention
                </CardTitle>
                <Button size="sm" variant="outline" className="gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[400px]">
                <div className="divide-y divide-border/50">
                  {unworkedLeads.map((lead) => (
                    <div
                      key={lead.id}
                      className={cn(
                        'p-4 hover:bg-accent/30 transition-colors',
                        lead.status === 'hot' && 'bg-destructive/5',
                      )}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {lead.name
                                .split(' ')
                                .map((n) => n[0])
                                .join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{lead.name}</p>
                              {getStatusBadge(lead.status)}
                              <Badge variant="outline" className="text-xs">
                                Score: {lead.score}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{lead.email}</p>
                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span>Source: {lead.source}</span>
                              <span>•</span>
                              <span>Created {formatDistanceToNow(lead.createdAt, { addSuffix: true })}</span>
                              {lead.assignedTo && (
                                <>
                                  <span>•</span>
                                  <span>Assigned: {lead.assignedTo}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-foreground">${lead.estimatedValue.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">Est. value</p>
                          <div className="flex gap-2 mt-2">
                            <Button size="sm" variant="outline" className="h-7 px-2">
                              <Mail className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 px-2">
                              <Phone className="h-3 w-3" />
                            </Button>
                            <Button size="sm" className="h-7 px-2">
                              <ArrowUpRight className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules">
          <Card className="border-border/50">
            <CardHeader className="border-b border-border/50">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  Follow-Up Automation Rules
                </CardTitle>
                <Button size="sm" className="gap-2">
                  <Zap className="h-4 w-4" />
                  Create Rule
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              {rules.map((rule) => (
                <div
                  key={rule.id}
                  className={cn(
                    'p-4 rounded-lg border transition-colors',
                    rule.enabled ? 'border-primary/30 bg-primary/5' : 'border-border/50 bg-card/50',
                  )}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          'h-10 w-10 rounded-lg flex items-center justify-center',
                          rule.enabled ? 'bg-primary/10' : 'bg-muted',
                        )}
                      >
                        {getActionIcon(rule.action.type)}
                      </div>
                      <div>
                        <p className="font-medium">{rule.name}</p>
                        <p className="text-sm text-muted-foreground mt-1">When: {rule.trigger.condition}</p>
                        <p className="text-sm text-muted-foreground">
                          Then: {rule.action.type} {rule.action.template && `(${rule.action.template})`}
                          {rule.action.assignee && `to ${rule.action.assignee}`}
                        </p>
                        {rule.lastTriggered && (
                          <p className="text-xs text-muted-foreground mt-2">
                            Last triggered: {formatDistanceToNow(rule.lastTriggered, { addSuffix: true })}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium">{rule.successRate}%</p>
                        <p className="text-xs text-muted-foreground">Success rate</p>
                      </div>
                      <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accountability">
          <Card className="border-border/50">
            <CardHeader className="border-b border-border/50">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Team Accountability Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {accountabilityMetrics.map((metric) => (
                  <div key={metric.userId} className="p-4 rounded-lg border border-border/50 bg-card/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {metric.userName
                              .split(' ')
                              .map((n) => n[0])
                              .join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{metric.userName}</p>
                            {metric.trend === 'up' && <TrendingUp className="h-4 w-4 text-emerald-500" />}
                            {metric.trend === 'down' && <TrendingDown className="h-4 w-4 text-destructive" />}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {metric.leadsWorked} of {metric.leadsAssigned} leads worked
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-center">
                          <p className="text-sm font-medium">
                            {Math.round((metric.leadsWorked / metric.leadsAssigned) * 100)}%
                          </p>
                          <p className="text-xs text-muted-foreground">Work Rate</p>
                        </div>
                        <div className="text-center">
                          <p
                            className={cn(
                              'text-sm font-medium',
                              metric.responseTime > 4 ? 'text-destructive' : 'text-emerald-500',
                            )}
                          >
                            {metric.responseTime}h
                          </p>
                          <p className="text-xs text-muted-foreground">Avg Response</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium">{metric.conversionRate}%</p>
                          <p className="text-xs text-muted-foreground">Conversion</p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3">
                      <Progress value={(metric.leadsWorked / metric.leadsAssigned) * 100} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
