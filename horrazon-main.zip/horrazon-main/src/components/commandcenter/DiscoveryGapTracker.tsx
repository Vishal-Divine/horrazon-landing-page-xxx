import { useState } from 'react';
import {
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  ChevronDown,
  ChevronRight,
  Target,
  FileSearch,
  Users,
  Lightbulb,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { discoveryWorkflows, discoveryAudits } from './mockData';
import { cn } from '@/lib/utils';
// date-fns formatDistanceToNow used in component

export function DiscoveryGapTracker() {
  const [expandedPhases, setExpandedPhases] = useState<string[]>(['discovery']);

  const togglePhase = (phase: string) => {
    setExpandedPhases((prev) => (prev.includes(phase) ? prev.filter((p) => p !== phase) : [...prev, phase]));
  };

  const phases = ['discovery', 'planning', 'implementation', 'optimization'];
  const phaseLabels: Record<string, string> = {
    discovery: 'Discovery Phase',
    planning: 'Planning Phase',
    implementation: 'Implementation',
    optimization: 'Optimization',
  };

  const phaseIcons: Record<string, React.ReactNode> = {
    discovery: <Search className="h-4 w-4" />,
    planning: <Target className="h-4 w-4" />,
    implementation: <FileSearch className="h-4 w-4" />,
    optimization: <Lightbulb className="h-4 w-4" />,
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
      case 'in_progress':
        return <Clock className="h-4 w-4 text-primary" />;
      case 'at_risk':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      default:
        return <XCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Completed</Badge>;
      case 'in_progress':
        return <Badge className="bg-primary/10 text-primary border-primary/20">In Progress</Badge>;
      case 'at_risk':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">At Risk</Badge>;
      default:
        return (
          <Badge variant="secondary" className="text-muted-foreground">
            Not Started
          </Badge>
        );
    }
  };

  const getAuditStatusBadge = (status: string) => {
    switch (status) {
      case 'audited':
        return <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Audited</Badge>;
      case 'pending':
        return <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">Pending</Badge>;
      case 'skipped':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Skipped - Critical!</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const overallProgress = Math.round(
    discoveryWorkflows.reduce((acc, w) => acc + w.progress, 0) / discoveryWorkflows.length,
  );

  const atRiskCount = discoveryWorkflows.filter((w) => w.status === 'at_risk').length;
  const skippedAudits = discoveryAudits.filter((a) => a.status === 'skipped').length;

  return (
    <div className="space-y-6">
      {/* Discovery Gap Warning */}
      {(atRiskCount > 0 || skippedAudits > 0) && (
        <Card className="border-destructive/50 bg-gradient-to-r from-destructive/5 to-destructive/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-destructive">Discovery Gap Detected</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  According to Salesforce 2025 research, 40% of implementations fail due to skipped discovery. Your
                  current status:
                </p>
                <div className="mt-3 flex flex-wrap gap-3">
                  {atRiskCount > 0 && (
                    <Badge variant="destructive" className="gap-1">
                      <AlertTriangle className="h-3 w-3" />
                      {atRiskCount} workflows at risk
                    </Badge>
                  )}
                  {skippedAudits > 0 && (
                    <Badge variant="destructive" className="gap-1">
                      <XCircle className="h-3 w-3" />
                      {skippedAudits} audits skipped
                    </Badge>
                  )}
                </div>
              </div>
              <Button variant="destructive" size="sm">
                Address Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Overall Progress */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Progress</p>
                <p className="text-3xl font-bold text-foreground">{overallProgress}%</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
                <Target className="h-7 w-7 text-primary" />
              </div>
            </div>
            <Progress value={overallProgress} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed Tasks</p>
                <p className="text-3xl font-bold text-emerald-500">
                  {discoveryWorkflows.filter((w) => w.status === 'completed').length}
                </p>
              </div>
              <CheckCircle2 className="h-10 w-10 text-emerald-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">of {discoveryWorkflows.length} total</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-3xl font-bold text-primary">
                  {discoveryWorkflows.filter((w) => w.status === 'in_progress').length}
                </p>
              </div>
              <Clock className="h-10 w-10 text-primary/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">Active workflows</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 border-destructive/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">At Risk</p>
                <p className="text-3xl font-bold text-destructive">{atRiskCount}</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-destructive/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">Require immediate attention</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Workflow Timeline */}
        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-primary" />
              Discovery Workflow Timeline
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            {phases.map((phase) => {
              const phaseWorkflows = discoveryWorkflows.filter((w) => w.phase === phase);
              const isExpanded = expandedPhases.includes(phase);

              return (
                <Collapsible key={phase} open={isExpanded}>
                  <CollapsibleTrigger
                    onClick={() => togglePhase(phase)}
                    className="flex items-center justify-between w-full p-3 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        {phaseIcons[phase]}
                      </div>
                      <span className="font-medium">{phaseLabels[phase]}</span>
                      <Badge variant="outline" className="text-xs">
                        {phaseWorkflows.length} tasks
                      </Badge>
                    </div>
                    {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </CollapsibleTrigger>
                  <CollapsibleContent className="mt-2 space-y-2 pl-4">
                    {phaseWorkflows.map((workflow) => (
                      <div
                        key={workflow.id}
                        className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card/50"
                      >
                        <div className="flex items-center gap-3">
                          {getStatusIcon(workflow.status)}
                          <div>
                            <p className="text-sm font-medium">{workflow.name}</p>
                            <p className="text-xs text-muted-foreground">Owner: {workflow.owner}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <Progress value={workflow.progress} className="w-20 h-2" />
                            <p className="text-xs text-muted-foreground mt-1">{workflow.progress}%</p>
                          </div>
                          {getStatusBadge(workflow.status)}
                        </div>
                      </div>
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </CardContent>
        </Card>

        {/* Audit Checklist */}
        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2">
              <FileSearch className="h-5 w-5 text-primary" />
              Pre-Implementation Audit Checklist
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            {discoveryAudits.map((audit) => (
              <div
                key={audit.id}
                className={cn(
                  'p-4 rounded-lg border transition-colors',
                  audit.status === 'skipped' ? 'border-destructive/50 bg-destructive/5' : 'border-border/50 bg-card/50',
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{audit.area}</p>
                      {getAuditStatusBadge(audit.status)}
                    </div>
                    {audit.findings > 0 && (
                      <p className="text-sm text-amber-600 mt-1">{audit.findings} findings identified</p>
                    )}
                    {audit.recommendation && (
                      <p
                        className={cn(
                          'text-sm mt-2 p-2 rounded',
                          audit.status === 'skipped'
                            ? 'bg-destructive/10 text-destructive'
                            : 'bg-primary/5 text-foreground',
                        )}
                      >
                        💡 {audit.recommendation}
                      </p>
                    )}
                  </div>
                  <Badge
                    variant="outline"
                    className={cn(
                      'capitalize text-xs',
                      audit.priority === 'high'
                        ? 'bg-destructive/10 text-destructive'
                        : audit.priority === 'medium'
                          ? 'bg-amber-500/10 text-amber-600'
                          : 'bg-muted',
                    )}
                  >
                    {audit.priority}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
