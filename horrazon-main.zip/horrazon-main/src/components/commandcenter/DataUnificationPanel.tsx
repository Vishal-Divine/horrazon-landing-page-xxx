import { useState } from 'react';
import {
  Database,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Loader2,
  ChevronRight,
  Zap,
  Users,
  TrendingUp,
  TrendingDown,
  Eye,
  Settings,
  ArrowRight,
  Activity,
  Shield,
  Clock,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { dataSources, dataHealthMetrics, unifiedProfiles } from './mockData';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { toast } from '@/hooks/use-toast';

// Health trend data
const healthTrendData = [
  { month: 'Jul', score: 72, issues: 45000 },
  { month: 'Aug', score: 75, issues: 42000 },
  { month: 'Sep', score: 78, issues: 38000 },
  { month: 'Oct', score: 82, issues: 35000 },
  { month: 'Nov', score: 85, issues: 31000 },
  { month: 'Dec', score: 87, issues: 28000 },
];

const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export function DataUnificationPanel() {
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const overallHealthScore = Math.round(dataSources.reduce((acc, ds) => acc + ds.healthScore, 0) / dataSources.length);

  const totalRecords = dataSources.reduce((acc, ds) => acc + ds.recordCount, 0);

  const selectedSourceData = dataSources.find((s) => s.id === selectedSource);

  const handleSyncAll = () => {
    setIsSyncing(true);
    toast({
      title: 'Sync Started',
      description: 'Synchronizing all data sources...',
    });
    setTimeout(() => {
      setIsSyncing(false);
      toast({
        title: 'Sync Complete',
        description: 'All data sources have been synchronized.',
      });
    }, 2000);
  };

  const handleSyncSource = (sourceId: string, sourceName: string) => {
    toast({
      title: 'Syncing ' + sourceName,
      description: 'Data synchronization in progress...',
    });
  };

  const handleViewDetails = (sourceId: string) => {
    setSelectedSource(sourceId);
    setDetailDialogOpen(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
      case 'syncing':
        return <Loader2 className="h-4 w-4 text-primary animate-spin" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-destructive" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'syncing':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'error':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      default:
        return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500';
    if (score >= 70) return 'text-amber-500';
    return 'text-destructive';
  };

  // Pie chart data for record distribution
  const recordDistribution = dataSources.map((s) => ({
    name: s.name,
    value: s.recordCount,
  }));

  return (
    <div className="space-y-6">
      {/* Overall Health Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50 bg-gradient-to-br from-card to-emerald-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Data Health Score</p>
                <p className={cn('text-3xl font-bold', getScoreColor(overallHealthScore))}>{overallHealthScore}%</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <Shield className="h-7 w-7 text-emerald-500" />
              </div>
            </div>
            <Progress value={overallHealthScore} className="mt-3 h-2" />
            <p className="text-xs text-emerald-500 mt-2 flex items-center gap-1">
              <TrendingUp className="h-3 w-3" />
              +5% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Records</p>
                <p className="text-3xl font-bold text-foreground">{(totalRecords / 1000000).toFixed(1)}M</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
                <Database className="h-7 w-7 text-primary" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Across {dataSources.length} connected sources</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-amber-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Data Quality Issues</p>
                <p className="text-3xl font-bold text-amber-500">
                  {dataHealthMetrics.reduce((acc, m) => acc + m.issues, 0).toLocaleString()}
                </p>
              </div>
              <div className="h-14 w-14 rounded-full bg-amber-500/10 flex items-center justify-center">
                <AlertTriangle className="h-7 w-7 text-amber-500" />
              </div>
            </div>
            <p className="text-xs text-destructive mt-3 flex items-center gap-1">
              <TrendingDown className="h-3 w-3" />
              -12% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-purple-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unification Rate</p>
                <p className="text-3xl font-bold text-purple-500">76%</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Zap className="h-7 w-7 text-purple-500" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Records matched across sources</p>
          </CardContent>
        </Card>
      </div>

      {/* Health Trend Chart */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 border-border/50">
          <CardHeader className="border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Data Health Trend
              </CardTitle>
              <Badge variant="secondary" className="text-xs">
                Last 6 months
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={healthTrendData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis domain={[60, 100]} className="text-xs" />
                  <RechartsTooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }}
                    name="Health Score"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="text-lg">Record Distribution</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={recordDistribution.slice(0, 5)}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {recordDistribution.slice(0, 5).map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip
                    formatter={(value: number) => value.toLocaleString()}
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {recordDistribution.slice(0, 5).map((item, index) => (
                <div key={item.name} className="flex items-center gap-1 text-xs">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                  <span className="text-muted-foreground">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Data Sources */}
        <Card className="lg:col-span-2 border-border/50">
          <CardHeader className="border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Connected Data Sources
              </CardTitle>
              <Button size="sm" variant="outline" className="gap-2" onClick={handleSyncAll} disabled={isSyncing}>
                <RefreshCw className={cn('h-4 w-4', isSyncing && 'animate-spin')} />
                {isSyncing ? 'Syncing...' : 'Sync All'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[400px]">
              <div className="divide-y divide-border/50">
                {dataSources.map((source) => (
                  <div
                    key={source.id}
                    className={cn(
                      'p-4 hover:bg-accent/30 transition-colors',
                      selectedSource === source.id && 'bg-accent/50',
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            'h-10 w-10 rounded-lg flex items-center justify-center',
                            source.status === 'error' ? 'bg-destructive/10' : 'bg-primary/10',
                          )}
                        >
                          <source.icon
                            className={cn('h-5 w-5', source.status === 'error' ? 'text-destructive' : 'text-primary')}
                          />
                        </div>
                        <div>
                          <p className="font-medium">{source.name}</p>
                          <p className="text-xs text-muted-foreground">{source.recordCount.toLocaleString()} records</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className={cn('capitalize', getStatusColor(source.status))}>
                          {getStatusIcon(source.status)}
                          <span className="ml-1">{source.status}</span>
                        </Badge>
                        <Tooltip>
                          <TooltipTrigger>
                            <div className={cn('text-lg font-bold', getScoreColor(source.healthScore))}>
                              {source.healthScore}%
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>Health Score</TooltipContent>
                        </Tooltip>
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                            onClick={() => handleSyncSource(source.id, source.name)}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                            onClick={() => handleViewDetails(source.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    {source.missingFields.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {source.missingFields.map((field) => (
                          <Badge
                            key={field}
                            variant="outline"
                            className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/20"
                          >
                            Missing: {field}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Last sync: {formatDistanceToNow(source.lastSync, { addSuffix: true })}
                      </span>
                      <span>Duplicates: {source.duplicateRate}%</span>
                      <span>Quality: {source.dataQuality}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Data Quality Metrics */}
        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="text-lg">Data Quality Dimensions</CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            {dataHealthMetrics.map((metric) => (
              <div key={metric.category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{metric.category}</span>
                    {metric.trend === 'up' && <TrendingUp className="h-3 w-3 text-emerald-500" />}
                    {metric.trend === 'down' && <TrendingDown className="h-3 w-3 text-destructive" />}
                  </div>
                  <span className={cn('font-bold', getScoreColor(metric.score))}>{metric.score}%</span>
                </div>
                <Progress value={metric.score} className="h-2" />
                <p className="text-xs text-muted-foreground">{metric.description}</p>
                <p className="text-xs text-amber-600">{metric.issues.toLocaleString()} issues to resolve</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Unified Customer Profiles Sample */}
      <Card className="border-border/50">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Single Source of Truth - Customer 360
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Sample Profiles</Badge>
              <Button size="sm" variant="outline" className="gap-2">
                View All <ArrowRight className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-4 md:grid-cols-3">
            {unifiedProfiles.map((profile) => (
              <div
                key={profile.id}
                className="rounded-lg border border-border/50 p-4 bg-card/50 hover:bg-accent/30 hover:border-primary/30 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium group-hover:text-primary transition-colors">{profile.name}</p>
                    <p className="text-sm text-muted-foreground">{profile.email}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={cn(
                      'text-xs',
                      profile.completeness >= 90
                        ? 'bg-emerald-500/10 text-emerald-600'
                        : profile.completeness >= 70
                          ? 'bg-amber-500/10 text-amber-600'
                          : 'bg-destructive/10 text-destructive',
                    )}
                  >
                    {profile.completeness}% complete
                  </Badge>
                </div>
                <div className="mt-3 flex flex-wrap gap-1">
                  {profile.sources.map((source) => (
                    <Badge key={source} variant="secondary" className="text-[10px]">
                      {source}
                    </Badge>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-muted-foreground">LTV: </span>
                    <span className="font-medium">${profile.ltv.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Risk: </span>
                    <span
                      className={cn('font-medium', profile.riskScore > 30 ? 'text-destructive' : 'text-emerald-500')}
                    >
                      {profile.riskScore}%
                    </span>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {profile.segments.slice(0, 3).map((segment) => (
                    <Badge key={segment} variant="outline" className="text-[10px] bg-primary/5">
                      {segment}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Source Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedSourceData && (
                <>
                  <selectedSourceData.icon className="h-5 w-5 text-primary" />
                  {selectedSourceData.name} Details
                </>
              )}
            </DialogTitle>
            <DialogDescription>Detailed view of data source health and configuration</DialogDescription>
          </DialogHeader>
          {selectedSourceData && (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-accent/30 text-center">
                  <p className="text-2xl font-bold text-foreground">
                    {selectedSourceData.recordCount.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">Total Records</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 text-center">
                  <p className={cn('text-2xl font-bold', getScoreColor(selectedSourceData.healthScore))}>
                    {selectedSourceData.healthScore}%
                  </p>
                  <p className="text-xs text-muted-foreground">Health Score</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 text-center">
                  <p className="text-2xl font-bold text-foreground">{selectedSourceData.dataQuality}%</p>
                  <p className="text-xs text-muted-foreground">Data Quality</p>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Connection Status</h4>
                <div className="flex items-center gap-2">
                  {getStatusIcon(selectedSourceData.status)}
                  <span className="capitalize">{selectedSourceData.status}</span>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-sm text-muted-foreground">
                    Last sync: {formatDistanceToNow(selectedSourceData.lastSync, { addSuffix: true })}
                  </span>
                </div>
              </div>

              {selectedSourceData.missingFields.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2 text-amber-600">Missing Fields</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedSourceData.missingFields.map((field) => (
                      <Badge key={field} variant="outline" className="bg-amber-500/10 text-amber-600">
                        {field}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h4 className="font-medium mb-2">Data Quality Metrics</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Duplicate Rate:</span>
                    <span className={selectedSourceData.duplicateRate > 5 ? 'text-destructive' : 'text-emerald-500'}>
                      {selectedSourceData.duplicateRate}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Completeness:</span>
                    <span>{selectedSourceData.dataQuality}%</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  className="flex-1 gap-2"
                  onClick={() => handleSyncSource(selectedSourceData.id, selectedSourceData.name)}
                >
                  <RefreshCw className="h-4 w-4" />
                  Sync Now
                </Button>
                <Button variant="outline" className="gap-2">
                  <Settings className="h-4 w-4" />
                  Configure
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
