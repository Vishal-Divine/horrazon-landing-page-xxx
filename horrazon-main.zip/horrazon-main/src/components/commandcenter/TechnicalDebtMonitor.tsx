import { useState } from 'react';
import {
  AlertOctagon,
  TrendingDown,
  TrendingUp,
  DollarSign,
  Wrench,
  Clock,
  Layers,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  Legend,
} from 'recharts';
import { technicalDebtItems, debtTrends } from './mockData';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function TechnicalDebtMonitor() {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');

  const totalDebt = technicalDebtItems.reduce((acc, item) => acc + item.estimatedCost, 0);
  const criticalDebt = technicalDebtItems
    .filter((i) => i.severity === 'critical')
    .reduce((acc, i) => acc + i.estimatedCost, 0);
  const highDebt = technicalDebtItems.filter((i) => i.severity === 'high').reduce((acc, i) => acc + i.estimatedCost, 0);

  const filteredItems = technicalDebtItems.filter((item) => {
    if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;
    if (severityFilter !== 'all' && item.severity !== severityFilter) return false;
    return true;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'high':
        return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'medium':
        return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'integration':
        return <Layers className="h-4 w-4" />;
      case 'customization':
        return <Wrench className="h-4 w-4" />;
      case 'data':
        return <AlertOctagon className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  // Calculate debt reduction
  const latestDebt = debtTrends[debtTrends.length - 1]?.total || 0;
  const previousDebt = debtTrends[debtTrends.length - 2]?.total || latestDebt;
  const debtChange = ((latestDebt - previousDebt) / previousDebt) * 100;

  return (
    <div className="space-y-6">
      {/* Debt Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50 bg-gradient-to-br from-card to-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Tech Debt</p>
                <p className="text-3xl font-bold text-foreground">${(totalDebt / 1000).toFixed(0)}K</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-destructive/10 flex items-center justify-center">
                <DollarSign className="h-7 w-7 text-destructive" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              {debtChange <= 0 ? (
                <TrendingDown className="h-4 w-4 text-emerald-500" />
              ) : (
                <TrendingUp className="h-4 w-4 text-destructive" />
              )}
              <span className={cn('text-sm font-medium', debtChange <= 0 ? 'text-emerald-500' : 'text-destructive')}>
                {debtChange > 0 ? '+' : ''}
                {debtChange.toFixed(1)}% vs last month
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-destructive/30 bg-gradient-to-br from-card to-destructive/10">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Critical Debt</p>
                <p className="text-3xl font-bold text-destructive">${(criticalDebt / 1000).toFixed(0)}K</p>
              </div>
              <AlertOctagon className="h-10 w-10 text-destructive/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {technicalDebtItems.filter((i) => i.severity === 'critical').length} critical items
            </p>
          </CardContent>
        </Card>

        <Card className="border-orange-500/30 bg-gradient-to-br from-card to-orange-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Priority</p>
                <p className="text-3xl font-bold text-orange-600">${(highDebt / 1000).toFixed(0)}K</p>
              </div>
              <Wrench className="h-10 w-10 text-orange-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {technicalDebtItems.filter((i) => i.severity === 'high').length} high priority items
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-emerald-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Debt Paid (6mo)</p>
                <p className="text-3xl font-bold text-emerald-500">$40K</p>
              </div>
              <TrendingDown className="h-10 w-10 text-emerald-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">27% reduction from peak</p>
          </CardContent>
        </Card>
      </div>

      {/* Debt Trend Chart */}
      <Card className="border-border/50">
        <CardHeader className="border-b border-border/50">
          <CardTitle className="flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-primary" />
            Technical Debt Trend (6 Months)
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={debtTrends}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`} className="text-xs" />
                <Tooltip
                  formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="critical"
                  stackId="1"
                  stroke="hsl(var(--destructive))"
                  fill="hsl(var(--destructive) / 0.3)"
                  name="Critical"
                />
                <Area
                  type="monotone"
                  dataKey="high"
                  stackId="1"
                  stroke="#f97316"
                  fill="rgba(249, 115, 22, 0.3)"
                  name="High"
                />
                <Area
                  type="monotone"
                  dataKey="medium"
                  stackId="1"
                  stroke="#eab308"
                  fill="rgba(234, 179, 8, 0.3)"
                  name="Medium"
                />
                <Area
                  type="monotone"
                  dataKey="low"
                  stackId="1"
                  stroke="hsl(var(--muted-foreground))"
                  fill="hsl(var(--muted) / 0.5)"
                  name="Low"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Debt Items List */}
      <Card className="border-border/50">
        <CardHeader className="border-b border-border/50">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-2">
              <AlertOctagon className="h-5 w-5 text-primary" />
              Technical Debt Registry
            </CardTitle>
            <div className="flex items-center gap-3">
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="integration">Integration</SelectItem>
                  <SelectItem value="customization">Customization</SelectItem>
                  <SelectItem value="data">Data</SelectItem>
                  <SelectItem value="workflow">Workflow</SelectItem>
                </SelectContent>
              </Select>
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severity</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[400px]">
            <div className="divide-y divide-border/50">
              {filteredItems.map((item) => (
                <div key={item.id} className="p-4 hover:bg-accent/30 transition-colors cursor-pointer">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          'h-10 w-10 rounded-lg flex items-center justify-center shrink-0',
                          item.severity === 'critical'
                            ? 'bg-destructive/10'
                            : item.severity === 'high'
                              ? 'bg-orange-500/10'
                              : 'bg-amber-500/10',
                        )}
                      >
                        {getCategoryIcon(item.category)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium">{item.name}</p>
                          <Badge
                            variant="outline"
                            className={cn('text-xs capitalize', getSeverityColor(item.severity))}
                          >
                            {item.severity}
                          </Badge>
                          <Badge variant="secondary" className="text-xs capitalize">
                            {item.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{item.impact}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {item.affectedSystems.map((sys) => (
                            <Badge key={sys} variant="outline" className="text-[10px]">
                              {sys}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-lg font-bold text-foreground">${item.estimatedCost.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">
                        Created {formatDistanceToNow(item.createdDate, { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
