import { useState } from 'react';
import {
  Users,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  BarChart3,
  Minus,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { adoptionMetrics, changeResistanceIndicators } from './mockData';
import { cn } from '@/lib/utils';

export function ChangeAdoptionPanel() {
  const overallAdoption = Math.round(
    adoptionMetrics.reduce((acc, m) => acc + m.adoptionRate, 0) / adoptionMetrics.length,
  );

  const chartData = adoptionMetrics.map((m) => ({
    name: m.feature,
    adoption: m.adoptionRate,
    change: m.lastWeekChange,
  }));

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-emerald-500" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-destructive" />;
      default:
        return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'medium':
        return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Change Management Warning */}
      {changeResistanceIndicators.filter((i) => i.severity === 'high').length > 0 && (
        <Card className="border-destructive/50 bg-gradient-to-r from-destructive/5 to-amber-500/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-destructive">Change Resistance Detected</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  According to Salesforce 2025 research, the "human factor" is the hardest part of implementation. Users
                  seeing the platform as "extra work" will revert to private spreadsheets.
                </p>
                <div className="mt-3 flex flex-wrap gap-3">
                  {changeResistanceIndicators
                    .filter((i) => i.severity === 'high')
                    .map((indicator, i) => (
                      <Badge key={i} variant="destructive" className="gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        {indicator.team}: {indicator.indicator}
                      </Badge>
                    ))}
                </div>
              </div>
              <Button variant="destructive" size="sm">
                View Action Plan
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50 bg-gradient-to-br from-card to-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Adoption</p>
                <p className="text-3xl font-bold text-foreground">{overallAdoption}%</p>
              </div>
              <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="h-7 w-7 text-primary" />
              </div>
            </div>
            <Progress value={overallAdoption} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-emerald-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Adoption</p>
                <p className="text-3xl font-bold text-emerald-500">
                  {adoptionMetrics.filter((m) => m.adoptionRate >= 70).length}
                </p>
              </div>
              <CheckCircle2 className="h-10 w-10 text-emerald-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">Features above 70%</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-amber-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Needs Attention</p>
                <p className="text-3xl font-bold text-amber-600">
                  {adoptionMetrics.filter((m) => m.adoptionRate < 50).length}
                </p>
              </div>
              <AlertTriangle className="h-10 w-10 text-amber-500/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">Features below 50%</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-gradient-to-br from-card to-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Resistance Alerts</p>
                <p className="text-3xl font-bold text-destructive">
                  {changeResistanceIndicators.filter((i) => i.severity === 'high').length}
                </p>
              </div>
              <AlertTriangle className="h-10 w-10 text-destructive/30" />
            </div>
            <p className="text-xs text-muted-foreground mt-3">High severity issues</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Feature Adoption Chart */}
        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Feature Adoption Rates
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis dataKey="name" type="category" width={120} className="text-xs" />
                  <Tooltip
                    formatter={(value: number) => [`${value}%`, 'Adoption']}
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="adoption" radius={[0, 4, 4, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={
                          entry.adoption >= 70
                            ? 'hsl(142, 76%, 36%)'
                            : entry.adoption >= 50
                              ? 'hsl(var(--primary))'
                              : 'hsl(var(--destructive))'
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Adoption Details */}
        <Card className="border-border/50">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Feature Adoption Details
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            {adoptionMetrics.map((metric) => (
              <div key={metric.feature} className="p-4 rounded-lg border border-border/50 bg-card/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        'h-10 w-10 rounded-lg flex items-center justify-center',
                        metric.adoptionRate >= 70
                          ? 'bg-emerald-500/10'
                          : metric.adoptionRate >= 50
                            ? 'bg-primary/10'
                            : 'bg-destructive/10',
                      )}
                    >
                      <Users
                        className={cn(
                          'h-5 w-5',
                          metric.adoptionRate >= 70
                            ? 'text-emerald-500'
                            : metric.adoptionRate >= 50
                              ? 'text-primary'
                              : 'text-destructive',
                        )}
                      />
                    </div>
                    <div>
                      <p className="font-medium">{metric.feature}</p>
                      <p className="text-sm text-muted-foreground">
                        {metric.activeUsers} of {metric.totalUsers} users active
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      {getTrendIcon(metric.trend)}
                      <span
                        className={cn(
                          'text-sm font-medium',
                          metric.lastWeekChange > 0
                            ? 'text-emerald-500'
                            : metric.lastWeekChange < 0
                              ? 'text-destructive'
                              : 'text-muted-foreground',
                        )}
                      >
                        {metric.lastWeekChange > 0 ? '+' : ''}
                        {metric.lastWeekChange}%
                      </span>
                    </div>
                    <div
                      className={cn(
                        'text-2xl font-bold',
                        metric.adoptionRate >= 70
                          ? 'text-emerald-500'
                          : metric.adoptionRate >= 50
                            ? 'text-foreground'
                            : 'text-destructive',
                      )}
                    >
                      {metric.adoptionRate}%
                    </div>
                  </div>
                </div>
                <Progress value={metric.adoptionRate} className="mt-3 h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Resistance Indicators */}
      <Card className="border-border/50">
        <CardHeader className="border-b border-border/50">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Change Resistance Indicators
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-4 md:grid-cols-3">
            {changeResistanceIndicators.map((indicator, i) => (
              <div
                key={i}
                className={cn(
                  'p-4 rounded-lg border',
                  indicator.severity === 'high'
                    ? 'border-destructive/50 bg-destructive/5'
                    : 'border-border/50 bg-card/50',
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{indicator.team}</p>
                    <Badge variant="outline" className={cn('text-xs capitalize', getSeverityColor(indicator.severity))}>
                      {indicator.severity}
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-2">{indicator.indicator}</p>
                <div className="mt-3 p-2 rounded bg-primary/5 flex items-start gap-2">
                  <Lightbulb className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs">{indicator.suggestedAction}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
