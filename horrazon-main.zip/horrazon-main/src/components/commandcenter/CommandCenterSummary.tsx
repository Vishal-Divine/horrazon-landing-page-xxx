import { Link } from 'react-router-dom';
import {
  Database,
  AlertTriangle,
  UserX,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Shield,
  Target,
  Zap,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface CommandCenterSummaryProps {
  compact?: boolean;
}

// Summary data from command center
const summaryData = {
  dataHealth: {
    score: 87,
    trend: 'up' as const,
    change: 5,
    issues: 31350,
  },
  unworkedLeads: {
    total: 5,
    hot: 3,
    revenue: 280000,
  },
  techDebt: {
    total: 105000,
    critical: 1,
    trend: 'down' as const,
  },
  adoption: {
    rate: 62,
    resistanceAlerts: 2,
  },
};

export function CommandCenterSummary({ compact = false }: CommandCenterSummaryProps) {
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500';
    if (score >= 70) return 'text-amber-500';
    return 'text-destructive';
  };

  if (compact) {
    return (
      <Card className="border-border/50 bg-gradient-to-br from-card via-primary/5 to-accent/10">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="h-5 w-5 text-primary" />
              Marketing Health
            </CardTitle>
            <Link to="/command-center">
              <Button size="sm" variant="ghost" className="gap-1 text-xs">
                View Details <ArrowRight className="h-3 w-3" />
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center">
              <p className={cn('text-2xl font-bold', getScoreColor(summaryData.dataHealth.score))}>
                {summaryData.dataHealth.score}%
              </p>
              <p className="text-xs text-muted-foreground">Data Health</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-destructive">{summaryData.unworkedLeads.hot}</p>
              <p className="text-xs text-muted-foreground">Hot Leads</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-amber-500">${(summaryData.techDebt.total / 1000).toFixed(0)}K</p>
              <p className="text-xs text-muted-foreground">Tech Debt</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground">{summaryData.adoption.rate}%</p>
              <p className="text-xs text-muted-foreground">Adoption</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {/* Data Health */}
      <Link to="/command-center" className="block group">
        <Card className="border-border/50 bg-gradient-to-br from-card to-emerald-500/5 hover:border-primary/50 transition-all h-full">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Data Health</p>
                <p className={cn('text-3xl font-bold', getScoreColor(summaryData.dataHealth.score))}>
                  {summaryData.dataHealth.score}%
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-emerald-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Database className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <Progress value={summaryData.dataHealth.score} className="flex-1 h-2 mr-3" />
              <div className="flex items-center gap-1 text-xs text-emerald-500">
                <TrendingUp className="h-3 w-3" />+{summaryData.dataHealth.change}%
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {summaryData.dataHealth.issues.toLocaleString()} issues to resolve
            </p>
          </CardContent>
        </Card>
      </Link>

      {/* Unworked Leads Alert */}
      <Link to="/command-center" className="block group">
        <Card
          className={cn(
            'border-border/50 bg-gradient-to-br from-card hover:border-primary/50 transition-all h-full',
            summaryData.unworkedLeads.hot > 0 ? 'to-destructive/5 border-destructive/30' : 'to-muted/5',
          )}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Follow-Up Alert</p>
                <p className="text-3xl font-bold text-destructive">{summaryData.unworkedLeads.hot}</p>
              </div>
              <div
                className={cn(
                  'h-12 w-12 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform',
                  summaryData.unworkedLeads.hot > 0 ? 'bg-destructive/10 animate-pulse' : 'bg-muted/30',
                )}
              >
                <UserX className="h-6 w-6 text-destructive" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              {summaryData.unworkedLeads.hot > 0 && (
                <Badge variant="destructive" className="text-xs animate-pulse">
                  🔥 Hot leads uncontacted
                </Badge>
              )}
            </div>
            <p className="text-xs text-amber-600 mt-2">
              ${(summaryData.unworkedLeads.revenue / 1000).toFixed(0)}K revenue at risk
            </p>
          </CardContent>
        </Card>
      </Link>

      {/* Technical Debt */}
      <Link to="/command-center" className="block group">
        <Card className="border-border/50 bg-gradient-to-br from-card to-amber-500/5 hover:border-primary/50 transition-all h-full">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Tech Debt</p>
                <p className="text-3xl font-bold text-amber-500">${(summaryData.techDebt.total / 1000).toFixed(0)}K</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-amber-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <AlertTriangle className="h-6 w-6 text-amber-500" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Badge variant="outline" className="text-xs bg-destructive/10 text-destructive">
                {summaryData.techDebt.critical} critical
              </Badge>
              <div className="flex items-center gap-1 text-xs text-emerald-500">
                <TrendingDown className="h-3 w-3" />
                Decreasing
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Estimated cost to resolve</p>
          </CardContent>
        </Card>
      </Link>

      {/* Adoption Rate */}
      <Link to="/command-center" className="block group">
        <Card className="border-border/50 bg-gradient-to-br from-card to-primary/5 hover:border-primary/50 transition-all h-full">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Platform Adoption</p>
                <p className="text-3xl font-bold text-foreground">{summaryData.adoption.rate}%</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Target className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="mt-3">
              <Progress value={summaryData.adoption.rate} className="h-2" />
            </div>
            {summaryData.adoption.resistanceAlerts > 0 && (
              <p className="text-xs text-amber-600 mt-2">
                ⚠️ {summaryData.adoption.resistanceAlerts} resistance indicators
              </p>
            )}
          </CardContent>
        </Card>
      </Link>
    </div>
  );
}
