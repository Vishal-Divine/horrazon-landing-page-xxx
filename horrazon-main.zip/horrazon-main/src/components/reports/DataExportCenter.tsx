import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  FileText,
  FileSpreadsheet,
  FileType,
  Presentation,
  Download,
  Clock,
  Calendar,
  Mail,
  Cloud,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Settings,
  Trash2,
  Play,
  Pause,
  RefreshCw,
  FolderOpen,
  Link,
  Zap,
  Filter,
  Archive,
  Send,
} from 'lucide-react';
import { toast } from 'sonner';

interface ExportFormat {
  id: string;
  name: string;
  icon: React.ReactNode;
  extension: string;
  description: string;
  features: string[];
}

interface ExportJob {
  id: string;
  name: string;
  format: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  createdAt: string;
  completedAt?: string;
  fileSize?: string;
  downloadUrl?: string;
}

interface ScheduledExport {
  id: string;
  name: string;
  reportType: string;
  format: string;
  schedule: string;
  recipients: string[];
  lastRun?: string;
  nextRun: string;
  isActive: boolean;
  destination: 'email' | 'cloud' | 'both';
}

const exportFormats: ExportFormat[] = [
  {
    id: 'pdf',
    name: 'PDF Document',
    icon: <FileText className="h-5 w-5 text-red-500" />,
    extension: '.pdf',
    description: 'Professional formatted reports with charts and styling',
    features: ['Charts & Graphs', 'Custom Branding', 'Page Headers/Footers', 'Table of Contents'],
  },
  {
    id: 'excel',
    name: 'Excel Spreadsheet',
    icon: <FileSpreadsheet className="h-5 w-5 text-green-600" />,
    extension: '.xlsx',
    description: 'Editable spreadsheet with formulas and multiple sheets',
    features: ['Multiple Sheets', 'Formulas Preserved', 'Pivot Tables', 'Conditional Formatting'],
  },
  {
    id: 'csv',
    name: 'CSV Data',
    icon: <FileType className="h-5 w-5 text-blue-500" />,
    extension: '.csv',
    description: 'Raw data export for custom analysis and integrations',
    features: ['Raw Data', 'Universal Compatibility', 'Small File Size', 'Easy Import'],
  },
  {
    id: 'pptx',
    name: 'PowerPoint',
    icon: <Presentation className="h-5 w-5 text-orange-500" />,
    extension: '.pptx',
    description: 'Presentation-ready slides with key insights and visuals',
    features: ['Slide Layouts', 'Chart Visuals', 'Speaker Notes', 'Custom Themes'],
  },
];

const mockExportJobs: ExportJob[] = [
  {
    id: '1',
    name: 'Q4 Performance Report',
    format: 'pdf',
    status: 'completed',
    progress: 100,
    createdAt: '2024-01-15 14:30',
    completedAt: '2024-01-15 14:32',
    fileSize: '2.4 MB',
    downloadUrl: '#',
  },
  {
    id: '2',
    name: 'Customer Data Export',
    format: 'excel',
    status: 'processing',
    progress: 67,
    createdAt: '2024-01-15 14:45',
  },
  {
    id: '3',
    name: 'Campaign Analytics',
    format: 'csv',
    status: 'queued',
    progress: 0,
    createdAt: '2024-01-15 14:50',
  },
  {
    id: '4',
    name: 'Executive Summary',
    format: 'pptx',
    status: 'failed',
    progress: 45,
    createdAt: '2024-01-15 13:00',
  },
];

const mockScheduledExports: ScheduledExport[] = [
  {
    id: '1',
    name: 'Weekly Performance Summary',
    reportType: 'Performance Dashboard',
    format: 'pdf',
    schedule: 'Every Monday at 9:00 AM',
    recipients: ['team@company.com', 'manager@company.com'],
    lastRun: '2024-01-08 09:00',
    nextRun: '2024-01-15 09:00',
    isActive: true,
    destination: 'email',
  },
  {
    id: '2',
    name: 'Monthly Data Backup',
    reportType: 'Full Data Export',
    format: 'excel',
    schedule: '1st of every month at 6:00 AM',
    recipients: ['data@company.com'],
    lastRun: '2024-01-01 06:00',
    nextRun: '2024-02-01 06:00',
    isActive: true,
    destination: 'cloud',
  },
  {
    id: '3',
    name: 'Daily Campaign Report',
    reportType: 'Campaign Analytics',
    format: 'csv',
    schedule: 'Daily at 11:59 PM',
    recipients: ['marketing@company.com'],
    lastRun: '2024-01-14 23:59',
    nextRun: '2024-01-15 23:59',
    isActive: false,
    destination: 'both',
  },
];

const reportTypes = [
  'Performance Dashboard',
  'Campaign Analytics',
  'Customer Insights',
  'Revenue Report',
  'Attribution Analysis',
  'Full Data Export',
  'Custom Report',
];

export const DataExportCenter: React.FC = () => {
  const [selectedFormat, setSelectedFormat] = useState<string>('pdf');
  const [exportJobs, setExportJobs] = useState<ExportJob[]>(mockExportJobs);
  const [scheduledExports, setScheduledExports] = useState<ScheduledExport[]>(mockScheduledExports);
  const [selectedReports, setSelectedReports] = useState<string[]>([]);
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includeRawData, setIncludeRawData] = useState(false);
  const [dateRange, setDateRange] = useState('last30days');
  const [compressionEnabled, setCompressionEnabled] = useState(false);

  // Schedule form state
  const [scheduleName, setScheduleName] = useState('');
  const [scheduleFrequency, setScheduleFrequency] = useState('weekly');
  const [scheduleTime, setScheduleTime] = useState('09:00');
  const [scheduleRecipients, setScheduleRecipients] = useState('');
  const [scheduleDestination, setScheduleDestination] = useState<'email' | 'cloud' | 'both'>('email');

  const handleExportNow = () => {
    const newJob: ExportJob = {
      id: Date.now().toString(),
      name: `Export ${new Date().toLocaleDateString()}`,
      format: selectedFormat,
      status: 'queued',
      progress: 0,
      createdAt: new Date().toLocaleString(),
    };
    setExportJobs([newJob, ...exportJobs]);
    toast.success('Export job queued successfully');

    // Simulate progress
    setTimeout(() => {
      setExportJobs((prev) =>
        prev.map((job) => (job.id === newJob.id ? { ...job, status: 'processing', progress: 30 } : job)),
      );
    }, 1000);

    setTimeout(() => {
      setExportJobs((prev) =>
        prev.map((job) =>
          job.id === newJob.id
            ? {
                ...job,
                status: 'completed',
                progress: 100,
                completedAt: new Date().toLocaleString(),
                fileSize: '1.8 MB',
                downloadUrl: '#',
              }
            : job,
        ),
      );
      toast.success('Export completed! Ready for download.');
    }, 3000);
  };

  const handleCreateSchedule = () => {
    if (!scheduleName) {
      toast.error('Please enter a schedule name');
      return;
    }

    const newSchedule: ScheduledExport = {
      id: Date.now().toString(),
      name: scheduleName,
      reportType: selectedReports[0] || 'Performance Dashboard',
      format: selectedFormat,
      schedule: `${scheduleFrequency === 'daily' ? 'Daily' : scheduleFrequency === 'weekly' ? 'Every Monday' : '1st of every month'} at ${scheduleTime}`,
      recipients: scheduleRecipients
        .split(',')
        .map((r) => r.trim())
        .filter(Boolean),
      nextRun: new Date(Date.now() + 86400000).toLocaleString(),
      isActive: true,
      destination: scheduleDestination,
    };

    setScheduledExports([newSchedule, ...scheduledExports]);
    toast.success('Scheduled export created successfully');
    setScheduleName('');
    setScheduleRecipients('');
  };

  const toggleScheduleActive = (id: string) => {
    setScheduledExports((prev) =>
      prev.map((schedule) => (schedule.id === id ? { ...schedule, isActive: !schedule.isActive } : schedule)),
    );
  };

  const deleteSchedule = (id: string) => {
    setScheduledExports((prev) => prev.filter((schedule) => schedule.id !== id));
    toast.success('Scheduled export deleted');
  };

  const retryExport = (id: string) => {
    setExportJobs((prev) => prev.map((job) => (job.id === id ? { ...job, status: 'queued', progress: 0 } : job)));
    toast.info('Retrying export...');
  };

  const getStatusBadge = (status: ExportJob['status']) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Completed</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Processing</Badge>;
      case 'queued':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Queued</Badge>;
      case 'failed':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Failed</Badge>;
    }
  };

  const getFormatIcon = (format: string) => {
    const formatConfig = exportFormats.find((f) => f.id === format);
    return formatConfig?.icon || <FileText className="h-4 w-4" />;
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="export" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-card/50 border border-border/50">
          <TabsTrigger value="export" className="data-[state=active]:bg-primary/20">
            <Download className="h-4 w-4 mr-2" />
            Quick Export
          </TabsTrigger>
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-primary/20">
            <Calendar className="h-4 w-4 mr-2" />
            Scheduled Exports
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-primary/20">
            <Clock className="h-4 w-4 mr-2" />
            Export History
          </TabsTrigger>
        </TabsList>

        {/* Quick Export Tab */}
        <TabsContent value="export" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Format Selection */}
            <Card className="lg:col-span-2 bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileType className="h-5 w-5 text-primary" />
                  Select Export Format
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {exportFormats.map((format) => (
                    <div
                      key={format.id}
                      onClick={() => setSelectedFormat(format.id)}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        selectedFormat === format.id
                          ? 'border-primary bg-primary/10'
                          : 'border-border/50 hover:border-primary/50 bg-background/50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-background/80">{format.icon}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium text-foreground">{format.name}</h4>
                            <Badge variant="outline" className="text-xs">
                              {format.extension}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{format.description}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {format.features.slice(0, 2).map((feature, i) => (
                              <Badge key={i} variant="secondary" className="text-[10px]">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Export Options */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Settings className="h-5 w-5 text-primary" />
                  Export Options
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="last7days">Last 7 Days</SelectItem>
                      <SelectItem value="last30days">Last 30 Days</SelectItem>
                      <SelectItem value="last90days">Last 90 Days</SelectItem>
                      <SelectItem value="thisMonth">This Month</SelectItem>
                      <SelectItem value="lastMonth">Last Month</SelectItem>
                      <SelectItem value="thisYear">This Year</SelectItem>
                      <SelectItem value="custom">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="include-charts" className="text-sm">
                      Include Charts
                    </Label>
                    <Switch id="include-charts" checked={includeCharts} onCheckedChange={setIncludeCharts} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="include-raw" className="text-sm">
                      Include Raw Data
                    </Label>
                    <Switch id="include-raw" checked={includeRawData} onCheckedChange={setIncludeRawData} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="compression" className="text-sm">
                      Compress Files
                    </Label>
                    <Switch id="compression" checked={compressionEnabled} onCheckedChange={setCompressionEnabled} />
                  </div>
                </div>

                <Separator />

                <Button onClick={handleExportNow} className="w-full" size="lg">
                  <Download className="h-4 w-4 mr-2" />
                  Export Now
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Report Selection */}
          <Card className="bg-card/50 border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-primary" />
                Select Reports to Export
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {reportTypes.map((report) => (
                  <div
                    key={report}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      selectedReports.includes(report)
                        ? 'border-primary bg-primary/10'
                        : 'border-border/50 hover:border-primary/50'
                    }`}
                    onClick={() => {
                      setSelectedReports((prev) =>
                        prev.includes(report) ? prev.filter((r) => r !== report) : [...prev, report],
                      );
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <Checkbox checked={selectedReports.includes(report)} />
                      <span className="text-sm">{report}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Scheduled Exports Tab */}
        <TabsContent value="scheduled" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create Schedule */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  Create Scheduled Export
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Schedule Name</Label>
                  <Input
                    placeholder="e.g., Weekly Performance Report"
                    value={scheduleName}
                    onChange={(e) => setScheduleName(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Export Format</Label>
                    <Select value={selectedFormat} onValueChange={setSelectedFormat}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {exportFormats.map((format) => (
                          <SelectItem key={format.id} value={format.id}>
                            <div className="flex items-center gap-2">
                              {format.icon}
                              {format.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Frequency</Label>
                    <Select value={scheduleFrequency} onValueChange={setScheduleFrequency}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Time</Label>
                    <Input type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} />
                  </div>

                  <div className="space-y-2">
                    <Label>Delivery</Label>
                    <Select
                      value={scheduleDestination}
                      onValueChange={(v: 'email' | 'cloud' | 'both') => setScheduleDestination(v)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="email">
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            Email
                          </div>
                        </SelectItem>
                        <SelectItem value="cloud">
                          <div className="flex items-center gap-2">
                            <Cloud className="h-4 w-4" />
                            Cloud Storage
                          </div>
                        </SelectItem>
                        <SelectItem value="both">
                          <div className="flex items-center gap-2">
                            <Send className="h-4 w-4" />
                            Both
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Recipients (comma-separated emails)</Label>
                  <Input
                    placeholder="email1@company.com, email2@company.com"
                    value={scheduleRecipients}
                    onChange={(e) => setScheduleRecipients(e.target.value)}
                  />
                </div>

                <Button onClick={handleCreateSchedule} className="w-full">
                  <Calendar className="h-4 w-4 mr-2" />
                  Create Schedule
                </Button>
              </CardContent>
            </Card>

            {/* Active Schedules */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Active Schedules
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-3">
                    {scheduledExports.map((schedule) => (
                      <div
                        key={schedule.id}
                        className={`p-4 rounded-lg border transition-all ${
                          schedule.isActive
                            ? 'border-primary/30 bg-primary/5'
                            : 'border-border/50 bg-muted/30 opacity-60'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            {getFormatIcon(schedule.format)}
                            <div>
                              <h4 className="font-medium text-foreground">{schedule.name}</h4>
                              <p className="text-xs text-muted-foreground mt-1">{schedule.reportType}</p>
                              <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {schedule.schedule}
                              </div>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                {schedule.destination === 'email' && <Mail className="h-3 w-3" />}
                                {schedule.destination === 'cloud' && <Cloud className="h-3 w-3" />}
                                {schedule.destination === 'both' && <Send className="h-3 w-3" />}
                                {schedule.recipients.length} recipient(s)
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => toggleScheduleActive(schedule.id)}
                            >
                              {schedule.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={() => deleteSchedule(schedule.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-border/50 flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Next: {schedule.nextRun}</span>
                          <Badge variant={schedule.isActive ? 'default' : 'secondary'}>
                            {schedule.isActive ? 'Active' : 'Paused'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Export History Tab */}
        <TabsContent value="history" className="space-y-6 mt-6">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Archive className="h-5 w-5 text-primary" />
                Export History
              </CardTitle>
              <div className="flex items-center gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-32">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {exportJobs.map((job) => (
                  <div key={job.id} className="p-4 rounded-lg border border-border/50 bg-background/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getFormatIcon(job.format)}
                        <div>
                          <h4 className="font-medium text-foreground">{job.name}</h4>
                          <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                            <span>Created: {job.createdAt}</span>
                            {job.completedAt && <span>Completed: {job.completedAt}</span>}
                            {job.fileSize && <span>Size: {job.fileSize}</span>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getStatusBadge(job.status)}
                        {job.status === 'completed' && (
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        )}
                        {job.status === 'failed' && (
                          <Button variant="outline" size="sm" onClick={() => retryExport(job.id)}>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Retry
                          </Button>
                        )}
                      </div>
                    </div>
                    {job.status === 'processing' && (
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                          <span>Processing...</span>
                          <span>{job.progress}%</span>
                        </div>
                        <Progress value={job.progress} className="h-2" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-card/50 border-border/50 p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/20">
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">147</p>
                  <p className="text-xs text-muted-foreground">Completed Exports</p>
                </div>
              </div>
            </Card>
            <Card className="bg-card/50 border-border/50 p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/20">
                  <Loader2 className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">3</p>
                  <p className="text-xs text-muted-foreground">In Progress</p>
                </div>
              </div>
            </Card>
            <Card className="bg-card/50 border-border/50 p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/20">
                  <Calendar className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">8</p>
                  <p className="text-xs text-muted-foreground">Active Schedules</p>
                </div>
              </div>
            </Card>
            <Card className="bg-card/50 border-border/50 p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/20">
                  <Archive className="h-5 w-5 text-orange-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">2.4 GB</p>
                  <p className="text-xs text-muted-foreground">Total Exported</p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
