import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Calendar,
  Clock,
  Mail,
  Users,
  Plus,
  Settings,
  Trash2,
  Edit,
  Play,
  Pause,
  Send,
  CheckCircle2,
  AlertCircle,
  CalendarClock,
  FileText,
  Sparkles,
  Bell,
  Zap,
  ArrowRight,
  MailCheck,
  MailX,
} from 'lucide-react';

interface ScheduledReport {
  id: string;
  name: string;
  template: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  dayOfWeek?: number;
  dayOfMonth?: number;
  time: string;
  timezone: string;
  recipients: { email: string; name: string; avatar?: string }[];
  lastSent?: string;
  nextSend: string;
  status: 'active' | 'paused' | 'failed';
  deliveryStats: { sent: number; opened: number; clicked: number };
  conditions?: string[];
}

const mockScheduledReports: ScheduledReport[] = [
  {
    id: '1',
    name: 'Weekly Performance Summary',
    template: 'Weekly Business Report',
    frequency: 'weekly',
    dayOfWeek: 1,
    time: '09:00',
    timezone: 'America/New_York',
    recipients: [
      { email: 'ceo@company.com', name: 'John Smith', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John' },
      {
        email: 'cmo@company.com',
        name: 'Sarah Johnson',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
      },
      { email: 'marketing@company.com', name: 'Team Marketing' },
    ],
    lastSent: 'Dec 2, 2024 9:00 AM',
    nextSend: 'Mon, Dec 9 at 9:00 AM EST',
    status: 'active',
    deliveryStats: { sent: 48, opened: 42, clicked: 28 },
  },
  {
    id: '2',
    name: 'Monthly Investor Update',
    template: 'Investor Update',
    frequency: 'monthly',
    dayOfMonth: 1,
    time: '08:00',
    timezone: 'America/New_York',
    recipients: [
      { email: 'investors@company.com', name: 'Investor Group' },
      { email: 'board@company.com', name: 'Board Members' },
    ],
    lastSent: 'Dec 1, 2024 8:00 AM',
    nextSend: 'Wed, Jan 1 at 8:00 AM EST',
    status: 'active',
    deliveryStats: { sent: 12, opened: 11, clicked: 8 },
    conditions: ['Only if revenue > $200K'],
  },
  {
    id: '3',
    name: 'Quarterly Board Deck',
    template: 'Board Deck',
    frequency: 'quarterly',
    dayOfMonth: 15,
    time: '10:00',
    timezone: 'America/New_York',
    recipients: [{ email: 'board@company.com', name: 'Board of Directors' }],
    lastSent: 'Oct 15, 2024 10:00 AM',
    nextSend: 'Wed, Jan 15 at 10:00 AM EST',
    status: 'paused',
    deliveryStats: { sent: 4, opened: 4, clicked: 4 },
  },
  {
    id: '4',
    name: 'Daily KPI Alert',
    template: 'KPI Dashboard',
    frequency: 'daily',
    time: '07:00',
    timezone: 'America/New_York',
    recipients: [{ email: 'ops@company.com', name: 'Operations Team' }],
    lastSent: 'Dec 7, 2024 7:00 AM',
    nextSend: 'Sun, Dec 8 at 7:00 AM EST',
    status: 'active',
    deliveryStats: { sent: 180, opened: 156, clicked: 42 },
    conditions: ['Only if ROAS < 4x', 'Only if spend > $1K'],
  },
];

const deliveryHistory = [
  {
    date: 'Dec 7, 2024',
    report: 'Weekly Performance Summary',
    recipients: 3,
    delivered: 3,
    opened: 2,
    status: 'success',
  },
  { date: 'Dec 7, 2024', report: 'Daily KPI Alert', recipients: 1, delivered: 1, opened: 1, status: 'success' },
  { date: 'Dec 6, 2024', report: 'Daily KPI Alert', recipients: 1, delivered: 1, opened: 0, status: 'success' },
  { date: 'Dec 5, 2024', report: 'Daily KPI Alert', recipients: 1, delivered: 0, opened: 0, status: 'failed' },
  { date: 'Dec 4, 2024', report: 'Daily KPI Alert', recipients: 1, delivered: 1, opened: 1, status: 'success' },
  {
    date: 'Dec 2, 2024',
    report: 'Weekly Performance Summary',
    recipients: 3,
    delivered: 3,
    opened: 3,
    status: 'success',
  },
  { date: 'Dec 1, 2024', report: 'Monthly Investor Update', recipients: 2, delivered: 2, opened: 2, status: 'success' },
];

export function ReportScheduler() {
  const [selectedReport, setSelectedReport] = useState<ScheduledReport | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const getFrequencyLabel = (freq: string) => {
    switch (freq) {
      case 'daily':
        return 'Every day';
      case 'weekly':
        return 'Every week';
      case 'monthly':
        return 'Every month';
      case 'quarterly':
        return 'Every quarter';
      default:
        return freq;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-success/10 text-success';
      case 'paused':
        return 'bg-warning/10 text-warning';
      case 'failed':
        return 'bg-destructive/10 text-destructive';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-chart-2/20 bg-gradient-to-br from-chart-2/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-2/10">
                <CalendarClock className="h-5 w-5 text-chart-2" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Report Scheduler
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Smart Delivery
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Automate report delivery with conditional triggers and smart scheduling
                </p>
              </div>
            </div>
            <Button className="gap-2" onClick={() => setShowCreateModal(true)}>
              <Plus className="h-4 w-4" />
              Schedule New Report
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Scheduled Reports</p>
                <p className="text-3xl font-bold">{mockScheduledReports.length}</p>
              </div>
              <FileText className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {mockScheduledReports.filter((r) => r.status === 'active').length} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Recipients</p>
                <p className="text-3xl font-bold">
                  {mockScheduledReports.reduce((sum, r) => sum + r.recipients.length, 0)}
                </p>
              </div>
              <Users className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Across all reports</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Delivery Rate</p>
                <p className="text-3xl font-bold text-success">98.2%</p>
              </div>
              <MailCheck className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Open Rate</p>
                <p className="text-3xl font-bold">87%</p>
              </div>
              <Mail className="h-8 w-8 text-chart-3" />
            </div>
            <Progress value={87} className="mt-2 h-1.5" />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="scheduled" className="space-y-4">
        <TabsList>
          <TabsTrigger value="scheduled" className="gap-2">
            <Calendar className="h-4 w-4" />
            Scheduled Reports
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <Clock className="h-4 w-4" />
            Delivery History
          </TabsTrigger>
          <TabsTrigger value="conditions" className="gap-2">
            <Zap className="h-4 w-4" />
            Smart Triggers
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scheduled" className="space-y-4">
          {mockScheduledReports.map((report) => (
            <Card
              key={report.id}
              className={`transition-all ${selectedReport?.id === report.id ? 'ring-1 ring-primary' : ''}`}
            >
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div
                      className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        report.status === 'active'
                          ? 'bg-success/20'
                          : report.status === 'paused'
                            ? 'bg-warning/20'
                            : 'bg-destructive/20'
                      }`}
                    >
                      <Calendar
                        className={`h-5 w-5 ${
                          report.status === 'active'
                            ? 'text-success'
                            : report.status === 'paused'
                              ? 'text-warning'
                              : 'text-destructive'
                        }`}
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold">{report.name}</p>
                        <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                        {report.conditions && (
                          <Badge variant="outline" className="gap-1">
                            <Zap className="h-3 w-3" />
                            Conditional
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {getFrequencyLabel(report.frequency)} • Next: {report.nextSend}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex -space-x-2">
                      {report.recipients.slice(0, 3).map((recipient, idx) => (
                        <Avatar key={idx} className="h-8 w-8 border-2 border-background">
                          <AvatarImage src={recipient.avatar} />
                          <AvatarFallback className="text-xs">
                            {recipient.name
                              .split(' ')
                              .map((n) => n[0])
                              .join('')}
                          </AvatarFallback>
                        </Avatar>
                      ))}
                      {report.recipients.length > 3 && (
                        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-xs border-2 border-background">
                          +{report.recipients.length - 3}
                        </div>
                      )}
                    </div>

                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Open Rate</p>
                      <p className="font-bold">
                        {Math.round((report.deliveryStats.opened / report.deliveryStats.sent) * 100)}%
                      </p>
                    </div>

                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        {report.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Send className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {report.conditions && (
                  <div className="mt-3 pt-3 border-t flex items-center gap-2">
                    <Zap className="h-4 w-4 text-chart-3" />
                    <span className="text-sm text-muted-foreground">Conditions:</span>
                    {report.conditions.map((condition, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {condition}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Deliveries</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {deliveryHistory.map((delivery, idx) => (
                  <div key={idx} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center ${
                          delivery.status === 'success' ? 'bg-success/20' : 'bg-destructive/20'
                        }`}
                      >
                        {delivery.status === 'success' ? (
                          <CheckCircle2 className="h-4 w-4 text-success" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-destructive" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{delivery.report}</p>
                        <p className="text-xs text-muted-foreground">{delivery.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Sent</p>
                        <p className="font-medium">{delivery.recipients}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Delivered</p>
                        <p className="font-medium">{delivery.delivered}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Opened</p>
                        <p className="font-medium">{delivery.opened}</p>
                      </div>
                      <Badge
                        className={
                          delivery.status === 'success'
                            ? 'bg-success/10 text-success'
                            : 'bg-destructive/10 text-destructive'
                        }
                      >
                        {delivery.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="conditions" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Bell className="h-5 w-5 text-chart-3" />
                  Alert-Based Triggers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">ROAS Drop Alert</p>
                    <p className="text-sm text-muted-foreground">Send when ROAS falls below 4x</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">Spend Threshold</p>
                    <p className="text-sm text-muted-foreground">Send when daily spend exceeds $5K</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">Conversion Drop</p>
                    <p className="text-sm text-muted-foreground">Send when conversion rate drops 20%</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className="h-5 w-5 text-chart-1" />
                  Milestone Triggers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">Revenue Milestone</p>
                    <p className="text-sm text-muted-foreground">Send when monthly revenue hits target</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">Customer Milestone</p>
                    <p className="text-sm text-muted-foreground">Send at every 1,000 new customers</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <p className="font-medium">Campaign Complete</p>
                    <p className="text-sm text-muted-foreground">Send when campaign budget is depleted</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
