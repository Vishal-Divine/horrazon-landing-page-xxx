import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Palette, Image, Type, Upload, Eye, Download, Save, Sparkles, Check, Plus } from 'lucide-react';

interface BrandTheme {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  fontFamily: string;
  logoUrl?: string;
}

const presetThemes: { name: string; theme: BrandTheme }[] = [
  {
    name: 'Modern Blue',
    theme: {
      primaryColor: '#3B82F6',
      secondaryColor: '#1E40AF',
      accentColor: '#60A5FA',
      backgroundColor: '#FFFFFF',
      textColor: '#1F2937',
      fontFamily: 'Inter',
    },
  },
  {
    name: 'Corporate Gray',
    theme: {
      primaryColor: '#374151',
      secondaryColor: '#111827',
      accentColor: '#6B7280',
      backgroundColor: '#F9FAFB',
      textColor: '#111827',
      fontFamily: 'Arial',
    },
  },
  {
    name: 'Vibrant Purple',
    theme: {
      primaryColor: '#7C3AED',
      secondaryColor: '#5B21B6',
      accentColor: '#A78BFA',
      backgroundColor: '#FFFFFF',
      textColor: '#1F2937',
      fontFamily: 'Poppins',
    },
  },
  {
    name: 'Nature Green',
    theme: {
      primaryColor: '#059669',
      secondaryColor: '#047857',
      accentColor: '#34D399',
      backgroundColor: '#FFFFFF',
      textColor: '#1F2937',
      fontFamily: 'Inter',
    },
  },
];

export function WhiteLabelStudio() {
  const [enabled, setEnabled] = useState(true);
  const [companyName, setCompanyName] = useState('Your Company');
  const [tagline, setTagline] = useState('Performance Marketing Analytics');
  const [theme, setTheme] = useState<BrandTheme>(presetThemes[0].theme);
  const [selectedPreset, setSelectedPreset] = useState<string>('Modern Blue');
  const [footerText, setFooterText] = useState('Confidential - For internal use only');
  const [showPoweredBy, setShowPoweredBy] = useState(false);

  const updateThemeColor = (key: keyof BrandTheme, value: string) => {
    setTheme({ ...theme, [key]: value });
    setSelectedPreset('');
  };

  const selectPreset = (preset: (typeof presetThemes)[0]) => {
    setTheme(preset.theme);
    setSelectedPreset(preset.name);
  };

  return (
    <div className="space-y-6">
      <Card className="border-chart-4/20 bg-gradient-to-br from-chart-4/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-4/10">
                <Palette className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  White Label Studio
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Brand Customization
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">Customize reports with your brand identity and styling</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" className="gap-2">
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button className="gap-2">
                <Save className="h-4 w-4" />
                Save Settings
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
        <div>
          <h3 className="font-semibold">Enable White Label Mode</h3>
          <p className="text-sm text-muted-foreground">
            Remove platform branding and apply custom styling to all reports
          </p>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} />
      </div>

      {enabled && (
        <Tabs defaultValue="branding" className="space-y-4">
          <TabsList>
            <TabsTrigger value="branding" className="gap-2">
              <Image className="h-4 w-4" />
              Branding
            </TabsTrigger>
            <TabsTrigger value="colors" className="gap-2">
              <Palette className="h-4 w-4" />
              Colors & Theme
            </TabsTrigger>
            <TabsTrigger value="typography" className="gap-2">
              <Type className="h-4 w-4" />
              Typography
            </TabsTrigger>
            <TabsTrigger value="preview" className="gap-2">
              <Eye className="h-4 w-4" />
              Live Preview
            </TabsTrigger>
          </TabsList>

          <TabsContent value="branding" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Company Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Company Name</Label>
                    <Input value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Tagline</Label>
                    <Input value={tagline} onChange={(e) => setTagline(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Report Footer</Label>
                    <Textarea value={footerText} onChange={(e) => setFooterText(e.target.value)} rows={2} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Show "Powered by" Attribution</Label>
                    <Switch checked={showPoweredBy} onCheckedChange={setShowPoweredBy} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Logo & Assets</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Primary Logo</Label>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                      <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">Drag & drop or click to upload</p>
                      <p className="text-xs text-muted-foreground mt-1">PNG, SVG up to 2MB • Recommended: 200x50px</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Favicon / Icon</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded border-2 border-dashed flex items-center justify-center">
                        <Plus className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <p>Square icon for reports</p>
                        <p className="text-xs">32x32px or 64x64px</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="colors" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Preset Themes</CardTitle>
                <CardDescription>Quick-start with a pre-designed color palette</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4">
                  {presetThemes.map((preset) => (
                    <div
                      key={preset.name}
                      className={`p-4 rounded-lg border cursor-pointer transition-all ${
                        selectedPreset === preset.name
                          ? 'border-primary ring-1 ring-primary'
                          : 'hover:border-primary/50'
                      }`}
                      onClick={() => selectPreset(preset)}
                    >
                      <div className="flex gap-1 mb-2">
                        <div className="h-6 w-6 rounded" style={{ backgroundColor: preset.theme.primaryColor }} />
                        <div className="h-6 w-6 rounded" style={{ backgroundColor: preset.theme.secondaryColor }} />
                        <div className="h-6 w-6 rounded" style={{ backgroundColor: preset.theme.accentColor }} />
                      </div>
                      <p className="text-sm font-medium">{preset.name}</p>
                      {selectedPreset === preset.name && <Check className="h-4 w-4 text-primary mt-1" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Custom Colors</CardTitle>
                <CardDescription>Fine-tune individual colors for your brand</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Primary Color</Label>
                    <div className="flex gap-2">
                      <Input
                        value={theme.primaryColor}
                        onChange={(e) => updateThemeColor('primaryColor', e.target.value)}
                      />
                      <div
                        className="h-10 w-10 rounded border shrink-0"
                        style={{ backgroundColor: theme.primaryColor }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Secondary Color</Label>
                    <div className="flex gap-2">
                      <Input
                        value={theme.secondaryColor}
                        onChange={(e) => updateThemeColor('secondaryColor', e.target.value)}
                      />
                      <div
                        className="h-10 w-10 rounded border shrink-0"
                        style={{ backgroundColor: theme.secondaryColor }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Accent Color</Label>
                    <div className="flex gap-2">
                      <Input
                        value={theme.accentColor}
                        onChange={(e) => updateThemeColor('accentColor', e.target.value)}
                      />
                      <div
                        className="h-10 w-10 rounded border shrink-0"
                        style={{ backgroundColor: theme.accentColor }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Background</Label>
                    <div className="flex gap-2">
                      <Input
                        value={theme.backgroundColor}
                        onChange={(e) => updateThemeColor('backgroundColor', e.target.value)}
                      />
                      <div
                        className="h-10 w-10 rounded border shrink-0"
                        style={{ backgroundColor: theme.backgroundColor }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Text Color</Label>
                    <div className="flex gap-2">
                      <Input value={theme.textColor} onChange={(e) => updateThemeColor('textColor', e.target.value)} />
                      <div className="h-10 w-10 rounded border shrink-0" style={{ backgroundColor: theme.textColor }} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="typography" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Font Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Heading Font</Label>
                    <Input value={theme.fontFamily} onChange={(e) => updateThemeColor('fontFamily', e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Body Font</Label>
                    <Input defaultValue="Inter" />
                  </div>
                </div>

                <div className="p-4 rounded-lg border">
                  <h4 className="text-lg font-semibold mb-2" style={{ fontFamily: theme.fontFamily }}>
                    Font Preview
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    The quick brown fox jumps over the lazy dog. 0123456789
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preview" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Live Preview</CardTitle>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Download className="h-4 w-4" />
                    Download Sample PDF
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div
                  className="rounded-lg p-8 min-h-[500px]"
                  style={{
                    backgroundColor: theme.backgroundColor,
                    color: theme.textColor,
                    fontFamily: theme.fontFamily,
                  }}
                >
                  <div
                    className="flex items-center justify-between border-b pb-4 mb-6"
                    style={{ borderColor: theme.accentColor + '40' }}
                  >
                    <div>
                      <h2 className="text-2xl font-bold" style={{ color: theme.primaryColor }}>
                        {companyName}
                      </h2>
                      <p className="text-sm opacity-70">{tagline}</p>
                    </div>
                    <div className="text-right text-sm opacity-70">
                      <p>Weekly Performance Report</p>
                      <p>December 1-7, 2024</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="p-4 rounded-lg" style={{ backgroundColor: theme.primaryColor + '10' }}>
                      <p className="text-sm opacity-70">Total Revenue</p>
                      <p className="text-2xl font-bold" style={{ color: theme.primaryColor }}>
                        $284.5K
                      </p>
                      <p className="text-xs" style={{ color: theme.accentColor }}>
                        +15% vs last week
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: theme.secondaryColor + '10' }}>
                      <p className="text-sm opacity-70">Blended ROAS</p>
                      <p className="text-2xl font-bold" style={{ color: theme.secondaryColor }}>
                        5.9x
                      </p>
                      <p className="text-xs" style={{ color: theme.accentColor }}>
                        +12% vs last week
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: theme.accentColor + '10' }}>
                      <p className="text-sm opacity-70">Orders</p>
                      <p className="text-2xl font-bold" style={{ color: theme.accentColor }}>
                        1,847
                      </p>
                      <p className="text-xs" style={{ color: theme.accentColor }}>
                        +8% vs last week
                      </p>
                    </div>
                  </div>

                  <div
                    className="p-4 rounded-lg mb-6"
                    style={{
                      backgroundColor: theme.primaryColor + '05',
                      borderLeft: `4px solid ${theme.primaryColor}`,
                    }}
                  >
                    <h3 className="font-semibold mb-2" style={{ color: theme.primaryColor }}>
                      Executive Summary
                    </h3>
                    <p className="text-sm opacity-80">
                      Strong performance across paid channels with ROAS improving by 12% YoY. Meta Ads continue as top
                      performer with 5.8x return.
                    </p>
                  </div>

                  <div
                    className="text-center pt-4 border-t text-xs opacity-50"
                    style={{ borderColor: theme.accentColor + '40' }}
                  >
                    {footerText}
                    {showPoweredBy && ' • Powered by Pogee Analytics'}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
