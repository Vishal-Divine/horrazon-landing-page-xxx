import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  GripVertical,
  Plus,
  Trash2,
  Eye,
  Download,
  Save,
  Layout,
  BarChart3,
  LineChart,
  PieChart,
  Table,
  DollarSign,
  TrendingUp,
  Users,
  ShoppingCart,
  Mail,
  Target,
  Percent,
  Calendar,
  Clock,
  Sparkles,
  Settings,
  Copy,
  Undo,
  Redo,
  ChevronRight,
  ChevronDown,
} from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface ReportWidget {
  id: string;
  name: string;
  type: 'metric' | 'chart' | 'table' | 'text';
  icon: any;
  category: string;
  size: 'sm' | 'md' | 'lg' | 'full';
  config?: Record<string, any>;
}

interface WidgetCategory {
  name: string;
  widgets: ReportWidget[];
  isOpen: boolean;
}

const widgetCategories: WidgetCategory[] = [
  {
    name: 'Key Metrics',
    isOpen: true,
    widgets: [
      { id: 'revenue', name: 'Revenue', type: 'metric', icon: DollarSign, category: 'metrics', size: 'sm' },
      { id: 'roas', name: 'ROAS', type: 'metric', icon: TrendingUp, category: 'metrics', size: 'sm' },
      { id: 'cac', name: 'Customer Acquisition Cost', type: 'metric', icon: Users, category: 'metrics', size: 'sm' },
      { id: 'ltv', name: 'Customer LTV', type: 'metric', icon: DollarSign, category: 'metrics', size: 'sm' },
      { id: 'orders', name: 'Total Orders', type: 'metric', icon: ShoppingCart, category: 'metrics', size: 'sm' },
      { id: 'aov', name: 'Average Order Value', type: 'metric', icon: ShoppingCart, category: 'metrics', size: 'sm' },
      { id: 'conversionRate', name: 'Conversion Rate', type: 'metric', icon: Percent, category: 'metrics', size: 'sm' },
      { id: 'newCustomers', name: 'New Customers', type: 'metric', icon: Users, category: 'metrics', size: 'sm' },
    ],
  },
  {
    name: 'Charts & Graphs',
    isOpen: true,
    widgets: [
      { id: 'revenueTrend', name: 'Revenue Trend', type: 'chart', icon: LineChart, category: 'charts', size: 'lg' },
      {
        id: 'channelBreakdown',
        name: 'Channel Breakdown',
        type: 'chart',
        icon: PieChart,
        category: 'charts',
        size: 'md',
      },
      { id: 'roasComparison', name: 'ROAS Comparison', type: 'chart', icon: BarChart3, category: 'charts', size: 'md' },
      {
        id: 'conversionFunnel',
        name: 'Conversion Funnel',
        type: 'chart',
        icon: BarChart3,
        category: 'charts',
        size: 'lg',
      },
      { id: 'cohortRetention', name: 'Cohort Retention', type: 'chart', icon: Table, category: 'charts', size: 'full' },
      {
        id: 'geoPerformance',
        name: 'Geographic Performance',
        type: 'chart',
        icon: BarChart3,
        category: 'charts',
        size: 'lg',
      },
    ],
  },
  {
    name: 'Tables & Data',
    isOpen: false,
    widgets: [
      { id: 'topProducts', name: 'Top Products', type: 'table', icon: Table, category: 'tables', size: 'lg' },
      { id: 'topCampaigns', name: 'Top Campaigns', type: 'table', icon: Table, category: 'tables', size: 'lg' },
      {
        id: 'channelMetrics',
        name: 'Channel Metrics Table',
        type: 'table',
        icon: Table,
        category: 'tables',
        size: 'full',
      },
      { id: 'audienceSegments', name: 'Audience Segments', type: 'table', icon: Table, category: 'tables', size: 'lg' },
    ],
  },
  {
    name: 'Email & Engagement',
    isOpen: false,
    widgets: [
      { id: 'emailMetrics', name: 'Email Performance', type: 'metric', icon: Mail, category: 'email', size: 'md' },
      { id: 'openRate', name: 'Open Rate Trend', type: 'chart', icon: LineChart, category: 'email', size: 'md' },
      { id: 'clickRate', name: 'Click Rate Trend', type: 'chart', icon: LineChart, category: 'email', size: 'md' },
      { id: 'topEmails', name: 'Top Performing Emails', type: 'table', icon: Table, category: 'email', size: 'lg' },
    ],
  },
  {
    name: 'Goals & Forecasts',
    isOpen: false,
    widgets: [
      { id: 'goalProgress', name: 'Goal Progress', type: 'chart', icon: Target, category: 'goals', size: 'md' },
      { id: 'forecast', name: 'Revenue Forecast', type: 'chart', icon: TrendingUp, category: 'goals', size: 'lg' },
      { id: 'quarterlyTargets', name: 'Quarterly Targets', type: 'table', icon: Table, category: 'goals', size: 'md' },
    ],
  },
];

interface ReportSection {
  id: string;
  name: string;
  widgets: string[];
  collapsed: boolean;
}

export function AdvancedReportBuilder() {
  const [categories, setCategories] = useState(widgetCategories);
  const [activeWidgets, setActiveWidgets] = useState<string[]>([
    'revenue',
    'roas',
    'orders',
    'revenueTrend',
    'channelBreakdown',
  ]);
  const [sections, setSections] = useState<ReportSection[]>([
    { id: 'summary', name: 'Executive Summary', widgets: ['revenue', 'roas', 'orders'], collapsed: false },
    {
      id: 'performance',
      name: 'Performance Analysis',
      widgets: ['revenueTrend', 'channelBreakdown'],
      collapsed: false,
    },
  ]);
  const [selectedWidget, setSelectedWidget] = useState<string | null>(null);
  const [reportName, setReportName] = useState('Weekly Business Report');
  const [dateRange, setDateRange] = useState('7d');
  const [comparison, setComparison] = useState('previous');

  const toggleCategory = (categoryName: string) => {
    setCategories(categories.map((cat) => (cat.name === categoryName ? { ...cat, isOpen: !cat.isOpen } : cat)));
  };

  const addWidget = (widgetId: string) => {
    if (!activeWidgets.includes(widgetId)) {
      setActiveWidgets([...activeWidgets, widgetId]);
      // Add to last section
      setSections(
        sections.map((section, idx) =>
          idx === sections.length - 1 ? { ...section, widgets: [...section.widgets, widgetId] } : section,
        ),
      );
    }
  };

  const removeWidget = (widgetId: string) => {
    setActiveWidgets(activeWidgets.filter((w) => w !== widgetId));
    setSections(
      sections.map((section) => ({
        ...section,
        widgets: section.widgets.filter((w) => w !== widgetId),
      })),
    );
  };

  const getWidgetById = (id: string): ReportWidget | undefined => {
    for (const cat of categories) {
      const widget = cat.widgets.find((w) => w.id === id);
      if (widget) return widget;
    }
    return undefined;
  };

  const addSection = () => {
    setSections([
      ...sections,
      {
        id: `section-${Date.now()}`,
        name: `Section ${sections.length + 1}`,
        widgets: [],
        collapsed: false,
      },
    ]);
  };

  return (
    <div className="space-y-6">
      <Card className="border-chart-1/20 bg-gradient-to-br from-chart-1/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/10">
                <Layout className="h-5 w-5 text-chart-1" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Advanced Report Builder
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Drag & Drop
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">Create custom reports with flexible layouts and widgets</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Undo className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Redo className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="gap-2">
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button variant="outline" className="gap-2">
                <Save className="h-4 w-4" />
                Save Draft
              </Button>
              <Button className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Widget Library */}
        <Card className="lg:col-span-1 max-h-[800px] overflow-y-auto">
          <CardHeader className="sticky top-0 bg-card z-10">
            <CardTitle className="text-base">Widget Library</CardTitle>
            <Input placeholder="Search widgets..." className="mt-2" />
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {categories.map((category) => (
              <Collapsible
                key={category.name}
                open={category.isOpen}
                onOpenChange={() => toggleCategory(category.name)}
              >
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between px-2 py-1 h-auto">
                    <span className="text-sm font-medium">{category.name}</span>
                    {category.isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-1 mt-1">
                  {category.widgets.map((widget) => {
                    const Icon = widget.icon;
                    const isActive = activeWidgets.includes(widget.id);
                    return (
                      <div
                        key={widget.id}
                        className={`flex items-center gap-2 p-2 rounded-lg border cursor-pointer transition-all ${
                          isActive
                            ? 'border-primary bg-primary/5'
                            : 'border-transparent hover:border-primary/50 hover:bg-muted/30'
                        }`}
                        onClick={() => (isActive ? removeWidget(widget.id) : addWidget(widget.id))}
                      >
                        <GripVertical className="h-3 w-3 text-muted-foreground" />
                        <Icon className="h-3.5 w-3.5" />
                        <span className="flex-1 text-xs">{widget.name}</span>
                        <Badge variant="outline" className="text-[10px] px-1 py-0">
                          {widget.size}
                        </Badge>
                      </div>
                    );
                  })}
                </CollapsibleContent>
              </Collapsible>
            ))}
          </CardContent>
        </Card>

        {/* Report Canvas */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex-1 mr-4">
                <Input
                  value={reportName}
                  onChange={(e) => setReportName(e.target.value)}
                  className="text-lg font-semibold border-none px-0 h-auto focus-visible:ring-0"
                />
              </div>
              <div className="flex items-center gap-2">
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-32">
                    <Calendar className="h-3 w-3 mr-1" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">Last 7 Days</SelectItem>
                    <SelectItem value="14d">Last 14 Days</SelectItem>
                    <SelectItem value="30d">Last 30 Days</SelectItem>
                    <SelectItem value="90d">Last Quarter</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={comparison} onValueChange={setComparison}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="previous">vs Previous Period</SelectItem>
                    <SelectItem value="lastyear">vs Last Year</SelectItem>
                    <SelectItem value="none">No Comparison</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {sections.map((section) => (
              <div key={section.id} className="rounded-lg border p-4">
                <div className="flex items-center justify-between mb-3">
                  <Input
                    value={section.name}
                    onChange={(e) =>
                      setSections(sections.map((s) => (s.id === section.id ? { ...s, name: e.target.value } : s)))
                    }
                    className="font-semibold border-none px-0 h-auto focus-visible:ring-0 max-w-xs"
                  />
                  <Button variant="ghost" size="sm">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>

                <div className="grid grid-cols-4 gap-3">
                  {section.widgets.map((widgetId) => {
                    const widget = getWidgetById(widgetId);
                    if (!widget) return null;
                    const Icon = widget.icon;
                    const colSpan =
                      widget.size === 'full'
                        ? 'col-span-4'
                        : widget.size === 'lg'
                          ? 'col-span-2'
                          : widget.size === 'md'
                            ? 'col-span-2'
                            : 'col-span-1';

                    return (
                      <div
                        key={widgetId}
                        className={`${colSpan} p-3 rounded border bg-muted/30 cursor-pointer transition-all hover:border-primary ${selectedWidget === widgetId ? 'border-primary ring-1 ring-primary' : ''}`}
                        onClick={() => setSelectedWidget(widgetId)}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4" />
                            <span className="text-sm font-medium">{widget.name}</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeWidget(widgetId);
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>

                        {widget.type === 'metric' && (
                          <div className="bg-background rounded p-2">
                            <p className="text-2xl font-bold">$284.5K</p>
                            <p className="text-xs text-success">+15% vs prev</p>
                          </div>
                        )}

                        {widget.type === 'chart' && (
                          <div className="bg-background rounded p-2 h-24 flex items-center justify-center">
                            <Icon className="h-8 w-8 text-muted-foreground/50" />
                          </div>
                        )}

                        {widget.type === 'table' && (
                          <div className="bg-background rounded p-2 h-24 flex items-center justify-center">
                            <Table className="h-8 w-8 text-muted-foreground/50" />
                          </div>
                        )}
                      </div>
                    );
                  })}

                  <div
                    className="col-span-1 p-3 rounded border border-dashed flex items-center justify-center cursor-pointer hover:border-primary hover:bg-muted/30 transition-all min-h-[80px]"
                    onClick={() => {
                      /* Open widget selector */
                    }}
                  >
                    <Plus className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              </div>
            ))}

            <Button variant="outline" className="w-full gap-2" onClick={addSection}>
              <Plus className="h-4 w-4" />
              Add Section
            </Button>
          </CardContent>
        </Card>

        {/* Widget Configuration */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Widget Settings</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedWidget ? (
              <div className="space-y-4">
                {(() => {
                  const widget = getWidgetById(selectedWidget);
                  if (!widget) return null;
                  return (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                        <widget.icon className="h-4 w-4" />
                        <span className="font-medium">{widget.name}</span>
                      </div>

                      <div className="space-y-2">
                        <Label>Display Size</Label>
                        <Select defaultValue={widget.size}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sm">Small (1/4)</SelectItem>
                            <SelectItem value="md">Medium (1/2)</SelectItem>
                            <SelectItem value="lg">Large (1/2)</SelectItem>
                            <SelectItem value="full">Full Width</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Title Override</Label>
                        <Input placeholder="Custom title..." />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label>Show Comparison</Label>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label>Show Sparkline</Label>
                        <Switch defaultChecked />
                      </div>

                      {widget.type === 'chart' && (
                        <>
                          <div className="space-y-2">
                            <Label>Chart Type</Label>
                            <Select defaultValue="line">
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="line">Line Chart</SelectItem>
                                <SelectItem value="bar">Bar Chart</SelectItem>
                                <SelectItem value="area">Area Chart</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="flex items-center justify-between">
                            <Label>Show Legend</Label>
                            <Switch defaultChecked />
                          </div>

                          <div className="flex items-center justify-between">
                            <Label>Show Grid</Label>
                            <Switch defaultChecked />
                          </div>
                        </>
                      )}

                      <Button variant="outline" className="w-full gap-2">
                        <Copy className="h-4 w-4" />
                        Duplicate Widget
                      </Button>
                    </>
                  );
                })()}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Select a widget to configure</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
