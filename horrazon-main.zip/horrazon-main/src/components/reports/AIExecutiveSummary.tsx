import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Brain,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  Target,
  DollarSign,
  Users,
  BarChart3,
  ArrowRight,
  Zap,
  RefreshCcw,
  Eye,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from 'recharts';

interface ExecutiveInsight {
  id: string;
  title: string;
  summary: string;
  impact: 'high' | 'medium' | 'low';
  category: 'revenue' | 'efficiency' | 'growth' | 'risk';
  metric: string;
  change: number;
  recommendation: string;
  confidence: number;
  dataPoints: number;
}

interface PerformanceAnomaly {
  id: string;
  metric: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: 'critical' | 'warning' | 'info';
  explanation: string;
  suggestedAction: string;
}

const mockInsights: ExecutiveInsight[] = [
  {
    id: '1',
    title: 'Revenue Surge in Email Channel',
    summary:
      'Email revenue increased 47% this week, driven by the holiday campaign series. This represents the highest single-week email performance in Q4.',
    impact: 'high',
    category: 'revenue',
    metric: '$128.4K Revenue',
    change: 47,
    recommendation: 'Extend the campaign series through December and increase send frequency to high-value segments.',
    confidence: 94,
    dataPoints: 12400,
  },
  {
    id: '2',
    title: 'Meta Ads ROAS Declining',
    summary:
      'ROAS on Meta Ads dropped from 5.8x to 4.2x over the past 14 days. CPM increased 28% due to holiday competition.',
    impact: 'high',
    category: 'efficiency',
    metric: '4.2x ROAS',
    change: -28,
    recommendation:
      'Shift 20% of Meta budget to TikTok where CPMs are 40% lower this week. Consider pausing underperforming ad sets.',
    confidence: 89,
    dataPoints: 8200,
  },
  {
    id: '3',
    title: 'Customer Acquisition Cost Optimized',
    summary:
      'CAC reduced by 18% through improved audience targeting and creative refresh. Current CAC is 24% below industry benchmark.',
    impact: 'medium',
    category: 'efficiency',
    metric: '$42.80 CAC',
    change: -18,
    recommendation: 'Document winning creative elements for future campaigns. Consider scaling successful audiences.',
    confidence: 92,
    dataPoints: 5600,
  },
  {
    id: '4',
    title: 'New Customer Segment Emerging',
    summary:
      'Identified a growing segment of 35-44 professionals with 2.4x higher LTV than average. This segment grew 34% month-over-month.',
    impact: 'medium',
    category: 'growth',
    metric: '+34% Segment Growth',
    change: 34,
    recommendation:
      'Create dedicated campaign targeting this segment. Develop lookalike audiences based on high-LTV customers.',
    confidence: 86,
    dataPoints: 3200,
  },
  {
    id: '5',
    title: 'Churn Risk Detected',
    summary: '248 high-value customers showing disengagement signals. Combined LTV at risk is approximately $186K.',
    impact: 'high',
    category: 'risk',
    metric: '$186K At Risk',
    change: -12,
    recommendation:
      'Deploy win-back email sequence immediately. Consider personalized offers for top 50 at-risk accounts.',
    confidence: 91,
    dataPoints: 248,
  },
];

const mockAnomalies: PerformanceAnomaly[] = [
  {
    id: '1',
    metric: 'Conversion Rate',
    expectedValue: 3.2,
    actualValue: 4.8,
    deviation: 50,
    severity: 'info',
    explanation: 'Holiday promotional pricing driving higher conversion. +50% above baseline.',
    suggestedAction: 'Monitor for sustainability post-promotion',
  },
  {
    id: '2',
    metric: 'Cart Abandonment',
    expectedValue: 68,
    actualValue: 78,
    deviation: 15,
    severity: 'warning',
    explanation: 'Shipping cost display issue on checkout page affecting mobile users.',
    suggestedAction: 'Review checkout UX on mobile devices',
  },
  {
    id: '3',
    metric: 'Google Ads CTR',
    expectedValue: 2.8,
    actualValue: 1.9,
    deviation: -32,
    severity: 'critical',
    explanation: 'Ad fatigue detected on top 3 campaigns running over 45 days.',
    suggestedAction: 'Refresh creatives and ad copy immediately',
  },
];

const weeklyTrendData = [
  { week: 'W1', revenue: 218000, projected: 215000, lastYear: 185000 },
  { week: 'W2', revenue: 232000, projected: 225000, lastYear: 192000 },
  { week: 'W3', revenue: 248000, projected: 240000, lastYear: 208000 },
  { week: 'W4', revenue: 284500, projected: 255000, lastYear: 224000 },
];

const channelPerformance = [
  { channel: 'Meta Ads', revenue: 142000, spend: 24000, roas: 5.9, change: 12 },
  { channel: 'Google Ads', revenue: 98000, spend: 18000, roas: 5.4, change: -8 },
  { channel: 'Email', revenue: 44000, spend: 2400, roas: 18.3, change: 47 },
  { channel: 'TikTok', revenue: 28000, spend: 6200, roas: 4.5, change: 24 },
  { channel: 'Organic', revenue: 62000, spend: 0, roas: 0, change: 8 },
];

export function AIExecutiveSummary() {
  const [timeframe, setTimeframe] = useState('7d');
  const [refreshing, setRefreshing] = useState(false);
  const [feedbackGiven, setFeedbackGiven] = useState<string[]>([]);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 2000);
  };

  const handleFeedback = (insightId: string, positive: boolean) => {
    setFeedbackGiven([...feedbackGiven, insightId]);
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'bg-destructive/10 text-destructive';
      case 'medium':
        return 'bg-warning/10 text-warning';
      case 'low':
        return 'bg-muted text-muted-foreground';
      default:
        return '';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'revenue':
        return <DollarSign className="h-4 w-4" />;
      case 'efficiency':
        return <Zap className="h-4 w-4" />;
      case 'growth':
        return <TrendingUp className="h-4 w-4" />;
      case 'risk':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <BarChart3 className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  AI Executive Summary
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Auto-Generated
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Intelligent insights extracted from{' '}
                  {mockInsights.reduce((sum, i) => sum + i.dataPoints, 0).toLocaleString()} data points
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="14d">Last 14 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                  <SelectItem value="90d">Last Quarter</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2" onClick={handleRefresh}>
                <RefreshCcw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                Regenerate
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Key Insights</p>
                <p className="text-3xl font-bold">{mockInsights.length}</p>
              </div>
              <Lightbulb className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {mockInsights.filter((i) => i.impact === 'high').length} high priority
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Anomalies Detected</p>
                <p className="text-3xl font-bold">{mockAnomalies.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-warning" />
            </div>
            <p className="mt-2 text-xs text-warning">
              {mockAnomalies.filter((a) => a.severity === 'critical').length} critical
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue vs Target</p>
                <p className="text-3xl font-bold text-success">+12%</p>
              </div>
              <Target className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">$284.5K vs $254K target</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">AI Confidence</p>
                <p className="text-3xl font-bold">91%</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-chart-2" />
            </div>
            <Progress value={91} className="mt-2 h-1.5" />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="insights" className="space-y-4">
        <TabsList>
          <TabsTrigger value="insights" className="gap-2">
            <Lightbulb className="h-4 w-4" />
            Key Insights
          </TabsTrigger>
          <TabsTrigger value="anomalies" className="gap-2">
            <AlertTriangle className="h-4 w-4" />
            Anomaly Detection
          </TabsTrigger>
          <TabsTrigger value="trends" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Trend Analysis
          </TabsTrigger>
          <TabsTrigger value="channels" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Channel Deep Dive
          </TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-4">
          {mockInsights.map((insight) => (
            <Card key={insight.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex">
                  <div
                    className={`w-1 ${
                      insight.category === 'revenue'
                        ? 'bg-success'
                        : insight.category === 'efficiency'
                          ? 'bg-chart-2'
                          : insight.category === 'growth'
                            ? 'bg-chart-1'
                            : 'bg-destructive'
                    }`}
                  />
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <div
                            className={`flex h-6 w-6 items-center justify-center rounded ${
                              insight.category === 'revenue'
                                ? 'bg-success/10 text-success'
                                : insight.category === 'efficiency'
                                  ? 'bg-chart-2/10 text-chart-2'
                                  : insight.category === 'growth'
                                    ? 'bg-chart-1/10 text-chart-1'
                                    : 'bg-destructive/10 text-destructive'
                            }`}
                          >
                            {getCategoryIcon(insight.category)}
                          </div>
                          <h4 className="font-semibold">{insight.title}</h4>
                          <Badge className={getImpactColor(insight.impact)}>{insight.impact} impact</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{insight.summary}</p>

                        <div className="flex items-center gap-6 mb-3">
                          <div>
                            <p className="text-xs text-muted-foreground">Key Metric</p>
                            <p className="font-bold">{insight.metric}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Change</p>
                            <p
                              className={`font-bold flex items-center gap-1 ${insight.change >= 0 ? 'text-success' : 'text-destructive'}`}
                            >
                              {insight.change >= 0 ? (
                                <TrendingUp className="h-3 w-3" />
                              ) : (
                                <TrendingDown className="h-3 w-3" />
                              )}
                              {insight.change >= 0 ? '+' : ''}
                              {insight.change}%
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Confidence</p>
                            <p className="font-bold">{insight.confidence}%</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Data Points</p>
                            <p className="font-bold">{insight.dataPoints.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="rounded-lg border border-chart-3/20 bg-chart-3/5 p-3">
                          <div className="flex items-start gap-2">
                            <Lightbulb className="h-4 w-4 text-chart-3 mt-0.5" />
                            <div>
                              <p className="text-sm font-medium">AI Recommendation</p>
                              <p className="text-sm text-muted-foreground">{insight.recommendation}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2">
                        <Button size="sm" className="gap-1">
                          Take Action
                          <ArrowRight className="h-3 w-3" />
                        </Button>
                        {!feedbackGiven.includes(insight.id) && (
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0"
                              onClick={() => handleFeedback(insight.id, true)}
                            >
                              <ThumbsUp className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0"
                              onClick={() => handleFeedback(insight.id, false)}
                            >
                              <ThumbsDown className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                        {feedbackGiven.includes(insight.id) && (
                          <p className="text-xs text-muted-foreground text-center">Thanks!</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="anomalies" className="space-y-4">
          {mockAnomalies.map((anomaly) => (
            <Card
              key={anomaly.id}
              className={`border-l-4 ${
                anomaly.severity === 'critical'
                  ? 'border-l-destructive'
                  : anomaly.severity === 'warning'
                    ? 'border-l-warning'
                    : 'border-l-chart-1'
              }`}
            >
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge
                        variant="outline"
                        className={
                          anomaly.severity === 'critical'
                            ? 'border-destructive text-destructive'
                            : anomaly.severity === 'warning'
                              ? 'border-warning text-warning'
                              : 'border-chart-1 text-chart-1'
                        }
                      >
                        {anomaly.severity}
                      </Badge>
                      <h4 className="font-semibold">{anomaly.metric}</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{anomaly.explanation}</p>

                    <div className="flex items-center gap-6 text-sm">
                      <div>
                        <span className="text-muted-foreground">Expected: </span>
                        <span className="font-medium">{anomaly.expectedValue}%</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Actual: </span>
                        <span className="font-medium">{anomaly.actualValue}%</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Deviation: </span>
                        <span className={`font-bold ${anomaly.deviation >= 0 ? 'text-success' : 'text-destructive'}`}>
                          {anomaly.deviation >= 0 ? '+' : ''}
                          {anomaly.deviation}%
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-xs text-muted-foreground mb-1">Suggested Action</p>
                    <p className="text-sm font-medium max-w-xs">{anomaly.suggestedAction}</p>
                    <Button size="sm" className="mt-2">
                      Investigate
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Weekly Revenue Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={weeklyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                    formatter={(value: number) => `$${(value / 1000).toFixed(0)}K`}
                  />
                  <Area
                    type="monotone"
                    dataKey="lastYear"
                    stroke="hsl(var(--muted-foreground))"
                    fill="hsl(var(--muted))"
                    fillOpacity={0.3}
                    name="Last Year"
                  />
                  <Area
                    type="monotone"
                    dataKey="projected"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.2}
                    strokeDasharray="5 5"
                    name="Projected"
                  />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                    name="Actual Revenue"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="channels" className="space-y-4">
          <div className="grid gap-4">
            {channelPerformance.map((channel) => (
              <Card key={channel.channel}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-32">
                        <p className="font-semibold">{channel.channel}</p>
                      </div>
                      <div className="w-24 text-right">
                        <p className="text-sm text-muted-foreground">Revenue</p>
                        <p className="font-bold">${(channel.revenue / 1000).toFixed(0)}K</p>
                      </div>
                      <div className="w-20 text-right">
                        <p className="text-sm text-muted-foreground">Spend</p>
                        <p className="font-medium">${(channel.spend / 1000).toFixed(1)}K</p>
                      </div>
                      <div className="w-20 text-right">
                        <p className="text-sm text-muted-foreground">ROAS</p>
                        <p className="font-bold">{channel.roas > 0 ? `${channel.roas}x` : '∞'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32">
                        <Progress value={Math.min((channel.revenue / 150000) * 100, 100)} className="h-2" />
                      </div>
                      <Badge
                        className={
                          channel.change >= 0 ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                        }
                      >
                        {channel.change >= 0 ? '+' : ''}
                        {channel.change}%
                      </Badge>
                      <Button size="sm" variant="outline">
                        Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
