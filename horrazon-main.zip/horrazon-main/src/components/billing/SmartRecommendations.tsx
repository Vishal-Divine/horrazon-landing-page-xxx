import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Sparkles,
  ArrowRight,
  DollarSign,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Zap,
  Target,
  Clock,
  RefreshCw,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/contexts/AppContext';

interface Recommendation {
  id: string;
  type: 'savings' | 'optimization' | 'upgrade' | 'alert';
  title: string;
  description: string;
  potentialSavings?: number;
  effort: 'low' | 'medium' | 'high';
  action: string;
  priority: number;
}

export default function SmartRecommendations() {
  const { wallet, campaignSpends } = useApp();

  // Generate smart recommendations based on data analysis
  const generateRecommendations = (): Recommendation[] => {
    const recs: Recommendation[] = [];

    // Auto-recharge recommendation
    if (!wallet.autoRechargeEnabled) {
      recs.push({
        id: 'auto-recharge',
        type: 'optimization',
        title: 'Enable Auto-Recharge',
        description: 'Prevent campaign interruptions by automatically adding funds when balance is low.',
        effort: 'low',
        action: 'Enable Now',
        priority: 1,
      });
    }

    // Annual billing savings
    recs.push({
      id: 'annual-billing',
      type: 'savings',
      title: 'Switch to Annual Billing',
      description: 'Save 20% on your subscription by switching from monthly to annual billing.',
      potentialSavings: 720,
      effort: 'low',
      action: 'Upgrade Plan',
      priority: 2,
    });

    // Budget optimization
    const lowPerformingCampaigns = campaignSpends.filter(
      (c) => c.status === 'active' && c.spent / c.budget < 0.5 && c.daysRemaining < 10,
    );
    if (lowPerformingCampaigns.length > 0) {
      recs.push({
        id: 'budget-reallocation',
        type: 'optimization',
        title: 'Reallocate Underutilized Budget',
        description: `${lowPerformingCampaigns.length} campaign(s) have unused budget. Consider reallocating to high-performers.`,
        potentialSavings: lowPerformingCampaigns.reduce((sum, c) => sum + (c.budget - c.spent), 0) * 0.3,
        effort: 'medium',
        action: 'Review Campaigns',
        priority: 3,
      });
    }

    // Platform consolidation
    const platforms = [...new Set(campaignSpends.map((c) => c.platform))];
    if (platforms.length > 3) {
      recs.push({
        id: 'consolidate-platforms',
        type: 'savings',
        title: 'Consolidate Ad Platforms',
        description:
          'Running ads across many platforms increases management overhead. Consider focusing on top performers.',
        potentialSavings: wallet.monthlySpent * 0.1,
        effort: 'high',
        action: 'Analyze Platforms',
        priority: 4,
      });
    }

    // Invoice optimization
    recs.push({
      id: 'bulk-prepay',
      type: 'savings',
      title: 'Bulk Prepay for Discounts',
      description: 'Add $10,000+ at once to receive volume discounts on transaction fees.',
      potentialSavings: 250,
      effort: 'low',
      action: 'Add Funds',
      priority: 5,
    });

    return recs.sort((a, b) => a.priority - b.priority);
  };

  const recommendations = generateRecommendations();
  const totalPotentialSavings = recommendations.reduce((sum, r) => sum + (r.potentialSavings || 0), 0);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'savings':
        return DollarSign;
      case 'optimization':
        return Zap;
      case 'upgrade':
        return TrendingDown;
      case 'alert':
        return AlertTriangle;
      default:
        return Lightbulb;
    }
  };

  const getTypeColors = (type: string) => {
    switch (type) {
      case 'savings':
        return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
      case 'optimization':
        return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'upgrade':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'alert':
        return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getEffortBadge = (effort: string) => {
    switch (effort) {
      case 'low':
        return 'bg-emerald-500/10 text-emerald-500';
      case 'medium':
        return 'bg-amber-500/10 text-amber-500';
      case 'high':
        return 'bg-destructive/10 text-destructive';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-1.5 rounded-lg bg-gradient-to-br from-primary/20 to-chart-2/20">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              Smart Recommendations
            </CardTitle>
            <CardDescription>AI-powered suggestions to optimize your billing</CardDescription>
          </div>
          {totalPotentialSavings > 0 && (
            <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 gap-1">
              <DollarSign className="h-3 w-3" />${totalPotentialSavings.toLocaleString()} potential savings
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {recommendations.slice(0, 4).map((rec) => {
          const Icon = getTypeIcon(rec.type);

          return (
            <div
              key={rec.id}
              className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/30 transition-all"
            >
              <div className={cn('p-2 rounded-lg shrink-0', getTypeColors(rec.type))}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-medium text-sm">{rec.title}</p>
                  <Badge variant="outline" className={cn('text-[9px] px-1.5 py-0', getEffortBadge(rec.effort))}>
                    {rec.effort} effort
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{rec.description}</p>
                {rec.potentialSavings && (
                  <p className="text-[10px] text-emerald-500 mt-1 flex items-center gap-1">
                    <TrendingDown className="h-2.5 w-2.5" />
                    Save up to ${rec.potentialSavings.toLocaleString()}/year
                  </p>
                )}
              </div>
              <Button variant="ghost" size="sm" className="shrink-0 h-7 text-xs gap-1">
                {rec.action}
                <ArrowRight className="h-3 w-3" />
              </Button>
            </div>
          );
        })}

        {/* Summary Footer */}
        <div className="flex items-center justify-between pt-3 border-t">
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Target className="h-3 w-3" />
              {recommendations.length} recommendations
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              Updated today
            </span>
          </div>
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <RefreshCw className="h-3 w-3" />
            Refresh
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
