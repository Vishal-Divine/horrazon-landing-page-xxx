import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, ArrowUpRight, DollarSign, Calendar, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell } from 'recharts';
import { cn } from '@/lib/utils';

interface ComparisonData {
  month: string;
  thisYear: number;
  lastYear: number;
  growth: number;
}

const comparisonData: ComparisonData[] = [
  { month: 'Jul', thisYear: 4200, lastYear: 3800, growth: 10.5 },
  { month: 'Aug', thisYear: 4800, lastYear: 4100, growth: 17.1 },
  { month: 'Sep', thisYear: 5100, lastYear: 4500, growth: 13.3 },
  { month: 'Oct', thisYear: 5800, lastYear: 4900, growth: 18.4 },
  { month: 'Nov', thisYear: 6200, lastYear: 5200, growth: 19.2 },
  { month: 'Dec', thisYear: 8240, lastYear: 5800, growth: 42.1 },
];

interface CostComparisonChartProps {
  onViewDetails?: () => void;
}

export default function CostComparisonChart({ onViewDetails }: CostComparisonChartProps) {
  const totalThisYear = comparisonData.reduce((sum, d) => sum + d.thisYear, 0);
  const totalLastYear = comparisonData.reduce((sum, d) => sum + d.lastYear, 0);
  const overallGrowth = ((totalThisYear - totalLastYear) / totalLastYear) * 100;
  const avgMonthlyGrowth = comparisonData.reduce((sum, d) => sum + d.growth, 0) / comparisonData.length;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-1.5 rounded-lg bg-chart-1/10">
                <BarChart3 className="h-4 w-4 text-chart-1" />
              </div>
              Cost Comparison
            </CardTitle>
            <CardDescription>Year-over-year spending analysis</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant="outline"
              className={
                overallGrowth > 0 ? 'text-chart-3 border-chart-3/30' : 'text-emerald-500 border-emerald-500/30'
              }
            >
              {overallGrowth > 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {overallGrowth > 0 ? '+' : ''}
              {overallGrowth.toFixed(1)}% YoY
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
            <div className="flex items-center gap-1.5 mb-1">
              <Calendar className="h-3 w-3 text-muted-foreground" />
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">This Year</p>
            </div>
            <p className="text-lg font-bold text-primary">{formatCurrency(totalThisYear)}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/50">
            <div className="flex items-center gap-1.5 mb-1">
              <Calendar className="h-3 w-3 text-muted-foreground" />
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Last Year</p>
            </div>
            <p className="text-lg font-bold">{formatCurrency(totalLastYear)}</p>
          </div>
          <div className="p-3 rounded-lg bg-chart-3/5 border border-chart-3/10">
            <div className="flex items-center gap-1.5 mb-1">
              <TrendingUp className="h-3 w-3 text-muted-foreground" />
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Avg Growth</p>
            </div>
            <p className="text-lg font-bold text-chart-3">+{avgMonthlyGrowth.toFixed(1)}%</p>
          </div>
        </div>

        {/* Chart */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonData} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
              <XAxis
                dataKey="month"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                axisLine={{ stroke: 'hsl(var(--border))' }}
              />
              <YAxis
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                axisLine={{ stroke: 'hsl(var(--border))' }}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => [
                  formatCurrency(value),
                  name === 'thisYear' ? '2024' : '2023',
                ]}
                labelFormatter={(label) => `${label} 2024`}
              />
              <Legend
                formatter={(value) => (value === 'thisYear' ? '2024' : '2023')}
                wrapperStyle={{ fontSize: '12px' }}
              />
              <Bar
                dataKey="lastYear"
                name="lastYear"
                fill="hsl(var(--muted-foreground))"
                radius={[4, 4, 0, 0]}
                opacity={0.4}
              />
              <Bar dataKey="thisYear" name="thisYear" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Growth Breakdown */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Monthly Growth Rate</p>
          <div className="flex gap-1">
            {comparisonData.map((d, i) => (
              <div key={d.month} className="flex-1 text-center">
                <div
                  className={cn(
                    'h-8 rounded-sm flex items-end justify-center mb-1',
                    d.growth > 20 ? 'bg-chart-3/20' : d.growth > 10 ? 'bg-chart-2/20' : 'bg-primary/20',
                  )}
                  style={{ paddingBottom: `${Math.min(d.growth, 50)}%` }}
                >
                  <span className="text-[9px] font-medium">+{d.growth.toFixed(0)}%</span>
                </div>
                <p className="text-[9px] text-muted-foreground">{d.month}</p>
              </div>
            ))}
          </div>
        </div>

        <Button variant="outline" className="w-full gap-2" onClick={onViewDetails}>
          View Detailed Report
          <ArrowUpRight className="h-3.5 w-3.5" />
        </Button>
      </CardContent>
    </Card>
  );
}
