import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { TrendingUp, TrendingDown, Calendar, DollarSign, Target, Zap } from 'lucide-react';
import { format, subDays, subWeeks, subMonths } from 'date-fns';

// Generate mock daily spend data
const generateDailyData = () => {
  const data = [];
  for (let i = 29; i >= 0; i--) {
    const date = subDays(new Date(), i);
    const baseSpend = 800 + Math.random() * 400;
    data.push({
      date: format(date, 'MMM d'),
      fullDate: date,
      spend: Math.round(baseSpend),
      budget: 1000,
      google: Math.round(baseSpend * 0.45),
      meta: Math.round(baseSpend * 0.35),
      tiktok: Math.round(baseSpend * 0.2),
    });
  }
  return data;
};

// Generate mock weekly data
const generateWeeklyData = () => {
  const data = [];
  for (let i = 11; i >= 0; i--) {
    const date = subWeeks(new Date(), i);
    const baseSpend = 5500 + Math.random() * 2000;
    data.push({
      date: `Week ${12 - i}`,
      fullDate: date,
      spend: Math.round(baseSpend),
      budget: 7000,
      conversions: Math.round(50 + Math.random() * 30),
      cpa: Math.round(baseSpend / (50 + Math.random() * 30)),
    });
  }
  return data;
};

// Generate mock monthly data
const generateMonthlyData = () => {
  const data = [];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  for (let i = 0; i < 12; i++) {
    const baseSpend = 20000 + Math.random() * 10000;
    const roas = 2 + Math.random() * 2;
    data.push({
      date: months[i],
      spend: Math.round(baseSpend),
      revenue: Math.round(baseSpend * roas),
      profit: Math.round(baseSpend * (roas - 1)),
      roas: parseFloat(roas.toFixed(2)),
    });
  }
  return data;
};

// Campaign performance data
const campaignData = [
  { name: 'Google Ads', spend: 12500, conversions: 234, cpa: 53.42, roas: 3.2, trend: 12 },
  { name: 'Meta Ads', spend: 9800, conversions: 189, cpa: 51.85, roas: 2.8, trend: -5 },
  { name: 'TikTok Ads', spend: 5200, conversions: 98, cpa: 53.06, roas: 2.1, trend: 28 },
  { name: 'LinkedIn Ads', spend: 3100, conversions: 45, cpa: 68.89, roas: 1.9, trend: 8 },
];

// Platform distribution for pie chart
const platformDistribution = [
  { name: 'Google Ads', value: 45, color: 'hsl(var(--chart-1))' },
  { name: 'Meta Ads', value: 32, color: 'hsl(var(--chart-2))' },
  { name: 'TikTok Ads', value: 15, color: 'hsl(var(--chart-3))' },
  { name: 'LinkedIn Ads', value: 8, color: 'hsl(var(--chart-4))' },
];

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
        <p className="font-medium text-sm mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm flex items-center gap-2">
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-medium">
              {entry.name.toLowerCase().includes('roas') ? `${entry.value}x` : formatCurrency(entry.value)}
            </span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function UsageAnalytics() {
  const [timeRange, setTimeRange] = useState('daily');
  const dailyData = generateDailyData();
  const weeklyData = generateWeeklyData();
  const monthlyData = generateMonthlyData();

  // Calculate summary stats
  const totalSpend = dailyData.reduce((sum, d) => sum + d.spend, 0);
  const avgDailySpend = totalSpend / dailyData.length;
  const spendTrend = ((dailyData[dailyData.length - 1].spend - dailyData[0].spend) / dailyData[0].spend) * 100;

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">30-Day Spend</p>
                <p className="text-2xl font-bold">{formatCurrency(totalSpend)}</p>
              </div>
              <div className="p-2 rounded-lg bg-chart-1/10">
                <DollarSign className="h-5 w-5 text-chart-1" />
              </div>
            </div>
            <div className="mt-2 flex items-center gap-1 text-xs">
              {spendTrend > 0 ? (
                <TrendingUp className="h-3 w-3 text-success" />
              ) : (
                <TrendingDown className="h-3 w-3 text-destructive" />
              )}
              <span className={spendTrend > 0 ? 'text-success' : 'text-destructive'}>
                {Math.abs(spendTrend).toFixed(1)}%
              </span>
              <span className="text-muted-foreground">vs last period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Avg Daily Spend</p>
                <p className="text-2xl font-bold">{formatCurrency(avgDailySpend)}</p>
              </div>
              <div className="p-2 rounded-lg bg-chart-2/10">
                <Calendar className="h-5 w-5 text-chart-2" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Budget: {formatCurrency(1000)}/day</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Conversions</p>
                <p className="text-2xl font-bold">566</p>
              </div>
              <div className="p-2 rounded-lg bg-chart-3/10">
                <Target className="h-5 w-5 text-chart-3" />
              </div>
            </div>
            <div className="mt-2 flex items-center gap-1 text-xs">
              <TrendingUp className="h-3 w-3 text-success" />
              <span className="text-success">18%</span>
              <span className="text-muted-foreground">improvement</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Avg ROAS</p>
                <p className="text-2xl font-bold">2.8x</p>
              </div>
              <div className="p-2 rounded-lg bg-chart-4/10">
                <Zap className="h-5 w-5 text-chart-4" />
              </div>
            </div>
            <div className="mt-2 flex items-center gap-1 text-xs">
              <TrendingUp className="h-3 w-3 text-success" />
              <span className="text-success">0.3x</span>
              <span className="text-muted-foreground">vs target</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Spend Trends Chart */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-lg">Spend Trends</CardTitle>
            <CardDescription>Track your advertising spend over time</CardDescription>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              {timeRange === 'daily' ? (
                <AreaChart data={dailyData}>
                  <defs>
                    <linearGradient id="spendGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="spend"
                    name="Spend"
                    stroke="hsl(var(--chart-1))"
                    fill="url(#spendGradient)"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="budget"
                    name="Budget"
                    stroke="hsl(var(--muted-foreground))"
                    strokeDasharray="5 5"
                    strokeWidth={2}
                    dot={false}
                  />
                </AreaChart>
              ) : timeRange === 'weekly' ? (
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="spend" name="Spend" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  <Line
                    type="monotone"
                    dataKey="budget"
                    name="Budget"
                    stroke="hsl(var(--muted-foreground))"
                    strokeDasharray="5 5"
                    strokeWidth={2}
                    dot={false}
                  />
                </BarChart>
              ) : (
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="spend"
                    name="Spend"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    name="Revenue"
                    stroke="hsl(var(--chart-2))"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="profit"
                    name="Profit"
                    stroke="hsl(var(--chart-3))"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              )}
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Platform Breakdown & Campaign Performance */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Platform Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Platform Distribution</CardTitle>
            <CardDescription>Spend breakdown by advertising platform</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="h-[200px] w-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={platformDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {platformDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-popover border border-border rounded-lg p-2 shadow-lg">
                              <p className="font-medium text-sm">{data.name}</p>
                              <p className="text-sm text-muted-foreground">{data.value}% of spend</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-3">
                {platformDistribution.map((platform) => (
                  <div key={platform.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: platform.color }} />
                      <span className="text-sm">{platform.name}</span>
                    </div>
                    <span className="font-medium">{platform.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Campaign Performance</CardTitle>
            <CardDescription>Key metrics by platform</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaignData.map((campaign) => (
                <div key={campaign.name} className="p-3 rounded-lg bg-muted/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{campaign.name}</span>
                    <Badge variant={campaign.trend > 0 ? 'default' : 'destructive'} className="text-xs">
                      {campaign.trend > 0 ? '+' : ''}
                      {campaign.trend}%
                    </Badge>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-xs">
                    <div>
                      <p className="text-muted-foreground">Spend</p>
                      <p className="font-medium">{formatCurrency(campaign.spend)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Conversions</p>
                      <p className="font-medium">{campaign.conversions}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">CPA</p>
                      <p className="font-medium">${campaign.cpa.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">ROAS</p>
                      <p className="font-medium text-success">{campaign.roas}x</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Spend Comparison */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Platform Spend Over Time</CardTitle>
          <CardDescription>Compare spend across advertising platforms</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyData.filter((_, i) => i % 3 === 0)}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickFormatter={(v) => `$${v}`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="google" name="Google Ads" stackId="a" fill="hsl(var(--chart-1))" />
                <Bar dataKey="meta" name="Meta Ads" stackId="a" fill="hsl(var(--chart-2))" />
                <Bar dataKey="tiktok" name="TikTok Ads" stackId="a" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
