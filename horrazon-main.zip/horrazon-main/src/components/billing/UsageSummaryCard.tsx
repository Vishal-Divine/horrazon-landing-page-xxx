import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Zap, Users, Database, Globe, FileText, TrendingUp, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface UsageItem {
  id: string;
  name: string;
  icon: React.ElementType;
  used: number;
  limit: number;
  unit: string;
  trend?: number;
}

const usageData: UsageItem[] = [
  { id: 'ad-spend', name: 'Ad Spend Tracked', icon: Zap, used: 342000, limit: 500000, unit: 'USD', trend: 12 },
  { id: 'team', name: 'Team Members', icon: Users, used: 8, limit: -1, unit: 'users' },
  { id: 'data', name: 'Data Retention', icon: Database, used: 45, limit: 90, unit: 'days' },
  { id: 'integrations', name: 'Integrations', icon: Globe, used: 5, limit: 10, unit: 'platforms' },
  { id: 'reports', name: 'Custom Reports', icon: FileText, used: 12, limit: 25, unit: 'reports' },
];

export default function UsageSummaryCard() {
  const formatValue = (value: number, unit: string) => {
    if (unit === 'USD') {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value);
    }
    return value.toLocaleString();
  };

  const getUsagePercentage = (used: number, limit: number) => {
    if (limit === -1) return 0; // Unlimited
    return Math.min((used / limit) * 100, 100);
  };

  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-destructive';
    if (percentage >= 75) return 'bg-amber-500';
    return 'bg-primary';
  };

  const getUsageStatus = (percentage: number) => {
    if (percentage >= 90) return { text: 'Critical', color: 'text-destructive bg-destructive/10' };
    if (percentage >= 75) return { text: 'High', color: 'text-amber-500 bg-amber-500/10' };
    if (percentage >= 50) return { text: 'Moderate', color: 'text-chart-2 bg-chart-2/10' };
    return { text: 'Good', color: 'text-emerald-500 bg-emerald-500/10' };
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <div className="p-1.5 rounded-lg bg-chart-4/10">
              <Zap className="h-4 w-4 text-chart-4" />
            </div>
            Plan Usage
          </CardTitle>
          <Badge variant="outline" className="gap-1">
            Pro Plan
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {usageData.map((item) => {
          const Icon = item.icon;
          const percentage = getUsagePercentage(item.used, item.limit);
          const status = getUsageStatus(percentage);
          const isUnlimited = item.limit === -1;

          return (
            <div key={item.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-md bg-muted">
                    <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                  </div>
                  <span className="text-sm font-medium">{item.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  {item.trend && (
                    <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                      <TrendingUp className="h-2.5 w-2.5" />+{item.trend}%
                    </span>
                  )}
                  {!isUnlimited && (
                    <Badge variant="outline" className={cn('text-[9px] px-1.5 py-0', status.color)}>
                      {status.text}
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  {isUnlimited ? (
                    <div className="h-2 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <span className="text-[8px] text-emerald-500">Unlimited</span>
                    </div>
                  ) : (
                    <Progress value={percentage} className={cn('h-2', percentage >= 90 && 'animate-pulse')} />
                  )}
                </div>
                <span className="text-xs text-muted-foreground min-w-[80px] text-right">
                  {formatValue(item.used, item.unit)}
                  {!isUnlimited && ` / ${formatValue(item.limit, item.unit)}`}
                  {isUnlimited && ' used'}
                </span>
              </div>
            </div>
          );
        })}

        {/* Warning for high usage items */}
        {usageData.some((item) => item.limit !== -1 && getUsagePercentage(item.used, item.limit) >= 75) && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 mt-2">
            <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium text-amber-600">Approaching Limits</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                Consider upgrading your plan to avoid service interruptions.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
