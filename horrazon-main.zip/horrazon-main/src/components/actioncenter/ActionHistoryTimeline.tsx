import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  RotateCcw,
  Facebook,
  Chrome,
  History,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { ActionHistory } from './types';
import { format, formatDistanceToNow } from 'date-fns';

interface ActionHistoryTimelineProps {
  history: ActionHistory[];
  onRollback?: (id: string) => void;
}

export function ActionHistoryTimeline({ history, onRollback }: ActionHistoryTimelineProps) {
  const getStatusIcon = (status: ActionHistory['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-4 w-4 text-success" />;
      case 'partial':
        return <AlertCircle className="h-4 w-4 text-warning" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-muted-foreground animate-pulse" />;
    }
  };

  const getStatusBadge = (status: ActionHistory['status']) => {
    const variants: Record<ActionHistory['status'], 'default' | 'secondary' | 'destructive' | 'outline'> = {
      success: 'default',
      partial: 'secondary',
      failed: 'destructive',
      pending: 'outline',
    };
    return (
      <Badge variant={variants[status]} className="capitalize">
        {status}
      </Badge>
    );
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'meta':
        return <Facebook className="h-4 w-4 text-[#1877F2]" />;
      case 'google':
        return <Chrome className="h-4 w-4 text-[#4285F4]" />;
      default:
        return null;
    }
  };

  const getImpactTrend = (expected: string, actual: string) => {
    const expectedNum = parseFloat(expected.replace(/[^0-9.-]/g, ''));
    const actualNum = parseFloat(actual.replace(/[^0-9.-]/g, ''));
    if (isNaN(actualNum)) return null;
    return actualNum >= expectedNum ? (
      <TrendingUp className="h-3 w-3 text-success" />
    ) : (
      <TrendingDown className="h-3 w-3 text-warning" />
    );
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <History className="h-5 w-5 text-primary" />
          Action History
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-[18px] top-0 bottom-0 w-px bg-border" />

            <div className="space-y-4">
              {history.map((item, index) => (
                <div key={item.id} className="relative flex gap-4">
                  {/* Timeline dot */}
                  <div className="relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border bg-card">
                    {getStatusIcon(item.status)}
                  </div>

                  {/* Content */}
                  <div className="flex-1 rounded-lg border bg-card p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getPlatformIcon(item.platform)}
                        <span className="font-medium">{item.actionName}</span>
                        {getStatusBadge(item.status)}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(item.executedAt, { addSuffix: true })}
                      </span>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">{item.campaign}</span>
                      <span className="mx-2">•</span>
                      <span>Executed by {item.executedBy}</span>
                    </div>

                    {/* Impact comparison */}
                    <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                      <div>
                        <p className="text-xs text-muted-foreground">Expected Impact</p>
                        <p className="text-sm font-medium">{item.expectedImpact}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Actual Impact</p>
                        <div className="flex items-center gap-1">
                          <p className="text-sm font-medium">{item.actualImpact}</p>
                          {getImpactTrend(item.expectedImpact, item.actualImpact)}
                        </div>
                      </div>
                    </div>

                    {/* Notes */}
                    {item.notes && <p className="text-xs text-muted-foreground italic">{item.notes}</p>}

                    {/* Rollback button */}
                    {item.rollbackAvailable && item.status !== 'pending' && (
                      <Button variant="outline" size="sm" className="gap-1 mt-2" onClick={() => onRollback?.(item.id)}>
                        <RotateCcw className="h-3 w-3" />
                        Rollback
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
