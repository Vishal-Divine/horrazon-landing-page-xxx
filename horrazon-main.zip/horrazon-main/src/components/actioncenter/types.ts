import { LucideIcon } from 'lucide-react';

export interface Action {
  id: string;
  insight: string;
  recommendation: string;
  impact: string;
  impactValue: number;
  severity: 'high' | 'medium' | 'positive';
  details: string;
  confidence: number;
  successProbability: number;
  urgency: string;
  urgencyMinutes: number;
  category: 'budget' | 'creative' | 'audience' | 'bidding';
  channels: string[];
  crossChannelImpact?: string;
  aiExplanation?: string;
  historicalData?: { date: string; value: number }[];
  relatedActions?: string[];
  estimatedTimeToImplement?: string;
  reversible?: boolean;
  dependencies?: string[];
}

export interface ActionSimulation {
  id: string;
  actionId: string;
  scenarioName: string;
  projectedOutcome: {
    revenue: number;
    roas: number;
    spend: number;
    conversions: number;
  };
  confidence: number;
  timeline: { day: string; value: number }[];
}

export interface ActionHistory {
  id: string;
  actionId: string;
  actionName: string;
  platform: string;
  campaign: string;
  executedAt: Date;
  executedBy: 'AI' | 'Manual';
  expectedImpact: string;
  actualImpact: string;
  status: 'success' | 'partial' | 'failed' | 'pending';
  rollbackAvailable: boolean;
  notes?: string;
}

export interface ImpactMetric {
  label: string;
  before: number;
  after: number;
  unit: string;
  trend: 'up' | 'down';
  isPositive: boolean;
}

export interface ActionInsight {
  id: string;
  title: string;
  description: string;
  dataPoints: string[];
  confidence: number;
  sources: string[];
}

export interface BulkActionGroup {
  id: string;
  name: string;
  actions: string[];
  estimatedImpact: string;
  riskLevel: 'low' | 'medium' | 'high';
}
