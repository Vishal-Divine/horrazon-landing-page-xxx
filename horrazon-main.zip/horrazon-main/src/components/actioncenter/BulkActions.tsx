import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Layers, AlertTriangle, CheckCircle2, Play, Info } from 'lucide-react';
import { BulkActionGroup } from './types';
import { toast } from '@/hooks/use-toast';

interface BulkActionsProps {
  groups: BulkActionGroup[];
  selectedActions: string[];
  onApply: (groupId: string) => void;
}

export function BulkActions({ groups, selectedActions, onApply }: BulkActionsProps) {
  const getRiskBadge = (risk: BulkActionGroup['riskLevel']) => {
    const styles: Record<BulkActionGroup['riskLevel'], string> = {
      low: 'bg-success/10 text-success',
      medium: 'bg-warning/10 text-warning',
      high: 'bg-destructive/10 text-destructive',
    };
    return (
      <Badge className={styles[risk]} variant="secondary">
        {risk} risk
      </Badge>
    );
  };

  const handleApply = (group: BulkActionGroup) => {
    onApply(group.id);
    toast({
      title: 'Bulk Action Applied',
      description: `${group.name} executed successfully with ${group.actions.length} actions.`,
    });
  };

  return (
    <Card className="border-accent/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Layers className="h-5 w-5 text-accent-foreground" />
          Bulk Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {groups.map((group) => {
          const matchingActions = group.actions.filter((a) => selectedActions.includes(a));
          const isFullySelected = matchingActions.length === group.actions.length;
          const isPartiallySelected = matchingActions.length > 0 && !isFullySelected;

          return (
            <div
              key={group.id}
              className={`rounded-lg border p-4 transition-all ${
                isFullySelected ? 'border-primary bg-primary/5' : 'hover:border-muted-foreground/30'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    {isFullySelected ? (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    ) : isPartiallySelected ? (
                      <AlertTriangle className="h-5 w-5 text-warning" />
                    ) : (
                      <Layers className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{group.name}</span>
                      {getRiskBadge(group.riskLevel)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {group.actions.length} actions • {group.estimatedImpact}
                    </p>
                    {isPartiallySelected && (
                      <p className="text-xs text-warning mt-1 flex items-center gap-1">
                        <Info className="h-3 w-3" />
                        {matchingActions.length} of {group.actions.length} selected
                      </p>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant={isFullySelected ? 'default' : 'outline'}
                  className="gap-1"
                  onClick={() => handleApply(group)}
                  disabled={!isFullySelected && matchingActions.length === 0}
                >
                  <Play className="h-3 w-3" />
                  Apply
                </Button>
              </div>
            </div>
          );
        })}

        {/* Custom bulk action prompt */}
        <div className="rounded-lg border border-dashed p-4 text-center">
          <p className="text-sm text-muted-foreground">Select actions above to create a custom bulk action</p>
          {selectedActions.length > 0 && (
            <Button variant="outline" size="sm" className="mt-2">
              Create Group ({selectedActions.length} selected)
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
