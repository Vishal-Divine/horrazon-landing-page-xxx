import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  TrendingUp,
  DollarSign,
  Users,
  Layers,
  AlertTriangle,
  Zap,
  Clock,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ActionCard {
  id: string;
  insight: string;
  description: string;
  category: 'budget' | 'creative' | 'audience' | 'bidding';
  platform: string;
  impact: string;
  estimatedValue: number;
  confidence: number;
  urgency: 'high' | 'medium' | 'low';
  recommendation: string;
  currentValue?: string;
  proposedValue?: string;
}

const actionCards: ActionCard[] = [
  {
    id: '1',
    insight: 'Summer Sale campaign has 4.0 ROAS',
    description:
      'This campaign is outperforming your average by 62%. Scaling budget could capture more high-intent traffic.',
    category: 'budget',
    platform: 'Meta',
    impact: '+$2,400 revenue',
    estimatedValue: 2400,
    confidence: 94,
    urgency: 'high',
    recommendation: 'Increase budget by 20%',
    currentValue: '$500/day',
    proposedValue: '$600/day',
  },
  {
    id: '2',
    insight: 'Hero Banner CTR dropped 28%',
    description: 'Creative fatigue detected. The ad has been running for 14 days with declining engagement.',
    category: 'creative',
    platform: 'Meta',
    impact: 'Prevent $800 waste',
    estimatedValue: 800,
    confidence: 89,
    urgency: 'high',
    recommendation: 'Refresh creative or pause',
    currentValue: '2.4% CTR',
    proposedValue: 'New variant',
  },
  {
    id: '3',
    insight: 'Lookalike audience exhausted',
    description: 'Frequency is 4.2 (above healthy threshold of 3). Audience is seeing your ads too often.',
    category: 'audience',
    platform: 'Meta',
    impact: 'Save $1,200/week',
    estimatedValue: 1200,
    confidence: 86,
    urgency: 'medium',
    recommendation: 'Expand audience or exclude converters',
    currentValue: '1.2M audience',
    proposedValue: '2.4M audience',
  },
  {
    id: '4',
    insight: 'CPC spike detected on brand terms',
    description: 'Your Google brand CPC increased 45% this week, likely due to competitor bidding.',
    category: 'bidding',
    platform: 'Google',
    impact: 'Reduce CPC by $1.20',
    estimatedValue: 960,
    confidence: 82,
    urgency: 'medium',
    recommendation: 'Adjust bid strategy',
    currentValue: '$3.80 CPC',
    proposedValue: '$2.60 CPC',
  },
  {
    id: '5',
    insight: 'Weekend performance opportunity',
    description: 'Your ROAS is 34% higher on weekends but budget remains flat. Dayparting could improve efficiency.',
    category: 'budget',
    platform: 'TikTok',
    impact: '+$1,800 revenue',
    estimatedValue: 1800,
    confidence: 78,
    urgency: 'low',
    recommendation: 'Increase weekend budget 25%',
    currentValue: 'Flat budget',
    proposedValue: '+25% Sat-Sun',
  },
];

const categoryIcons = {
  budget: DollarSign,
  creative: Layers,
  audience: Users,
  bidding: TrendingUp,
};

const categoryColors = {
  budget: 'text-success',
  creative: 'text-chart-1',
  audience: 'text-chart-2',
  bidding: 'text-chart-3',
};

const urgencyColors = {
  high: 'bg-destructive text-destructive-foreground',
  medium: 'bg-warning text-warning-foreground',
  low: 'bg-muted text-muted-foreground',
};

export function ActionFeed() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [actions, setActions] = useState(actionCards);
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);

  const currentCard = actions[currentIndex];
  const remainingCards = actions.length - currentIndex;
  const totalValue = actions.slice(currentIndex).reduce((sum, a) => sum + a.estimatedValue, 0);

  const handleApprove = () => {
    setSwipeDirection('right');
    toast({
      title: 'Action Approved',
      description: `Executing: ${currentCard.recommendation}`,
    });
    setTimeout(() => {
      setSwipeDirection(null);
      if (currentIndex < actions.length - 1) {
        setCurrentIndex(currentIndex + 1);
      }
    }, 300);
  };

  const handleDismiss = () => {
    setSwipeDirection('left');
    toast({
      title: 'Action Dismissed',
      description: 'This recommendation has been skipped.',
    });
    setTimeout(() => {
      setSwipeDirection(null);
      if (currentIndex < actions.length - 1) {
        setCurrentIndex(currentIndex + 1);
      }
    }, 300);
  };

  const handleUndo = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  if (!currentCard) {
    return (
      <Card className="border-success/20 bg-gradient-to-br from-card to-success/5">
        <CardContent className="flex flex-col items-center justify-center p-12 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/20 mb-4">
            <Check className="h-8 w-8 text-success" />
          </div>
          <h3 className="text-xl font-bold mb-2">All Caught Up!</h3>
          <p className="text-muted-foreground">You've reviewed all pending recommendations.</p>
          <Button variant="outline" className="mt-4 gap-2" onClick={() => setCurrentIndex(0)}>
            <RotateCcw className="h-4 w-4" />
            Review Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  const CategoryIcon = categoryIcons[currentCard.category];

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-4 w-4 text-primary" />
            </div>
            Smart Action Feed
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="gap-1">
              <Clock className="h-3 w-3" />
              {remainingCards} pending
            </Badge>
            <Badge className="bg-success text-success-foreground gap-1">
              <DollarSign className="h-3 w-3" />${totalValue.toLocaleString()} potential
            </Badge>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Swipe right to approve, left to dismiss. Like Tinder, but for marketing decisions.
        </p>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Progress */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {currentIndex + 1} of {actions.length}
          </span>
          <Progress value={((currentIndex + 1) / actions.length) * 100} className="h-2 flex-1" />
          {currentIndex > 0 && (
            <Button variant="ghost" size="sm" className="gap-1 text-xs" onClick={handleUndo}>
              <RotateCcw className="h-3 w-3" />
              Undo
            </Button>
          )}
        </div>

        {/* Card Stack */}
        <div className="relative min-h-[380px]">
          {/* Background cards */}
          {actions.slice(currentIndex + 1, currentIndex + 3).map((card, idx) => (
            <div
              key={card.id}
              className="absolute inset-0 rounded-xl border bg-card"
              style={{
                transform: `scale(${1 - (idx + 1) * 0.05}) translateY(${(idx + 1) * 8}px)`,
                opacity: 1 - (idx + 1) * 0.3,
                zIndex: 10 - idx,
              }}
            />
          ))}

          {/* Current card */}
          <div
            className={cn(
              'relative rounded-xl border-2 bg-card p-6 transition-transform duration-300 z-20',
              swipeDirection === 'right' && 'translate-x-[120%] rotate-12',
              swipeDirection === 'left' && '-translate-x-[120%] -rotate-12',
              currentCard.urgency === 'high' ? 'border-destructive/50' : 'border-border',
            )}
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'flex h-12 w-12 items-center justify-center rounded-xl bg-muted',
                    categoryColors[currentCard.category],
                  )}
                >
                  <CategoryIcon className="h-6 w-6" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-1 text-[10px]">
                    {currentCard.platform}
                  </Badge>
                  <h3 className="font-semibold text-lg leading-tight">{currentCard.insight}</h3>
                </div>
              </div>
              <Badge className={urgencyColors[currentCard.urgency]}>{currentCard.urgency} priority</Badge>
            </div>

            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4">{currentCard.description}</p>

            {/* Current vs Proposed */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Current</p>
                <p className="font-semibold">{currentCard.currentValue}</p>
              </div>
              <div className="rounded-lg bg-primary/10 p-3 border border-primary/20">
                <p className="text-xs text-primary mb-1">Proposed</p>
                <p className="font-semibold text-primary">{currentCard.proposedValue}</p>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-success">{currentCard.impact}</p>
                <p className="text-xs text-muted-foreground">Est. Impact</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{currentCard.confidence}%</p>
                <p className="text-xs text-muted-foreground">Confidence</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-chart-1">${currentCard.estimatedValue}</p>
                <p className="text-xs text-muted-foreground">Value</p>
              </div>
            </div>

            {/* AI Recommendation */}
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 mb-4">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium">AI Recommendation</span>
              </div>
              <p className="text-sm text-muted-foreground">{currentCard.recommendation}</p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                size="lg"
                variant="outline"
                className="flex-1 gap-2 border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                onClick={handleDismiss}
              >
                <ThumbsDown className="h-5 w-5" />
                Dismiss
              </Button>
              <Button size="lg" className="flex-1 gap-2 bg-success hover:bg-success/90" onClick={handleApprove}>
                <ThumbsUp className="h-5 w-5" />
                Approve
              </Button>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="rounded-lg bg-muted/50 p-2">
            <p className="text-lg font-bold">{actions.filter((a) => a.category === 'budget').length}</p>
            <p className="text-[10px] text-muted-foreground">Budget</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-2">
            <p className="text-lg font-bold">{actions.filter((a) => a.category === 'creative').length}</p>
            <p className="text-[10px] text-muted-foreground">Creative</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-2">
            <p className="text-lg font-bold">{actions.filter((a) => a.category === 'audience').length}</p>
            <p className="text-[10px] text-muted-foreground">Audience</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-2">
            <p className="text-lg font-bold">{actions.filter((a) => a.category === 'bidding').length}</p>
            <p className="text-[10px] text-muted-foreground">Bidding</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
