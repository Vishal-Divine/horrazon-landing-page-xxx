import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Target, Users, Zap, Play, RefreshCw } from 'lucide-react';
import { Action } from './types';

interface ImpactSimulatorProps {
  action: Action;
  onClose: () => void;
}

export function ImpactSimulator({ action, onClose }: ImpactSimulatorProps) {
  const [intensity, setIntensity] = useState([50]);
  const [scenario, setScenario] = useState<'conservative' | 'moderate' | 'aggressive'>('moderate');

  const getProjection = () => {
    const base = action.impactValue;
    const multiplier = intensity[0] / 50;
    const scenarioMultiplier = scenario === 'conservative' ? 0.7 : scenario === 'aggressive' ? 1.4 : 1;

    return {
      revenue: Math.round(base * multiplier * scenarioMultiplier * 100),
      roas: (3.2 + multiplier * scenarioMultiplier * 0.8).toFixed(1),
      conversions: Math.round(base * multiplier * scenarioMultiplier * 2),
      spend: Math.round(base * multiplier * scenarioMultiplier * 30),
    };
  };

  const projection = getProjection();

  const timelineData = [
    { day: 'Day 1', conservative: 1200, moderate: 1800, aggressive: 2400 },
    { day: 'Day 2', conservative: 1600, moderate: 2400, aggressive: 3200 },
    { day: 'Day 3', conservative: 1900, moderate: 2800, aggressive: 3800 },
    { day: 'Day 4', conservative: 2100, moderate: 3100, aggressive: 4200 },
    { day: 'Day 5', conservative: 2200, moderate: 3300, aggressive: 4500 },
    { day: 'Day 6', conservative: 2300, moderate: 3400, aggressive: 4700 },
    { day: 'Day 7', conservative: 2400, moderate: 3500, aggressive: 4800 },
  ];

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Zap className="h-5 w-5 text-primary" />
            Impact Simulator
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Scenario Selection */}
        <div>
          <p className="text-sm text-muted-foreground mb-3">Select Scenario</p>
          <Tabs value={scenario} onValueChange={(v) => setScenario(v as typeof scenario)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="conservative">Conservative</TabsTrigger>
              <TabsTrigger value="moderate">Moderate</TabsTrigger>
              <TabsTrigger value="aggressive">Aggressive</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Intensity Slider */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm text-muted-foreground">Action Intensity</p>
            <Badge variant="outline">{intensity[0]}%</Badge>
          </div>
          <Slider value={intensity} onValueChange={setIntensity} max={100} min={10} step={10} className="w-full" />
        </div>

        {/* Projected Outcomes */}
        <div className="grid grid-cols-4 gap-3">
          <div className="rounded-lg border bg-card p-3 text-center">
            <DollarSign className="h-5 w-5 mx-auto text-success mb-1" />
            <p className="text-lg font-bold">${projection.revenue}</p>
            <p className="text-xs text-muted-foreground">Revenue</p>
          </div>
          <div className="rounded-lg border bg-card p-3 text-center">
            <TrendingUp className="h-5 w-5 mx-auto text-primary mb-1" />
            <p className="text-lg font-bold">{projection.roas}x</p>
            <p className="text-xs text-muted-foreground">ROAS</p>
          </div>
          <div className="rounded-lg border bg-card p-3 text-center">
            <Target className="h-5 w-5 mx-auto text-chart-2 mb-1" />
            <p className="text-lg font-bold">{projection.conversions}</p>
            <p className="text-xs text-muted-foreground">Conversions</p>
          </div>
          <div className="rounded-lg border bg-card p-3 text-center">
            <Users className="h-5 w-5 mx-auto text-chart-3 mb-1" />
            <p className="text-lg font-bold">${projection.spend}</p>
            <p className="text-xs text-muted-foreground">Spend</p>
          </div>
        </div>

        {/* Timeline Chart */}
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={10} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 'var(--radius)',
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey={scenario}
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))' }}
                name="Projected Revenue"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Confidence & Actions */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-2">
            <Badge
              variant={
                scenario === 'conservative' ? 'secondary' : scenario === 'aggressive' ? 'destructive' : 'default'
              }
            >
              {scenario === 'conservative'
                ? '85% confidence'
                : scenario === 'aggressive'
                  ? '68% confidence'
                  : '78% confidence'}
            </Badge>
            <span className="text-xs text-muted-foreground">
              Based on {action.historicalData?.length || 5} data points
            </span>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1">
              <RefreshCw className="h-3 w-3" />
              Reset
            </Button>
            <Button size="sm" className="gap-1">
              <Play className="h-3 w-3" />
              Apply
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
