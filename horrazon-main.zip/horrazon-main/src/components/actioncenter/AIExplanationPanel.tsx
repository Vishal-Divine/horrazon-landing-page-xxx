import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Brain, TrendingUp, TrendingDown, Lightbulb, Database, Clock, Info } from 'lucide-react';
import { Action } from './types';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

interface AIExplanationPanelProps {
  action: Action;
}

export function AIExplanationPanel({ action }: AIExplanationPanelProps) {
  const factors = [
    { name: 'Historical Performance', weight: 35, value: 92 },
    { name: 'Market Conditions', weight: 25, value: 78 },
    { name: 'Audience Behavior', weight: 20, value: 85 },
    { name: 'Competitor Activity', weight: 12, value: 71 },
    { name: 'Seasonal Trends', weight: 8, value: 88 },
  ];

  return (
    <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Brain className="h-5 w-5 text-chart-1" />
          AI Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Main Explanation */}
        <div className="rounded-lg bg-muted/50 p-4">
          <div className="flex items-start gap-3">
            <Lightbulb className="h-5 w-5 text-primary mt-0.5 shrink-0" />
            <div>
              <p className="text-sm leading-relaxed">
                {action.aiExplanation ||
                  'AI analysis is processing this recommendation based on historical data and current market conditions.'}
              </p>
            </div>
          </div>
        </div>

        {/* Confidence Breakdown */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium">Decision Factors</span>
            <Badge variant="outline" className="gap-1">
              <Database className="h-3 w-3" />
              {factors.length} signals analyzed
            </Badge>
          </div>
          <div className="space-y-3">
            {factors.map((factor) => (
              <div key={factor.name}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-muted-foreground">{factor.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{factor.weight}% weight</span>
                    <span className="text-xs font-medium">{factor.value}%</span>
                  </div>
                </div>
                <Progress value={factor.value} className="h-1.5" />
              </div>
            ))}
          </div>
        </div>

        {/* Historical Trend */}
        {action.historicalData && action.historicalData.length > 0 && (
          <div>
            <span className="text-sm font-medium">Historical Trend</span>
            <div className="h-24 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={action.historicalData}>
                  <XAxis dataKey="date" hide />
                  <YAxis hide domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                      fontSize: '12px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke={action.severity === 'positive' ? 'hsl(var(--success))' : 'hsl(var(--destructive))'}
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-3 pt-2 border-t">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Time to Implement</p>
              <p className="text-sm font-medium">{action.estimatedTimeToImplement || '~10 mins'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Reversible</p>
              <p className="text-sm font-medium">{action.reversible ? 'Yes' : 'No'}</p>
            </div>
          </div>
        </div>

        {/* Dependencies */}
        {action.dependencies && action.dependencies.length > 0 && (
          <div className="pt-2 border-t">
            <span className="text-sm text-muted-foreground">Dependencies</span>
            <div className="flex flex-wrap gap-2 mt-2">
              {action.dependencies.map((dep, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {dep}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
