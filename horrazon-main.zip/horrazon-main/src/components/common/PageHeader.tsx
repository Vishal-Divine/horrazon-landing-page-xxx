import { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PageHeaderAction {
  label: string;
  icon?: ReactNode;
  onClick?: () => void;
  href?: string;
  variant?: 'default' | 'outline' | 'secondary' | 'ghost' | 'destructive';
}

interface PageHeaderProps {
  title: string;
  description?: string;
  icon?: ReactNode;
  actions?: PageHeaderAction[];
  children?: ReactNode;
  className?: string;
}

/**
 * Reusable page header component with title, description, and actions
 */
export function PageHeader({ title, description, icon, actions, children, className }: PageHeaderProps) {
  return (
    <header className={cn('flex items-center justify-between', className)}>
      <div className="flex items-center gap-4">
        {icon && <div className="p-2.5 rounded-xl bg-primary/10 text-primary">{icon}</div>}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">{title}</h1>
          {description && <p className="text-muted-foreground mt-1">{description}</p>}
        </div>
      </div>
      {(actions || children) && (
        <div className="flex items-center gap-3">
          {actions?.map((action, index) => (
            <Button key={index} variant={action.variant || 'outline'} onClick={action.onClick} asChild={!!action.href}>
              {action.href ? (
                <a href={action.href}>
                  {action.icon}
                  {action.label}
                </a>
              ) : (
                <>
                  {action.icon}
                  {action.label}
                </>
              )}
            </Button>
          ))}
          {children}
        </div>
      )}
    </header>
  );
}

export default PageHeader;
