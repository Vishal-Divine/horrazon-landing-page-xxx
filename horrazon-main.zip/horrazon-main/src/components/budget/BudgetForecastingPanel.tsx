import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Target,
  Calendar,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  RefreshCw,
  Download,
} from 'lucide-react';
import { useState } from 'react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

const monthlyForecast = [
  { month: 'Jan', actual: 248, forecast: null, lower: null, upper: null },
  { month: 'Feb', actual: 262, forecast: null, lower: null, upper: null },
  { month: 'Mar', actual: 278, forecast: null, lower: null, upper: null },
  { month: 'Apr', actual: 285, forecast: null, lower: null, upper: null },
  { month: 'May', actual: 292, forecast: null, lower: null, upper: null },
  { month: 'Jun', actual: 310, forecast: null, lower: null, upper: null },
  { month: 'Jul', actual: null, forecast: 325, lower: 308, upper: 342 },
  { month: 'Aug', actual: null, forecast: 338, lower: 318, upper: 358 },
  { month: 'Sep', actual: null, forecast: 352, lower: 328, upper: 376 },
  { month: 'Oct', actual: null, forecast: 368, lower: 340, upper: 396 },
  { month: 'Nov', actual: null, forecast: 385, lower: 352, upper: 418 },
  { month: 'Dec', actual: null, forecast: 402, lower: 365, upper: 439 },
];

const channelForecast = [
  { channel: 'Google Ads', current: 92, forecast: 108, growth: 17.4, confidence: 94 },
  { channel: 'Meta Ads', current: 78, forecast: 88, growth: 12.8, confidence: 91 },
  { channel: 'TikTok Ads', current: 42, forecast: 58, growth: 38.1, confidence: 88 },
  { channel: 'LinkedIn Ads', current: 24, forecast: 26, growth: 8.3, confidence: 85 },
  { channel: 'Programmatic', current: 12, forecast: 18, growth: 50.0, confidence: 82 },
];

const seasonalFactors = [
  { factor: 'Q4 Holiday Rush', impact: '+35%', period: 'Nov-Dec', confidence: 96 },
  { factor: 'Back to School', impact: '+18%', period: 'Aug-Sep', confidence: 92 },
  { factor: 'Summer Slowdown', impact: '-12%', period: 'Jun-Jul', confidence: 89 },
  { factor: 'New Year Sales', impact: '+22%', period: 'Jan', confidence: 94 },
];

const revenueProjection = [
  { month: 'Jul', revenue: 1360, cost: 325, profit: 1035, roas: 4.2 },
  { month: 'Aug', revenue: 1418, cost: 338, profit: 1080, roas: 4.2 },
  { month: 'Sep', revenue: 1514, cost: 352, profit: 1162, roas: 4.3 },
  { month: 'Oct', revenue: 1620, cost: 368, profit: 1252, roas: 4.4 },
  { month: 'Nov', revenue: 1771, cost: 385, profit: 1386, roas: 4.6 },
  { month: 'Dec', revenue: 1930, cost: 402, profit: 1528, roas: 4.8 },
];

export function BudgetForecastingPanel() {
  const [forecastHorizon, setForecastHorizon] = useState('6');
  const [seasonalAdjustment, setSeasonalAdjustment] = useState([100]);
  const [growthRate, setGrowthRate] = useState([5]);

  const totalForecastedSpend = monthlyForecast.filter((m) => m.forecast).reduce((sum, m) => sum + (m.forecast || 0), 0);

  const avgForecastedROAS = revenueProjection.reduce((sum, m) => sum + m.roas, 0) / revenueProjection.length;

  return (
    <div className="space-y-6">
      {/* Forecast Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">6-Month Forecast</p>
                <p className="text-3xl font-bold">${totalForecastedSpend.toFixed(0)}K</p>
              </div>
              <Brain className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              +18.4% vs current period
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Projected Revenue</p>
                <p className="text-3xl font-bold">$9.6M</p>
              </div>
              <Target className="h-10 w-10 text-success" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <ArrowUpRight className="h-3 w-3" />
              +24.2% growth expected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Forecasted ROAS</p>
                <p className="text-3xl font-bold">{avgForecastedROAS.toFixed(1)}x</p>
              </div>
              <BarChart3 className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              Improving efficiency trend
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Forecast Confidence</p>
                <p className="text-3xl font-bold">91%</p>
              </div>
              <Sparkles className="h-10 w-10 text-chart-3" />
            </div>
            <Progress value={91} className="h-2 mt-2" />
            <p className="mt-1 text-xs text-muted-foreground">Based on 24 months data</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="spend" className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="spend">Spend Forecast</TabsTrigger>
            <TabsTrigger value="revenue">Revenue Projection</TabsTrigger>
            <TabsTrigger value="channels">Channel Breakdown</TabsTrigger>
            <TabsTrigger value="seasonal">Seasonal Factors</TabsTrigger>
          </TabsList>
          <div className="flex gap-2">
            <Select value={forecastHorizon} onValueChange={setForecastHorizon}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3">3 Months</SelectItem>
                <SelectItem value="6">6 Months</SelectItem>
                <SelectItem value="12">12 Months</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="spend" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-chart-1" />
                  AI-Powered Spend Forecast
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={monthlyForecast}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(v) => `$${v}K`} />
                    <Tooltip formatter={(value) => (value ? [`$${value}K`, ''] : ['-', ''])} />
                    <Area
                      type="monotone"
                      dataKey="upper"
                      stroke="none"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.1}
                      name="Upper Bound"
                    />
                    <Area
                      type="monotone"
                      dataKey="lower"
                      stroke="none"
                      fill="hsl(var(--background))"
                      name="Lower Bound"
                    />
                    <Line
                      type="monotone"
                      dataKey="actual"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={3}
                      dot={{ r: 4 }}
                      name="Actual"
                    />
                    <Line
                      type="monotone"
                      dataKey="forecast"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={3}
                      strokeDasharray="5 5"
                      dot={{ r: 4 }}
                      name="Forecast"
                    />
                    <Legend />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Forecast Parameters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Growth Rate Assumption</Label>
                    <span className="text-sm font-medium">{growthRate[0]}%</span>
                  </div>
                  <Slider value={growthRate} onValueChange={setGrowthRate} max={20} step={0.5} />
                  <p className="text-xs text-muted-foreground">Monthly growth rate applied to forecast</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Seasonal Adjustment</Label>
                    <span className="text-sm font-medium">{seasonalAdjustment[0]}%</span>
                  </div>
                  <Slider
                    value={seasonalAdjustment}
                    onValueChange={setSeasonalAdjustment}
                    min={50}
                    max={150}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">Adjust for seasonal variations</p>
                </div>

                <div className="pt-4 space-y-3">
                  <h4 className="text-sm font-medium">Forecast Assumptions</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Base Model</span>
                      <span>ARIMA + ML Ensemble</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Training Data</span>
                      <span>24 months</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Updated</span>
                      <span>2 hours ago</span>
                    </div>
                  </div>
                </div>

                <Button className="w-full gap-2">
                  <Sparkles className="h-4 w-4" />
                  Regenerate Forecast
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Revenue & Profit Projection</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={revenueProjection}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `$${v}K`} />
                  <Tooltip formatter={(value) => [`$${value}K`, '']} />
                  <Bar dataKey="cost" stackId="a" fill="hsl(var(--chart-3))" name="Ad Spend" />
                  <Bar dataKey="profit" stackId="a" fill="hsl(var(--chart-2))" name="Profit" />
                  <Legend />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            {revenueProjection.slice(0, 3).map((month) => (
              <Card key={month.month}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold">{month.month} Projection</h4>
                    <Badge>{month.roas}x ROAS</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Revenue</span>
                      <span className="font-medium text-success">${month.revenue}K</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Ad Spend</span>
                      <span className="font-medium">${month.cost}K</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Profit</span>
                      <span className="font-bold text-success">${month.profit}K</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="channels" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Channel Growth Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {channelForecast.map((channel) => (
                  <div key={channel.channel} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{channel.channel}</span>
                        <Badge variant={channel.growth > 20 ? 'default' : 'secondary'} className="gap-1">
                          {channel.growth > 0 ? (
                            <ArrowUpRight className="h-3 w-3" />
                          ) : (
                            <ArrowDownRight className="h-3 w-3" />
                          )}
                          {channel.growth > 0 ? '+' : ''}
                          {channel.growth}%
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">Confidence: {channel.confidence}%</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs text-muted-foreground mb-1">
                          <span>Current: ${channel.current}K</span>
                          <span>Forecast: ${channel.forecast}K</span>
                        </div>
                        <div className="relative h-3 bg-muted rounded-full overflow-hidden">
                          <div
                            className="absolute h-full bg-chart-2 rounded-full"
                            style={{ width: `${(channel.current / channel.forecast) * 100}%` }}
                          />
                          <div className="absolute h-full bg-chart-1/50 rounded-full" style={{ width: '100%' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seasonal" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            {seasonalFactors.map((factor, i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold">{factor.factor}</h4>
                      <p className="text-sm text-muted-foreground mt-1">Period: {factor.period}</p>
                    </div>
                    <Badge
                      variant={factor.impact.startsWith('+') ? 'default' : 'secondary'}
                      className="text-lg px-3 py-1"
                    >
                      {factor.impact}
                    </Badge>
                  </div>
                  <div className="mt-4 flex items-center gap-2">
                    <Progress value={factor.confidence} className="flex-1 h-2" />
                    <span className="text-sm text-muted-foreground">{factor.confidence}%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Confidence score</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Seasonal Impact Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                AI-detected seasonal patterns based on historical performance data. These factors are automatically
                applied to forecasts.
              </p>
              <div className="grid gap-4 md:grid-cols-4">
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-chart-1">Q1</p>
                  <p className="text-sm text-muted-foreground">Moderate</p>
                  <p className="text-lg font-semibold mt-2">+8%</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-chart-2">Q2</p>
                  <p className="text-sm text-muted-foreground">Stable</p>
                  <p className="text-lg font-semibold mt-2">+3%</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-chart-3">Q3</p>
                  <p className="text-sm text-muted-foreground">Recovery</p>
                  <p className="text-lg font-semibold mt-2">+12%</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-success/10">
                  <p className="text-2xl font-bold text-success">Q4</p>
                  <p className="text-sm text-muted-foreground">Peak</p>
                  <p className="text-lg font-semibold mt-2 text-success">+35%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
