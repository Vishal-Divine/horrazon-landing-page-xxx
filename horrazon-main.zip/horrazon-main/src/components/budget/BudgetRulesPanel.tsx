import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Zap,
  Play,
  Pause,
  Settings2,
  Plus,
  Trash2,
  Edit2,
  ArrowRight,
  Clock,
  CheckCircle2,
  XCircle,
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Percent,
  RefreshCw,
} from 'lucide-react';
import { useState } from 'react';

interface BudgetRule {
  id: string;
  name: string;
  trigger: string;
  condition: string;
  action: string;
  channels: string[];
  status: 'active' | 'paused' | 'draft';
  executions: number;
  lastExecuted?: string;
  savings?: number;
  type: 'auto-adjust' | 'alert' | 'reallocation' | 'pause' | 'boost';
}

const mockRules: BudgetRule[] = [
  {
    id: '1',
    name: 'Auto-Reduce Overspending Channels',
    trigger: 'Daily spend exceeds 120% of target',
    condition: 'ROAS < 4.0x',
    action: 'Reduce daily budget by 15%',
    channels: ['All Channels'],
    status: 'active',
    executions: 12,
    lastExecuted: '2 hours ago',
    savings: 8400,
    type: 'auto-adjust',
  },
  {
    id: '2',
    name: 'Boost High-Performing Campaigns',
    trigger: 'ROAS exceeds 6.0x for 3 consecutive days',
    condition: 'Budget utilization < 90%',
    action: 'Increase budget by 20%',
    channels: ['TikTok Ads', 'Google Ads'],
    status: 'active',
    executions: 5,
    lastExecuted: 'Yesterday',
    type: 'boost',
  },
  {
    id: '3',
    name: 'Weekend Budget Optimization',
    trigger: 'Saturday or Sunday',
    condition: 'Historical weekend performance > weekday',
    action: 'Reallocate 10% from LinkedIn to Meta',
    channels: ['LinkedIn Ads', 'Meta Ads'],
    status: 'active',
    executions: 8,
    lastExecuted: '2 days ago',
    type: 'reallocation',
  },
  {
    id: '4',
    name: 'Emergency Pause Low ROAS',
    trigger: 'ROAS drops below 2.0x',
    condition: 'Spend > $1,000 in last 24h',
    action: 'Pause campaign and alert team',
    channels: ['Programmatic'],
    status: 'paused',
    executions: 2,
    type: 'pause',
  },
  {
    id: '5',
    name: 'End of Month Budget Push',
    trigger: 'Last 5 days of month',
    condition: 'Budget remaining > 15%',
    action: 'Increase spend on top performers by 25%',
    channels: ['Google Ads', 'Meta Ads'],
    status: 'draft',
    executions: 0,
    type: 'boost',
  },
];

const executionHistory = [
  {
    id: 1,
    rule: 'Auto-Reduce Overspending Channels',
    channel: 'Meta Ads',
    action: 'Budget reduced by 15%',
    result: 'success',
    time: '2 hours ago',
    impact: '-$1,200/day',
  },
  {
    id: 2,
    rule: 'Boost High-Performing Campaigns',
    channel: 'TikTok Ads',
    action: 'Budget increased by 20%',
    result: 'success',
    time: 'Yesterday',
    impact: '+$840/day',
  },
  {
    id: 3,
    rule: 'Weekend Budget Optimization',
    channel: 'Meta Ads',
    action: 'Budget reallocated',
    result: 'success',
    time: '2 days ago',
    impact: '+12% weekend ROAS',
  },
  {
    id: 4,
    rule: 'Auto-Reduce Overspending Channels',
    channel: 'Google Ads',
    action: 'Budget reduced by 15%',
    result: 'success',
    time: '3 days ago',
    impact: '-$920/day',
  },
  {
    id: 5,
    rule: 'Emergency Pause Low ROAS',
    channel: 'Programmatic',
    action: 'Campaign paused',
    result: 'warning',
    time: '1 week ago',
    impact: 'Saved $2,100',
  },
];

const getRuleIcon = (type: string) => {
  switch (type) {
    case 'auto-adjust':
      return <Settings2 className="h-5 w-5 text-chart-1" />;
    case 'boost':
      return <TrendingUp className="h-5 w-5 text-success" />;
    case 'reallocation':
      return <RefreshCw className="h-5 w-5 text-chart-2" />;
    case 'pause':
      return <Pause className="h-5 w-5 text-destructive" />;
    case 'alert':
      return <Zap className="h-5 w-5 text-warning" />;
    default:
      return <Settings2 className="h-5 w-5" />;
  }
};

export function BudgetRulesPanel() {
  const [rules, setRules] = useState(mockRules);
  const [showCreateForm, setShowCreateForm] = useState(false);

  const toggleRule = (id: string) => {
    setRules((prev) =>
      prev.map((rule) => {
        if (rule.id === id) {
          return {
            ...rule,
            status: rule.status === 'active' ? 'paused' : 'active',
          };
        }
        return rule;
      }),
    );
  };

  const activeRules = rules.filter((r) => r.status === 'active').length;
  const totalExecutions = rules.reduce((sum, r) => sum + r.executions, 0);
  const totalSavings = rules.reduce((sum, r) => sum + (r.savings || 0), 0);

  return (
    <div className="space-y-6">
      {/* Rules Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Rules</p>
                <p className="text-3xl font-bold">{activeRules}</p>
              </div>
              <Zap className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">of {rules.length} configured</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Executions</p>
                <p className="text-3xl font-bold">{totalExecutions}</p>
              </div>
              <Play className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Budget Saved</p>
                <p className="text-3xl font-bold">${(totalSavings / 1000).toFixed(1)}K</p>
              </div>
              <DollarSign className="h-10 w-10 text-success" />
            </div>
            <p className="mt-2 text-xs text-success">From automated optimizations</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-3xl font-bold">94%</p>
              </div>
              <BarChart3 className="h-10 w-10 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Rule execution success</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Rules List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Budget Automation Rules</h3>
            <Button size="sm" className="gap-2" onClick={() => setShowCreateForm(!showCreateForm)}>
              <Plus className="h-4 w-4" />
              Create Rule
            </Button>
          </div>

          {showCreateForm && (
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="text-base">Create New Rule</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Rule Name</Label>
                    <Input placeholder="e.g., Auto-pause underperformers" />
                  </div>
                  <div className="space-y-2">
                    <Label>Rule Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="auto-adjust">Auto-Adjust Budget</SelectItem>
                        <SelectItem value="boost">Boost Performance</SelectItem>
                        <SelectItem value="reallocation">Budget Reallocation</SelectItem>
                        <SelectItem value="pause">Pause Campaign</SelectItem>
                        <SelectItem value="alert">Alert Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Trigger Condition</Label>
                  <div className="flex gap-2">
                    <Select>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Metric" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="roas">ROAS</SelectItem>
                        <SelectItem value="spend">Daily Spend</SelectItem>
                        <SelectItem value="cpa">CPA</SelectItem>
                        <SelectItem value="impressions">Impressions</SelectItem>
                        <SelectItem value="clicks">Clicks</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Operator" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gt">Greater than</SelectItem>
                        <SelectItem value="lt">Less than</SelectItem>
                        <SelectItem value="eq">Equals</SelectItem>
                        <SelectItem value="change">Changes by</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="Value" className="w-24" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Action to Take</Label>
                  <div className="flex gap-2">
                    <Select>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Select action" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="increase">Increase budget by %</SelectItem>
                        <SelectItem value="decrease">Decrease budget by %</SelectItem>
                        <SelectItem value="pause">Pause campaign</SelectItem>
                        <SelectItem value="reallocate">Reallocate to channel</SelectItem>
                        <SelectItem value="alert">Send alert only</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="%" className="w-20" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Apply to Channels</Label>
                  <div className="flex flex-wrap gap-2">
                    {['Google Ads', 'Meta Ads', 'TikTok Ads', 'LinkedIn Ads', 'Programmatic'].map((channel) => (
                      <label
                        key={channel}
                        className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-full border cursor-pointer hover:bg-muted"
                      >
                        <input type="checkbox" className="rounded" />
                        {channel}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancel
                  </Button>
                  <Button variant="secondary">Save as Draft</Button>
                  <Button>Create & Activate</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {rules.map((rule) => (
            <Card
              key={rule.id}
              className={`transition-all ${rule.status === 'paused' ? 'opacity-60' : ''} ${rule.status === 'draft' ? 'border-dashed' : ''}`}
            >
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div
                      className={`p-3 rounded-lg ${
                        rule.type === 'boost'
                          ? 'bg-success/10'
                          : rule.type === 'pause'
                            ? 'bg-destructive/10'
                            : rule.type === 'reallocation'
                              ? 'bg-chart-2/10'
                              : 'bg-chart-1/10'
                      }`}
                    >
                      {getRuleIcon(rule.type)}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{rule.name}</h4>
                        <Badge
                          variant={
                            rule.status === 'active' ? 'default' : rule.status === 'paused' ? 'secondary' : 'outline'
                          }
                        >
                          {rule.status}
                        </Badge>
                        <Badge variant="outline" className="capitalize">
                          {rule.type}
                        </Badge>
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>
                          <strong>When:</strong> {rule.trigger}
                        </p>
                        <p>
                          <strong>If:</strong> {rule.condition}
                        </p>
                        <p>
                          <strong>Then:</strong> {rule.action}
                        </p>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2">
                        <span>Channels: {rule.channels.join(', ')}</span>
                        <span>•</span>
                        <span>{rule.executions} executions</span>
                        {rule.lastExecuted && (
                          <>
                            <span>•</span>
                            <span>Last: {rule.lastExecuted}</span>
                          </>
                        )}
                        {rule.savings && (
                          <>
                            <span>•</span>
                            <span className="text-success">Saved ${(rule.savings / 1000).toFixed(1)}K</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                    <Switch
                      checked={rule.status === 'active'}
                      onCheckedChange={() => toggleRule(rule.id)}
                      disabled={rule.status === 'draft'}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Execution History */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Executions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {executionHistory.map((exec) => (
              <div key={exec.id} className="p-3 rounded-lg border bg-muted/30">
                <div className="flex items-start gap-2">
                  {exec.result === 'success' ? (
                    <CheckCircle2 className="h-4 w-4 text-success mt-0.5" />
                  ) : (
                    <XCircle className="h-4 w-4 text-warning mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{exec.rule}</p>
                    <p className="text-xs text-muted-foreground">
                      {exec.channel}: {exec.action}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {exec.impact}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{exec.time}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" size="sm">
              View All History
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Rule Templates */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Quick Rule Templates
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            {[
              { name: 'Stop Loss Protection', desc: 'Pause when ROAS < 2.0x', icon: Pause },
              { name: 'Profit Maximizer', desc: 'Boost ROAS > 5.0x campaigns', icon: TrendingUp },
              { name: 'Budget Balancer', desc: 'Auto-reallocate based on performance', icon: RefreshCw },
              { name: 'Seasonal Adjuster', desc: 'Increase budget during peak periods', icon: BarChart3 },
            ].map((template, i) => (
              <Card key={i} className="cursor-pointer hover:border-primary/50 transition-colors">
                <CardContent className="pt-6">
                  <template.icon className="h-8 w-8 text-chart-1 mb-3" />
                  <h4 className="font-medium">{template.name}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{template.desc}</p>
                  <Button variant="link" className="p-0 h-auto mt-2">
                    Use template <ArrowRight className="h-3 w-3 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
