import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Brain,
  Sparkles,
  TrendingUp,
  Target,
  Zap,
  CheckCircle2,
  ArrowRight,
  BarChart3,
  PieChart,
  Lightbulb,
  DollarSign,
  RefreshCw,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import {
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

const optimizationScore = {
  overall: 78,
  categories: [
    { name: 'Budget Allocation', score: 82, maxScore: 100 },
    { name: 'Channel Mix', score: 75, maxScore: 100 },
    { name: 'Pacing Efficiency', score: 88, maxScore: 100 },
    { name: 'ROAS Optimization', score: 72, maxScore: 100 },
    { name: 'Seasonal Adjustment', score: 68, maxScore: 100 },
    { name: 'Audience Targeting', score: 80, maxScore: 100 },
  ],
};

const radarData = [
  { category: 'Allocation', current: 82, optimal: 95 },
  { category: 'Channel Mix', current: 75, optimal: 90 },
  { category: 'Pacing', current: 88, optimal: 95 },
  { category: 'ROAS', current: 72, optimal: 88 },
  { category: 'Seasonal', current: 68, optimal: 85 },
  { category: 'Targeting', current: 80, optimal: 92 },
];

const optimizationOpportunities = [
  {
    id: 1,
    title: 'Shift 15% from LinkedIn to TikTok',
    category: 'Channel Mix',
    impact: '+$18,400 revenue',
    effort: 'low',
    confidence: 94,
    description: 'TikTok shows 2x better ROAS than LinkedIn. Reallocating budget can significantly improve returns.',
    potentialROAS: 5.8,
    currentROAS: 4.2,
  },
  {
    id: 2,
    title: 'Implement Dayparting for Google Ads',
    category: 'Pacing',
    impact: '+12% conversion rate',
    effort: 'medium',
    confidence: 88,
    description:
      'Peak conversion times identified between 10am-2pm and 7pm-9pm. Focusing budget on these windows can improve efficiency.',
    potentialROAS: 5.2,
    currentROAS: 4.8,
  },
  {
    id: 3,
    title: 'Increase Weekend Meta Ads Budget',
    category: 'Seasonal',
    impact: '+$8,600 revenue',
    effort: 'low',
    confidence: 91,
    description: 'Weekend ROAS is 24% higher than weekdays. Shifting budget to weekends can capture more value.',
    potentialROAS: 5.6,
    currentROAS: 5.2,
  },
  {
    id: 4,
    title: 'Consolidate Underperforming Campaigns',
    category: 'Allocation',
    impact: 'Save $4,200/month',
    effort: 'medium',
    confidence: 86,
    description: '12 campaigns have <2.5x ROAS. Consolidating these into top performers will reduce waste.',
    potentialROAS: 4.8,
    currentROAS: 4.2,
  },
];

const whatIfScenarios = [
  { scenario: 'Increase TikTok by 30%', revenue: 1180000, cost: 280000, roas: 4.21, change: '+8.2%' },
  { scenario: 'Reduce LinkedIn by 50%', revenue: 1050000, cost: 236000, roas: 4.45, change: '+2.4%' },
  { scenario: 'Double Programmatic', revenue: 1120000, cost: 272000, roas: 4.12, change: '+4.8%' },
  { scenario: 'Focus on Mobile', revenue: 1200000, cost: 268000, roas: 4.48, change: '+10.5%' },
];

const efficiencyMetrics = [
  { channel: 'Google Ads', efficiency: 94, benchmark: 85, wasted: 2400 },
  { channel: 'Meta Ads', efficiency: 88, benchmark: 82, wasted: 4800 },
  { channel: 'TikTok Ads', efficiency: 96, benchmark: 80, wasted: 800 },
  { channel: 'LinkedIn Ads', efficiency: 72, benchmark: 75, wasted: 6200 },
  { channel: 'Programmatic', efficiency: 78, benchmark: 70, wasted: 3100 },
];

export function BudgetOptimizationPanel() {
  return (
    <div className="space-y-6">
      {/* Optimization Score Header */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="relative inline-flex items-center justify-center">
                <svg className="w-32 h-32">
                  <circle
                    className="text-muted stroke-current"
                    strokeWidth="8"
                    fill="transparent"
                    r="56"
                    cx="64"
                    cy="64"
                  />
                  <circle
                    className="text-chart-1 stroke-current"
                    strokeWidth="8"
                    strokeLinecap="round"
                    fill="transparent"
                    r="56"
                    cx="64"
                    cy="64"
                    style={{
                      strokeDasharray: `${optimizationScore.overall * 3.52} 352`,
                      transform: 'rotate(-90deg)',
                      transformOrigin: '50% 50%',
                    }}
                  />
                </svg>
                <div className="absolute">
                  <p className="text-4xl font-bold">{optimizationScore.overall}</p>
                  <p className="text-xs text-muted-foreground">out of 100</p>
                </div>
              </div>
              <h3 className="text-lg font-semibold mt-4">Optimization Score</h3>
              <p className="text-sm text-muted-foreground">Your budget is performing well, with room for improvement</p>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-chart-1" />
              Category Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {optimizationScore.categories.map((cat) => (
              <div key={cat.name} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span>{cat.name}</span>
                  <span className="font-medium">
                    {cat.score}/{cat.maxScore}
                  </span>
                </div>
                <div className="relative">
                  <Progress value={cat.score} className="h-2" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="opportunities" className="space-y-6">
        <TabsList>
          <TabsTrigger value="opportunities">Optimization Opportunities</TabsTrigger>
          <TabsTrigger value="whatif">What-If Analysis</TabsTrigger>
          <TabsTrigger value="efficiency">Efficiency Analysis</TabsTrigger>
          <TabsTrigger value="radar">Performance Radar</TabsTrigger>
        </TabsList>

        <TabsContent value="opportunities" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">AI-Recommended Optimizations</h3>
              <p className="text-sm text-muted-foreground">Actionable opportunities to improve budget performance</p>
            </div>
            <Button className="gap-2">
              <Sparkles className="h-4 w-4" />
              Apply All Recommendations
            </Button>
          </div>

          <div className="grid gap-4">
            {optimizationOpportunities.map((opp) => (
              <Card key={opp.id}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-chart-1/10">
                        <Lightbulb className="h-6 w-6 text-chart-1" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{opp.title}</h4>
                          <Badge variant="outline">{opp.category}</Badge>
                          <Badge variant={opp.effort === 'low' ? 'default' : 'secondary'}>{opp.effort} effort</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{opp.description}</p>
                        <div className="flex items-center gap-6 pt-2">
                          <div>
                            <p className="text-xs text-muted-foreground">Projected Impact</p>
                            <p className="text-lg font-bold text-success">{opp.impact}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Current ROAS</p>
                            <p className="text-lg font-medium">{opp.currentROAS}x</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Potential ROAS</p>
                            <p className="text-lg font-bold text-success">{opp.potentialROAS}x</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Confidence</p>
                            <p className="text-lg font-medium">{opp.confidence}%</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Learn More
                      </Button>
                      <Button size="sm" className="gap-1">
                        <CheckCircle2 className="h-4 w-4" />
                        Apply
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="whatif" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                What-If Scenario Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {whatIfScenarios.map((scenario, i) => (
                  <Card key={i} className="cursor-pointer hover:border-primary/50 transition-colors">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold">{scenario.scenario}</h4>
                        <Badge variant={scenario.change.startsWith('+') ? 'default' : 'secondary'} className="gap-1">
                          {scenario.change.startsWith('+') ? (
                            <ArrowUpRight className="h-3 w-3" />
                          ) : (
                            <ArrowDownRight className="h-3 w-3" />
                          )}
                          {scenario.change}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-xs text-muted-foreground">Revenue</p>
                          <p className="text-lg font-bold">${(scenario.revenue / 1000000).toFixed(2)}M</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Cost</p>
                          <p className="text-lg font-medium">${(scenario.cost / 1000).toFixed(0)}K</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">ROAS</p>
                          <p className="text-lg font-bold text-success">{scenario.roas}x</p>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full mt-4" size="sm">
                        Simulate This Scenario
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Custom Scenario Builder</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Create custom budget scenarios to see projected outcomes before making changes.
              </p>
              <Button className="gap-2">
                <Zap className="h-4 w-4" />
                Launch Scenario Builder
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="efficiency" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Channel Efficiency Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={efficiencyMetrics} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
                  <YAxis type="category" dataKey="channel" className="text-xs" width={100} />
                  <Tooltip formatter={(value) => [`${value}%`, '']} />
                  <Bar dataKey="efficiency" fill="hsl(var(--chart-1))" name="Current Efficiency" />
                  <Bar dataKey="benchmark" fill="hsl(var(--chart-2))" name="Industry Benchmark" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-5">
            {efficiencyMetrics.map((metric) => (
              <Card key={metric.channel}>
                <CardContent className="pt-6">
                  <h4 className="font-medium text-sm">{metric.channel}</h4>
                  <div className="mt-2">
                    <div className="flex items-end gap-1">
                      <span className="text-2xl font-bold">{metric.efficiency}%</span>
                      <span
                        className={`text-xs mb-1 ${metric.efficiency >= metric.benchmark ? 'text-success' : 'text-destructive'}`}
                      >
                        {metric.efficiency >= metric.benchmark ? '↑' : '↓'} vs {metric.benchmark}%
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Wasted: ${(metric.wasted / 1000).toFixed(1)}K/mo
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-success" />
                Total Recovery Opportunity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-8">
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Waste Identified</p>
                  <p className="text-4xl font-bold text-destructive">$17.3K</p>
                </div>
                <ArrowRight className="h-8 w-8 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Recoverable with Optimization</p>
                  <p className="text-4xl font-bold text-success">$14.8K</p>
                </div>
                <Button size="lg" className="gap-2 ml-auto">
                  <Sparkles className="h-5 w-5" />
                  Start Recovery Plan
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="radar" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Radar Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={radarData}>
                  <PolarGrid className="stroke-muted" />
                  <PolarAngleAxis dataKey="category" className="text-xs" />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} className="text-xs" />
                  <Radar
                    name="Current"
                    dataKey="current"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.3}
                  />
                  <Radar
                    name="Optimal"
                    dataKey="optimal"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.1}
                    strokeDasharray="5 5"
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
              <div className="flex items-center justify-center gap-8 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-chart-1" />
                  <span className="text-sm">Current Performance</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-chart-2 border-2 border-dashed border-chart-2" />
                  <span className="text-sm">Optimal Target</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
