import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertTriangle,
  Bell,
  BellOff,
  Mail,
  MessageSquare,
  Smartphone,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Percent,
  Clock,
  Shield,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
} from 'lucide-react';
import { useState } from 'react';

interface BudgetAlert {
  id: string;
  name: string;
  type: 'overspend' | 'underspend' | 'roas' | 'pace' | 'threshold' | 'anomaly';
  condition: string;
  threshold: number;
  channels: string[];
  notifications: ('email' | 'sms' | 'slack' | 'in-app')[];
  enabled: boolean;
  triggered: number;
  lastTriggered?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

const mockAlerts: BudgetAlert[] = [
  {
    id: '1',
    name: 'Daily Overspend Alert',
    type: 'overspend',
    condition: 'Daily spend exceeds target by',
    threshold: 15,
    channels: ['Google Ads', 'Meta Ads'],
    notifications: ['email', 'slack', 'in-app'],
    enabled: true,
    triggered: 8,
    lastTriggered: '2 hours ago',
    severity: 'high',
  },
  {
    id: '2',
    name: 'ROAS Drop Warning',
    type: 'roas',
    condition: 'ROAS drops below',
    threshold: 3.5,
    channels: ['All Channels'],
    notifications: ['email', 'in-app'],
    enabled: true,
    triggered: 3,
    lastTriggered: 'Yesterday',
    severity: 'medium',
  },
  {
    id: '3',
    name: 'Budget Exhaustion Alert',
    type: 'threshold',
    condition: 'Monthly budget utilization exceeds',
    threshold: 85,
    channels: ['All Channels'],
    notifications: ['email', 'sms', 'slack', 'in-app'],
    enabled: true,
    triggered: 1,
    lastTriggered: '3 days ago',
    severity: 'critical',
  },
  {
    id: '4',
    name: 'Underspend Detection',
    type: 'underspend',
    condition: 'Daily spend is below target by',
    threshold: 20,
    channels: ['TikTok Ads', 'Programmatic'],
    notifications: ['email'],
    enabled: false,
    triggered: 5,
    severity: 'low',
  },
  {
    id: '5',
    name: 'Pacing Anomaly Detection',
    type: 'anomaly',
    condition: 'Spend pattern deviates from normal by',
    threshold: 25,
    channels: ['All Channels'],
    notifications: ['slack', 'in-app'],
    enabled: true,
    triggered: 2,
    lastTriggered: '5 hours ago',
    severity: 'medium',
  },
];

const recentNotifications = [
  { id: 1, message: 'Meta Ads overspent by 18% today', time: '2 hours ago', severity: 'high', read: false },
  { id: 2, message: 'TikTok ROAS improved to 7.2x', time: '4 hours ago', severity: 'low', read: true },
  {
    id: 3,
    message: 'Monthly budget 78% utilized with 8 days left',
    time: '6 hours ago',
    severity: 'medium',
    read: true,
  },
  { id: 4, message: 'Google Ads pacing on track', time: 'Yesterday', severity: 'low', read: true },
  { id: 5, message: 'Anomaly detected in Programmatic spend', time: 'Yesterday', severity: 'medium', read: true },
];

const getAlertIcon = (type: string) => {
  switch (type) {
    case 'overspend':
      return <TrendingUp className="h-5 w-5 text-destructive" />;
    case 'underspend':
      return <TrendingDown className="h-5 w-5 text-warning" />;
    case 'roas':
      return <Percent className="h-5 w-5 text-chart-1" />;
    case 'pace':
      return <Clock className="h-5 w-5 text-chart-2" />;
    case 'threshold':
      return <DollarSign className="h-5 w-5 text-chart-3" />;
    case 'anomaly':
      return <Shield className="h-5 w-5 text-chart-4" />;
    default:
      return <AlertTriangle className="h-5 w-5" />;
  }
};

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'critical':
      return 'bg-destructive/10 text-destructive border-destructive/30';
    case 'high':
      return 'bg-warning/10 text-warning border-warning/30';
    case 'medium':
      return 'bg-chart-1/10 text-chart-1 border-chart-1/30';
    case 'low':
      return 'bg-success/10 text-success border-success/30';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

export function BudgetAlertsPanel() {
  const [alerts, setAlerts] = useState(mockAlerts);
  const [showCreateForm, setShowCreateForm] = useState(false);

  const toggleAlert = (id: string) => {
    setAlerts((prev) => prev.map((alert) => (alert.id === id ? { ...alert, enabled: !alert.enabled } : alert)));
  };

  const activeAlerts = alerts.filter((a) => a.enabled).length;
  const totalTriggered = alerts.reduce((sum, a) => sum + a.triggered, 0);

  return (
    <div className="space-y-6">
      {/* Alert Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Alerts</p>
                <p className="text-3xl font-bold">{activeAlerts}</p>
              </div>
              <Bell className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">of {alerts.length} configured</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Times Triggered</p>
                <p className="text-3xl font-bold">{totalTriggered}</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-warning" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unread Notifications</p>
                <p className="text-3xl font-bold">{recentNotifications.filter((n) => !n.read).length}</p>
              </div>
              <MessageSquare className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Response Time</p>
                <p className="text-3xl font-bold">4.2m</p>
              </div>
              <Clock className="h-10 w-10 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Avg. alert response</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Alert Configuration */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Configured Alerts</h3>
            <Button size="sm" className="gap-2" onClick={() => setShowCreateForm(!showCreateForm)}>
              <Plus className="h-4 w-4" />
              Create Alert
            </Button>
          </div>

          {showCreateForm && (
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="text-base">Create New Alert</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Alert Name</Label>
                    <Input placeholder="e.g., Weekend Overspend Alert" />
                  </div>
                  <div className="space-y-2">
                    <Label>Alert Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="overspend">Overspend Alert</SelectItem>
                        <SelectItem value="underspend">Underspend Alert</SelectItem>
                        <SelectItem value="roas">ROAS Threshold</SelectItem>
                        <SelectItem value="pace">Pacing Alert</SelectItem>
                        <SelectItem value="threshold">Budget Threshold</SelectItem>
                        <SelectItem value="anomaly">Anomaly Detection</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Threshold Value</Label>
                    <Input type="number" placeholder="e.g., 15" />
                  </div>
                  <div className="space-y-2">
                    <Label>Severity Level</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select severity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Notification Channels</Label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" className="rounded" defaultChecked />
                      <Mail className="h-4 w-4" /> Email
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" className="rounded" />
                      <Smartphone className="h-4 w-4" /> SMS
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" className="rounded" defaultChecked />
                      <MessageSquare className="h-4 w-4" /> Slack
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input type="checkbox" className="rounded" defaultChecked />
                      <Bell className="h-4 w-4" /> In-App
                    </label>
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancel
                  </Button>
                  <Button>Create Alert</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {alerts.map((alert) => (
            <Card key={alert.id} className={`transition-all ${!alert.enabled ? 'opacity-60' : ''}`}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${getSeverityColor(alert.severity)}`}>
                      {getAlertIcon(alert.type)}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{alert.name}</h4>
                        <Badge variant="outline" className="capitalize">
                          {alert.type}
                        </Badge>
                        <Badge className={getSeverityColor(alert.severity).replace('bg-', 'bg-').replace('/10', '/20')}>
                          {alert.severity}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {alert.condition}{' '}
                        <span className="font-semibold">
                          {alert.threshold}
                          {alert.type === 'roas' ? 'x' : '%'}
                        </span>
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Channels: {alert.channels.join(', ')}</span>
                        <span>•</span>
                        <span>Triggered {alert.triggered}x this month</span>
                        {alert.lastTriggered && (
                          <>
                            <span>•</span>
                            <span>Last: {alert.lastTriggered}</span>
                          </>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        {alert.notifications.includes('email') && <Mail className="h-4 w-4 text-muted-foreground" />}
                        {alert.notifications.includes('sms') && (
                          <Smartphone className="h-4 w-4 text-muted-foreground" />
                        )}
                        {alert.notifications.includes('slack') && (
                          <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        )}
                        {alert.notifications.includes('in-app') && <Bell className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                    <Switch checked={alert.enabled} onCheckedChange={() => toggleAlert(alert.id)} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              Recent Notifications
              <Button variant="ghost" size="sm">
                Mark all read
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-3 rounded-lg border ${!notification.read ? 'bg-primary/5 border-primary/20' : 'bg-muted/30'}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${
                        notification.severity === 'high'
                          ? 'bg-destructive'
                          : notification.severity === 'medium'
                            ? 'bg-warning'
                            : 'bg-success'
                      }`}
                    />
                    <div>
                      <p className={`text-sm ${!notification.read ? 'font-medium' : ''}`}>{notification.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                    </div>
                  </div>
                  {!notification.read && (
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <CheckCircle2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
