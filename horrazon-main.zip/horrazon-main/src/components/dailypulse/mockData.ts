import { TrendingUp, DollarSign, ShoppingCart, MousePointerClick, Sun, Snowflake, Calendar, Zap } from 'lucide-react';
import {
  KPIData,
  CampaignData,
  Alert,
  Insight,
  ExternalFactor,
  RealtimeMetric,
  AutomationRule,
  ScheduledReport,
  Forecast,
} from './types';

export const generateSparkline = (baseValue: number, trend: number) => {
  return Array.from({ length: 7 }, (_, i) => ({
    value: baseValue + Math.random() * trend * (i + 1) - trend / 2,
  }));
};

export const generateForecast = (baseValue: number, days: number): Forecast[] => {
  const forecasts: Forecast[] = [];
  const now = new Date();

  for (let i = 0; i < days; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() + i);
    const predicted = baseValue * (1 + (Math.random() * 0.1 - 0.05) + i * 0.01);
    const variance = predicted * 0.1;

    forecasts.push({
      date: date.toISOString().split('T')[0],
      predicted: Math.round(predicted),
      upperBound: Math.round(predicted + variance),
      lowerBound: Math.round(predicted - variance),
      actual: i < 3 ? Math.round(predicted * (0.95 + Math.random() * 0.1)) : undefined,
    });
  }

  return forecasts;
};

export const kpisData: KPIData[] = [
  {
    title: 'ROAS',
    value: '4.2x',
    change: '+12%',
    trend: 'up',
    icon: TrendingUp,
    sparklineData: generateSparkline(3.8, 0.6),
    goal: 5,
    current: 4.2,
    anomaly: null,
    forecast: 4.6,
    confidence: 85,
  },
  {
    title: 'Spend',
    value: '$24.5K',
    change: '+8%',
    trend: 'up',
    icon: DollarSign,
    sparklineData: generateSparkline(22000, 3000),
    goal: 30000,
    current: 24500,
    anomaly: null,
    forecast: 28000,
    confidence: 78,
  },
  {
    title: 'Conversions',
    value: '1,248',
    change: '+15%',
    trend: 'up',
    icon: ShoppingCart,
    sparklineData: generateSparkline(1100, 200),
    goal: 1500,
    current: 1248,
    anomaly: null,
    forecast: 1420,
    confidence: 82,
  },
  {
    title: 'CPC',
    value: '$2.34',
    change: '-5%',
    trend: 'down',
    icon: MousePointerClick,
    sparklineData: generateSparkline(2.5, -0.3),
    anomaly: 'warning',
    forecast: 2.28,
    confidence: 72,
  },
];

export const campaignsData: CampaignData[] = [
  {
    name: 'Summer Sale 2024',
    revenue: 124000,
    spend: 28000,
    roas: 4.4,
    conversions: 1240,
    clicks: 45000,
    impressions: 890000,
    ctr: 5.1,
    status: 'active',
    trend: 'up',
    platform: 'Meta Ads',
  },
  {
    name: 'Brand Awareness',
    revenue: 89000,
    spend: 32000,
    roas: 2.8,
    conversions: 890,
    clicks: 62000,
    impressions: 1250000,
    ctr: 4.96,
    status: 'active',
    trend: 'stable',
    platform: 'Google Ads',
  },
  {
    name: 'Product Launch Q4',
    revenue: 152000,
    spend: 41000,
    roas: 3.7,
    conversions: 1520,
    clicks: 78000,
    impressions: 1560000,
    ctr: 5.0,
    status: 'active',
    trend: 'up',
    platform: 'Meta Ads',
  },
  {
    name: 'Retargeting - Cart Abandonment',
    revenue: 67000,
    spend: 15000,
    roas: 4.5,
    conversions: 670,
    clicks: 28000,
    impressions: 420000,
    ctr: 6.7,
    status: 'active',
    trend: 'up',
    platform: 'Meta Ads',
  },
  {
    name: 'Holiday Promo Early Bird',
    revenue: 98000,
    spend: 22000,
    roas: 4.5,
    conversions: 980,
    clicks: 52000,
    impressions: 780000,
    ctr: 6.67,
    status: 'active',
    trend: 'up',
    platform: 'TikTok Ads',
  },
  {
    name: 'B2B Lead Gen',
    revenue: 45000,
    spend: 18000,
    roas: 2.5,
    conversions: 450,
    clicks: 12000,
    impressions: 340000,
    ctr: 3.53,
    status: 'paused',
    trend: 'down',
    platform: 'LinkedIn Ads',
  },
];

export const alertsData: Alert[] = [
  {
    id: 'alert-1',
    severity: 'warning',
    message: 'Meta Ads CPC increased by 28% in the last 2 hours - Immediate action recommended',
    timestamp: new Date(Date.now() - 15 * 60000),
    action: {
      label: 'Pause Low ROAS Ads',
      icon: 'pause',
      onClick: () => {},
    },
  },
  {
    id: 'alert-2',
    severity: 'warning',
    message: '3 campaigns approaching daily budget limit - Budget will be exhausted by 6 PM',
    timestamp: new Date(Date.now() - 45 * 60000),
    action: {
      label: 'Increase Budget',
      icon: 'optimize',
      onClick: () => {},
    },
  },
  {
    id: 'alert-3',
    severity: 'success',
    message: 'Google Ads ROAS improved by 22% this week - Scale opportunity detected',
    timestamp: new Date(Date.now() - 2 * 3600000),
    action: {
      label: 'Scale Campaign',
      icon: 'optimize',
      onClick: () => {},
    },
  },
  {
    id: 'alert-4',
    severity: 'info',
    message: 'New audience segment performing 35% better than control group',
    timestamp: new Date(Date.now() - 4 * 3600000),
    action: {
      label: 'Expand Audience',
      icon: 'play',
      onClick: () => {},
    },
  },
];

export const insightsData: Insight[] = [
  {
    id: 'insight-1',
    content:
      'Your best performing time is 2-4 PM on weekdays. Consider increasing bids during this window for 15-20% higher conversions.',
    category: 'optimization',
    impact: 'high',
    actionable: true,
    relatedMetric: 'conversions',
  },
  {
    id: 'insight-2',
    content:
      'Retargeting campaigns show 3x higher conversion rate. Recommend allocating 15% more budget to this segment.',
    category: 'opportunity',
    impact: 'high',
    actionable: true,
    relatedMetric: 'roas',
  },
  {
    id: 'insight-3',
    content:
      'Mobile traffic converting 42% better than desktop. Optimize ad creative for mobile viewing and consider mobile-first landing pages.',
    category: 'trend',
    impact: 'medium',
    actionable: true,
    relatedMetric: 'conversions',
  },
  {
    id: 'insight-4',
    content:
      'Black Friday approaching in 12 days - Historical data shows 3x increase in conversion rate during this period.',
    category: 'opportunity',
    impact: 'high',
    actionable: true,
  },
  {
    id: 'insight-5',
    content: 'Competitor ad spend in your category increased 45% this week. Monitor CPC trends closely.',
    category: 'warning',
    impact: 'medium',
    actionable: false,
  },
];

export const externalFactorsData: ExternalFactor[] = [
  {
    icon: Sun,
    label: 'Sunny Weekend Forecast',
    impact: '+8% traffic expected',
    color: 'text-yellow-500',
    confidence: 75,
  },
  {
    icon: Snowflake,
    label: 'Holiday Season Active',
    impact: '+15% conversions',
    color: 'text-blue-500',
    confidence: 88,
  },
  { icon: Calendar, label: 'Black Friday -12 days', impact: '+200% expected', color: 'text-primary', confidence: 92 },
  {
    icon: Zap,
    label: 'Flash Sale Competitor',
    impact: '-5% share of voice',
    color: 'text-destructive',
    confidence: 65,
  },
];

export const realtimeMetrics: RealtimeMetric[] = [
  { label: 'Active Sessions', value: 2847, previousValue: 2650, unit: '', lastUpdated: new Date() },
  { label: 'Revenue Today', value: 34520, previousValue: 31200, unit: '$', lastUpdated: new Date() },
  { label: 'Conversions Today', value: 127, previousValue: 112, unit: '', lastUpdated: new Date() },
  { label: 'Current CPC', value: 2.34, previousValue: 2.41, unit: '$', lastUpdated: new Date() },
  { label: 'Cart Adds (1h)', value: 89, previousValue: 76, unit: '', lastUpdated: new Date() },
];

export const automationRules: AutomationRule[] = [
  {
    id: 'rule-1',
    name: 'Pause Low ROAS Campaigns',
    trigger: { metric: 'roas', condition: 'below', threshold: 2.0 },
    action: { type: 'pause', params: { duration: '24h' } },
    enabled: true,
    lastTriggered: new Date(Date.now() - 86400000),
  },
  {
    id: 'rule-2',
    name: 'Scale High Performers',
    trigger: { metric: 'roas', condition: 'above', threshold: 4.5 },
    action: { type: 'scale', params: { increase: 20 } },
    enabled: true,
  },
  {
    id: 'rule-3',
    name: 'CPC Alert',
    trigger: { metric: 'cpc', condition: 'change', threshold: 15 },
    action: { type: 'notify', params: { channel: 'slack' } },
    enabled: true,
    lastTriggered: new Date(Date.now() - 3600000),
  },
];

export const scheduledReports: ScheduledReport[] = [
  {
    id: 'report-1',
    name: 'Daily Performance Summary',
    frequency: 'daily',
    recipients: ['marketing@company.com', 'ceo@company.com'],
    metrics: ['roas', 'spend', 'conversions', 'revenue'],
    nextRun: new Date(Date.now() + 43200000),
    enabled: true,
  },
  {
    id: 'report-2',
    name: 'Weekly Campaign Analysis',
    frequency: 'weekly',
    recipients: ['marketing@company.com'],
    metrics: ['campaign_performance', 'audience_insights', 'budget_utilization'],
    nextRun: new Date(Date.now() + 259200000),
    enabled: true,
  },
];
