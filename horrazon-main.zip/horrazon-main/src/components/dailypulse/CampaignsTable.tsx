import { useState } from 'react';
import { TrendingUp, TrendingDown, Minus, ArrowUpDown, ChevronDown, Filter, Search, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CampaignData } from './types';
import { campaignsData } from './mockData';
import { cn } from '@/lib/utils';

interface CampaignsTableProps {
  onCampaignClick: (campaign: CampaignData) => void;
}

type SortField = 'name' | 'revenue' | 'spend' | 'roas' | 'conversions' | 'ctr';
type SortOrder = 'asc' | 'desc';

export function CampaignsTable({ onCampaignClick }: CampaignsTableProps) {
  const [campaigns] = useState<CampaignData[]>(campaignsData);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('revenue');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [statusFilter, setStatusFilter] = useState<string[]>(['active', 'paused']);
  const [platformFilter, setPlatformFilter] = useState<string[]>([]);

  const platforms = Array.from(new Set(campaigns.map((c) => c.platform)));

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const filteredCampaigns = campaigns
    .filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .filter((c) => statusFilter.includes(c.status))
    .filter((c) => platformFilter.length === 0 || platformFilter.includes(c.platform))
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const modifier = sortOrder === 'asc' ? 1 : -1;
      if (typeof aValue === 'string') {
        return aValue.localeCompare(bValue as string) * modifier;
      }
      return ((aValue as number) - (bValue as number)) * modifier;
    });

  const TrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-3 w-3 text-success" />;
      case 'down':
        return <TrendingDown className="h-3 w-3 text-destructive" />;
      default:
        return <Minus className="h-3 w-3 text-muted-foreground" />;
    }
  };

  return (
    <Card className="border-border/50 shadow-md">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Campaign Performance</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search campaigns..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 h-8 w-48"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-8">
                  <Filter className="h-4 w-4 mr-1" /> Status
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuCheckboxItem
                  checked={statusFilter.includes('active')}
                  onCheckedChange={(checked) => {
                    setStatusFilter((prev) => (checked ? [...prev, 'active'] : prev.filter((s) => s !== 'active')));
                  }}
                >
                  Active
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={statusFilter.includes('paused')}
                  onCheckedChange={(checked) => {
                    setStatusFilter((prev) => (checked ? [...prev, 'paused'] : prev.filter((s) => s !== 'paused')));
                  }}
                >
                  Paused
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={statusFilter.includes('ended')}
                  onCheckedChange={(checked) => {
                    setStatusFilter((prev) => (checked ? [...prev, 'ended'] : prev.filter((s) => s !== 'ended')));
                  }}
                >
                  Ended
                </DropdownMenuCheckboxItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-8">
                  Platform
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {platforms.map((platform) => (
                  <DropdownMenuCheckboxItem
                    key={platform}
                    checked={platformFilter.includes(platform)}
                    onCheckedChange={(checked) => {
                      setPlatformFilter((prev) => (checked ? [...prev, platform] : prev.filter((p) => p !== platform)));
                    }}
                  >
                    {platform}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[250px]">
                <Button variant="ghost" className="h-8 px-2 -ml-2 font-medium" onClick={() => handleSort('name')}>
                  Campaign
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" className="h-8 px-2 font-medium" onClick={() => handleSort('revenue')}>
                  Revenue
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" className="h-8 px-2 font-medium" onClick={() => handleSort('spend')}>
                  Spend
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" className="h-8 px-2 font-medium" onClick={() => handleSort('roas')}>
                  ROAS
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" className="h-8 px-2 font-medium" onClick={() => handleSort('conversions')}>
                  Conv.
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" className="h-8 px-2 font-medium" onClick={() => handleSort('ctr')}>
                  CTR
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </Button>
              </TableHead>
              <TableHead className="text-center">Trend</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCampaigns.map((campaign) => (
              <TableRow
                key={campaign.name}
                className="cursor-pointer hover:bg-accent/50"
                onClick={() => onCampaignClick(campaign)}
              >
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        'w-2 h-2 rounded-full',
                        campaign.status === 'active'
                          ? 'bg-success'
                          : campaign.status === 'paused'
                            ? 'bg-yellow-500'
                            : 'bg-muted-foreground',
                      )}
                    />
                    <div>
                      <p className="font-medium text-sm">{campaign.name}</p>
                      <p className="text-xs text-muted-foreground">{campaign.platform}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-right font-medium">${(campaign.revenue / 1000).toFixed(1)}K</TableCell>
                <TableCell className="text-right text-muted-foreground">
                  ${(campaign.spend / 1000).toFixed(1)}K
                </TableCell>
                <TableCell className="text-right">
                  <Badge
                    variant={campaign.roas >= 4 ? 'default' : campaign.roas >= 2.5 ? 'secondary' : 'destructive'}
                    className={cn(campaign.roas >= 4 && 'bg-success text-success-foreground')}
                  >
                    {campaign.roas}x
                  </Badge>
                </TableCell>
                <TableCell className="text-right">{campaign.conversions.toLocaleString()}</TableCell>
                <TableCell className="text-right">{campaign.ctr}%</TableCell>
                <TableCell className="text-center">{TrendIcon(campaign.trend)}</TableCell>
                <TableCell>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Eye className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
