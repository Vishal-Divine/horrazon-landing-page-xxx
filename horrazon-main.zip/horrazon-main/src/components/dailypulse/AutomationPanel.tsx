import { useState } from 'react';
import {
  Zap,
  Plus,
  Settings,
  Pause,
  Play,
  Trash2,
  Bell,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  Mail,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { automationRules, scheduledReports } from './mockData';
import { AutomationRule, ScheduledReport } from './types';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

export function AutomationPanel() {
  const [rules, setRules] = useState<AutomationRule[]>(automationRules);
  const [reports, setReports] = useState<ScheduledReport[]>(scheduledReports);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('rules');

  const toggleRule = (ruleId: string) => {
    setRules((prev) => prev.map((r) => (r.id === ruleId ? { ...r, enabled: !r.enabled } : r)));
    toast({
      title: 'Rule Updated',
      description: 'Automation rule has been updated',
    });
  };

  const toggleReport = (reportId: string) => {
    setReports((prev) => prev.map((r) => (r.id === reportId ? { ...r, enabled: !r.enabled } : r)));
  };

  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case 'above':
        return TrendingUp;
      case 'below':
        return TrendingDown;
      case 'change':
        return AlertTriangle;
      default:
        return AlertTriangle;
    }
  };

  const getActionIcon = (actionType: string) => {
    switch (actionType) {
      case 'pause':
        return Pause;
      case 'scale':
        return TrendingUp;
      case 'notify':
        return Bell;
      case 'adjust_bid':
        return Settings;
      default:
        return Zap;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  return (
    <Card className="border-border/50 shadow-md">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Automation & Scheduling</CardTitle>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" /> New Rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Automation Rule</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Rule Name</Label>
                  <Input placeholder="e.g., Pause Low ROAS Campaigns" />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label>Metric</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="roas">ROAS</SelectItem>
                        <SelectItem value="cpc">CPC</SelectItem>
                        <SelectItem value="ctr">CTR</SelectItem>
                        <SelectItem value="conversions">Conversions</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Condition</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="above">Above</SelectItem>
                        <SelectItem value="below">Below</SelectItem>
                        <SelectItem value="change">Changes by</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Threshold</Label>
                    <Input type="number" placeholder="2.0" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Action</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select action" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pause">Pause Campaign</SelectItem>
                      <SelectItem value="scale">Scale Budget</SelectItem>
                      <SelectItem value="notify">Send Notification</SelectItem>
                      <SelectItem value="adjust_bid">Adjust Bid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="w-full"
                  onClick={() => {
                    setIsCreateOpen(false);
                    toast({
                      title: 'Rule Created',
                      description: 'Your automation rule has been created',
                    });
                  }}
                >
                  Create Rule
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="rules">
              <Zap className="h-4 w-4 mr-1" /> Rules ({rules.length})
            </TabsTrigger>
            <TabsTrigger value="reports">
              <Calendar className="h-4 w-4 mr-1" /> Reports ({reports.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rules" className="space-y-3">
            {rules.map((rule) => {
              const ConditionIcon = getConditionIcon(rule.trigger.condition);
              const ActionIcon = getActionIcon(rule.action.type);

              return (
                <div
                  key={rule.id}
                  className={cn(
                    'p-3 rounded-lg border transition-all',
                    rule.enabled
                      ? 'bg-card border-border/50 hover:border-primary/30'
                      : 'bg-muted/30 border-border/30 opacity-60',
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn('p-2 rounded-lg', rule.enabled ? 'bg-primary/10' : 'bg-muted')}>
                        <Zap className={cn('h-4 w-4', rule.enabled ? 'text-primary' : 'text-muted-foreground')} />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{rule.name}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                          <span className="flex items-center gap-1">
                            <ConditionIcon className="h-3 w-3" />
                            {rule.trigger.metric.toUpperCase()} {rule.trigger.condition} {rule.trigger.threshold}
                          </span>
                          <span>→</span>
                          <span className="flex items-center gap-1">
                            <ActionIcon className="h-3 w-3" />
                            {rule.action.type.replace('_', ' ')}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {rule.lastTriggered && (
                        <Badge variant="outline" className="text-xs">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatTimeAgo(rule.lastTriggered)}
                        </Badge>
                      )}
                      <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                    </div>
                  </div>
                </div>
              );
            })}
          </TabsContent>

          <TabsContent value="reports" className="space-y-3">
            {reports.map((report) => (
              <div
                key={report.id}
                className={cn(
                  'p-3 rounded-lg border transition-all',
                  report.enabled
                    ? 'bg-card border-border/50 hover:border-primary/30'
                    : 'bg-muted/30 border-border/30 opacity-60',
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn('p-2 rounded-lg', report.enabled ? 'bg-primary/10' : 'bg-muted')}>
                      <Mail className={cn('h-4 w-4', report.enabled ? 'text-primary' : 'text-muted-foreground')} />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{report.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <Badge variant="secondary" className="text-[10px] py-0">
                          {report.frequency}
                        </Badge>
                        <span>•</span>
                        <span>{report.recipients.length} recipients</span>
                        <span>•</span>
                        <span>{report.metrics.length} metrics</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-[10px] text-muted-foreground">Next run</p>
                      <p className="text-xs font-medium">
                        {new Date(report.nextRun).toLocaleDateString('en', {
                          weekday: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                    <Switch checked={report.enabled} onCheckedChange={() => toggleReport(report.id)} />
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" size="sm">
              <Plus className="h-4 w-4 mr-1" /> Schedule New Report
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
