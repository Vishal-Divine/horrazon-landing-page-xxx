import { useState } from 'react';
import { TrendingUp, Calendar, Target, Info } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend,
} from 'recharts';
import { generateForecast } from './mockData';
import { cn } from '@/lib/utils';

const metricOptions = [
  { id: 'revenue', label: 'Revenue', unit: '$' },
  { id: 'conversions', label: 'Conversions', unit: '' },
  { id: 'roas', label: 'ROAS', unit: 'x' },
  { id: 'spend', label: 'Spend', unit: '$' },
];

export function ForecastPanel() {
  const [selectedMetric, setSelectedMetric] = useState('revenue');
  const [forecastDays, setForecastDays] = useState(14);

  const baseValues: Record<string, number> = {
    revenue: 125000,
    conversions: 1248,
    roas: 4.2,
    spend: 24500,
  };

  const forecastData = generateForecast(baseValues[selectedMetric], forecastDays);
  const metric = metricOptions.find((m) => m.id === selectedMetric)!;

  const formatValue = (value: number) => {
    if (metric.unit === '$') {
      return `$${(value / 1000).toFixed(1)}K`;
    }
    if (metric.id === 'roas') {
      return `${value.toFixed(2)}x`;
    }
    return value.toLocaleString();
  };

  // Calculate forecast summary
  const lastActual = forecastData.filter((d) => d.actual).pop();
  const lastForecast = forecastData[forecastData.length - 1];
  const expectedGrowth = lastActual
    ? (((lastForecast.predicted - lastActual.actual!) / lastActual.actual!) * 100).toFixed(1)
    : '0';

  return (
    <Card className="border-border/50 shadow-md">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">AI-Powered Forecasting</CardTitle>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs text-xs">
                    Forecasts are generated using machine learning models trained on your historical data, seasonality
                    patterns, and external factors.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              <Target className="h-3 w-3 mr-1" />
              82% Accuracy
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* Metric Selector */}
        <div className="flex items-center justify-between">
          <Tabs value={selectedMetric} onValueChange={setSelectedMetric}>
            <TabsList className="h-8">
              {metricOptions.map((m) => (
                <TabsTrigger key={m.id} value={m.id} className="text-xs px-3 h-6">
                  {m.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
          <div className="flex items-center gap-1">
            {[7, 14, 30].map((days) => (
              <Button
                key={days}
                variant={forecastDays === days ? 'default' : 'ghost'}
                size="sm"
                className="h-7 px-2 text-xs"
                onClick={() => setForecastDays(days)}
              >
                {days}d
              </Button>
            ))}
          </div>
        </div>

        {/* Forecast Summary */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-accent/30 border border-border/30">
            <p className="text-xs text-muted-foreground">Current</p>
            <p className="text-lg font-bold">{formatValue(baseValues[selectedMetric])}</p>
          </div>
          <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
            <p className="text-xs text-muted-foreground">Forecast ({forecastDays}d)</p>
            <p className="text-lg font-bold text-primary">{formatValue(lastForecast.predicted)}</p>
          </div>
          <div
            className={cn(
              'p-3 rounded-lg border',
              Number(expectedGrowth) >= 0
                ? 'bg-success/10 border-success/20'
                : 'bg-destructive/10 border-destructive/20',
            )}
          >
            <p className="text-xs text-muted-foreground">Expected Growth</p>
            <p className={cn('text-lg font-bold', Number(expectedGrowth) >= 0 ? 'text-success' : 'text-destructive')}>
              {Number(expectedGrowth) >= 0 ? '+' : ''}
              {expectedGrowth}%
            </p>
          </div>
        </div>

        {/* Forecast Chart */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={forecastData}>
              <defs>
                <linearGradient id="forecastGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis
                dataKey="date"
                stroke="hsl(var(--muted-foreground))"
                fontSize={10}
                tickFormatter={(value) => new Date(value).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
              />
              <YAxis
                stroke="hsl(var(--muted-foreground))"
                fontSize={10}
                tickFormatter={(value) => formatValue(value)}
              />
              <RechartsTooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 'var(--radius)',
                }}
                formatter={(value: number, name: string) => [formatValue(value), name]}
              />
              <Legend />
              {/* Confidence interval */}
              <Area
                type="monotone"
                dataKey="upperBound"
                stroke="transparent"
                fill="hsl(var(--primary))"
                fillOpacity={0.1}
                name="Upper Bound"
              />
              <Area
                type="monotone"
                dataKey="lowerBound"
                stroke="transparent"
                fill="hsl(var(--background))"
                name="Lower Bound"
              />
              {/* Predicted line */}
              <Area
                type="monotone"
                dataKey="predicted"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                strokeDasharray="5 5"
                fill="url(#forecastGradient)"
                name="Forecast"
              />
              {/* Actual data */}
              <Area
                type="monotone"
                dataKey="actual"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                fill="url(#actualGradient)"
                name="Actual"
              />
              <ReferenceLine
                x={forecastData.filter((d) => d.actual).pop()?.date}
                stroke="hsl(var(--muted-foreground))"
                strokeDasharray="3 3"
                label={{ value: 'Today', fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Insights */}
        <div className="p-3 rounded-lg bg-accent/30 border border-border/30">
          <p className="text-xs text-muted-foreground mb-1">AI Insight</p>
          <p className="text-sm">
            Based on current trends and upcoming holiday season, we predict a{' '}
            <span className="font-semibold text-success">+{expectedGrowth}%</span> increase in{' '}
            {metric.label.toLowerCase()}. Consider increasing budget allocation to maximize this opportunity.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
