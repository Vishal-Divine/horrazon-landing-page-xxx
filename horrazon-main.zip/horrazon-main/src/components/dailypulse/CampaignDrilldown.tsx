import { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ExternalLink,
  Pause,
  Play,
  BarChart3,
  Target,
  MousePointerClick,
  Eye,
  DollarSign,
  ArrowRight,
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { CampaignData } from './types';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface CampaignDrilldownProps {
  campaign: CampaignData | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const performanceData = [
  { date: 'Mon', revenue: 15200, spend: 3400, conversions: 152 },
  { date: 'Tue', revenue: 18400, spend: 3800, conversions: 184 },
  { date: 'Wed', revenue: 16800, spend: 3600, conversions: 168 },
  { date: 'Thu', revenue: 21200, spend: 4200, conversions: 212 },
  { date: 'Fri', revenue: 19600, spend: 4000, conversions: 196 },
  { date: 'Sat', revenue: 24000, spend: 4800, conversions: 240 },
  { date: 'Sun', revenue: 22400, spend: 4600, conversions: 224 },
];

const audienceData = [
  { name: '18-24', value: 15, color: 'hsl(var(--chart-1))' },
  { name: '25-34', value: 35, color: 'hsl(var(--chart-2))' },
  { name: '35-44', value: 28, color: 'hsl(var(--chart-3))' },
  { name: '45-54', value: 14, color: 'hsl(var(--chart-4))' },
  { name: '55+', value: 8, color: 'hsl(var(--chart-5))' },
];

const adSets = [
  { name: 'Lookalike - Purchasers', spend: 8500, roas: 5.2, status: 'active' },
  { name: 'Interest - Fashion', spend: 6200, roas: 3.8, status: 'active' },
  { name: 'Retargeting - 7 days', spend: 4800, roas: 6.1, status: 'active' },
  { name: 'Broad Targeting', spend: 8500, roas: 2.4, status: 'paused' },
];

export function CampaignDrilldown({ campaign, open, onOpenChange }: CampaignDrilldownProps) {
  const [activeTab, setActiveTab] = useState('overview');

  if (!campaign) return null;

  const metrics = [
    {
      label: 'Revenue',
      value: `$${(campaign.revenue / 1000).toFixed(1)}K`,
      icon: DollarSign,
      change: '+12%',
      trend: 'up',
    },
    {
      label: 'ROAS',
      value: `${campaign.roas}x`,
      icon: TrendingUp,
      change: '+8%',
      trend: 'up',
    },
    {
      label: 'Conversions',
      value: campaign.conversions.toLocaleString(),
      icon: Target,
      change: '+15%',
      trend: 'up',
    },
    {
      label: 'CTR',
      value: `${campaign.ctr}%`,
      icon: MousePointerClick,
      change: '-2%',
      trend: 'down',
    },
    {
      label: 'Impressions',
      value: `${(campaign.impressions / 1000000).toFixed(1)}M`,
      icon: Eye,
      change: '+22%',
      trend: 'up',
    },
    {
      label: 'Clicks',
      value: `${(campaign.clicks / 1000).toFixed(1)}K`,
      icon: MousePointerClick,
      change: '+18%',
      trend: 'up',
    },
  ];

  const TrendIcon = campaign.trend === 'up' ? TrendingUp : campaign.trend === 'down' ? TrendingDown : Minus;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DialogTitle className="text-xl">{campaign.name}</DialogTitle>
              <Badge
                variant={campaign.status === 'active' ? 'default' : 'secondary'}
                className={cn(campaign.status === 'active' && 'bg-success text-success-foreground')}
              >
                {campaign.status}
              </Badge>
              <Badge variant="outline">{campaign.platform}</Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  toast({
                    title: campaign.status === 'active' ? 'Campaign Paused' : 'Campaign Resumed',
                    description: `${campaign.name} has been ${campaign.status === 'active' ? 'paused' : 'resumed'}`,
                  });
                }}
              >
                {campaign.status === 'active' ? (
                  <>
                    <Pause className="h-4 w-4 mr-1" /> Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-1" /> Resume
                  </>
                )}
              </Button>
              <Button variant="outline" size="sm">
                <ExternalLink className="h-4 w-4 mr-1" /> Open in Platform
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="audience">Audience</TabsTrigger>
            <TabsTrigger value="adsets">Ad Sets</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            {/* Key Metrics Grid */}
            <div className="grid grid-cols-3 gap-3">
              {metrics.map((metric, i) => (
                <Card key={i} className="border-border/50">
                  <CardContent className="pt-4 pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <metric.icon className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{metric.label}</span>
                      </div>
                      <span
                        className={cn(
                          'text-xs font-medium',
                          metric.trend === 'up' ? 'text-success' : 'text-destructive',
                        )}
                      >
                        {metric.change}
                      </span>
                    </div>
                    <p className="text-xl font-bold mt-1">{metric.value}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Budget Progress */}
            <Card className="border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Budget Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Spent</span>
                    <span className="font-medium">${campaign.spend.toLocaleString()} / $35,000</span>
                  </div>
                  <Progress value={(campaign.spend / 35000) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((campaign.spend / 35000) * 100)}% of monthly budget used
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="mt-4">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-sm font-medium">7-Day Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.2}
                    />
                    <Area
                      type="monotone"
                      dataKey="spend"
                      stroke="hsl(var(--chart-3))"
                      fill="hsl(var(--chart-3))"
                      fillOpacity={0.2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audience" className="mt-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Age Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={audienceData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {audienceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Top Performing Segments</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { segment: '25-34, Female, Mobile', roas: 5.8 },
                    { segment: '35-44, Male, Desktop', roas: 4.2 },
                    { segment: '18-24, Female, iOS', roas: 3.9 },
                  ].map((seg, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-accent/50">
                      <span className="text-sm">{seg.segment}</span>
                      <Badge variant="secondary">{seg.roas}x ROAS</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="adsets" className="mt-4">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-sm font-medium">Ad Set Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {adSets.map((adSet, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:bg-accent/30 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            'w-2 h-2 rounded-full',
                            adSet.status === 'active' ? 'bg-success' : 'bg-muted-foreground',
                          )}
                        />
                        <div>
                          <p className="font-medium text-sm">{adSet.name}</p>
                          <p className="text-xs text-muted-foreground">Spend: ${adSet.spend.toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge
                          variant={adSet.roas >= 4 ? 'default' : adSet.roas >= 2.5 ? 'secondary' : 'destructive'}
                          className={cn(adSet.roas >= 4 && 'bg-success text-success-foreground')}
                        >
                          {adSet.roas}x ROAS
                        </Badge>
                        <Button variant="ghost" size="sm">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
