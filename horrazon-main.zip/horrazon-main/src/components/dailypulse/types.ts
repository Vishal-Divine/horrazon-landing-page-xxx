import { LucideIcon } from 'lucide-react';

export interface KPIData {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: LucideIcon;
  sparklineData: { value: number }[];
  goal?: number;
  current?: number;
  anomaly?: 'warning' | 'critical' | null;
  forecast?: number;
  confidence?: number;
}

export interface CampaignData {
  name: string;
  revenue: number;
  spend: number;
  roas: number;
  conversions: number;
  clicks: number;
  impressions: number;
  ctr: number;
  status: 'active' | 'paused' | 'ended';
  trend: 'up' | 'down' | 'stable';
  platform: string;
}

export interface Alert {
  id: string;
  severity: 'warning' | 'info' | 'success';
  message: string;
  timestamp: Date;
  action: {
    label: string;
    icon: 'pause' | 'play' | 'optimize';
    onClick: () => void;
  };
  isResolved?: boolean;
}

export interface Insight {
  id: string;
  content: string;
  category: 'optimization' | 'opportunity' | 'warning' | 'trend';
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
  relatedMetric?: string;
}

export interface ExternalFactor {
  icon: LucideIcon;
  label: string;
  impact: string;
  color: string;
  confidence: number;
}

export interface RealtimeMetric {
  label: string;
  value: number;
  previousValue: number;
  unit: string;
  lastUpdated: Date;
}

export interface Annotation {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: Date;
  metricId?: string;
  replies?: Annotation[];
}

export interface ScheduledReport {
  id: string;
  name: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  recipients: string[];
  metrics: string[];
  nextRun: Date;
  enabled: boolean;
}

export interface AutomationRule {
  id: string;
  name: string;
  trigger: {
    metric: string;
    condition: 'above' | 'below' | 'change';
    threshold: number;
  };
  action: {
    type: 'pause' | 'scale' | 'notify' | 'adjust_bid';
    params: Record<string, unknown>;
  };
  enabled: boolean;
  lastTriggered?: Date;
}

export interface Forecast {
  date: string;
  predicted: number;
  upperBound: number;
  lowerBound: number;
  actual?: number;
}
