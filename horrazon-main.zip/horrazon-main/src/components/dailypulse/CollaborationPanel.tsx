import { useState } from 'react';
import { Users, MessageSquare, Send, AtSign, Pin, Clock, MoreHorizontal, Reply, Heart, Share2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface Comment {
  id: string;
  user: {
    name: string;
    avatar?: string;
    initials: string;
  };
  content: string;
  timestamp: Date;
  isPinned?: boolean;
  likes: number;
  replies?: Comment[];
  metricRef?: string;
}

const mockComments: Comment[] = [
  {
    id: '1',
    user: { name: 'Sarah Johnson', initials: 'SJ' },
    content: 'Great improvement on ROAS this week! The new audience targeting is working well.',
    timestamp: new Date(Date.now() - 1800000),
    isPinned: true,
    likes: 3,
    metricRef: 'ROAS',
  },
  {
    id: '2',
    user: { name: 'Mike Chen', initials: 'MC' },
    content: '@Sarah Johnson agreed! Should we allocate more budget to the retargeting segment?',
    timestamp: new Date(Date.now() - 3600000),
    likes: 1,
    replies: [
      {
        id: '2-1',
        user: { name: 'Sarah Johnson', initials: 'SJ' },
        content: "Yes, let's increase by 15% and monitor for a week.",
        timestamp: new Date(Date.now() - 1800000),
        likes: 2,
      },
    ],
  },
  {
    id: '3',
    user: { name: 'Alex Rivera', initials: 'AR' },
    content: 'CPC spike alert - investigating the cause. Will update shortly.',
    timestamp: new Date(Date.now() - 7200000),
    likes: 0,
    metricRef: 'CPC',
  },
];

const teamMembers = [
  { name: 'Sarah Johnson', initials: 'SJ', status: 'online' },
  { name: 'Mike Chen', initials: 'MC', status: 'online' },
  { name: 'Alex Rivera', initials: 'AR', status: 'away' },
  { name: 'Jordan Lee', initials: 'JL', status: 'offline' },
];

export function CollaborationPanel() {
  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [newComment, setNewComment] = useState('');
  const [showMentions, setShowMentions] = useState(false);

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  const handleSendComment = () => {
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      user: { name: 'You', initials: 'YO' },
      content: newComment,
      timestamp: new Date(),
      likes: 0,
    };

    setComments([comment, ...comments]);
    setNewComment('');
    toast({
      title: 'Comment Posted',
      description: 'Your comment has been shared with the team',
    });
  };

  const handleLike = (commentId: string) => {
    setComments((prev) => prev.map((c) => (c.id === commentId ? { ...c, likes: c.likes + 1 } : c)));
  };

  return (
    <Card className="border-border/50 shadow-md">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Team Collaboration</CardTitle>
          </div>
          <div className="flex items-center -space-x-2">
            {teamMembers.slice(0, 3).map((member, i) => (
              <Avatar key={i} className="h-7 w-7 border-2 border-background">
                <AvatarFallback className="text-[10px] bg-primary/10">{member.initials}</AvatarFallback>
              </Avatar>
            ))}
            {teamMembers.length > 3 && (
              <div className="h-7 w-7 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-medium">
                +{teamMembers.length - 3}
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* Online Team Members */}
        <div className="flex items-center gap-2 p-2 rounded-lg bg-accent/30">
          <span className="text-xs text-muted-foreground">Online:</span>
          {teamMembers
            .filter((m) => m.status === 'online')
            .map((member, i) => (
              <div key={i} className="flex items-center gap-1">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-success opacity-75 animate-ping"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
                </span>
                <span className="text-xs font-medium">{member.name.split(' ')[0]}</span>
              </div>
            ))}
        </div>

        {/* Comments Input */}
        <div className="relative">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs bg-primary text-primary-foreground">YO</AvatarFallback>
            </Avatar>
            <div className="flex-1 relative">
              <Input
                placeholder="Add a comment or @mention..."
                value={newComment}
                onChange={(e) => {
                  setNewComment(e.target.value);
                  setShowMentions(e.target.value.includes('@'));
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleSendComment()}
                className="pr-20"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => setNewComment((prev) => prev + '@')}
                >
                  <AtSign className="h-4 w-4 text-muted-foreground" />
                </Button>
                <Button size="icon" className="h-6 w-6" onClick={handleSendComment} disabled={!newComment.trim()}>
                  <Send className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>

          {/* Mentions dropdown */}
          {showMentions && (
            <div className="absolute top-full left-10 mt-1 w-48 rounded-lg border bg-popover p-1 shadow-lg z-10">
              {teamMembers.map((member, i) => (
                <button
                  key={i}
                  className="w-full flex items-center gap-2 p-2 rounded-md hover:bg-accent text-left text-sm"
                  onClick={() => {
                    const atIndex = newComment.lastIndexOf('@');
                    setNewComment(newComment.slice(0, atIndex) + `@${member.name} `);
                    setShowMentions(false);
                  }}
                >
                  <Avatar className="h-5 w-5">
                    <AvatarFallback className="text-[8px]">{member.initials}</AvatarFallback>
                  </Avatar>
                  <span>{member.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Comments List */}
        <ScrollArea className="h-[280px] pr-2">
          <div className="space-y-3">
            {comments.map((comment) => (
              <div
                key={comment.id}
                className={cn(
                  'p-3 rounded-lg border transition-all hover:bg-accent/30',
                  comment.isPinned && 'bg-primary/5 border-primary/20',
                )}
              >
                <div className="flex items-start gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="text-xs bg-muted">{comment.user.initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{comment.user.name}</span>
                        {comment.isPinned && <Pin className="h-3 w-3 text-primary" />}
                        {comment.metricRef && (
                          <Badge variant="secondary" className="text-[10px] py-0">
                            {comment.metricRef}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">
                          <Clock className="h-3 w-3 inline mr-0.5" />
                          {formatTimeAgo(comment.timestamp)}
                        </span>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <MoreHorizontal className="h-3 w-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Pin className="h-3 w-3 mr-2" /> Pin comment
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Share2 className="h-3 w-3 mr-2" /> Share
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <p className="text-sm text-foreground mt-1">{comment.content}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <button
                        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                        onClick={() => handleLike(comment.id)}
                      >
                        <Heart className={cn('h-3 w-3', comment.likes > 0 && 'fill-destructive text-destructive')} />
                        {comment.likes > 0 && comment.likes}
                      </button>
                      <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Reply className="h-3 w-3" /> Reply
                      </button>
                    </div>

                    {/* Replies */}
                    {comment.replies && comment.replies.length > 0 && (
                      <div className="mt-3 pl-3 border-l-2 border-border/50 space-y-2">
                        {comment.replies.map((reply) => (
                          <div key={reply.id} className="flex items-start gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-[8px]">{reply.user.initials}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-xs">{reply.user.name}</span>
                                <span className="text-[10px] text-muted-foreground">
                                  {formatTimeAgo(reply.timestamp)}
                                </span>
                              </div>
                              <p className="text-xs text-foreground mt-0.5">{reply.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
