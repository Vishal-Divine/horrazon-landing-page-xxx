import { useState, useEffect } from 'react';
import { Activity, TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { RealtimeMetric } from './types';
import { cn } from '@/lib/utils';

interface RealtimeMetricsBarProps {
  metrics: RealtimeMetric[];
  onRefresh?: () => void;
}

export function RealtimeMetricsBar({ metrics, onRefresh }: RealtimeMetricsBarProps) {
  const [isLive, setIsLive] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [animatedMetrics, setAnimatedMetrics] = useState(metrics);

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
      // Simulate real-time updates
      setAnimatedMetrics((prev) =>
        prev.map((m) => ({
          ...m,
          previousValue: m.value,
          value: m.value * (0.98 + Math.random() * 0.04),
          lastUpdated: new Date(),
        })),
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const formatValue = (value: number, unit: string) => {
    if (unit === '$') {
      return `$${value >= 1000 ? (value / 1000).toFixed(1) + 'K' : value.toFixed(2)}`;
    }
    return value >= 1000 ? (value / 1000).toFixed(1) + 'K' : Math.round(value).toString();
  };

  const getChange = (current: number, previous: number) => {
    const change = ((current - previous) / previous) * 100;
    return change;
  };

  return (
    <div className="flex items-center gap-2 p-3 rounded-xl bg-gradient-to-r from-primary/5 via-card to-primary/5 border border-primary/20 overflow-x-auto">
      {/* Live indicator */}
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/50 shrink-0">
        <div className="relative">
          <Activity className={cn('h-4 w-4 transition-colors', isLive ? 'text-success' : 'text-muted-foreground')} />
          {isLive && (
            <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
            </span>
          )}
        </div>
        <span className="text-xs font-medium text-foreground">Live</span>
      </div>

      {/* Metrics */}
      <div className="flex items-center gap-3 flex-1">
        {animatedMetrics.map((metric, i) => {
          const change = getChange(metric.value, metric.previousValue);
          const isPositive = change > 0;

          return (
            <div
              key={i}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card/80 border border-border/30 hover:border-primary/30 transition-all cursor-pointer group shrink-0"
            >
              <div className="flex flex-col">
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{metric.label}</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-foreground">{formatValue(metric.value, metric.unit)}</span>
                  <div
                    className={cn(
                      'flex items-center gap-0.5 text-[10px] font-medium',
                      isPositive ? 'text-success' : 'text-destructive',
                    )}
                  >
                    {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    <span>{Math.abs(change).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Last update */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-[10px] text-muted-foreground">
          Updated {Math.round((Date.now() - lastUpdate.getTime()) / 1000)}s ago
        </span>
        <button
          onClick={() => {
            onRefresh?.();
            setLastUpdate(new Date());
          }}
          className="p-1.5 rounded-md hover:bg-accent transition-colors"
        >
          <RefreshCw className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground" />
        </button>
      </div>
    </div>
  );
}
