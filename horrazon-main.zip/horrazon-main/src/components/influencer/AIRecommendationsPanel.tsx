import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Brain,
  Sparkles,
  TrendingUp,
  Target,
  DollarSign,
  Users,
  Zap,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  BarChart3,
  Percent,
  Clock,
  ThumbsUp,
  ThumbsDown,
  RefreshCcw,
} from 'lucide-react';

interface InfluencerRecommendation {
  id: string;
  name: string;
  avatar: string;
  platform: string;
  followers: string;
  engagement: number;
  matchScore: number;
  predictedROAS: number;
  estimatedRevenue: number;
  budgetRequired: number;
  audienceOverlap: number;
  riskScore: 'low' | 'medium' | 'high';
  reasons: string[];
  contentAffinity: number;
  brandFit: number;
  historicalPerformance?: number;
}

interface BudgetOptimization {
  influencerId: string;
  influencerName: string;
  currentBudget: number;
  suggestedBudget: number;
  expectedROAS: number;
  revenueChange: number;
  reason: string;
}

const mockRecommendations: InfluencerRecommendation[] = [
  {
    id: '1',
    name: '@lifestyle_jane',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jane',
    platform: 'Instagram',
    followers: '156K',
    engagement: 5.8,
    matchScore: 94,
    predictedROAS: 7.8,
    estimatedRevenue: 28400,
    budgetRequired: 3600,
    audienceOverlap: 8.2,
    riskScore: 'low',
    reasons: ['High audience match (87%)', 'Similar brand partnerships', 'Consistent posting schedule'],
    contentAffinity: 92,
    brandFit: 96,
  },
  {
    id: '2',
    name: '@fitness_coach_tom',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Tom',
    platform: 'TikTok',
    followers: '420K',
    engagement: 8.2,
    matchScore: 91,
    predictedROAS: 9.2,
    estimatedRevenue: 42800,
    budgetRequired: 4800,
    audienceOverlap: 6.4,
    riskScore: 'low',
    reasons: ['Viral content history', 'High Gen-Z reach', 'Low competition in niche'],
    contentAffinity: 88,
    brandFit: 91,
  },
  {
    id: '3',
    name: '@techsavvy_lisa',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lisa',
    platform: 'YouTube',
    followers: '890K',
    engagement: 4.1,
    matchScore: 87,
    predictedROAS: 6.4,
    estimatedRevenue: 52400,
    budgetRequired: 8200,
    audienceOverlap: 12.8,
    riskScore: 'medium',
    reasons: ['Strong authority in space', 'Long-form content expertise', 'Higher audience overlap warning'],
    contentAffinity: 94,
    brandFit: 82,
  },
  {
    id: '4',
    name: '@beauty_micro_mia',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mia',
    platform: 'Instagram',
    followers: '48K',
    engagement: 9.4,
    matchScore: 89,
    predictedROAS: 11.2,
    estimatedRevenue: 18200,
    budgetRequired: 1600,
    audienceOverlap: 4.2,
    riskScore: 'low',
    reasons: ['Micro-influencer efficiency', 'Highly engaged niche', 'Authentic voice'],
    contentAffinity: 90,
    brandFit: 94,
  },
];

const mockBudgetOptimizations: BudgetOptimization[] = [
  {
    influencerId: '1',
    influencerName: '@beautybyemma',
    currentBudget: 4500,
    suggestedBudget: 6200,
    expectedROAS: 9.4,
    revenueChange: 14200,
    reason: 'Highest performing creator with consistent ROI above 8x',
  },
  {
    influencerId: '2',
    influencerName: '@fitnessguru_sarah',
    currentBudget: 3200,
    suggestedBudget: 2400,
    expectedROAS: 5.8,
    revenueChange: -3800,
    reason: 'Declining engagement rate; reallocate to higher performers',
  },
  {
    influencerId: '3',
    influencerName: '@techreviews_mike',
    currentBudget: 5100,
    suggestedBudget: 4800,
    expectedROAS: 6.2,
    revenueChange: -1400,
    reason: 'Stable performance; slight reduction for optimization',
  },
  {
    influencerId: '4',
    influencerName: '@foodie_alex',
    currentBudget: 2800,
    suggestedBudget: 2200,
    expectedROAS: 4.8,
    revenueChange: -2200,
    reason: 'Audience quality concerns; reduce until metrics improve',
  },
];

export function AIRecommendationsPanel() {
  const [budgetRange, setBudgetRange] = useState([5000, 15000]);
  const [prioritizeEngagement, setPrioritizeEngagement] = useState(true);
  const [avoidOverlap, setAvoidOverlap] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1500);
  };

  const totalOptimizedRevenue = mockBudgetOptimizations.reduce((sum, opt) => sum + opt.revenueChange, 0);

  return (
    <div className="space-y-6">
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  AI Recommendations Engine
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Powered by ML
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Intelligent influencer matching, budget optimization & partnership suggestions
                </p>
              </div>
            </div>
            <Button variant="outline" className="gap-2" onClick={handleRefresh}>
              <RefreshCcw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh Analysis
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">New Matches Found</p>
                <p className="text-3xl font-bold">24</p>
              </div>
              <Users className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+8 since last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Match Score</p>
                <p className="text-3xl font-bold">89%</p>
              </div>
              <Target className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">High quality pool</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Predicted Revenue</p>
                <p className="text-3xl font-bold">$141K</p>
              </div>
              <TrendingUp className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-success">From top recommendations</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Optimization Gain</p>
                <p className="text-3xl font-bold text-success">+${(totalOptimizedRevenue / 1000).toFixed(1)}K</p>
              </div>
              <Zap className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">With budget reallocation</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="recommendations" className="space-y-4">
        <TabsList>
          <TabsTrigger value="recommendations" className="gap-2">
            <Sparkles className="h-4 w-4" />
            New Influencer Recommendations
          </TabsTrigger>
          <TabsTrigger value="budget" className="gap-2">
            <DollarSign className="h-4 w-4" />
            Budget Optimization
          </TabsTrigger>
          <TabsTrigger value="partnerships" className="gap-2">
            <Users className="h-4 w-4" />
            Partnership Suggestions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Matching Preferences</CardTitle>
                <Badge variant="outline">4 filters active</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-3">
                  <Label>Budget Range (per influencer)</Label>
                  <Slider value={budgetRange} onValueChange={setBudgetRange} min={1000} max={25000} step={500} />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>${budgetRange[0].toLocaleString()}</span>
                    <span>${budgetRange[1].toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="engagement">Prioritize High Engagement</Label>
                    <Switch id="engagement" checked={prioritizeEngagement} onCheckedChange={setPrioritizeEngagement} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="overlap">Avoid Audience Overlap {'>'}15%</Label>
                    <Switch id="overlap" checked={avoidOverlap} onCheckedChange={setAvoidOverlap} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            {mockRecommendations.map((rec) => (
              <Card key={rec.id} className="overflow-hidden transition-all hover:shadow-lg">
                <CardContent className="p-0">
                  <div className="flex items-start gap-4 p-4">
                    <Avatar className="h-14 w-14 ring-2 ring-primary/20">
                      <AvatarImage src={rec.avatar} />
                      <AvatarFallback>{rec.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{rec.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {rec.platform} • {rec.followers} followers
                          </p>
                        </div>
                        <Badge
                          className={
                            rec.matchScore >= 90
                              ? 'bg-success/10 text-success'
                              : rec.matchScore >= 80
                                ? 'bg-chart-2/10 text-chart-2'
                                : 'bg-warning/10 text-warning'
                          }
                        >
                          {rec.matchScore}% Match
                        </Badge>
                      </div>

                      <div className="mt-3 grid grid-cols-3 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Est. ROAS</p>
                          <p className="font-bold text-success">{rec.predictedROAS}x</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Est. Revenue</p>
                          <p className="font-bold">${(rec.estimatedRevenue / 1000).toFixed(1)}K</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Budget</p>
                          <p className="font-bold">${(rec.budgetRequired / 1000).toFixed(1)}K</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t bg-muted/30 px-4 py-3">
                    <div className="mb-2 flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <BarChart3 className="h-3 w-3 text-chart-1" />
                        <span>Engagement: {rec.engagement}%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Percent className="h-3 w-3 text-chart-2" />
                        <span>Brand Fit: {rec.brandFit}%</span>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          rec.riskScore === 'low'
                            ? 'border-success/50 text-success'
                            : rec.riskScore === 'medium'
                              ? 'border-warning/50 text-warning'
                              : 'border-destructive/50 text-destructive'
                        }
                      >
                        {rec.riskScore} risk
                      </Badge>
                    </div>

                    <div className="space-y-1">
                      {rec.reasons.slice(0, 2).map((reason, idx) => (
                        <div key={idx} className="flex items-center gap-1 text-xs text-muted-foreground">
                          <CheckCircle2 className="h-3 w-3 text-success" />
                          {reason}
                        </div>
                      ))}
                    </div>

                    <div className="mt-3 flex gap-2">
                      <Button size="sm" className="flex-1 gap-1">
                        <ThumbsUp className="h-3 w-3" />
                        Add to Pipeline
                      </Button>
                      <Button size="sm" variant="outline" className="gap-1">
                        <ThumbsDown className="h-3 w-3" />
                        Skip
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="budget" className="space-y-4">
          <Card className="border-chart-3/30 bg-chart-3/5">
            <CardContent className="flex items-center gap-4 py-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-chart-3/20">
                <Brain className="h-6 w-6 text-chart-3" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">AI Budget Optimization</h4>
                <p className="text-sm text-muted-foreground">
                  Reallocating $2,100 across 4 influencers could increase revenue by $
                  {(totalOptimizedRevenue / 1000).toFixed(1)}K
                </p>
              </div>
              <Button className="gap-2">
                Apply All Suggestions
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <div className="space-y-3">
            {mockBudgetOptimizations.map((opt) => (
              <Card key={opt.influencerId}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div>
                        <h4 className="font-semibold">{opt.influencerName}</h4>
                        <p className="text-sm text-muted-foreground">{opt.reason}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Current Budget</p>
                        <p className="font-medium">${opt.currentBudget.toLocaleString()}</p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Suggested</p>
                        <p
                          className={`font-bold ${
                            opt.suggestedBudget > opt.currentBudget ? 'text-success' : 'text-warning'
                          }`}
                        >
                          ${opt.suggestedBudget.toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Expected ROAS</p>
                        <p className="font-bold">{opt.expectedROAS}x</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Revenue Impact</p>
                        <p className={`font-bold ${opt.revenueChange >= 0 ? 'text-success' : 'text-destructive'}`}>
                          {opt.revenueChange >= 0 ? '+' : ''}${(opt.revenueChange / 1000).toFixed(1)}K
                        </p>
                      </div>
                      <Button size="sm" variant="outline">
                        Apply
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="partnerships" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Clock className="h-5 w-5 text-chart-1" />
                  Optimal Posting Times
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-lg border p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Instagram</span>
                    <Badge variant="outline">Best: 11am-1pm EST</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">+42% engagement vs random timing</p>
                </div>
                <div className="rounded-lg border p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">TikTok</span>
                    <Badge variant="outline">Best: 7pm-9pm EST</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">+38% engagement vs random timing</p>
                </div>
                <div className="rounded-lg border p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">YouTube</span>
                    <Badge variant="outline">Best: Sat 10am EST</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">+28% watch time vs random timing</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="h-5 w-5 text-chart-2" />
                  Content Strategy Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-2 rounded-lg border border-success/20 bg-success/5 p-3">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 text-success" />
                  <div>
                    <p className="text-sm font-medium">Prioritize Tutorial Content</p>
                    <p className="text-xs text-muted-foreground">12.4x ROAS vs 6.8x for unboxings</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 rounded-lg border border-chart-2/20 bg-chart-2/5 p-3">
                  <AlertCircle className="mt-0.5 h-4 w-4 text-chart-2" />
                  <div>
                    <p className="text-sm font-medium">Add Carousel Posts</p>
                    <p className="text-xs text-muted-foreground">78% higher save rate on Instagram</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 rounded-lg border border-chart-3/20 bg-chart-3/5 p-3">
                  <Zap className="mt-0.5 h-4 w-4 text-chart-3" />
                  <div>
                    <p className="text-sm font-medium">Leverage Duets/Collabs</p>
                    <p className="text-xs text-muted-foreground">2.3x viral potential on TikTok</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Cross-Promotion Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-4">
                    <div className="flex -space-x-2">
                      <Avatar className="h-8 w-8 ring-2 ring-background">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Emma" />
                      </Avatar>
                      <Avatar className="h-8 w-8 ring-2 ring-background">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah" />
                      </Avatar>
                    </div>
                    <div>
                      <p className="font-medium">@beautybyemma × @fitnessguru_sarah</p>
                      <p className="text-sm text-muted-foreground">Wellness crossover campaign opportunity</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Combined Reach</p>
                      <p className="font-bold">1.18M</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Expected Lift</p>
                      <p className="font-bold text-success">+34%</p>
                    </div>
                    <Button size="sm">Explore</Button>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-4">
                    <div className="flex -space-x-2">
                      <Avatar className="h-8 w-8 ring-2 ring-background">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Mike" />
                      </Avatar>
                      <Avatar className="h-8 w-8 ring-2 ring-background">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Lisa" />
                      </Avatar>
                    </div>
                    <div>
                      <p className="font-medium">@techreviews_mike × @techsavvy_lisa</p>
                      <p className="text-sm text-muted-foreground">Tech product launch collaboration</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Combined Reach</p>
                      <p className="font-bold">1.41M</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Expected Lift</p>
                      <p className="font-bold text-success">+28%</p>
                    </div>
                    <Button size="sm">Explore</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
