import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Search,
  Filter,
  Sparkles,
  Users,
  TrendingUp,
  MapPin,
  Hash,
  Instagram,
  Youtube,
  Share2,
  CheckCircle2,
  Star,
  Eye,
  Heart,
  MessageCircle,
  UserPlus,
  Bookmark,
  ExternalLink,
  ChevronDown,
  RefreshCcw,
} from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface DiscoveredInfluencer {
  id: string;
  name: string;
  avatar: string;
  platform: 'Instagram' | 'TikTok' | 'YouTube';
  followers: number;
  engagement: number;
  niche: string;
  location: string;
  avgViews: number;
  recentGrowth: number;
  audienceQuality: number;
  verified: boolean;
  recentPosts: number;
  avgLikes: number;
  avgComments: number;
  brandMentions: string[];
  contentThemes: string[];
  estimatedRate: { min: number; max: number };
  lookalikeTo?: string;
}

const mockDiscoveredInfluencers: DiscoveredInfluencer[] = [
  {
    id: '1',
    name: '@wellness_warrior',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Warrior',
    platform: 'Instagram',
    followers: 245000,
    engagement: 6.2,
    niche: 'Health & Wellness',
    location: 'Los Angeles, CA',
    avgViews: 42000,
    recentGrowth: 12.4,
    audienceQuality: 94,
    verified: true,
    recentPosts: 84,
    avgLikes: 12400,
    avgComments: 892,
    brandMentions: ['Nike', 'Lululemon', 'Gymshark'],
    contentThemes: ['Fitness', 'Nutrition', 'Mindfulness'],
    estimatedRate: { min: 2500, max: 4000 },
    lookalikeTo: '@fitnessguru_sarah',
  },
  {
    id: '2',
    name: '@skincare_secrets',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Skincare',
    platform: 'TikTok',
    followers: 892000,
    engagement: 9.8,
    niche: 'Beauty & Skincare',
    location: 'New York, NY',
    avgViews: 320000,
    recentGrowth: 28.6,
    audienceQuality: 91,
    verified: true,
    recentPosts: 142,
    avgLikes: 78000,
    avgComments: 4200,
    brandMentions: ['CeraVe', 'The Ordinary', 'Glow Recipe'],
    contentThemes: ['Skincare Routines', 'Product Reviews', 'GRWM'],
    estimatedRate: { min: 5000, max: 8000 },
    lookalikeTo: '@beautybyemma',
  },
  {
    id: '3',
    name: '@gadget_guru_pro',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gadget',
    platform: 'YouTube',
    followers: 1240000,
    engagement: 4.2,
    niche: 'Technology',
    location: 'Austin, TX',
    avgViews: 420000,
    recentGrowth: 8.4,
    audienceQuality: 96,
    verified: true,
    recentPosts: 48,
    avgLikes: 28000,
    avgComments: 2400,
    brandMentions: ['Apple', 'Samsung', 'Sony'],
    contentThemes: ['Reviews', 'Unboxing', 'Tech News'],
    estimatedRate: { min: 8000, max: 15000 },
    lookalikeTo: '@techreviews_mike',
  },
  {
    id: '4',
    name: '@home_chef_daily',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Chef',
    platform: 'Instagram',
    followers: 156000,
    engagement: 5.8,
    niche: 'Food & Cooking',
    location: 'Chicago, IL',
    avgViews: 28000,
    recentGrowth: 15.2,
    audienceQuality: 89,
    verified: false,
    recentPosts: 96,
    avgLikes: 8400,
    avgComments: 624,
    brandMentions: ['HelloFresh', 'Lodge Cast Iron'],
    contentThemes: ['Recipes', 'Meal Prep', 'Kitchen Tips'],
    estimatedRate: { min: 1800, max: 3000 },
    lookalikeTo: '@foodie_alex',
  },
  {
    id: '5',
    name: '@fashion_forward_kay',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kay',
    platform: 'TikTok',
    followers: 480000,
    engagement: 7.4,
    niche: 'Fashion & Style',
    location: 'Miami, FL',
    avgViews: 180000,
    recentGrowth: 22.8,
    audienceQuality: 92,
    verified: true,
    recentPosts: 118,
    avgLikes: 42000,
    avgComments: 2800,
    brandMentions: ['Zara', 'Shein', 'Revolve'],
    contentThemes: ['OOTD', 'Hauls', 'Style Tips'],
    estimatedRate: { min: 3500, max: 5500 },
  },
  {
    id: '6',
    name: '@travel_tales_tom',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=TravelTom',
    platform: 'YouTube',
    followers: 680000,
    engagement: 5.6,
    niche: 'Travel & Adventure',
    location: 'Denver, CO',
    avgViews: 280000,
    recentGrowth: 11.2,
    audienceQuality: 94,
    verified: true,
    recentPosts: 36,
    avgLikes: 24000,
    avgComments: 1800,
    brandMentions: ['Away', 'Airbnb', 'REI'],
    contentThemes: ['Vlogs', 'Guides', 'Adventures'],
    estimatedRate: { min: 6000, max: 10000 },
  },
];

const formatFollowers = (num: number) => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
  return num.toString();
};

const PlatformIcon = ({ platform }: { platform: string }) => {
  switch (platform) {
    case 'Instagram':
      return <Instagram className="h-4 w-4 text-pink-500" />;
    case 'YouTube':
      return <Youtube className="h-4 w-4 text-red-500" />;
    case 'TikTok':
      return <Share2 className="h-4 w-4" />;
    default:
      return null;
  }
};

export function InfluencerDiscoveryPanel() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [selectedNiche, setSelectedNiche] = useState<string>('all');
  const [followerRange, setFollowerRange] = useState([50000, 1000000]);
  const [engagementMin, setEngagementMin] = useState([4]);
  const [showFilters, setShowFilters] = useState(true);
  const [savedInfluencers, setSavedInfluencers] = useState<string[]>([]);

  const toggleSaved = (id: string) => {
    setSavedInfluencers((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]));
  };

  const filteredInfluencers = mockDiscoveredInfluencers.filter((inf) => {
    if (selectedPlatform !== 'all' && inf.platform !== selectedPlatform) return false;
    if (selectedNiche !== 'all' && !inf.niche.toLowerCase().includes(selectedNiche.toLowerCase())) return false;
    if (inf.followers < followerRange[0] || inf.followers > followerRange[1]) return false;
    if (inf.engagement < engagementMin[0]) return false;
    if (searchQuery && !inf.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <Card className="border-chart-1/20 bg-gradient-to-br from-chart-1/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/10">
                <Search className="h-5 w-5 text-chart-1" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Influencer Discovery
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    AI-Powered
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Find creators matching your brand with lookalike analysis and niche targeting
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2">
                <Bookmark className="h-4 w-4" />
                Saved ({savedInfluencers.length})
              </Button>
              <Button className="gap-2">
                <RefreshCcw className="h-4 w-4" />
                Refresh Results
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Discovered Today</p>
                <p className="text-3xl font-bold">142</p>
              </div>
              <Users className="h-8 w-8 text-chart-1" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Match</p>
                <p className="text-3xl font-bold">38</p>
              </div>
              <Star className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{'>'}85% brand fit</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Rising Stars</p>
                <p className="text-3xl font-bold">24</p>
              </div>
              <TrendingUp className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-success">{'>'}20% growth rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Lookalikes Found</p>
                <p className="text-3xl font-bold">16</p>
              </div>
              <Sparkles className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Similar to top performers</p>
          </CardContent>
        </Card>
      </div>

      <Collapsible open={showFilters} onOpenChange={setShowFilters}>
        <Card>
          <CardHeader className="py-3">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full justify-between px-0">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <span className="font-semibold">Search & Filters</span>
                </div>
                <ChevronDown className={`h-4 w-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
              </Button>
            </CollapsibleTrigger>
          </CardHeader>
          <CollapsibleContent>
            <CardContent className="space-y-4 pt-0">
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, niche, or hashtag..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Platforms</SelectItem>
                    <SelectItem value="Instagram">Instagram</SelectItem>
                    <SelectItem value="TikTok">TikTok</SelectItem>
                    <SelectItem value="YouTube">YouTube</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedNiche} onValueChange={setSelectedNiche}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Niche" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Niches</SelectItem>
                    <SelectItem value="beauty">Beauty</SelectItem>
                    <SelectItem value="fitness">Fitness</SelectItem>
                    <SelectItem value="tech">Technology</SelectItem>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="fashion">Fashion</SelectItem>
                    <SelectItem value="travel">Travel</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-3">
                  <Label>Follower Range</Label>
                  <Slider
                    value={followerRange}
                    onValueChange={setFollowerRange}
                    min={10000}
                    max={2000000}
                    step={10000}
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{formatFollowers(followerRange[0])}</span>
                    <span>{formatFollowers(followerRange[1])}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Minimum Engagement Rate</Label>
                  <Slider value={engagementMin} onValueChange={setEngagementMin} min={1} max={15} step={0.5} />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{engagementMin[0]}%+</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="verified" />
                  <Label htmlFor="verified" className="text-sm">
                    Verified only
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="lookalike" />
                  <Label htmlFor="lookalike" className="text-sm">
                    Lookalikes only
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="rising" />
                  <Label htmlFor="rising" className="text-sm">
                    Rising stars ({'>'}15% growth)
                  </Label>
                </div>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredInfluencers.map((influencer) => (
          <Card key={influencer.id} className="overflow-hidden transition-all hover:shadow-lg">
            <CardContent className="p-0">
              <div className="relative p-4">
                {influencer.lookalikeTo && (
                  <Badge variant="secondary" className="absolute right-4 top-4 gap-1 bg-chart-4/10 text-chart-4">
                    <Sparkles className="h-3 w-3" />
                    Similar to {influencer.lookalikeTo}
                  </Badge>
                )}

                <div className="flex items-start gap-3">
                  <Avatar className="h-14 w-14 ring-2 ring-border">
                    <AvatarImage src={influencer.avatar} />
                    <AvatarFallback>{influencer.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold">{influencer.name}</h4>
                      {influencer.verified && <CheckCircle2 className="h-4 w-4 text-primary" />}
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                      <PlatformIcon platform={influencer.platform} />
                      <span>{formatFollowers(influencer.followers)} followers</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-3 text-center text-sm">
                  <div>
                    <p className="text-muted-foreground">Engagement</p>
                    <p className="font-bold text-success">{influencer.engagement}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Avg Views</p>
                    <p className="font-bold">{formatFollowers(influencer.avgViews)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Growth</p>
                    <p className="font-bold text-chart-1">+{influencer.recentGrowth}%</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-sm">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span className="text-muted-foreground">{influencer.location}</span>
                  </div>
                  <Badge variant="outline">{influencer.niche}</Badge>
                </div>
              </div>

              <div className="border-t bg-muted/30 px-4 py-3">
                <div className="mb-2 flex flex-wrap gap-1">
                  {influencer.contentThemes.map((theme, idx) => (
                    <Badge key={idx} variant="outline" className="gap-1 text-xs">
                      <Hash className="h-2 w-2" />
                      {theme}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      {formatFollowers(influencer.avgLikes)}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-3 w-3" />
                      {formatFollowers(influencer.avgComments)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {influencer.recentPosts} posts
                    </span>
                  </div>
                  <span className="font-medium text-foreground">
                    ${influencer.estimatedRate.min.toLocaleString()}-$
                    {influencer.estimatedRate.max.toLocaleString()}
                  </span>
                </div>

                <div className="mt-2 flex items-center gap-2">
                  <div className="flex-1">
                    <div className="mb-1 flex justify-between text-xs">
                      <span>Audience Quality</span>
                      <span className="font-medium">{influencer.audienceQuality}%</span>
                    </div>
                    <Progress value={influencer.audienceQuality} className="h-1.5" />
                  </div>
                </div>

                <div className="mt-3 flex gap-2">
                  <Button size="sm" className="flex-1 gap-1">
                    <UserPlus className="h-3 w-3" />
                    Add to Pipeline
                  </Button>
                  <Button
                    size="sm"
                    variant={savedInfluencers.includes(influencer.id) ? 'default' : 'outline'}
                    className="gap-1"
                    onClick={() => toggleSaved(influencer.id)}
                  >
                    <Bookmark className={`h-3 w-3 ${savedInfluencers.includes(influencer.id) ? 'fill-current' : ''}`} />
                  </Button>
                  <Button size="sm" variant="outline" className="gap-1">
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
