import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Bot,
  TrendingDown,
  TrendingUp,
  Eye,
  Users,
  Activity,
  BarChart3,
  Clock,
  Zap,
  FileText,
  RefreshCcw,
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface FraudAnalysis {
  influencerId: string;
  name: string;
  avatar: string;
  platform: string;
  overallRiskScore: number;
  authenticityScore: number;
  fakeFollowerPercent: number;
  botEngagementPercent: number;
  engagementConsistency: number;
  followerGrowthPattern: 'organic' | 'suspicious' | 'artificial';
  likeCommentRatio: number;
  audienceCredibility: number;
  riskFactors: { factor: string; severity: 'low' | 'medium' | 'high'; description: string }[];
  positiveIndicators: string[];
  lastScanned: string;
}

interface EngagementPattern {
  time: string;
  genuine: number;
  suspicious: number;
}

const mockFraudAnalysis: FraudAnalysis[] = [
  {
    influencerId: '1',
    name: '@beautybyemma',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    platform: 'TikTok',
    overallRiskScore: 8,
    authenticityScore: 98,
    fakeFollowerPercent: 1.4,
    botEngagementPercent: 2.1,
    engagementConsistency: 94,
    followerGrowthPattern: 'organic',
    likeCommentRatio: 14.2,
    audienceCredibility: 96,
    riskFactors: [],
    positiveIndicators: [
      'Consistent engagement over 24 months',
      'Verified audience demographics',
      'Organic follower growth pattern',
      'High comment-to-like ratio',
    ],
    lastScanned: '2 hours ago',
  },
  {
    influencerId: '2',
    name: '@fitnessguru_sarah',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    platform: 'Instagram',
    overallRiskScore: 18,
    authenticityScore: 94,
    fakeFollowerPercent: 2.8,
    botEngagementPercent: 3.4,
    engagementConsistency: 88,
    followerGrowthPattern: 'organic',
    likeCommentRatio: 18.4,
    audienceCredibility: 92,
    riskFactors: [
      {
        factor: 'Engagement spike detected',
        severity: 'low',
        description: '14% higher engagement in Dec - likely holiday content',
      },
    ],
    positiveIndicators: ['Verified account', 'Consistent posting schedule', 'Natural audience demographics'],
    lastScanned: '1 hour ago',
  },
  {
    influencerId: '3',
    name: '@techreviews_mike',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    platform: 'YouTube',
    overallRiskScore: 22,
    authenticityScore: 91,
    fakeFollowerPercent: 4.2,
    botEngagementPercent: 5.8,
    engagementConsistency: 82,
    followerGrowthPattern: 'organic',
    likeCommentRatio: 28.6,
    audienceCredibility: 88,
    riskFactors: [
      {
        factor: 'High like-to-comment ratio',
        severity: 'low',
        description: 'Typical for tech review content format',
      },
      {
        factor: 'Geographic anomaly',
        severity: 'low',
        description: '8% audience from unexpected regions',
      },
    ],
    positiveIndicators: ['Long content watch time', 'Subscriber loyalty metrics strong'],
    lastScanned: '3 hours ago',
  },
  {
    influencerId: '4',
    name: '@foodie_alex',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    platform: 'Instagram',
    overallRiskScore: 42,
    authenticityScore: 86,
    fakeFollowerPercent: 5.8,
    botEngagementPercent: 8.2,
    engagementConsistency: 68,
    followerGrowthPattern: 'suspicious',
    likeCommentRatio: 42.4,
    audienceCredibility: 78,
    riskFactors: [
      {
        factor: 'Suspicious follower growth',
        severity: 'medium',
        description: '12K followers gained in 48 hours without viral content',
      },
      {
        factor: 'Bot activity detected',
        severity: 'medium',
        description: '8.2% engagement appears automated',
      },
      {
        factor: 'Low comment quality',
        severity: 'low',
        description: '42% generic single-emoji comments',
      },
    ],
    positiveIndicators: ['Real content creator', 'Active engagement in comments'],
    lastScanned: '30 minutes ago',
  },
];

const engagementPatternData: EngagementPattern[] = [
  { time: '12am', genuine: 2.1, suspicious: 0.1 },
  { time: '3am', genuine: 0.8, suspicious: 0.4 },
  { time: '6am', genuine: 4.2, suspicious: 0.2 },
  { time: '9am', genuine: 12.4, suspicious: 0.3 },
  { time: '12pm', genuine: 18.2, suspicious: 0.4 },
  { time: '3pm', genuine: 14.8, suspicious: 0.3 },
  { time: '6pm', genuine: 22.4, suspicious: 0.5 },
  { time: '9pm', genuine: 16.2, suspicious: 0.3 },
];

const followerGrowthData = [
  { month: 'Jul', followers: 842000, organic: 840000, suspicious: 2000 },
  { month: 'Aug', followers: 856000, organic: 853000, suspicious: 3000 },
  { month: 'Sep', followers: 868000, organic: 864000, suspicious: 4000 },
  { month: 'Oct', followers: 878000, organic: 874000, suspicious: 4000 },
  { month: 'Nov', followers: 884000, organic: 880000, suspicious: 4000 },
  { month: 'Dec', followers: 892000, organic: 888000, suspicious: 4000 },
];

export function FraudRiskIntelligence() {
  const [selectedInfluencer, setSelectedInfluencer] = useState(mockFraudAnalysis[0]);
  const [scanning, setScanning] = useState(false);

  const handleRescan = () => {
    setScanning(true);
    setTimeout(() => setScanning(false), 2000);
  };

  const getRiskColor = (score: number) => {
    if (score <= 20) return 'text-success';
    if (score <= 40) return 'text-warning';
    return 'text-destructive';
  };

  const getRiskBadge = (score: number) => {
    if (score <= 20) return { label: 'Low Risk', className: 'bg-success/10 text-success' };
    if (score <= 40) return { label: 'Medium Risk', className: 'bg-warning/10 text-warning' };
    return { label: 'High Risk', className: 'bg-destructive/10 text-destructive' };
  };

  return (
    <div className="space-y-6">
      <Card className="border-warning/20 bg-gradient-to-br from-warning/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                <ShieldAlert className="h-5 w-5 text-warning" />
              </div>
              <div>
                <CardTitle>Fraud & Risk Intelligence</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Advanced bot detection, engagement authenticity scoring & risk analysis
                </p>
              </div>
            </div>
            <Button variant="outline" className="gap-2" onClick={handleRescan}>
              <RefreshCcw className={`h-4 w-4 ${scanning ? 'animate-spin' : ''}`} />
              Scan All Partners
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-success/30 bg-success/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Verified Partners</p>
                <p className="text-3xl font-bold text-success">3</p>
              </div>
              <ShieldCheck className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-success">{'<'}20 risk score</p>
          </CardContent>
        </Card>

        <Card className="border-warning/30 bg-warning/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Review Needed</p>
                <p className="text-3xl font-bold text-warning">1</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-warning" />
            </div>
            <p className="mt-2 text-xs text-warning">20-50 risk score</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Authenticity</p>
                <p className="text-3xl font-bold">92%</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+2% vs last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Bot Activity Blocked</p>
                <p className="text-3xl font-bold">4.2%</p>
              </div>
              <Bot className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Across all partners</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Partner Risk Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 p-2">
            {mockFraudAnalysis.map((analysis) => {
              const riskBadge = getRiskBadge(analysis.overallRiskScore);
              return (
                <div
                  key={analysis.influencerId}
                  className={`cursor-pointer rounded-lg border p-3 transition-colors hover:bg-muted/50 ${
                    selectedInfluencer.influencerId === analysis.influencerId ? 'border-primary bg-primary/5' : ''
                  }`}
                  onClick={() => setSelectedInfluencer(analysis)}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={analysis.avatar} />
                      <AvatarFallback>{analysis.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{analysis.name}</p>
                        <Badge className={riskBadge.className}>{riskBadge.label}</Badge>
                      </div>
                      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{analysis.platform}</span>
                        <span>•</span>
                        <span>Scanned {analysis.lastScanned}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 flex items-center gap-4 text-xs">
                    <div className="flex items-center gap-1">
                      <ShieldCheck className="h-3 w-3 text-success" />
                      <span>{analysis.authenticityScore}% authentic</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bot className="h-3 w-3 text-muted-foreground" />
                      <span>{analysis.fakeFollowerPercent}% fake</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={selectedInfluencer.avatar} />
                  <AvatarFallback>{selectedInfluencer.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">{selectedInfluencer.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {selectedInfluencer.platform} • Detailed Risk Analysis
                  </p>
                </div>
              </div>
              <Badge className={getRiskBadge(selectedInfluencer.overallRiskScore).className}>
                Risk Score: {selectedInfluencer.overallRiskScore}/100
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="engagement">Engagement Analysis</TabsTrigger>
                <TabsTrigger value="growth">Growth Pattern</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="rounded-lg border p-3 text-center">
                    <p className="text-sm text-muted-foreground">Authenticity</p>
                    <p className="text-2xl font-bold text-success">{selectedInfluencer.authenticityScore}%</p>
                  </div>
                  <div className="rounded-lg border p-3 text-center">
                    <p className="text-sm text-muted-foreground">Fake Followers</p>
                    <p
                      className={`text-2xl font-bold ${
                        selectedInfluencer.fakeFollowerPercent < 3 ? 'text-success' : 'text-warning'
                      }`}
                    >
                      {selectedInfluencer.fakeFollowerPercent}%
                    </p>
                  </div>
                  <div className="rounded-lg border p-3 text-center">
                    <p className="text-sm text-muted-foreground">Bot Engagement</p>
                    <p
                      className={`text-2xl font-bold ${
                        selectedInfluencer.botEngagementPercent < 5 ? 'text-success' : 'text-warning'
                      }`}
                    >
                      {selectedInfluencer.botEngagementPercent}%
                    </p>
                  </div>
                  <div className="rounded-lg border p-3 text-center">
                    <p className="text-sm text-muted-foreground">Audience Quality</p>
                    <p className="text-2xl font-bold">{selectedInfluencer.audienceCredibility}%</p>
                  </div>
                </div>

                {selectedInfluencer.riskFactors.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="flex items-center gap-2 font-semibold">
                      <AlertTriangle className="h-4 w-4 text-warning" />
                      Risk Factors ({selectedInfluencer.riskFactors.length})
                    </h4>
                    {selectedInfluencer.riskFactors.map((factor, idx) => (
                      <div
                        key={idx}
                        className={`rounded-lg border p-3 ${
                          factor.severity === 'high'
                            ? 'border-destructive/30 bg-destructive/5'
                            : factor.severity === 'medium'
                              ? 'border-warning/30 bg-warning/5'
                              : 'border-border'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <p className="font-medium">{factor.factor}</p>
                          <Badge
                            variant="outline"
                            className={
                              factor.severity === 'high'
                                ? 'border-destructive text-destructive'
                                : factor.severity === 'medium'
                                  ? 'border-warning text-warning'
                                  : ''
                            }
                          >
                            {factor.severity}
                          </Badge>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">{factor.description}</p>
                      </div>
                    ))}
                  </div>
                )}

                <div className="space-y-2">
                  <h4 className="flex items-center gap-2 font-semibold">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    Positive Indicators
                  </h4>
                  <div className="grid gap-2 md:grid-cols-2">
                    {selectedInfluencer.positiveIndicators.map((indicator, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2 rounded-lg border border-success/20 bg-success/5 p-2 text-sm"
                      >
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        {indicator}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="engagement" className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h4 className="mb-4 font-semibold">Engagement Pattern Analysis (24h)</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={engagementPatternData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 'var(--radius)',
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="genuine"
                        stackId="1"
                        stroke="hsl(var(--success))"
                        fill="hsl(var(--success))"
                        fillOpacity={0.3}
                        name="Genuine"
                      />
                      <Area
                        type="monotone"
                        dataKey="suspicious"
                        stackId="1"
                        stroke="hsl(var(--destructive))"
                        fill="hsl(var(--destructive))"
                        fillOpacity={0.3}
                        name="Suspicious"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                  <p className="mt-2 text-center text-sm text-muted-foreground">
                    Engagement follows natural human activity patterns • {'>'}97% genuine interactions
                  </p>
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Activity className="h-4 w-4" />
                      Engagement Consistency
                    </div>
                    <p className="mt-1 text-2xl font-bold">{selectedInfluencer.engagementConsistency}%</p>
                    <Progress value={selectedInfluencer.engagementConsistency} className="mt-2 h-2" />
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <BarChart3 className="h-4 w-4" />
                      Like/Comment Ratio
                    </div>
                    <p className="mt-1 text-2xl font-bold">{selectedInfluencer.likeCommentRatio}:1</p>
                    <p className="mt-1 text-xs text-success">Within healthy range</p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      Response Time
                    </div>
                    <p className="mt-1 text-2xl font-bold">2.4h</p>
                    <p className="mt-1 text-xs text-muted-foreground">Avg reply time</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="growth" className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h4 className="mb-4 font-semibold">Follower Growth Analysis (6 months)</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={followerGrowthData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 'var(--radius)',
                        }}
                        formatter={(value: number) => value.toLocaleString()}
                      />
                      <Line
                        type="monotone"
                        dataKey="organic"
                        stroke="hsl(var(--success))"
                        strokeWidth={2}
                        name="Organic Growth"
                      />
                      <Line
                        type="monotone"
                        dataKey="suspicious"
                        stroke="hsl(var(--destructive))"
                        strokeWidth={2}
                        name="Suspicious"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="flex items-center gap-4 rounded-lg border border-success/20 bg-success/5 p-4">
                  <TrendingUp className="h-8 w-8 text-success" />
                  <div>
                    <p className="font-semibold">Organic Growth Pattern Verified</p>
                    <p className="text-sm text-muted-foreground">
                      Steady 1.2% monthly growth consistent with content quality and posting frequency
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
