import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import {
  Calculator,
  TrendingUp,
  DollarSign,
  Target,
  Sparkles,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  BarChart3,
  Users,
  Eye,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  ComposedChart,
  Bar,
} from 'recharts';

interface ScenarioResult {
  revenue: number;
  roas: number;
  reach: number;
  conversions: number;
  cpa: number;
  confidence: number;
}

const outcomeProjections = [
  { week: 'W1', conservative: 4200, expected: 5800, optimistic: 7400 },
  { week: 'W2', conservative: 9800, expected: 14200, optimistic: 18400 },
  { week: 'W3', conservative: 16400, expected: 24800, optimistic: 32200 },
  { week: 'W4', conservative: 22800, expected: 36400, optimistic: 48200 },
  { week: 'W5', conservative: 28400, expected: 46800, optimistic: 62400 },
  { week: 'W6', conservative: 32800, expected: 54200, optimistic: 74800 },
];

const roasComparison = [
  { scenario: 'Current Mix', roas: 6.8 },
  { scenario: 'Heavy TikTok', roas: 8.2 },
  { scenario: 'Heavy IG', roas: 5.4 },
  { scenario: 'Micro Focus', roas: 9.4 },
  { scenario: 'Macro Focus', roas: 5.8 },
];

export function CampaignROIPredictor() {
  const [budget, setBudget] = useState([10000]);
  const [duration, setDuration] = useState('6');
  const [platform, setPlatform] = useState('mixed');
  const [includeVideo, setIncludeVideo] = useState(true);
  const [influencerTier, setInfluencerTier] = useState('mixed');
  const [calculating, setCalculating] = useState(false);
  const [showResults, setShowResults] = useState(true);

  const [scenarios] = useState({
    conservative: {
      revenue: 32800,
      roas: 3.28,
      reach: 1240000,
      conversions: 824,
      cpa: 12.14,
      confidence: 92,
    },
    expected: {
      revenue: 54200,
      roas: 5.42,
      reach: 2180000,
      conversions: 1364,
      cpa: 7.33,
      confidence: 78,
    },
    optimistic: {
      revenue: 74800,
      roas: 7.48,
      reach: 3420000,
      conversions: 1872,
      cpa: 5.34,
      confidence: 58,
    },
  });

  const handleCalculate = () => {
    setCalculating(true);
    setTimeout(() => {
      setCalculating(false);
      setShowResults(true);
    }, 1500);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toString();
  };

  return (
    <div className="space-y-6">
      <Card className="border-chart-2/20 bg-gradient-to-br from-chart-2/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-2/10">
                <Calculator className="h-5 w-5 text-chart-2" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Campaign ROI Predictor
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    ML-Powered
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Predict campaign outcomes with confidence intervals and scenario modeling
                </p>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Campaign Parameters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label>Total Budget</Label>
              <Slider value={budget} onValueChange={setBudget} min={5000} max={50000} step={1000} />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Budget:</span>
                <span className="font-bold">${budget[0].toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Campaign Duration</Label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 Weeks</SelectItem>
                  <SelectItem value="4">4 Weeks</SelectItem>
                  <SelectItem value="6">6 Weeks</SelectItem>
                  <SelectItem value="8">8 Weeks</SelectItem>
                  <SelectItem value="12">12 Weeks</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Platform Focus</Label>
              <Select value={platform} onValueChange={setPlatform}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mixed">Mixed (Recommended)</SelectItem>
                  <SelectItem value="instagram">Instagram Heavy</SelectItem>
                  <SelectItem value="tiktok">TikTok Heavy</SelectItem>
                  <SelectItem value="youtube">YouTube Heavy</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Influencer Tier</Label>
              <Select value={influencerTier} onValueChange={setInfluencerTier}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mixed">Mixed Tiers</SelectItem>
                  <SelectItem value="micro">Micro (10K-100K)</SelectItem>
                  <SelectItem value="macro">Macro (100K-1M)</SelectItem>
                  <SelectItem value="mega">Mega (1M+)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="video">Include Video Content</Label>
              <Switch id="video" checked={includeVideo} onCheckedChange={setIncludeVideo} />
            </div>

            <Button className="w-full gap-2" onClick={handleCalculate}>
              {calculating ? (
                <>
                  <Sparkles className="h-4 w-4 animate-pulse" />
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="h-4 w-4" />
                  Predict ROI
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              Projected Outcomes
              <Badge variant="outline">3 Scenarios</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {showResults && (
              <>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-lg border border-muted bg-muted/30 p-4">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Conservative</span>
                      <Badge variant="outline" className="gap-1">
                        <ArrowDownRight className="h-3 w-3" />
                        {scenarios.conservative.confidence}%
                      </Badge>
                    </div>
                    <p className="text-2xl font-bold">${(scenarios.conservative.revenue / 1000).toFixed(1)}K</p>
                    <p className="text-sm text-muted-foreground">{scenarios.conservative.roas}x ROAS</p>
                    <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                      <p>Reach: {formatNumber(scenarios.conservative.reach)}</p>
                      <p>Conversions: {scenarios.conservative.conversions}</p>
                    </div>
                  </div>

                  <div className="rounded-lg border-2 border-primary bg-primary/5 p-4">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-medium">Expected</span>
                      <Badge className="gap-1 bg-primary/10 text-primary">
                        <Target className="h-3 w-3" />
                        {scenarios.expected.confidence}%
                      </Badge>
                    </div>
                    <p className="text-2xl font-bold text-primary">
                      ${(scenarios.expected.revenue / 1000).toFixed(1)}K
                    </p>
                    <p className="font-medium text-primary">{scenarios.expected.roas}x ROAS</p>
                    <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                      <p>Reach: {formatNumber(scenarios.expected.reach)}</p>
                      <p>Conversions: {scenarios.expected.conversions}</p>
                    </div>
                  </div>

                  <div className="rounded-lg border border-success/30 bg-success/5 p-4">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm text-success">Optimistic</span>
                      <Badge variant="outline" className="gap-1 border-success/50 text-success">
                        <ArrowUpRight className="h-3 w-3" />
                        {scenarios.optimistic.confidence}%
                      </Badge>
                    </div>
                    <p className="text-2xl font-bold text-success">
                      ${(scenarios.optimistic.revenue / 1000).toFixed(1)}K
                    </p>
                    <p className="text-sm text-success">{scenarios.optimistic.roas}x ROAS</p>
                    <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                      <p>Reach: {formatNumber(scenarios.optimistic.reach)}</p>
                      <p>Conversions: {scenarios.optimistic.conversions}</p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="mb-4 font-semibold">Revenue Projection Over Time</h4>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={outcomeProjections}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 'var(--radius)',
                        }}
                        formatter={(value: number) => `$${value.toLocaleString()}`}
                      />
                      <Area
                        type="monotone"
                        dataKey="optimistic"
                        stroke="hsl(var(--success))"
                        fill="hsl(var(--success))"
                        fillOpacity={0.1}
                        strokeWidth={1}
                        strokeDasharray="3 3"
                        name="Optimistic"
                      />
                      <Area
                        type="monotone"
                        dataKey="expected"
                        stroke="hsl(var(--primary))"
                        fill="hsl(var(--primary))"
                        fillOpacity={0.2}
                        strokeWidth={2}
                        name="Expected"
                      />
                      <Area
                        type="monotone"
                        dataKey="conservative"
                        stroke="hsl(var(--muted-foreground))"
                        fill="hsl(var(--muted-foreground))"
                        fillOpacity={0.1}
                        strokeWidth={1}
                        strokeDasharray="3 3"
                        name="Conservative"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Scenario Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <ComposedChart data={roasComparison} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis
                  dataKey="scenario"
                  type="category"
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  width={100}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--popover))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 'var(--radius)',
                  }}
                  formatter={(value: number) => `${value}x ROAS`}
                />
                <Bar dataKey="roas" fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Key Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border border-success/20 bg-success/5 p-3">
              <CheckCircle2 className="mt-0.5 h-5 w-5 text-success" />
              <div>
                <p className="font-medium">High Confidence Prediction</p>
                <p className="text-sm text-muted-foreground">
                  78% probability of achieving 5.4x+ ROAS based on historical data
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border border-chart-2/20 bg-chart-2/5 p-3">
              <BarChart3 className="mt-0.5 h-5 w-5 text-chart-2" />
              <div>
                <p className="font-medium">Micro-Influencer Advantage</p>
                <p className="text-sm text-muted-foreground">
                  Shifting 30% budget to micro tier could increase ROAS by 1.8x
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <AlertCircle className="mt-0.5 h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium">Seasonality Factor</p>
                <p className="text-sm text-muted-foreground">Q4 campaigns historically show +28% performance boost</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border border-chart-3/20 bg-chart-3/5 p-3">
              <TrendingUp className="mt-0.5 h-5 w-5 text-chart-3" />
              <div>
                <p className="font-medium">Optimal Budget Allocation</p>
                <p className="text-sm text-muted-foreground">
                  TikTok: 45% | Instagram: 35% | YouTube: 20% for max efficiency
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
