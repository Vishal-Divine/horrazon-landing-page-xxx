import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  FileText,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Scale,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Calculator,
  Sparkles,
  Clock,
  Shield,
  Percent,
  Users,
  BarChart3,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface PricingAnalysis {
  influencerId: string;
  name: string;
  avatar: string;
  platform: string;
  followers: string;
  askingRate: number;
  fairValueMin: number;
  fairValueMax: number;
  marketAvg: number;
  recommendedOffer: number;
  negotiationRoom: number;
  valueScore: number;
  riskFactors: string[];
  contractSuggestions: string[];
  historicalDeals: { brand: string; rate: number }[];
}

const pricingAnalysis: PricingAnalysis[] = [
  {
    influencerId: '1',
    name: '@beautybyemma',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    platform: 'TikTok',
    followers: '892K',
    askingRate: 8500,
    fairValueMin: 6800,
    fairValueMax: 9200,
    marketAvg: 7800,
    recommendedOffer: 7500,
    negotiationRoom: 12,
    valueScore: 94,
    riskFactors: [],
    contractSuggestions: [
      'Lock in 3-month rate for 10% discount',
      'Include exclusivity for 15% premium',
      'Performance bonus at 8x ROAS',
    ],
    historicalDeals: [
      { brand: 'Glow Recipe', rate: 8200 },
      { brand: 'CeraVe', rate: 7800 },
      { brand: 'Fenty Beauty', rate: 9000 },
    ],
  },
  {
    influencerId: '2',
    name: '@fitnessguru_sarah',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    platform: 'Instagram',
    followers: '284K',
    askingRate: 4200,
    fairValueMin: 3200,
    fairValueMax: 4400,
    marketAvg: 3600,
    recommendedOffer: 3800,
    negotiationRoom: 18,
    valueScore: 86,
    riskFactors: ['Engagement trending down 8% QoQ'],
    contractSuggestions: [
      'Negotiate based on declining engagement',
      'Include content repurposing rights',
      'Set performance milestones',
    ],
    historicalDeals: [
      { brand: 'Gymshark', rate: 4000 },
      { brand: 'MyProtein', rate: 3800 },
    ],
  },
  {
    influencerId: '3',
    name: '@techreviews_mike',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    platform: 'YouTube',
    followers: '520K',
    askingRate: 12000,
    fairValueMin: 9800,
    fairValueMax: 14200,
    marketAvg: 11400,
    recommendedOffer: 10500,
    negotiationRoom: 8,
    valueScore: 91,
    riskFactors: [],
    contractSuggestions: [
      'Bundle dedicated video + shorts',
      'Include affiliate link in description',
      'Request long-term partnership discount',
    ],
    historicalDeals: [
      { brand: 'Samsung', rate: 14000 },
      { brand: 'Anker', rate: 9500 },
      { brand: 'Logitech', rate: 11000 },
    ],
  },
];

const marketRateBenchmarks = [
  { tier: 'Nano (1-10K)', instagram: 250, tiktok: 200, youtube: 400 },
  { tier: 'Micro (10-100K)', instagram: 1200, tiktok: 800, youtube: 2500 },
  { tier: 'Mid (100K-500K)', instagram: 4500, tiktok: 3200, youtube: 8000 },
  { tier: 'Macro (500K-1M)', instagram: 9500, tiktok: 7500, youtube: 18000 },
  { tier: 'Mega (1M+)', instagram: 25000, tiktok: 20000, youtube: 45000 },
];

export function ContractNegotiationInsights() {
  const [selectedInfluencer, setSelectedInfluencer] = useState(pricingAnalysis[0]);
  const [offerAmount, setOfferAmount] = useState([selectedInfluencer.recommendedOffer]);
  const [includeExclusivity, setIncludeExclusivity] = useState(false);
  const [contentBundle, setContentBundle] = useState(false);
  const [performanceBonus, setPerformanceBonus] = useState(true);

  const calculateAdjustedOffer = () => {
    let base = offerAmount[0];
    if (includeExclusivity) base *= 1.15;
    if (contentBundle) base *= 1.08;
    if (performanceBonus) base *= 0.95;
    return Math.round(base);
  };

  const getPricePositionColor = (asking: number, fairMin: number, fairMax: number) => {
    if (asking <= fairMin) return 'text-success';
    if (asking <= fairMax) return 'text-chart-2';
    return 'text-destructive';
  };

  return (
    <div className="space-y-6">
      <Card className="border-chart-4/20 bg-gradient-to-br from-chart-4/5 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-4/10">
                <Scale className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Contract & Negotiation Insights
                  <Badge variant="secondary" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    Fair Value AI
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Pricing intelligence, fair value calculations & contract optimization
                </p>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Savings</p>
                <p className="text-3xl font-bold text-success">18%</p>
              </div>
              <DollarSign className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">From AI negotiations</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Deals Optimized</p>
                <p className="text-3xl font-bold">42</p>
              </div>
              <FileText className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">This quarter</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Value Score</p>
                <p className="text-3xl font-bold">89%</p>
              </div>
              <BarChart3 className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-success">+12% vs market</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Saved</p>
                <p className="text-3xl font-bold">$48K</p>
              </div>
              <TrendingUp className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">YTD savings</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pricing" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pricing" className="gap-2">
            <DollarSign className="h-4 w-4" />
            Pricing Analysis
          </TabsTrigger>
          <TabsTrigger value="negotiation" className="gap-2">
            <Scale className="h-4 w-4" />
            Negotiation Tool
          </TabsTrigger>
          <TabsTrigger value="benchmarks" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Market Benchmarks
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pricing" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {pricingAnalysis.map((analysis) => (
              <Card
                key={analysis.influencerId}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedInfluencer.influencerId === analysis.influencerId ? 'border-primary ring-1 ring-primary' : ''
                }`}
                onClick={() => {
                  setSelectedInfluencer(analysis);
                  setOfferAmount([analysis.recommendedOffer]);
                }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={analysis.avatar} />
                      <AvatarFallback>{analysis.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">{analysis.name}</h4>
                        <Badge
                          className={
                            analysis.valueScore >= 90
                              ? 'bg-success/10 text-success'
                              : analysis.valueScore >= 80
                                ? 'bg-chart-2/10 text-chart-2'
                                : 'bg-warning/10 text-warning'
                          }
                        >
                          {analysis.valueScore}% Value
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {analysis.platform} • {analysis.followers}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Asking Rate</span>
                      <span
                        className={`font-bold ${getPricePositionColor(
                          analysis.askingRate,
                          analysis.fairValueMin,
                          analysis.fairValueMax,
                        )}`}
                      >
                        ${analysis.askingRate.toLocaleString()}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Fair Value Range</span>
                        <span>
                          ${analysis.fairValueMin.toLocaleString()} - ${analysis.fairValueMax.toLocaleString()}
                        </span>
                      </div>
                      <div className="relative h-2 w-full rounded-full bg-muted">
                        <div
                          className="absolute h-full rounded-full bg-chart-2"
                          style={{
                            left: `${
                              ((analysis.fairValueMin - analysis.fairValueMin * 0.2) / (analysis.fairValueMax * 1.2)) *
                              100
                            }%`,
                            width: `${
                              ((analysis.fairValueMax - analysis.fairValueMin) / (analysis.fairValueMax * 1.2)) * 100
                            }%`,
                          }}
                        />
                        <div
                          className="absolute top-1/2 h-4 w-1 -translate-y-1/2 rounded-full bg-foreground"
                          style={{
                            left: `${(analysis.askingRate / (analysis.fairValueMax * 1.2)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between rounded-lg bg-muted/50 p-2">
                      <span className="text-sm">Recommended Offer</span>
                      <span className="font-bold text-primary">${analysis.recommendedOffer.toLocaleString()}</span>
                    </div>

                    {analysis.riskFactors.length > 0 && (
                      <div className="flex items-center gap-2 text-xs text-warning">
                        <AlertTriangle className="h-3 w-3" />
                        {analysis.riskFactors[0]}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="negotiation" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Calculator className="h-5 w-5" />
                  Build Your Offer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={selectedInfluencer.avatar} />
                    <AvatarFallback>{selectedInfluencer.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold">{selectedInfluencer.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      Asking: ${selectedInfluencer.askingRate.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Base Offer Amount</Label>
                  <Slider
                    value={offerAmount}
                    onValueChange={setOfferAmount}
                    min={selectedInfluencer.fairValueMin * 0.8}
                    max={selectedInfluencer.fairValueMax * 1.1}
                    step={100}
                  />
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Your offer:</span>
                    <span className="font-bold">${offerAmount[0].toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="exclusivity">Category Exclusivity</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">+15%</span>
                      <Switch id="exclusivity" checked={includeExclusivity} onCheckedChange={setIncludeExclusivity} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="bundle">Content Bundle (3 posts)</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">+8%</span>
                      <Switch id="bundle" checked={contentBundle} onCheckedChange={setContentBundle} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Percent className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="bonus">Performance Bonus Structure</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-success">-5%</span>
                      <Switch id="bonus" checked={performanceBonus} onCheckedChange={setPerformanceBonus} />
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border-2 border-primary bg-primary/5 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Final Offer</span>
                    <span className="text-2xl font-bold text-primary">
                      ${calculateAdjustedOffer().toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {((1 - calculateAdjustedOffer() / selectedInfluencer.askingRate) * 100).toFixed(0)}% below asking
                    rate
                  </p>
                </div>

                <Button className="w-full gap-2">
                  Generate Contract Draft
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Lightbulb className="h-5 w-5 text-chart-3" />
                  Negotiation Strategy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h4 className="font-semibold">Key Talking Points</h4>
                  {selectedInfluencer.contractSuggestions.map((suggestion, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2 rounded-lg border border-chart-3/20 bg-chart-3/5 p-3"
                    >
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-chart-3" />
                      <p className="text-sm">{suggestion}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Historical Deal References</h4>
                  <div className="space-y-2">
                    {selectedInfluencer.historicalDeals.map((deal, idx) => (
                      <div key={idx} className="flex items-center justify-between rounded-lg border p-2 text-sm">
                        <span>{deal.brand}</span>
                        <span className="font-medium">${deal.rate.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-lg border p-3">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Best Time to Negotiate</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    End of month/quarter when creators are more flexible on rates
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="benchmarks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Market Rate Benchmarks by Tier</CardTitle>
              <p className="text-sm text-muted-foreground">Average rates per sponsored post across platforms</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={marketRateBenchmarks}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="tier" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                    formatter={(value: number) => `$${value.toLocaleString()}`}
                  />
                  <Bar dataKey="instagram" fill="hsl(var(--chart-1))" name="Instagram" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="tiktok" fill="hsl(var(--chart-2))" name="TikTok" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="youtube" fill="hsl(var(--chart-3))" name="YouTube" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-4 flex justify-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded bg-chart-1" />
                  <span className="text-sm">Instagram</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded bg-chart-2" />
                  <span className="text-sm">TikTok</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded bg-chart-3" />
                  <span className="text-sm">YouTube</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
