import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock } from 'lucide-react';

interface PeriodSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export default function PeriodSelector({ value, onChange }: PeriodSelectorProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Calendar className="h-4 w-4" />
        <span className="font-medium">Compare to:</span>
      </div>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-[200px] bg-card border-border/60 hover:border-primary/40 transition-colors">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="previous_period">Previous Period</SelectItem>
          <SelectItem value="previous_week">Previous Week</SelectItem>
          <SelectItem value="previous_month">Previous Month</SelectItem>
          <SelectItem value="same_period_last_year">Same Period Last Year</SelectItem>
          <SelectItem value="custom">Custom Range</SelectItem>
        </SelectContent>
      </Select>

      <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-muted/50 border border-border/50">
        <Clock className="h-3.5 w-3.5 text-success animate-pulse" />
        <span className="text-xs font-medium text-muted-foreground">
          Last updated: <span className="text-foreground">2 min ago</span>
        </span>
      </div>
    </div>
  );
}
