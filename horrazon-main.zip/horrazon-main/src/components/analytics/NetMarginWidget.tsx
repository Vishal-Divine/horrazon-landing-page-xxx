import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Minus,
  Package,
  Megaphone,
  Calculator,
  ArrowRight,
  Info,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  ComposedChart,
  Area,
} from 'recharts';
import { Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface ChannelMargin {
  channel: string;
  revenue: number;
  cogs: number;
  adSpend: number;
  netMargin: number;
  marginPercent: number;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
}

interface TimeSeriesMargin {
  date: string;
  revenue: number;
  cogs: number;
  adSpend: number;
  netMargin: number;
}

const channelMarginData: ChannelMargin[] = [
  {
    channel: 'Meta Ads',
    revenue: 48500,
    cogs: 19400,
    adSpend: 12000,
    netMargin: 17100,
    marginPercent: 35.3,
    trend: 'up',
    trendValue: 4.2,
  },
  {
    channel: 'Google Ads',
    revenue: 32800,
    cogs: 13120,
    adSpend: 9800,
    netMargin: 9880,
    marginPercent: 30.1,
    trend: 'down',
    trendValue: -2.1,
  },
  {
    channel: 'TikTok Ads',
    revenue: 24200,
    cogs: 9680,
    adSpend: 8400,
    netMargin: 6120,
    marginPercent: 25.3,
    trend: 'up',
    trendValue: 8.4,
  },
  {
    channel: 'Influencer',
    revenue: 18600,
    cogs: 7440,
    adSpend: 6200,
    netMargin: 4960,
    marginPercent: 26.7,
    trend: 'stable',
    trendValue: 0.3,
  },
  {
    channel: 'Email',
    revenue: 15200,
    cogs: 6080,
    adSpend: 1200,
    netMargin: 7920,
    marginPercent: 52.1,
    trend: 'up',
    trendValue: 2.8,
  },
];

const timeSeriesData: TimeSeriesMargin[] = [
  { date: 'Mon', revenue: 24500, cogs: 9800, adSpend: 6200, netMargin: 8500 },
  { date: 'Tue', revenue: 26800, cogs: 10720, adSpend: 6800, netMargin: 9280 },
  { date: 'Wed', revenue: 22100, cogs: 8840, adSpend: 5900, netMargin: 7360 },
  { date: 'Thu', revenue: 28400, cogs: 11360, adSpend: 7200, netMargin: 9840 },
  { date: 'Fri', revenue: 31200, cogs: 12480, adSpend: 7800, netMargin: 10920 },
  { date: 'Sat', revenue: 35600, cogs: 14240, adSpend: 8400, netMargin: 12960 },
  { date: 'Sun', revenue: 29800, cogs: 11920, adSpend: 7400, netMargin: 10480 },
];

const tooltipStyle = {
  backgroundColor: 'hsl(var(--popover))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '8px',
};

export function NetMarginWidget() {
  const totalRevenue = channelMarginData.reduce((sum, c) => sum + c.revenue, 0);
  const totalCOGS = channelMarginData.reduce((sum, c) => sum + c.cogs, 0);
  const totalAdSpend = channelMarginData.reduce((sum, c) => sum + c.adSpend, 0);
  const totalNetMargin = channelMarginData.reduce((sum, c) => sum + c.netMargin, 0);
  const overallMarginPercent = ((totalNetMargin / totalRevenue) * 100).toFixed(1);

  const TrendIcon = ({ trend, value }: { trend: 'up' | 'down' | 'stable'; value: number }) => {
    if (trend === 'up') return <TrendingUp className="h-3 w-3 text-success" />;
    if (trend === 'down') return <TrendingDown className="h-3 w-3 text-destructive" />;
    return <Minus className="h-3 w-3 text-muted-foreground" />;
  };

  return (
    <Card className="border-success/20 bg-gradient-to-br from-card to-success/5">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/10">
              <Calculator className="h-4 w-4 text-success" />
            </div>
            Real-Time Net Margin
            <TooltipProvider>
              <UITooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">Net Margin = Revenue - COGS - Ad Spend</p>
                  <p className="text-xs text-muted-foreground mt-1">Shows true profit efficiency after all costs</p>
                </TooltipContent>
              </UITooltip>
            </TooltipProvider>
          </CardTitle>
          <Badge className="bg-success text-success-foreground">{overallMarginPercent}% margin</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-3">
          <div className="rounded-lg bg-chart-1/10 p-3 text-center">
            <p className="text-lg font-bold text-chart-1">${(totalRevenue / 1000).toFixed(1)}K</p>
            <p className="text-[10px] text-muted-foreground">Revenue</p>
          </div>
          <div className="rounded-lg bg-destructive/10 p-3 text-center">
            <p className="text-lg font-bold text-destructive">-${(totalCOGS / 1000).toFixed(1)}K</p>
            <p className="text-[10px] text-muted-foreground">COGS</p>
          </div>
          <div className="rounded-lg bg-warning/10 p-3 text-center">
            <p className="text-lg font-bold text-warning">-${(totalAdSpend / 1000).toFixed(1)}K</p>
            <p className="text-[10px] text-muted-foreground">Ad Spend</p>
          </div>
          <div className="rounded-lg bg-success/10 p-3 text-center">
            <p className="text-lg font-bold text-success">${(totalNetMargin / 1000).toFixed(1)}K</p>
            <p className="text-[10px] text-muted-foreground">Net Margin</p>
          </div>
        </div>

        <Tabs defaultValue="channels" className="space-y-3">
          <TabsList className="w-full">
            <TabsTrigger value="channels" className="flex-1">
              By Channel
            </TabsTrigger>
            <TabsTrigger value="timeline" className="flex-1">
              Timeline
            </TabsTrigger>
          </TabsList>

          <TabsContent value="channels">
            <div className="space-y-3">
              {channelMarginData.map((channel) => (
                <div
                  key={channel.channel}
                  className="rounded-lg border border-border/50 bg-card/50 p-3 hover:border-primary/30 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{channel.channel}</span>
                      <div className="flex items-center gap-1">
                        <TrendIcon trend={channel.trend} value={channel.trendValue} />
                        <span
                          className={`text-xs ${
                            channel.trend === 'up'
                              ? 'text-success'
                              : channel.trend === 'down'
                                ? 'text-destructive'
                                : 'text-muted-foreground'
                          }`}
                        >
                          {channel.trendValue > 0 ? '+' : ''}
                          {channel.trendValue}%
                        </span>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={`${
                        channel.marginPercent >= 40
                          ? 'bg-success/10 text-success border-success/30'
                          : channel.marginPercent >= 25
                            ? 'bg-chart-1/10 text-chart-1 border-chart-1/30'
                            : 'bg-warning/10 text-warning border-warning/30'
                      }`}
                    >
                      {channel.marginPercent}% margin
                    </Badge>
                  </div>

                  {/* Stacked bar visualization */}
                  <div className="flex h-6 w-full overflow-hidden rounded-md">
                    <div
                      className="bg-success flex items-center justify-center"
                      style={{ width: `${(channel.netMargin / channel.revenue) * 100}%` }}
                    >
                      <span className="text-[9px] text-success-foreground font-medium">
                        ${(channel.netMargin / 1000).toFixed(1)}K
                      </span>
                    </div>
                    <div
                      className="bg-destructive/70 flex items-center justify-center"
                      style={{ width: `${(channel.cogs / channel.revenue) * 100}%` }}
                    >
                      <span className="text-[9px] text-destructive-foreground font-medium">COGS</span>
                    </div>
                    <div
                      className="bg-warning/70 flex items-center justify-center"
                      style={{ width: `${(channel.adSpend / channel.revenue) * 100}%` }}
                    >
                      <span className="text-[9px] text-warning-foreground font-medium">Ads</span>
                    </div>
                  </div>

                  <div className="flex justify-between mt-2 text-[10px] text-muted-foreground">
                    <span>Revenue: ${channel.revenue.toLocaleString()}</span>
                    <span>COGS: ${channel.cogs.toLocaleString()}</span>
                    <span>Ad Spend: ${channel.adSpend.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="timeline">
            <ResponsiveContainer width="100%" height={200}>
              <ComposedChart data={timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickFormatter={(v) => `$${v / 1000}K`} />
                <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => `$${value.toLocaleString()}`} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  fill="hsl(var(--chart-1))"
                  fillOpacity={0.2}
                  stroke="hsl(var(--chart-1))"
                  name="Revenue"
                />
                <Line
                  type="monotone"
                  dataKey="netMargin"
                  stroke="hsl(var(--success))"
                  strokeWidth={3}
                  dot={{ fill: 'hsl(var(--success))' }}
                  name="Net Margin"
                />
                <Bar dataKey="adSpend" fill="hsl(var(--warning))" fillOpacity={0.6} name="Ad Spend" />
              </ComposedChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>

        {/* Insight */}
        <div className="rounded-lg bg-primary/5 border border-primary/20 p-3">
          <div className="flex items-start gap-2">
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <TrendingUp className="h-3 w-3 text-primary" />
            </div>
            <div className="text-sm">
              <span className="font-medium">Profit Insight: </span>
              <span className="text-muted-foreground">
                Email marketing has the highest margin (52.1%) despite lower revenue. Consider reallocating $2K from
                Google Ads to Email for +$1.8K additional profit.
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
