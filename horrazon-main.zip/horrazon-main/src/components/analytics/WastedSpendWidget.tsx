import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, Package, DollarSign, TrendingDown, Pause, ExternalLink } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface WastedSpendItem {
  id: string;
  campaignName: string;
  platform: string;
  dailySpend: number;
  stock: number;
  productName: string;
  wastedAmount: number;
  daysWasted: number;
  severity: 'critical' | 'warning' | 'moderate';
}

const wastedSpendData: WastedSpendItem[] = [
  {
    id: '1',
    campaignName: 'Summer Sale - Sandals',
    platform: 'Meta',
    dailySpend: 124,
    stock: 3,
    productName: 'Beach Sandals Pro',
    wastedAmount: 372,
    daysWasted: 3,
    severity: 'critical',
  },
  {
    id: '2',
    campaignName: 'TOF - Running Shoes',
    platform: 'Google',
    dailySpend: 89,
    stock: 4,
    productName: 'UltraRun X1',
    wastedAmount: 178,
    daysWasted: 2,
    severity: 'critical',
  },
  {
    id: '3',
    campaignName: 'Retarget - Dresses',
    platform: 'TikTok',
    dailySpend: 56,
    stock: 2,
    productName: 'Summer Maxi Dress',
    wastedAmount: 112,
    daysWasted: 2,
    severity: 'critical',
  },
  {
    id: '4',
    campaignName: 'Brand Awareness - Hats',
    platform: 'Meta',
    dailySpend: 42,
    stock: 8,
    productName: 'Classic Baseball Cap',
    wastedAmount: 0,
    daysWasted: 0,
    severity: 'warning',
  },
];

const severityColors = {
  critical: 'bg-destructive/10 border-destructive/30 text-destructive',
  warning: 'bg-warning/10 border-warning/30 text-warning',
  moderate: 'bg-muted border-border text-muted-foreground',
};

const severityBadgeColors = {
  critical: 'bg-destructive text-destructive-foreground',
  warning: 'bg-warning text-warning-foreground',
  moderate: 'bg-muted text-muted-foreground',
};

export function WastedSpendWidget() {
  const criticalItems = wastedSpendData.filter((i) => i.severity === 'critical');
  const totalWasted = wastedSpendData.reduce((sum, i) => sum + i.wastedAmount, 0);
  const totalDailyWaste = criticalItems.reduce((sum, i) => sum + i.dailySpend, 0);

  const handlePauseCampaign = (campaign: WastedSpendItem) => {
    toast({
      title: 'Campaign Paused',
      description: `${campaign.campaignName} has been paused. Saving ~$${campaign.dailySpend}/day.`,
    });
  };

  return (
    <Card className="border-destructive/20 bg-gradient-to-br from-card to-destructive/5">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-destructive/10">
              <TrendingDown className="h-4 w-4 text-destructive" />
            </div>
            Wasted Spend Alert
          </CardTitle>
          <Badge variant="destructive" className="animate-pulse">
            ${totalWasted.toLocaleString()} at risk
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          Campaigns spending on low-stock products (Stock &lt; 5 AND Daily Spend &gt; $50)
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-lg bg-destructive/10 p-3 text-center">
            <p className="text-2xl font-bold text-destructive">{criticalItems.length}</p>
            <p className="text-xs text-muted-foreground">Critical Campaigns</p>
          </div>
          <div className="rounded-lg bg-warning/10 p-3 text-center">
            <p className="text-2xl font-bold text-warning">${totalDailyWaste}</p>
            <p className="text-xs text-muted-foreground">Daily Waste</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <p className="text-2xl font-bold">${totalWasted}</p>
            <p className="text-xs text-muted-foreground">Total Wasted</p>
          </div>
        </div>

        {/* Campaign List */}
        <div className="space-y-3">
          {wastedSpendData
            .filter((i) => i.severity === 'critical')
            .map((item) => (
              <div key={item.id} className={`rounded-lg border p-4 ${severityColors[item.severity]}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-destructive/20">
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                    </div>
                    <div className="space-y-1">
                      <p className="font-semibold text-foreground">{item.campaignName}</p>
                      <div className="flex items-center gap-2 text-sm">
                        <Badge variant="outline" className="text-[10px]">
                          {item.platform}
                        </Badge>
                        <span className="text-muted-foreground">{item.productName}</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs">
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-3 w-3" />${item.dailySpend}/day spend
                        </span>
                        <span className="flex items-center gap-1 text-destructive font-medium">
                          <Package className="h-3 w-3" />
                          Only {item.stock} in stock
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge className={severityBadgeColors[item.severity]}>${item.wastedAmount} wasted</Badge>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="destructive"
                        className="h-7 gap-1 text-xs"
                        onClick={() => handlePauseCampaign(item)}
                      >
                        <Pause className="h-3 w-3" />
                        Pause
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0">
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Stock Level Bar */}
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Stock Level</span>
                    <span className="font-medium">{item.stock} / 100 units</span>
                  </div>
                  <Progress value={item.stock} className="h-2" />
                </div>
              </div>
            ))}
        </div>

        {/* Warning Items */}
        {wastedSpendData.filter((i) => i.severity === 'warning').length > 0 && (
          <div className="pt-2 border-t border-border">
            <p className="text-xs text-muted-foreground mb-2">Approaching Low Stock:</p>
            {wastedSpendData
              .filter((i) => i.severity === 'warning')
              .map((item) => (
                <div key={item.id} className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-warning" />
                    <span className="text-sm">{item.productName}</span>
                    <Badge variant="outline" className="text-[10px]">
                      {item.stock} left
                    </Badge>
                  </div>
                  <span className="text-sm font-medium">${item.dailySpend}/day</span>
                </div>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
