import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Image,
  Video,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  RotateCcw,
  ExternalLink,
  Play,
  Eye,
  DollarSign,
  Zap,
  ArrowUpDown,
  BarChart3,
  PieChart,
  Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart as RechartsPie,
  Pie,
  Cell,
  BarChart,
  Bar,
  CartesianGrid,
  Legend,
} from 'recharts';

interface Creative {
  id: string;
  name: string;
  type: 'image' | 'video';
  thumbnail: string;
  platform: string;
  roas: number;
  ctr: number;
  ctrChange: number;
  impressions: number;
  spend: number;
  revenue: number;
  status: 'active' | 'fatigued' | 'warning' | 'paused';
  fatigueScore: number;
  daysActive: number;
  lastUpdated: string;
  trendData: { day: string; ctr: number; roas: number }[];
}

const creativesData: Creative[] = [
  {
    id: '1',
    name: 'Summer_Hero_Beach_V3',
    type: 'video',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&h=300&fit=crop',
    platform: 'Meta',
    roas: 4.8,
    ctr: 2.4,
    ctrChange: -24,
    impressions: 145000,
    spend: 2400,
    revenue: 11520,
    status: 'fatigued',
    fatigueScore: 85,
    daysActive: 14,
    lastUpdated: '2 hours ago',
    trendData: [
      { day: 'Mon', ctr: 3.2, roas: 5.1 },
      { day: 'Tue', ctr: 3.0, roas: 4.9 },
      { day: 'Wed', ctr: 2.8, roas: 4.8 },
      { day: 'Thu', ctr: 2.6, roas: 4.6 },
      { day: 'Fri', ctr: 2.4, roas: 4.8 },
    ],
  },
  {
    id: '2',
    name: 'Product_UGC_Review_01',
    type: 'video',
    thumbnail: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=300&fit=crop',
    platform: 'TikTok',
    roas: 6.2,
    ctr: 4.8,
    ctrChange: 8,
    impressions: 89000,
    spend: 1800,
    revenue: 11160,
    status: 'active',
    fatigueScore: 12,
    daysActive: 5,
    lastUpdated: '1 hour ago',
    trendData: [
      { day: 'Mon', ctr: 4.2, roas: 5.8 },
      { day: 'Tue', ctr: 4.4, roas: 6.0 },
      { day: 'Wed', ctr: 4.6, roas: 6.1 },
      { day: 'Thu', ctr: 4.7, roas: 6.2 },
      { day: 'Fri', ctr: 4.8, roas: 6.2 },
    ],
  },
  {
    id: '3',
    name: 'Lifestyle_Carousel_Summer',
    type: 'image',
    thumbnail: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop',
    platform: 'Meta',
    roas: 3.2,
    ctr: 1.8,
    ctrChange: -18,
    impressions: 112000,
    spend: 1600,
    revenue: 5120,
    status: 'warning',
    fatigueScore: 68,
    daysActive: 10,
    lastUpdated: '3 hours ago',
    trendData: [
      { day: 'Mon', ctr: 2.2, roas: 3.8 },
      { day: 'Tue', ctr: 2.1, roas: 3.5 },
      { day: 'Wed', ctr: 2.0, roas: 3.4 },
      { day: 'Thu', ctr: 1.9, roas: 3.3 },
      { day: 'Fri', ctr: 1.8, roas: 3.2 },
    ],
  },
  {
    id: '4',
    name: 'Flash_Sale_Banner_V2',
    type: 'image',
    thumbnail: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=300&fit=crop',
    platform: 'Google',
    roas: 5.4,
    ctr: 3.2,
    ctrChange: 2,
    impressions: 78000,
    spend: 1200,
    revenue: 6480,
    status: 'active',
    fatigueScore: 22,
    daysActive: 7,
    lastUpdated: '30 min ago',
    trendData: [
      { day: 'Mon', ctr: 3.0, roas: 5.2 },
      { day: 'Tue', ctr: 3.1, roas: 5.3 },
      { day: 'Wed', ctr: 3.1, roas: 5.3 },
      { day: 'Thu', ctr: 3.2, roas: 5.4 },
      { day: 'Fri', ctr: 3.2, roas: 5.4 },
    ],
  },
  {
    id: '5',
    name: 'Influencer_Collab_Sara',
    type: 'video',
    thumbnail: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop',
    platform: 'TikTok',
    roas: 7.1,
    ctr: 5.6,
    ctrChange: 12,
    impressions: 234000,
    spend: 3200,
    revenue: 22720,
    status: 'active',
    fatigueScore: 8,
    daysActive: 3,
    lastUpdated: '45 min ago',
    trendData: [
      { day: 'Mon', ctr: 5.0, roas: 6.5 },
      { day: 'Tue', ctr: 5.2, roas: 6.8 },
      { day: 'Wed', ctr: 5.4, roas: 7.0 },
      { day: 'Thu', ctr: 5.5, roas: 7.0 },
      { day: 'Fri', ctr: 5.6, roas: 7.1 },
    ],
  },
  {
    id: '6',
    name: 'Retarget_Abandoned_Cart',
    type: 'image',
    thumbnail: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=300&h=300&fit=crop',
    platform: 'Meta',
    roas: 2.1,
    ctr: 0.9,
    ctrChange: -32,
    impressions: 56000,
    spend: 800,
    revenue: 1680,
    status: 'fatigued',
    fatigueScore: 92,
    daysActive: 21,
    lastUpdated: '4 hours ago',
    trendData: [
      { day: 'Mon', ctr: 1.4, roas: 2.8 },
      { day: 'Tue', ctr: 1.2, roas: 2.5 },
      { day: 'Wed', ctr: 1.1, roas: 2.3 },
      { day: 'Thu', ctr: 1.0, roas: 2.2 },
      { day: 'Fri', ctr: 0.9, roas: 2.1 },
    ],
  },
];

const statusColors = {
  active: 'bg-success/10 text-success border-success/30',
  fatigued: 'bg-destructive/10 text-destructive border-destructive/30',
  warning: 'bg-warning/10 text-warning border-warning/30',
  paused: 'bg-muted text-muted-foreground border-border',
};

const statusLabels = {
  active: 'Performing Well',
  fatigued: 'Creative Fatigue',
  warning: 'Declining',
  paused: 'Paused',
};

const CHART_COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

// Aggregated data for summary charts
const platformSpendData = [
  { name: 'Meta', value: 4800, color: 'hsl(var(--chart-1))' },
  { name: 'TikTok', value: 5000, color: 'hsl(var(--chart-2))' },
  { name: 'Google', value: 1200, color: 'hsl(var(--chart-3))' },
];

const performanceTrendData = [
  { day: 'Mon', avgCtr: 3.0, avgRoas: 4.8 },
  { day: 'Tue', avgCtr: 3.0, avgRoas: 4.8 },
  { day: 'Wed', avgCtr: 3.0, avgRoas: 4.8 },
  { day: 'Thu', avgCtr: 2.98, avgRoas: 4.78 },
  { day: 'Fri', avgCtr: 3.12, avgRoas: 4.8 },
];

const typePerformanceData = [
  { type: 'Video', roas: 6.0, ctr: 4.3, spend: 7400 },
  { type: 'Image', roas: 3.6, ctr: 2.0, spend: 3600 },
];

export function CreativeGallery() {
  const [filter, setFilter] = useState<'all' | 'fatigued' | 'active'>('all');
  const [sortBy, setSortBy] = useState<'roas' | 'ctr' | 'fatigue'>('fatigue');

  const filteredCreatives = creativesData
    .filter((c) => {
      if (filter === 'all') return true;
      if (filter === 'fatigued') return c.status === 'fatigued' || c.status === 'warning';
      return c.status === 'active';
    })
    .sort((a, b) => {
      if (sortBy === 'roas') return b.roas - a.roas;
      if (sortBy === 'ctr') return b.ctr - a.ctr;
      return b.fatigueScore - a.fatigueScore;
    });

  const fatiguedCount = creativesData.filter((c) => c.status === 'fatigued' || c.status === 'warning').length;
  const activeCount = creativesData.filter((c) => c.status === 'active').length;
  const totalSpend = creativesData.reduce((acc, c) => acc + c.spend, 0);
  const totalRevenue = creativesData.reduce((acc, c) => acc + c.revenue, 0);
  const avgRoas = (totalRevenue / totalSpend).toFixed(1);

  const handleRefreshCreative = (creative: Creative) => {
    toast({
      title: 'Refresh Recommended',
      description: `Creating a new variant for ${creative.name}. AI will suggest improvements.`,
    });
  };

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-chart-1/20 to-chart-2/20">
              <Image className="h-5 w-5 text-chart-1" />
            </div>
            <div>
              <span className="text-lg">Creative Performance Studio</span>
              <p className="text-xs text-muted-foreground font-normal mt-0.5">
                AI-powered fatigue detection & performance analytics
              </p>
            </div>
          </CardTitle>
          <div className="flex items-center gap-2">
            {fatiguedCount > 0 && (
              <Badge variant="destructive" className="animate-pulse gap-1">
                <AlertTriangle className="h-3 w-3" />
                {fatiguedCount} Need Attention
              </Badge>
            )}
            <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/30">
              <Activity className="h-3 w-3" />
              {activeCount} Active
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        {/* Summary Stats & Charts Row */}
        <div className="grid gap-4 lg:grid-cols-4">
          {/* Quick Stats */}
          <Card className="border-border/30 bg-gradient-to-br from-muted/30 to-muted/10">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground uppercase tracking-wide">Total Spend</span>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-2xl font-bold">${totalSpend.toLocaleString()}</p>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-muted-foreground">Revenue:</span>
                <span className="font-semibold text-success">${totalRevenue.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {avgRoas}x Avg ROAS
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Platform Spend Pie */}
          <Card className="border-border/30 bg-gradient-to-br from-muted/30 to-muted/10">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <PieChart className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground uppercase tracking-wide">Spend by Platform</span>
              </div>
              <ResponsiveContainer width="100%" height={100}>
                <RechartsPie>
                  <Pie
                    data={platformSpendData}
                    cx="50%"
                    cy="50%"
                    innerRadius={25}
                    outerRadius={40}
                    dataKey="value"
                    paddingAngle={2}
                  >
                    {platformSpendData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                </RechartsPie>
              </ResponsiveContainer>
              <div className="flex justify-center gap-3 mt-1">
                {platformSpendData.map((p, i) => (
                  <div key={p.name} className="flex items-center gap-1 text-[10px]">
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: CHART_COLORS[i] }} />
                    <span>{p.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Performance Trend */}
          <Card className="border-border/30 bg-gradient-to-br from-muted/30 to-muted/10">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground uppercase tracking-wide">CTR Trend (5 Days)</span>
              </div>
              <ResponsiveContainer width="100%" height={100}>
                <AreaChart data={performanceTrendData}>
                  <defs>
                    <linearGradient id="ctrGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis hide domain={[2.5, 3.5]} />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Area
                    type="monotone"
                    dataKey="avgCtr"
                    stroke="hsl(var(--chart-1))"
                    fill="url(#ctrGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Type Performance */}
          <Card className="border-border/30 bg-gradient-to-br from-muted/30 to-muted/10">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground uppercase tracking-wide">ROAS by Type</span>
              </div>
              <ResponsiveContainer width="100%" height={100}>
                <BarChart data={typePerformanceData} layout="vertical">
                  <XAxis type="number" hide />
                  <YAxis
                    type="category"
                    dataKey="type"
                    tick={{ fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    width={45}
                  />
                  <Tooltip formatter={(value) => `${value}x`} />
                  <Bar dataKey="roas" fill="hsl(var(--chart-2))" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1 px-1">
                <span>Video: 4.3% CTR</span>
                <span>Image: 2.0% CTR</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between">
          <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <TabsList className="h-9">
              <TabsTrigger value="all" className="text-xs">
                All ({creativesData.length})
              </TabsTrigger>
              <TabsTrigger value="fatigued" className="gap-1 text-xs">
                <AlertTriangle className="h-3 w-3" />
                Fatigued ({fatiguedCount})
              </TabsTrigger>
              <TabsTrigger value="active" className="text-xs">
                Active ({activeCount})
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <Button
            variant="outline"
            size="sm"
            className="gap-1 text-xs h-9"
            onClick={() => setSortBy(sortBy === 'fatigue' ? 'roas' : sortBy === 'roas' ? 'ctr' : 'fatigue')}
          >
            <ArrowUpDown className="h-3 w-3" />
            Sort: {sortBy.toUpperCase()}
          </Button>
        </div>

        {/* Creative Grid */}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredCreatives.map((creative) => (
            <div
              key={creative.id}
              className={cn(
                'group relative rounded-xl border overflow-hidden transition-all hover:shadow-lg',
                creative.status === 'fatigued'
                  ? 'border-destructive/50 bg-destructive/5'
                  : creative.status === 'warning'
                    ? 'border-warning/50 bg-warning/5'
                    : 'border-border hover:border-primary/30',
              )}
            >
              {/* Thumbnail */}
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={creative.thumbnail}
                  alt={creative.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />

                {/* Overlay badges */}
                <div className="absolute top-2 left-2 flex gap-1">
                  <Badge variant="secondary" className="gap-1 text-[10px] bg-background/90 backdrop-blur-sm">
                    {creative.type === 'video' ? <Video className="h-3 w-3" /> : <Image className="h-3 w-3" />}
                    {creative.type}
                  </Badge>
                  <Badge variant="outline" className="text-[10px] bg-background/90 backdrop-blur-sm">
                    {creative.platform}
                  </Badge>
                </div>

                {/* Status badge */}
                <div className="absolute top-2 right-2">
                  <Badge className={cn('text-[10px]', statusColors[creative.status])}>
                    {statusLabels[creative.status]}
                  </Badge>
                </div>

                {/* Fatigue Alert Overlay */}
                {creative.status === 'fatigued' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-destructive/30 backdrop-blur-[2px]">
                    <div className="rounded-lg bg-destructive px-4 py-3 text-center shadow-lg">
                      <AlertTriangle className="h-6 w-6 mx-auto text-destructive-foreground" />
                      <p className="text-sm font-bold text-destructive-foreground mt-1">Creative Fatigue</p>
                      <p className="text-xs text-destructive-foreground/80">
                        CTR -{Math.abs(creative.ctrChange)}% in 3 days
                      </p>
                    </div>
                  </div>
                )}

                {/* Video play button */}
                {creative.type === 'video' && creative.status !== 'fatigued' && (
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-background/90 backdrop-blur-sm shadow-lg">
                      <Play className="h-6 w-6 text-foreground" />
                    </div>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{creative.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {creative.daysActive} days active • {creative.lastUpdated}
                    </p>
                  </div>
                </div>

                {/* Mini Trend Chart */}
                <div className="h-12 -mx-1">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={creative.trendData}>
                      <defs>
                        <linearGradient id={`trend-${creative.id}`} x1="0" y1="0" x2="0" y2="1">
                          <stop
                            offset="5%"
                            stopColor={creative.ctrChange >= 0 ? 'hsl(var(--success))' : 'hsl(var(--destructive))'}
                            stopOpacity={0.3}
                          />
                          <stop
                            offset="95%"
                            stopColor={creative.ctrChange >= 0 ? 'hsl(var(--success))' : 'hsl(var(--destructive))'}
                            stopOpacity={0}
                          />
                        </linearGradient>
                      </defs>
                      <Area
                        type="monotone"
                        dataKey="ctr"
                        stroke={creative.ctrChange >= 0 ? 'hsl(var(--success))' : 'hsl(var(--destructive))'}
                        fill={`url(#trend-${creative.id})`}
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Fatigue Score */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Zap className="h-3 w-3" />
                      Fatigue Score
                    </span>
                    <span
                      className={cn(
                        'font-semibold',
                        creative.fatigueScore >= 70
                          ? 'text-destructive'
                          : creative.fatigueScore >= 40
                            ? 'text-warning'
                            : 'text-success',
                      )}
                    >
                      {creative.fatigueScore}%
                    </span>
                  </div>
                  <Progress
                    value={creative.fatigueScore}
                    className={cn(
                      'h-1.5',
                      creative.fatigueScore >= 70
                        ? '[&>div]:bg-destructive'
                        : creative.fatigueScore >= 40
                          ? '[&>div]:bg-warning'
                          : '[&>div]:bg-success',
                    )}
                  />
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="rounded-lg bg-muted/50 p-2 text-center">
                    <p className="text-lg font-bold text-chart-1">{creative.roas}x</p>
                    <p className="text-[10px] text-muted-foreground">ROAS</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-2 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <span className="text-lg font-bold">{creative.ctr}%</span>
                      {creative.ctrChange !== 0 && (
                        <span
                          className={cn(
                            'text-[10px] flex items-center',
                            creative.ctrChange > 0 ? 'text-success' : 'text-destructive',
                          )}
                        >
                          {creative.ctrChange > 0 ? (
                            <TrendingUp className="h-3 w-3" />
                          ) : (
                            <TrendingDown className="h-3 w-3" />
                          )}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground">CTR</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-2 text-center">
                    <p className="text-lg font-bold">${(creative.spend / 1000).toFixed(1)}k</p>
                    <p className="text-[10px] text-muted-foreground">Spend</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t border-border/50">
                  <span className="flex items-center gap-1">
                    <Eye className="h-3 w-3" />
                    {(creative.impressions / 1000).toFixed(0)}K impressions
                  </span>
                  <span className="font-medium text-success">${creative.revenue.toLocaleString()} revenue</span>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-1">
                  {(creative.status === 'fatigued' || creative.status === 'warning') && (
                    <Button
                      size="sm"
                      variant="destructive"
                      className="flex-1 gap-1 text-xs h-8"
                      onClick={() => handleRefreshCreative(creative)}
                    >
                      <RotateCcw className="h-3 w-3" />
                      Refresh
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="gap-1 text-xs flex-1 h-8">
                    <ExternalLink className="h-3 w-3" />
                    Details
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
