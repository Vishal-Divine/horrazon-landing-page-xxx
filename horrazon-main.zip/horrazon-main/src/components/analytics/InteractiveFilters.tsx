import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Separator } from '@/components/ui/separator';
import {
  Filter,
  X,
  Calendar as CalendarIcon,
  ChevronDown,
  RefreshCw,
  Download,
  SlidersHorizontal,
  Check,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export interface FilterOption {
  id: string;
  label: string;
  checked: boolean;
}

export interface FilterGroup {
  id: string;
  label: string;
  options: FilterOption[];
  multiSelect?: boolean;
}

export interface DateRangePreset {
  id: string;
  label: string;
  days: number;
}

interface InteractiveFiltersProps {
  filterGroups: FilterGroup[];
  dateRange?: { start: Date; end: Date };
  datePresets?: DateRangePreset[];
  selectedPreset?: string;
  onFilterChange: (groupId: string, optionId: string, checked: boolean) => void;
  onDateRangeChange?: (start: Date, end: Date) => void;
  onPresetChange?: (presetId: string) => void;
  onClearFilters: () => void;
  onExport?: () => void;
  onRefresh?: () => void;
  className?: string;
}

const defaultPresets: DateRangePreset[] = [
  { id: '7d', label: 'Last 7 days', days: 7 },
  { id: '30d', label: 'Last 30 days', days: 30 },
  { id: '90d', label: 'Last 90 days', days: 90 },
  { id: 'ytd', label: 'Year to date', days: 365 },
];

export const InteractiveFilters = ({
  filterGroups,
  dateRange,
  datePresets = defaultPresets,
  selectedPreset = '30d',
  onFilterChange,
  onDateRangeChange,
  onPresetChange,
  onClearFilters,
  onExport,
  onRefresh,
  className,
}: InteractiveFiltersProps) => {
  const [isDateOpen, setIsDateOpen] = useState(false);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);

  const activeFiltersCount = filterGroups.reduce(
    (count, group) => count + group.options.filter((opt) => opt.checked).length,
    0,
  );

  const getActiveFiltersForGroup = (group: FilterGroup) => {
    return group.options.filter((opt) => opt.checked);
  };

  return (
    <div className={cn('flex flex-wrap items-center gap-2', className)}>
      {/* Date Range Selector */}
      <Popover open={isDateOpen} onOpenChange={setIsDateOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="gap-2 min-w-[180px] justify-start">
            <CalendarIcon className="h-4 w-4" />
            {datePresets.find((p) => p.id === selectedPreset)?.label || 'Select date'}
            <ChevronDown className="h-4 w-4 ml-auto opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <div className="p-3 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {datePresets.map((preset) => (
                <Button
                  key={preset.id}
                  variant={selectedPreset === preset.id ? 'default' : 'outline'}
                  size="sm"
                  className="justify-start"
                  onClick={() => {
                    onPresetChange?.(preset.id);
                    setIsDateOpen(false);
                  }}
                >
                  {preset.label}
                </Button>
              ))}
            </div>
            <Separator />
            <div className="text-sm font-medium">Custom Range</div>
            <Calendar
              mode="range"
              selected={dateRange ? { from: dateRange.start, to: dateRange.end } : undefined}
              onSelect={(range) => {
                if (range?.from && range?.to) {
                  onDateRangeChange?.(range.from, range.to);
                }
              }}
              numberOfMonths={2}
              className="rounded-md border"
            />
          </div>
        </PopoverContent>
      </Popover>

      {/* Quick Filter Pills */}
      {filterGroups.slice(0, 2).map((group) => (
        <Popover key={group.id}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn('gap-2', getActiveFiltersForGroup(group).length > 0 && 'border-primary')}
            >
              {group.label}
              {getActiveFiltersForGroup(group).length > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                  {getActiveFiltersForGroup(group).length}
                </Badge>
              )}
              <ChevronDown className="h-4 w-4 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56 p-3" align="start">
            <div className="space-y-2">
              <div className="font-medium text-sm">{group.label}</div>
              <Separator />
              {group.options.map((option) => (
                <label
                  key={option.id}
                  className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 rounded p-1.5 transition-colors"
                >
                  <Checkbox
                    checked={option.checked}
                    onCheckedChange={(checked) => onFilterChange(group.id, option.id, checked as boolean)}
                  />
                  <span className="text-sm">{option.label}</span>
                </label>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      ))}

      {/* Advanced Filters */}
      <Popover open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="gap-2">
            <SlidersHorizontal className="h-4 w-4" />
            Filters
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                {activeFiltersCount}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="start">
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <span className="font-medium">All Filters</span>
              <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={onClearFilters}>
                Clear all
              </Button>
            </div>
          </div>
          <div className="p-4 max-h-[400px] overflow-y-auto space-y-4">
            {filterGroups.map((group) => (
              <div key={group.id} className="space-y-2">
                <div className="font-medium text-sm text-muted-foreground">{group.label}</div>
                <div className="space-y-1">
                  {group.options.map((option) => (
                    <label
                      key={option.id}
                      className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 rounded p-2 transition-colors"
                    >
                      <Checkbox
                        checked={option.checked}
                        onCheckedChange={(checked) => onFilterChange(group.id, option.id, checked as boolean)}
                      />
                      <span className="text-sm flex-1">{option.label}</span>
                      {option.checked && <Check className="h-4 w-4 text-primary" />}
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="p-4 border-t border-border flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setIsFiltersOpen(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={() => setIsFiltersOpen(false)}>
              Apply Filters
            </Button>
          </div>
        </PopoverContent>
      </Popover>

      {/* Active Filter Tags */}
      {activeFiltersCount > 0 && (
        <div className="flex items-center gap-1 ml-2">
          {filterGroups.flatMap((group) =>
            group.options
              .filter((opt) => opt.checked)
              .slice(0, 3)
              .map((opt) => (
                <Badge
                  key={`${group.id}-${opt.id}`}
                  variant="secondary"
                  className="gap-1 pr-1 cursor-pointer hover:bg-destructive/20"
                  onClick={() => onFilterChange(group.id, opt.id, false)}
                >
                  {opt.label}
                  <X className="h-3 w-3" />
                </Badge>
              )),
          )}
          {activeFiltersCount > 3 && (
            <Badge variant="outline" className="text-xs">
              +{activeFiltersCount - 3} more
            </Badge>
          )}
        </div>
      )}

      <div className="flex-1" />

      {/* Action Buttons */}
      {onRefresh && (
        <Button variant="ghost" size="icon" onClick={onRefresh}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      )}
      {onExport && (
        <Button variant="outline" className="gap-2" onClick={onExport}>
          <Download className="h-4 w-4" />
          Export
        </Button>
      )}
    </div>
  );
};

export default InteractiveFilters;
