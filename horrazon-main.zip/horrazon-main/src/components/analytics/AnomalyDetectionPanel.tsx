import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Zap,
  Clock,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Activity,
  Eye,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { AnomalyDetection, RiskLevel } from '@/types/analytics';

interface AnomalyDetectionPanelProps {
  anomalies: AnomalyDetection[];
  onAcknowledge?: (id: string) => void;
  onInvestigate?: (anomaly: AnomalyDetection) => void;
}

const severityConfig: Record<RiskLevel, { label: string; color: string; bgColor: string; icon: typeof AlertTriangle }> =
  {
    critical: {
      label: 'Critical',
      color: 'text-destructive',
      bgColor: 'bg-destructive/10 border-destructive/30',
      icon: AlertTriangle,
    },
    high: {
      label: 'High',
      color: 'text-destructive',
      bgColor: 'bg-destructive/5 border-destructive/20',
      icon: AlertTriangle,
    },
    medium: { label: 'Medium', color: 'text-warning', bgColor: 'bg-warning/5 border-warning/20', icon: AlertTriangle },
    low: { label: 'Low', color: 'text-chart-1', bgColor: 'bg-chart-1/5 border-chart-1/20', icon: Activity },
  };

const typeConfig = {
  spike: { label: 'Spike Detected', icon: TrendingUp, color: 'text-success' },
  drop: { label: 'Drop Detected', icon: TrendingDown, color: 'text-destructive' },
  'trend-change': { label: 'Trend Change', icon: Activity, color: 'text-warning' },
  'seasonal-anomaly': { label: 'Seasonal Anomaly', icon: Clock, color: 'text-chart-1' },
};

export const AnomalyDetectionPanel = ({ anomalies, onAcknowledge, onInvestigate }: AnomalyDetectionPanelProps) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const sortedAnomalies = [...anomalies].sort((a, b) => {
    const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });

  const criticalCount = anomalies.filter((a) => a.severity === 'critical').length;
  const highCount = anomalies.filter((a) => a.severity === 'high').length;

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <div className="relative">
              <Zap className="h-5 w-5 text-primary" />
              {criticalCount > 0 && (
                <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-destructive animate-pulse" />
              )}
            </div>
            Anomaly Detection
          </CardTitle>
          <div className="flex items-center gap-2">
            {criticalCount > 0 && (
              <Badge variant="destructive" className="animate-pulse">
                {criticalCount} Critical
              </Badge>
            )}
            {highCount > 0 && (
              <Badge variant="outline" className="text-destructive border-destructive/30">
                {highCount} High
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {sortedAnomalies.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <CheckCircle2 className="h-12 w-12 text-success mb-4" />
            <p className="font-semibold text-lg">All Systems Normal</p>
            <p className="text-sm text-muted-foreground">No anomalies detected in the current time period</p>
          </div>
        ) : (
          sortedAnomalies.map((anomaly) => {
            const sevConfig = severityConfig[anomaly.severity];
            const tConfig = typeConfig[anomaly.type];
            const isExpanded = expandedId === anomaly.id;
            const TypeIcon = tConfig.icon;
            const SevIcon = sevConfig.icon;

            return (
              <div
                key={anomaly.id}
                className={cn('rounded-lg border transition-all', sevConfig.bgColor, isExpanded && 'shadow-md')}
              >
                <div
                  className="flex items-start gap-4 p-4 cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : anomaly.id)}
                >
                  <div
                    className={cn(
                      'h-10 w-10 rounded-full flex items-center justify-center',
                      anomaly.severity === 'critical' ? 'bg-destructive/20 animate-pulse' : 'bg-muted',
                    )}
                  >
                    <SevIcon className={cn('h-5 w-5', sevConfig.color)} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={cn('text-xs', tConfig.color, 'bg-background/50')}>
                        <TypeIcon className="h-3 w-3 mr-1" />
                        {tConfig.label}
                      </Badge>
                      <Badge variant="outline" className={cn('text-xs', sevConfig.color)}>
                        {sevConfig.label}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{anomaly.metric}</span>
                    </div>

                    <div className="mt-2 flex items-center gap-4">
                      <div>
                        <span className="text-2xl font-bold">{anomaly.value.toLocaleString()}</span>
                        <span className="text-sm text-muted-foreground ml-2">
                          (expected: {anomaly.expectedValue.toLocaleString()})
                        </span>
                      </div>
                      <Badge
                        variant="secondary"
                        className={cn('text-xs', anomaly.type === 'spike' ? 'text-success' : 'text-destructive')}
                      >
                        {anomaly.type === 'spike' ? '+' : ''}
                        {(((anomaly.value - anomaly.expectedValue) / anomaly.expectedValue) * 100).toFixed(1)}%
                      </Badge>
                    </div>

                    <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(anomaly.timestamp).toLocaleString()}
                      </span>
                      <span>Deviation: {anomaly.deviation.toFixed(2)}σ</span>
                    </div>
                  </div>

                  <ChevronRight
                    className={cn('h-5 w-5 text-muted-foreground transition-transform', isExpanded && 'rotate-90')}
                  />
                </div>

                {isExpanded && (
                  <div className="px-4 pb-4 pt-2 space-y-4 border-t border-border/50">
                    {/* Possible Causes */}
                    <div>
                      <p className="text-sm font-medium flex items-center gap-2 mb-2">
                        <Lightbulb className="h-4 w-4 text-warning" />
                        Possible Causes
                      </p>
                      <ul className="space-y-1 ml-6">
                        {anomaly.possibleCauses.map((cause, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
                            {cause}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Recommended Actions */}
                    <div>
                      <p className="text-sm font-medium flex items-center gap-2 mb-2">
                        <Zap className="h-4 w-4 text-primary" />
                        Recommended Actions
                      </p>
                      <ul className="space-y-1 ml-6">
                        {anomaly.recommendedActions.map((action, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-2">
                      <Button size="sm" variant="outline" className="gap-1" onClick={() => onInvestigate?.(anomaly)}>
                        <Eye className="h-4 w-4" />
                        Investigate
                      </Button>
                      <Button size="sm" variant="ghost" className="gap-1" onClick={() => onAcknowledge?.(anomaly.id)}>
                        <CheckCircle2 className="h-4 w-4" />
                        Acknowledge
                      </Button>
                      <Button size="sm" variant="ghost" className="gap-1 text-muted-foreground">
                        <XCircle className="h-4 w-4" />
                        Dismiss
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
};

export default AnomalyDetectionPanel;
