import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Brain,
  Zap,
  TrendingUp,
  Clock,
  Target,
  CheckCircle2,
  Play,
  ChevronRight,
  Sparkles,
  BarChart3,
  Users,
  DollarSign,
  AlertTriangle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { AIRecommendation, OptimizationScore } from '@/types/analytics';

interface AIOptimizationEngineProps {
  score: OptimizationScore;
  recommendations: AIRecommendation[];
  onApply?: (recommendation: AIRecommendation) => void;
  onDismiss?: (id: string) => void;
  onSchedule?: (recommendation: AIRecommendation) => void;
}

const priorityConfig = {
  critical: { color: 'text-destructive', bgColor: 'bg-destructive/10 border-destructive/30', icon: AlertTriangle },
  high: { color: 'text-warning', bgColor: 'bg-warning/10 border-warning/20', icon: Zap },
  medium: { color: 'text-chart-1', bgColor: 'bg-chart-1/10 border-chart-1/20', icon: Target },
  low: { color: 'text-muted-foreground', bgColor: 'bg-muted border-border', icon: BarChart3 },
};

const typeIcons = {
  optimization: BarChart3,
  automation: Zap,
  creative: Sparkles,
  targeting: Users,
  budget: DollarSign,
};

const getScoreColor = (score: number): string => {
  if (score >= 80) return 'text-success';
  if (score >= 60) return 'text-chart-1';
  if (score >= 40) return 'text-warning';
  return 'text-destructive';
};

const getScoreLabel = (score: number): string => {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Needs Work';
  return 'Critical';
};

export const AIOptimizationEngine = ({
  score,
  recommendations,
  onApply,
  onDismiss,
  onSchedule,
}: AIOptimizationEngineProps) => {
  const pendingRecommendations = recommendations.filter((r) => r.status === 'pending');
  const sortedRecommendations = [...pendingRecommendations].sort((a, b) => {
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  const totalPotentialImpact = recommendations
    .filter((r) => r.status === 'pending')
    .reduce((sum, r) => sum + r.expectedImpact.improvement, 0);

  return (
    <div className="space-y-6">
      {/* Optimization Score Card */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-primary/10 to-accent/10">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              AI Optimization Score
            </CardTitle>
            <Badge variant="outline" className="gap-1">
              <Sparkles className="h-3 w-3" />
              Powered by ML
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-8">
            {/* Main Score */}
            <div className="relative h-32 w-32">
              <svg className="h-32 w-32 -rotate-90 transform">
                <circle cx="64" cy="64" r="56" stroke="hsl(var(--muted))" strokeWidth="12" fill="none" />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="hsl(var(--primary))"
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={`${score.overall * 3.52} 352`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={cn('text-4xl font-bold', getScoreColor(score.overall))}>{score.overall}</span>
                <span className="text-xs text-muted-foreground">{getScoreLabel(score.overall)}</span>
              </div>
            </div>

            {/* Category Scores */}
            <div className="flex-1 grid grid-cols-2 gap-4">
              {Object.entries(score.categories).map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="capitalize text-muted-foreground">{key}</span>
                    <span className={cn('font-semibold', getScoreColor(value))}>{value}</span>
                  </div>
                  <Progress value={value} className="h-2" />
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border/50">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              Last analyzed: 2 hours ago
            </div>
            <Button variant="outline" size="sm" className="gap-1">
              <Brain className="h-4 w-4" />
              Run Analysis
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations Summary */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="border-destructive/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-destructive/20 flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {recommendations.filter((r) => r.priority === 'critical' && r.status === 'pending').length}
              </p>
              <p className="text-xs text-muted-foreground">Critical</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-warning/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-warning/20 flex items-center justify-center">
              <Zap className="h-5 w-5 text-warning" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {recommendations.filter((r) => r.priority === 'high' && r.status === 'pending').length}
              </p>
              <p className="text-xs text-muted-foreground">High Priority</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-success/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-success/20 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold">{recommendations.filter((r) => r.status === 'applied').length}</p>
              <p className="text-xs text-muted-foreground">Applied</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-primary/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">+{totalPotentialImpact.toFixed(0)}%</p>
              <p className="text-xs text-muted-foreground">Potential Gain</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              AI Recommendations
            </CardTitle>
            <Badge variant="secondary">{pendingRecommendations.length} pending</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {sortedRecommendations.slice(0, 5).map((rec) => {
            const prioConfig = priorityConfig[rec.priority];
            const TypeIcon = typeIcons[rec.type];
            const PrioIcon = prioConfig.icon;

            return (
              <div
                key={rec.id}
                className={cn('rounded-lg border p-4 transition-all hover:shadow-md', prioConfig.bgColor)}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={cn(
                      'h-10 w-10 rounded-full flex items-center justify-center',
                      rec.priority === 'critical' ? 'bg-destructive/20 animate-pulse' : 'bg-muted',
                    )}
                  >
                    <TypeIcon className={cn('h-5 w-5', prioConfig.color)} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className={cn('text-xs', prioConfig.color)}>
                        <PrioIcon className="h-3 w-3 mr-1" />
                        {rec.priority}
                      </Badge>
                      <Badge variant="secondary" className="text-xs capitalize">
                        {rec.type}
                      </Badge>
                      {rec.implementation.automated && (
                        <Badge className="text-xs bg-success/20 text-success">Auto-apply available</Badge>
                      )}
                    </div>

                    <h4 className="font-semibold mt-2">{rec.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{rec.description}</p>

                    <div className="flex items-center gap-6 mt-3 text-sm">
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 text-success" />
                        <span className="text-success font-medium">
                          +{rec.expectedImpact.improvement.toFixed(1)}% {rec.expectedImpact.metric}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Target className="h-4 w-4" />
                        <span>{rec.confidence}% confidence</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>{rec.implementation.estimatedTime}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Button size="sm" className="gap-1" onClick={() => onApply?.(rec)}>
                      <Play className="h-4 w-4" />
                      Apply
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => onSchedule?.(rec)}>
                      <Clock className="h-4 w-4" />
                      Schedule
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}

          {sortedRecommendations.length > 5 && (
            <Button variant="ghost" className="w-full gap-1">
              View {sortedRecommendations.length - 5} more recommendations
              <ChevronRight className="h-4 w-4" />
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AIOptimizationEngine;
