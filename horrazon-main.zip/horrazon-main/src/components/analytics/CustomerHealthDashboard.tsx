import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Heart,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Users,
  DollarSign,
  ShoppingBag,
  Clock,
  Zap,
  ChevronRight,
  Target,
  Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { CustomerProfile, HealthStatus, RiskLevel } from '@/types/analytics';

interface CustomerHealthDashboardProps {
  customers: CustomerProfile[];
  onCustomerClick?: (customer: CustomerProfile) => void;
}

const healthStatusConfig: Record<HealthStatus, { label: string; color: string; icon: typeof Heart }> = {
  healthy: { label: 'Healthy', color: 'bg-success text-success-foreground', icon: Heart },
  'at-risk': { label: 'At Risk', color: 'bg-warning text-warning-foreground', icon: AlertTriangle },
  churning: { label: 'Churning', color: 'bg-destructive text-destructive-foreground', icon: TrendingDown },
  churned: { label: 'Churned', color: 'bg-muted text-muted-foreground', icon: TrendingDown },
  new: { label: 'New', color: 'bg-chart-1 text-chart-1-foreground', icon: Zap },
};

const riskLevelConfig: Record<RiskLevel, { label: string; color: string }> = {
  low: { label: 'Low Risk', color: 'text-success' },
  medium: { label: 'Medium Risk', color: 'text-warning' },
  high: { label: 'High Risk', color: 'text-destructive' },
  critical: { label: 'Critical', color: 'text-destructive animate-pulse' },
};

export const CustomerHealthDashboard = ({ customers, onCustomerClick }: CustomerHealthDashboardProps) => {
  // Calculate summary metrics
  const healthDistribution = customers.reduce(
    (acc, c) => {
      acc[c.healthStatus] = (acc[c.healthStatus] || 0) + 1;
      return acc;
    },
    {} as Record<HealthStatus, number>,
  );

  const avgHealthScore = Math.round(customers.reduce((sum, c) => sum + c.healthScore, 0) / customers.length);

  const atRiskRevenue = customers
    .filter((c) => c.churnRisk === 'high' || c.churnRisk === 'critical')
    .reduce((sum, c) => sum + c.lifetimeValue, 0);

  const avgChurnProbability = Math.round(
    (customers.reduce((sum, c) => sum + c.churnProbability, 0) / customers.length) * 100,
  );

  const topRiskCustomers = [...customers].sort((a, b) => b.churnProbability - a.churnProbability).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                <Activity className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold">{avgHealthScore}</p>
                <p className="text-sm text-muted-foreground">Avg Health Score</p>
              </div>
            </div>
            <Progress value={avgHealthScore} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card className="border-success/20 bg-success/5">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-success/20 flex items-center justify-center">
                <Heart className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-3xl font-bold">{healthDistribution.healthy || 0}</p>
                <p className="text-sm text-muted-foreground">Healthy Customers</p>
              </div>
            </div>
            <p className="mt-2 text-xs text-success">
              {(((healthDistribution.healthy || 0) / customers.length) * 100).toFixed(1)}% of total
            </p>
          </CardContent>
        </Card>

        <Card className="border-destructive/20 bg-destructive/5">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-destructive/20 flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-3xl font-bold">{avgChurnProbability}%</p>
                <p className="text-sm text-muted-foreground">Avg Churn Risk</p>
              </div>
            </div>
            <p className="mt-2 text-xs text-destructive">
              {(healthDistribution['at-risk'] || 0) + (healthDistribution.churning || 0)} at risk
            </p>
          </CardContent>
        </Card>

        <Card className="border-warning/20 bg-warning/5">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-warning/20 flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-3xl font-bold">${(atRiskRevenue / 1000).toFixed(1)}K</p>
                <p className="text-sm text-muted-foreground">Revenue at Risk</p>
              </div>
            </div>
            <p className="mt-2 text-xs text-warning">From high-risk customers</p>
          </CardContent>
        </Card>
      </div>

      {/* Health Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Customer Health Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 h-8 rounded-lg overflow-hidden">
            {Object.entries(healthDistribution).map(([status, count]) => {
              const config = healthStatusConfig[status as HealthStatus];
              const percentage = (count / customers.length) * 100;
              if (percentage < 1) return null;
              return (
                <div
                  key={status}
                  className={cn(
                    'flex items-center justify-center text-xs font-medium transition-all hover:opacity-80',
                    config.color,
                  )}
                  style={{ width: `${percentage}%` }}
                  title={`${config.label}: ${count} (${percentage.toFixed(1)}%)`}
                >
                  {percentage > 10 && `${percentage.toFixed(0)}%`}
                </div>
              );
            })}
          </div>
          <div className="flex flex-wrap gap-3 mt-4">
            {Object.entries(healthStatusConfig).map(([status, config]) => (
              <div key={status} className="flex items-center gap-2">
                <div className={cn('h-3 w-3 rounded-full', config.color)} />
                <span className="text-xs text-muted-foreground">
                  {config.label} ({healthDistribution[status as HealthStatus] || 0})
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Risk Customers */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Highest Churn Risk Customers
            </CardTitle>
            <Button variant="outline" size="sm">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topRiskCustomers.map((customer, index) => {
              const healthConfig = healthStatusConfig[customer.healthStatus];
              const riskConfig = riskLevelConfig[customer.churnRisk];

              return (
                <div
                  key={customer.id}
                  className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-card hover:bg-muted/30 transition-all cursor-pointer group"
                  onClick={() => onCustomerClick?.(customer)}
                >
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-destructive/10 text-destructive font-bold">
                    #{index + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold truncate">{customer.name}</p>
                      <Badge variant="outline" className={cn('text-xs', riskConfig.color)}>
                        {(customer.churnProbability * 100).toFixed(0)}% churn risk
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{customer.email}</p>
                  </div>

                  <div className="hidden md:flex items-center gap-6 text-sm">
                    <div className="text-center">
                      <p className="font-semibold">${customer.lifetimeValue.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">LTV</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold">{customer.daysSinceLastPurchase}d</p>
                      <p className="text-xs text-muted-foreground">Last Order</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold">{customer.totalOrders}</p>
                      <p className="text-xs text-muted-foreground">Orders</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge className={cn('text-xs', healthConfig.color)}>{healthConfig.label}</Badge>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerHealthDashboard;
