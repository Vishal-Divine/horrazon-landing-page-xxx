import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Clock, Zap, TrendingUp, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SendTimeData {
  hour: number;
  day: string;
  openRate: number;
  clickRate: number;
  score: number;
  sampleSize: number;
}

interface PredictiveSendTimeHeatmapProps {
  data: SendTimeData[];
  title?: string;
  onTimeSelect?: (hour: number, day: string) => void;
}

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const hours = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];

const formatHour = (hour: number): string => {
  if (hour === 0) return '12 AM';
  if (hour === 12) return '12 PM';
  if (hour < 12) return `${hour} AM`;
  return `${hour - 12} PM`;
};

const getScoreColor = (score: number): string => {
  if (score >= 90) return 'bg-success';
  if (score >= 75) return 'bg-success/70';
  if (score >= 60) return 'bg-chart-1';
  if (score >= 45) return 'bg-chart-3';
  if (score >= 30) return 'bg-warning';
  return 'bg-muted';
};

const getScoreIntensity = (score: number): number => {
  return 0.3 + (score / 100) * 0.7;
};

export const PredictiveSendTimeHeatmap = ({
  data,
  title = 'Optimal Send Time Analysis',
  onTimeSelect,
}: PredictiveSendTimeHeatmapProps) => {
  // Create a lookup map for quick access
  const dataMap = new Map<string, SendTimeData>();
  data.forEach((d) => {
    dataMap.set(`${d.day}-${d.hour}`, d);
  });

  // Find best times
  const sortedByScore = [...data].sort((a, b) => b.score - a.score);
  const topTimes = sortedByScore.slice(0, 3);
  const worstTimes = sortedByScore.slice(-3).reverse();

  // Calculate averages by day and hour
  const avgByDay = days.map((day) => {
    const dayData = data.filter((d) => d.day === day);
    return {
      day,
      avgScore: dayData.reduce((sum, d) => sum + d.score, 0) / dayData.length || 0,
    };
  });

  const avgByHour = hours.map((hour) => {
    const hourData = data.filter((d) => d.hour === hour);
    return {
      hour,
      avgScore: hourData.reduce((sum, d) => sum + d.score, 0) / hourData.length || 0,
    };
  });

  const bestDay = avgByDay.sort((a, b) => b.avgScore - a.avgScore)[0];
  const bestHour = avgByHour.sort((a, b) => b.avgScore - a.avgScore)[0];

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs gap-1">
              <Zap className="h-3 w-3" />
              AI Optimized
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Top Insights */}
        <div className="grid grid-cols-3 gap-4">
          <div className="rounded-lg bg-success/10 border border-success/20 p-4">
            <div className="flex items-center gap-2 text-success mb-2">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs font-medium">Best Time</span>
            </div>
            <p className="text-lg font-bold">{formatHour(topTimes[0]?.hour || 9)}</p>
            <p className="text-xs text-muted-foreground">{topTimes[0]?.day || 'Tue'}</p>
            <p className="text-xs text-success mt-1">{topTimes[0]?.openRate.toFixed(1)}% open rate</p>
          </div>

          <div className="rounded-lg bg-primary/10 border border-primary/20 p-4">
            <div className="flex items-center gap-2 text-primary mb-2">
              <Clock className="h-4 w-4" />
              <span className="text-xs font-medium">Best Day</span>
            </div>
            <p className="text-lg font-bold">{bestDay?.day || 'Tuesday'}</p>
            <p className="text-xs text-muted-foreground">Overall performance</p>
            <p className="text-xs text-primary mt-1">Score: {bestDay?.avgScore.toFixed(0) || 75}</p>
          </div>

          <div className="rounded-lg bg-chart-1/10 border border-chart-1/20 p-4">
            <div className="flex items-center gap-2 text-chart-1 mb-2">
              <Zap className="h-4 w-4" />
              <span className="text-xs font-medium">Peak Hour</span>
            </div>
            <p className="text-lg font-bold">{formatHour(bestHour?.hour || 9)}</p>
            <p className="text-xs text-muted-foreground">Across all days</p>
            <p className="text-xs text-chart-1 mt-1">Score: {bestHour?.avgScore.toFixed(0) || 80}</p>
          </div>
        </div>

        {/* Heatmap */}
        <TooltipProvider>
          <div className="overflow-x-auto">
            <div className="min-w-[600px]">
              {/* Header row with hours */}
              <div className="flex">
                <div className="w-12 shrink-0" />
                {hours.map((hour) => (
                  <div key={hour} className="flex-1 text-center text-xs text-muted-foreground pb-2">
                    {hour % 3 === 0 ? formatHour(hour) : ''}
                  </div>
                ))}
              </div>

              {/* Data rows */}
              {days.map((day) => (
                <div key={day} className="flex items-center gap-1 mb-1">
                  <div className="w-12 shrink-0 text-xs font-medium text-muted-foreground">{day}</div>
                  {hours.map((hour) => {
                    const cellData = dataMap.get(`${day}-${hour}`);
                    const score = cellData?.score || Math.random() * 50 + 25;
                    const isTopTime = topTimes.some((t) => t.day === day && t.hour === hour);

                    return (
                      <Tooltip key={hour}>
                        <TooltipTrigger asChild>
                          <button
                            className={cn(
                              'flex-1 h-8 rounded-sm transition-all hover:ring-2 hover:ring-primary/50 hover:scale-105',
                              getScoreColor(score),
                              isTopTime && 'ring-2 ring-success ring-offset-1 ring-offset-background',
                            )}
                            style={{ opacity: getScoreIntensity(score) }}
                            onClick={() => onTimeSelect?.(hour, day)}
                          >
                            {isTopTime && <Zap className="h-3 w-3 text-white mx-auto" />}
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="text-xs">
                          <div className="space-y-1">
                            <p className="font-semibold">
                              {day} at {formatHour(hour)}
                            </p>
                            <p>Score: {score.toFixed(0)}/100</p>
                            {cellData && (
                              <>
                                <p>Open Rate: {cellData.openRate.toFixed(1)}%</p>
                                <p>Click Rate: {cellData.clickRate.toFixed(1)}%</p>
                                <p className="text-muted-foreground">
                                  Based on {cellData.sampleSize.toLocaleString()} sends
                                </p>
                              </>
                            )}
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </TooltipProvider>

        {/* Legend */}
        <div className="flex items-center justify-between pt-4 border-t border-border/50">
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted-foreground">Performance:</span>
            <div className="flex items-center gap-1">
              {[30, 45, 60, 75, 90].map((score) => (
                <div key={score} className="flex flex-col items-center">
                  <div
                    className={cn('h-4 w-8 rounded-sm', getScoreColor(score))}
                    style={{ opacity: getScoreIntensity(score) }}
                  />
                  <span className="text-[10px] text-muted-foreground mt-1">{score}</span>
                </div>
              ))}
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            <Info className="h-3 w-3" />
            How it works
          </Button>
        </div>

        {/* Recommendations */}
        <div className="rounded-lg bg-muted/30 p-4">
          <p className="text-sm font-medium mb-2 flex items-center gap-2">
            <Zap className="h-4 w-4 text-primary" />
            AI Recommendations
          </p>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-success" />
              Schedule your most important campaigns for {formatHour(topTimes[0]?.hour || 9)} on{' '}
              {topTimes[0]?.day || 'Tuesday'}
            </li>
            <li className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-chart-1" />
              Avoid sending between {formatHour(worstTimes[0]?.hour || 6)} -{' '}
              {formatHour((worstTimes[0]?.hour || 6) + 1)} when engagement is lowest
            </li>
            <li className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              Weekend sends show 15% lower engagement - reserve for less critical campaigns
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default PredictiveSendTimeHeatmap;
