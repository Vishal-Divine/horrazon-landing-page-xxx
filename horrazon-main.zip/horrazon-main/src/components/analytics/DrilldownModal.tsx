import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import {
  X,
  TrendingUp,
  TrendingDown,
  Users,
  DollarSign,
  Calendar,
  ArrowRight,
  Download,
  Share2,
  Maximize2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DrilldownData {
  title: string;
  subtitle?: string;
  type: 'segment' | 'campaign' | 'channel' | 'customer' | 'metric';
  metrics: {
    label: string;
    value: string | number;
    change?: number;
    trend?: 'up' | 'down' | 'stable';
  }[];
  chartData?: any[];
  breakdownData?: {
    label: string;
    value: number;
    percentage: number;
    color?: string;
  }[];
  relatedItems?: {
    id: string;
    label: string;
    value: string;
  }[];
}

interface DrilldownModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: DrilldownData | null;
  onDrillDeeper?: (itemId: string) => void;
}

export const DrilldownModal = ({ open, onOpenChange, data, onDrillDeeper }: DrilldownModalProps) => {
  if (!data) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between pr-8">
            <div>
              <DialogTitle className="text-xl">{data.title}</DialogTitle>
              {data.subtitle && <p className="text-sm text-muted-foreground mt-1">{data.subtitle}</p>}
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon">
                <Share2 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon">
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon">
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="mt-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
            {data.relatedItems && <TabsTrigger value="related">Related</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="mt-4 space-y-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {data.metrics.map((metric, index) => (
                <Card key={index} className="border-border/50">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground">{metric.label}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-2xl font-bold">{metric.value}</span>
                      {metric.change !== undefined && (
                        <Badge
                          variant="secondary"
                          className={cn(
                            'text-xs',
                            metric.trend === 'up' ? 'text-success' : metric.trend === 'down' ? 'text-destructive' : '',
                          )}
                        >
                          {metric.trend === 'up' && <TrendingUp className="h-3 w-3 mr-1" />}
                          {metric.trend === 'down' && <TrendingDown className="h-3 w-3 mr-1" />}
                          {metric.change > 0 ? '+' : ''}
                          {metric.change}%
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Summary Chart */}
            {data.chartData && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Performance Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={data.chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--popover))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: 'var(--radius)',
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="value"
                          stroke="hsl(var(--primary))"
                          fill="hsl(var(--primary) / 0.2)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="trends" className="mt-4">
            <Card>
              <CardContent className="pt-6">
                {data.chartData ? (
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={data.chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--popover))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: 'var(--radius)',
                          }}
                        />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="hsl(var(--primary))"
                          strokeWidth={2}
                          name="Current"
                        />
                        <Line
                          type="monotone"
                          dataKey="previous"
                          stroke="hsl(var(--muted-foreground))"
                          strokeWidth={2}
                          strokeDasharray="5 5"
                          name="Previous"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                    No trend data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="breakdown" className="mt-4">
            <Card>
              <CardContent className="pt-6 space-y-4">
                {data.breakdownData ? (
                  <>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data.breakdownData} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                          <YAxis
                            type="category"
                            dataKey="label"
                            stroke="hsl(var(--muted-foreground))"
                            fontSize={12}
                            width={100}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: 'var(--radius)',
                            }}
                          />
                          <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-2">
                      {data.breakdownData.map((item, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors cursor-pointer"
                          onClick={() => onDrillDeeper?.(item.label)}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className="h-3 w-3 rounded-full"
                              style={{ backgroundColor: item.color || 'hsl(var(--primary))' }}
                            />
                            <span className="font-medium">{item.label}</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="font-semibold">{item.value.toLocaleString()}</span>
                            <Badge variant="secondary">{item.percentage.toFixed(1)}%</Badge>
                            <ArrowRight className="h-4 w-4 text-muted-foreground" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                    No breakdown data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {data.relatedItems && (
            <TabsContent value="related" className="mt-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid gap-3">
                    {data.relatedItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:border-primary/50 hover:bg-muted/30 transition-all cursor-pointer group"
                        onClick={() => onDrillDeeper?.(item.id)}
                      >
                        <span className="font-medium">{item.label}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-muted-foreground">{item.value}</span>
                          <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default DrilldownModal;
