import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface CohortData {
  cohortMonth: string;
  cohortSize: number;
  retentionRates: number[];
}

interface CohortRetentionChartProps {
  data: CohortData[];
  title?: string;
  className?: string;
}

const getRetentionColor = (rate: number): string => {
  if (rate >= 80) return 'bg-success/80 text-success-foreground';
  if (rate >= 60) return 'bg-chart-1/70 text-foreground';
  if (rate >= 40) return 'bg-chart-3/60 text-foreground';
  if (rate >= 20) return 'bg-warning/50 text-foreground';
  return 'bg-destructive/40 text-foreground';
};

const getIntensity = (rate: number): number => {
  return Math.min(1, rate / 100);
};

export const CohortRetentionChart = ({
  data,
  title = 'Cohort Retention Analysis',
  className,
}: CohortRetentionChartProps) => {
  const maxMonths = useMemo(() => {
    return Math.max(...data.map((d) => d.retentionRates.length));
  }, [data]);

  const monthHeaders = useMemo(() => {
    return Array.from({ length: maxMonths }, (_, i) => `M${i}`);
  }, [maxMonths]);

  const averageRetention = useMemo(() => {
    const averages: number[] = [];
    for (let i = 0; i < maxMonths; i++) {
      const rates = data.map((d) => d.retentionRates[i]).filter((r) => r !== undefined);
      if (rates.length > 0) {
        averages.push(Math.round((rates.reduce((a, b) => a + b, 0) / rates.length) * 10) / 10);
      }
    }
    return averages;
  }, [data, maxMonths]);

  return (
    <Card className={cn('border-border/50', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Retention strength:</span>
            <div className="flex gap-1">
              {[20, 40, 60, 80, 100].map((level) => (
                <div
                  key={level}
                  className={cn(
                    'h-3 w-6 rounded-sm text-[8px] flex items-center justify-center',
                    getRetentionColor(level),
                  )}
                >
                  {level}%
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50">
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground">Cohort</th>
                  <th className="text-center py-2 px-2 font-medium text-muted-foreground">Size</th>
                  {monthHeaders.map((month) => (
                    <th key={month} className="text-center py-2 px-2 font-medium text-muted-foreground min-w-[48px]">
                      {month}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((cohort, index) => (
                  <tr
                    key={cohort.cohortMonth}
                    className="border-b border-border/30 hover:bg-muted/30 transition-colors"
                  >
                    <td className="py-2 px-2 font-medium">{cohort.cohortMonth}</td>
                    <td className="text-center py-2 px-2">
                      <Badge variant="secondary" className="text-xs font-mono">
                        {cohort.cohortSize.toLocaleString()}
                      </Badge>
                    </td>
                    {monthHeaders.map((_, monthIndex) => {
                      const rate = cohort.retentionRates[monthIndex];
                      if (rate === undefined) {
                        return (
                          <td key={monthIndex} className="text-center py-2 px-2">
                            <div className="h-8 w-full rounded bg-muted/20" />
                          </td>
                        );
                      }
                      return (
                        <td key={monthIndex} className="text-center py-2 px-1">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                className={cn(
                                  'h-8 w-full rounded flex items-center justify-center text-xs font-medium cursor-pointer transition-all hover:scale-105 hover:ring-2 hover:ring-primary/50',
                                  getRetentionColor(rate),
                                )}
                                style={{ opacity: 0.5 + getIntensity(rate) * 0.5 }}
                              >
                                {rate.toFixed(1)}%
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="text-xs">
                              <div className="space-y-1">
                                <p className="font-semibold">
                                  {cohort.cohortMonth} - Month {monthIndex}
                                </p>
                                <p>Retention: {rate.toFixed(1)}%</p>
                                <p>Users: {Math.round((cohort.cohortSize * rate) / 100).toLocaleString()}</p>
                                <p className="text-muted-foreground">
                                  {monthIndex === 0
                                    ? 'Initial cohort'
                                    : rate >= 70
                                      ? 'Excellent retention'
                                      : rate >= 50
                                        ? 'Good retention'
                                        : rate >= 30
                                          ? 'Average retention'
                                          : 'Needs attention'}
                                </p>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </td>
                      );
                    })}
                  </tr>
                ))}
                {/* Average row */}
                <tr className="bg-muted/30 font-semibold">
                  <td className="py-2 px-2">Average</td>
                  <td className="text-center py-2 px-2">-</td>
                  {averageRetention.map((avg, index) => (
                    <td key={index} className="text-center py-2 px-1">
                      <div
                        className={cn(
                          'h-8 w-full rounded flex items-center justify-center text-xs font-bold border-2 border-primary/30',
                          getRetentionColor(avg),
                        )}
                      >
                        {avg.toFixed(1)}%
                      </div>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </TooltipProvider>

        {/* Insights */}
        <div className="mt-4 grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{averageRetention[1]?.toFixed(1) || '-'}%</p>
            <p className="text-xs text-muted-foreground">Month 1 Retention</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-chart-1">{averageRetention[3]?.toFixed(1) || '-'}%</p>
            <p className="text-xs text-muted-foreground">Month 3 Retention</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-chart-2">{averageRetention[6]?.toFixed(1) || '-'}%</p>
            <p className="text-xs text-muted-foreground">Month 6 Retention</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CohortRetentionChart;
