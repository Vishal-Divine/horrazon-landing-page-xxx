import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  TrendingUp,
  TrendingDown,
  Users,
  Target,
  Sparkles,
  ChevronRight,
  ArrowRight,
  Zap,
  Star,
  Crown,
  Heart,
  AlertTriangle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { CustomerSegment, SegmentType } from '@/types/analytics';

interface AdvancedSegmentationPanelProps {
  segments: CustomerSegment[];
  onSegmentClick?: (segment: CustomerSegment) => void;
  onCreateCampaign?: (segment: CustomerSegment) => void;
}

const segmentConfig: Record<SegmentType, { icon: typeof Star; color: string; bgColor: string; description: string }> = {
  champions: {
    icon: Crown,
    color: 'text-amber-500',
    bgColor: 'bg-amber-500/10 border-amber-500/20',
    description: 'Bought recently, buy often, spend the most',
  },
  loyal: {
    icon: Heart,
    color: 'text-pink-500',
    bgColor: 'bg-pink-500/10 border-pink-500/20',
    description: 'Spend good money, responsive to promotions',
  },
  potential: {
    icon: TrendingUp,
    color: 'text-success',
    bgColor: 'bg-success/10 border-success/20',
    description: 'Recent customers with average frequency',
  },
  new: {
    icon: Sparkles,
    color: 'text-chart-1',
    bgColor: 'bg-chart-1/10 border-chart-1/20',
    description: 'Just made first purchase, high potential',
  },
  promising: {
    icon: Star,
    color: 'text-chart-2',
    bgColor: 'bg-chart-2/10 border-chart-2/20',
    description: "Recent shoppers who haven't spent much",
  },
  'needs-attention': {
    icon: Target,
    color: 'text-warning',
    bgColor: 'bg-warning/10 border-warning/20',
    description: 'Above average recency, frequency & monetary',
  },
  'about-to-sleep': {
    icon: AlertTriangle,
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10 border-orange-500/20',
    description: 'Below average recency & frequency',
  },
  'at-risk': {
    icon: AlertTriangle,
    color: 'text-destructive',
    bgColor: 'bg-destructive/10 border-destructive/20',
    description: 'Spent big money, purchased often, long ago',
  },
  'cant-lose': {
    icon: Crown,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10 border-purple-500/20',
    description: "Made big purchases but haven't returned",
  },
  hibernating: {
    icon: TrendingDown,
    color: 'text-slate-500',
    bgColor: 'bg-slate-500/10 border-slate-500/20',
    description: 'Last purchase was a long time ago, low spenders',
  },
  lost: {
    icon: TrendingDown,
    color: 'text-muted-foreground',
    bgColor: 'bg-muted/50 border-border',
    description: 'Lowest recency, frequency & monetary scores',
  },
};

export const AdvancedSegmentationPanel = ({
  segments,
  onSegmentClick,
  onCreateCampaign,
}: AdvancedSegmentationPanelProps) => {
  const totalCustomers = segments.reduce((sum, s) => sum + s.customerCount, 0);
  const totalRevenue = segments.reduce((sum, s) => sum + s.revenueContribution, 0);

  // Sort segments by customer count
  const sortedSegments = [...segments].sort((a, b) => b.customerCount - a.customerCount);

  // Key metrics
  const topSegment = sortedSegments[0];
  const highValueSegments = segments.filter((s) => ['champions', 'loyal', 'cant-lose'].includes(s.type));
  const atRiskSegments = segments.filter((s) => ['at-risk', 'about-to-sleep', 'hibernating'].includes(s.type));

  const highValueRevenue = highValueSegments.reduce((sum, s) => sum + s.revenueContribution, 0);
  const atRiskRevenue = atRiskSegments.reduce((sum, s) => sum + s.revenueContribution, 0);

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            RFM Segmentation Analysis
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            {segments.length} Active Segments
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <div className="rounded-lg bg-muted/30 p-3 text-center">
            <p className="text-2xl font-bold">{totalCustomers.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Total Customers</p>
          </div>
          <div className="rounded-lg bg-success/10 border border-success/20 p-3 text-center">
            <p className="text-2xl font-bold text-success">
              {highValueSegments.reduce((sum, s) => sum + s.customerCount, 0).toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">High Value</p>
          </div>
          <div className="rounded-lg bg-warning/10 border border-warning/20 p-3 text-center">
            <p className="text-2xl font-bold text-warning">
              {atRiskSegments.reduce((sum, s) => sum + s.customerCount, 0).toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">At Risk</p>
          </div>
          <div className="rounded-lg bg-primary/10 border border-primary/20 p-3 text-center">
            <p className="text-2xl font-bold text-primary">${(totalRevenue / 1000000).toFixed(1)}M</p>
            <p className="text-xs text-muted-foreground">Total Revenue</p>
          </div>
        </div>

        {/* Segment Distribution Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">Segment Distribution</span>
            <span className="text-muted-foreground">By customer count</span>
          </div>
          <div className="flex h-6 rounded-lg overflow-hidden">
            {sortedSegments.map((segment) => {
              const config = segmentConfig[segment.type];
              const width = (segment.customerCount / totalCustomers) * 100;
              if (width < 2) return null;

              return (
                <div
                  key={segment.id}
                  className={cn(
                    'flex items-center justify-center text-xs font-medium transition-all hover:brightness-110 cursor-pointer',
                    config.bgColor.replace('bg-', 'bg-').replace('/10', '/60'),
                  )}
                  style={{ width: `${width}%` }}
                  onClick={() => onSegmentClick?.(segment)}
                  title={`${segment.name}: ${segment.customerCount.toLocaleString()} (${width.toFixed(1)}%)`}
                >
                  {width > 8 && segment.name.split(' ')[0]}
                </div>
              );
            })}
          </div>
        </div>

        {/* Segment Cards */}
        <div className="grid gap-3">
          {sortedSegments.map((segment) => {
            const config = segmentConfig[segment.type];
            const SegmentIcon = config.icon;
            const percentOfTotal = (segment.customerCount / totalCustomers) * 100;

            return (
              <div
                key={segment.id}
                className={cn(
                  'flex items-center gap-4 p-4 rounded-lg border transition-all cursor-pointer hover:shadow-md group',
                  config.bgColor,
                )}
                onClick={() => onSegmentClick?.(segment)}
              >
                <div
                  className={cn(
                    'h-12 w-12 rounded-full flex items-center justify-center',
                    config.bgColor.replace('/10', '/20'),
                  )}
                >
                  <SegmentIcon className={cn('h-6 w-6', config.color)} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{segment.name}</p>
                    <Badge variant="secondary" className="text-xs">
                      {percentOfTotal.toFixed(1)}%
                    </Badge>
                    {segment.growthRate > 0 ? (
                      <Badge className="text-xs bg-success/20 text-success">
                        <TrendingUp className="h-3 w-3 mr-1" />+{segment.growthRate.toFixed(1)}%
                      </Badge>
                    ) : (
                      segment.growthRate < 0 && (
                        <Badge className="text-xs bg-destructive/20 text-destructive">
                          <TrendingDown className="h-3 w-3 mr-1" />
                          {segment.growthRate.toFixed(1)}%
                        </Badge>
                      )
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{config.description}</p>
                </div>

                <div className="hidden md:flex items-center gap-6 text-sm">
                  <div className="text-center">
                    <p className="font-semibold">{segment.customerCount.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Customers</p>
                  </div>
                  <div className="text-center">
                    <p className="font-semibold">${segment.avgLTV.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Avg LTV</p>
                  </div>
                  <div className="text-center">
                    <p className="font-semibold">${segment.avgOrderValue.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Avg Order</p>
                  </div>
                  <div className="text-center">
                    <p
                      className={cn(
                        'font-semibold',
                        segment.churnRate > 30
                          ? 'text-destructive'
                          : segment.churnRate > 15
                            ? 'text-warning'
                            : 'text-success',
                      )}
                    >
                      {segment.churnRate.toFixed(1)}%
                    </p>
                    <p className="text-xs text-muted-foreground">Churn Rate</p>
                  </div>
                </div>

                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCreateCampaign?.(segment);
                  }}
                >
                  <Zap className="h-3 w-3" />
                  Campaign
                </Button>

                <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-foreground transition-colors" />
              </div>
            );
          })}
        </div>

        {/* Action Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-border/50">
          <div className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">${(atRiskRevenue / 1000).toFixed(0)}K</span> revenue at risk
            from churning segments
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            Export Segments <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdvancedSegmentationPanel;
