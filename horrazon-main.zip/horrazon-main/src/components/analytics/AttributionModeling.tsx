import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  ArrowRight,
  Info,
  Shuffle,
  GitBranch,
  Target,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  Sankey,
  Layer,
  Rectangle,
} from 'recharts';
import { cn } from '@/lib/utils';
import { AttributionModel, AttributionResult } from '@/types/analytics';

interface AttributionModelingProps {
  results: AttributionResult[];
  selectedModel: AttributionModel;
  onModelChange?: (model: AttributionModel) => void;
}

const modelConfig: Record<AttributionModel, { name: string; description: string }> = {
  'first-touch': {
    name: 'First Touch',
    description: 'Full credit to the first interaction',
  },
  'last-touch': {
    name: 'Last Touch',
    description: 'Full credit to the last interaction before conversion',
  },
  linear: {
    name: 'Linear',
    description: 'Equal credit across all touchpoints',
  },
  'time-decay': {
    name: 'Time Decay',
    description: 'More credit to recent interactions',
  },
  'position-based': {
    name: 'Position Based',
    description: '40% first, 40% last, 20% middle touches',
  },
  'data-driven': {
    name: 'Data Driven',
    description: 'ML-based attribution using your conversion data',
  },
  shapley: {
    name: 'Shapley Value',
    description: 'Game theory-based fair contribution analysis',
  },
};

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
  'hsl(var(--primary))',
];

export const AttributionModeling = ({ results, selectedModel, onModelChange }: AttributionModelingProps) => {
  const totalRevenue = results.reduce((sum, r) => sum + r.revenue, 0);
  const totalConversions = results.reduce((sum, r) => sum + r.conversions, 0);

  // Sort by attribution share for display
  const sortedResults = [...results].sort((a, b) => b.attributionShare - a.attributionShare);

  // Calculate model comparison data
  const modelComparisonData = results.map((r) => ({
    channel: r.channel,
    ...r.modelContribution,
  }));

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-primary" />
            Multi-Touch Attribution
          </CardTitle>
          <Badge variant="outline" className="text-xs gap-1">
            <Target className="h-3 w-3" />
            {modelConfig[selectedModel].name}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">{modelConfig[selectedModel].description}</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Model Selector */}
        <div className="flex flex-wrap gap-2">
          {Object.entries(modelConfig).map(([key, config]) => (
            <Button
              key={key}
              variant={selectedModel === key ? 'default' : 'outline'}
              size="sm"
              className="text-xs"
              onClick={() => onModelChange?.(key as AttributionModel)}
            >
              {config.name}
            </Button>
          ))}
        </div>

        {/* Summary Metrics */}
        <div className="grid grid-cols-4 gap-4">
          <div className="rounded-lg bg-muted/30 p-4 text-center">
            <p className="text-2xl font-bold">{totalConversions.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Total Conversions</p>
          </div>
          <div className="rounded-lg bg-primary/10 border border-primary/20 p-4 text-center">
            <p className="text-2xl font-bold text-primary">${(totalRevenue / 1000000).toFixed(2)}M</p>
            <p className="text-xs text-muted-foreground">Attributed Revenue</p>
          </div>
          <div className="rounded-lg bg-success/10 border border-success/20 p-4 text-center">
            <p className="text-2xl font-bold text-success">{sortedResults[0]?.channel}</p>
            <p className="text-xs text-muted-foreground">Top Channel</p>
          </div>
          <div className="rounded-lg bg-chart-1/10 border border-chart-1/20 p-4 text-center">
            <p className="text-2xl font-bold text-chart-1">{(sortedResults[0]?.roas || 0).toFixed(1)}x</p>
            <p className="text-xs text-muted-foreground">Best ROAS</p>
          </div>
        </div>

        <Tabs defaultValue="breakdown" className="space-y-4">
          <TabsList>
            <TabsTrigger value="breakdown" className="gap-1">
              <BarChart3 className="h-4 w-4" />
              Channel Breakdown
            </TabsTrigger>
            <TabsTrigger value="comparison" className="gap-1">
              <Shuffle className="h-4 w-4" />
              Model Comparison
            </TabsTrigger>
          </TabsList>

          <TabsContent value="breakdown" className="space-y-4">
            {/* Attribution Bar Chart */}
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sortedResults} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis
                    type="category"
                    dataKey="channel"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    width={100}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                    formatter={(value: number, name: string) => {
                      if (name === 'revenue') return [`$${(value / 1000).toFixed(1)}K`, 'Revenue'];
                      if (name === 'attributionShare') return [`${value.toFixed(1)}%`, 'Attribution'];
                      return [value, name];
                    }}
                  />
                  <Legend />
                  <Bar dataKey="attributionShare" name="Attribution %" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]}>
                    {sortedResults.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Channel Details */}
            <div className="space-y-3">
              {sortedResults.map((result, index) => (
                <div
                  key={result.channel}
                  className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-card hover:bg-muted/30 transition-all"
                >
                  <div
                    className="h-10 w-10 rounded-full flex items-center justify-center text-white font-bold"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  >
                    {index + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{result.channel}</p>
                      <Badge variant="secondary" className="text-xs">
                        {result.attributionShare.toFixed(1)}%
                      </Badge>
                    </div>
                    <Progress value={result.attributionShare} className="h-2 mt-2" />
                  </div>

                  <div className="hidden md:flex items-center gap-6 text-sm">
                    <div className="text-center">
                      <p className="font-semibold">{result.conversions.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">Conversions</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold">${(result.revenue / 1000).toFixed(1)}K</p>
                      <p className="text-xs text-muted-foreground">Revenue</p>
                    </div>
                    <div className="text-center">
                      <p className="font-semibold">${(result.cost / 1000).toFixed(1)}K</p>
                      <p className="text-xs text-muted-foreground">Cost</p>
                    </div>
                    <div className="text-center">
                      <p
                        className={cn(
                          'font-semibold',
                          result.roas >= 3 ? 'text-success' : result.roas >= 1 ? 'text-warning' : 'text-destructive',
                        )}
                      >
                        {result.roas.toFixed(1)}x
                      </p>
                      <p className="text-xs text-muted-foreground">ROAS</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="comparison" className="space-y-4">
            <div className="rounded-lg bg-muted/30 p-4">
              <p className="text-sm font-medium mb-2 flex items-center gap-2">
                <Info className="h-4 w-4 text-primary" />
                Model Comparison Insights
              </p>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-chart-1" />
                  First-touch gives higher credit to awareness channels (Paid Social, Display)
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-chart-2" />
                  Last-touch emphasizes conversion channels (Paid Search, Email)
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-chart-3" />
                  Data-driven model shows Organic Search is undervalued by 23%
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Shapley values suggest reallocating 12% budget from Display to Email
                </li>
              </ul>
            </div>

            {/* Model comparison chart placeholder */}
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={modelComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="channel" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="first-touch" name="First Touch" fill="hsl(var(--chart-1))" />
                  <Bar dataKey="last-touch" name="Last Touch" fill="hsl(var(--chart-2))" />
                  <Bar dataKey="linear" name="Linear" fill="hsl(var(--chart-3))" />
                  <Bar dataKey="data-driven" name="Data Driven" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>

        {/* Action Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-border/50">
          <p className="text-sm text-muted-foreground">
            Attribution window: <span className="font-medium text-foreground">30 days</span> • Lookback:{' '}
            <span className="font-medium text-foreground">All touchpoints</span>
          </p>
          <Button variant="outline" size="sm" className="gap-1">
            Configure Settings <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AttributionModeling;
