import { LucideIcon } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface KPICardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: LucideIcon;
}

export default function KPICard({ title, value, change, trend, icon: Icon }: KPICardProps) {
  const isPositive = trend === 'up';

  return (
    <Card className="group p-6 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-0.5 border-border/50">
      <div className="flex items-start justify-between">
        <div className="space-y-2.5">
          <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
          <p className="text-4xl font-bold tracking-tight bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text">
            {value}
          </p>
          <div className="flex items-center gap-1.5 pt-1">
            <span
              className={cn(
                'text-sm font-semibold px-2 py-0.5 rounded-md',
                isPositive ? 'text-success bg-success/10' : 'text-destructive bg-destructive/10',
              )}
            >
              {change}
            </span>
            <span className="text-xs text-muted-foreground/80">vs last period</span>
          </div>
        </div>
        <div
          className={cn(
            'rounded-xl p-3.5 transition-all duration-300 group-hover:scale-110',
            isPositive
              ? 'bg-gradient-to-br from-success/10 to-success/5 ring-1 ring-success/20'
              : 'bg-gradient-to-br from-destructive/10 to-destructive/5 ring-1 ring-destructive/20',
          )}
        >
          <Icon
            className={cn(
              'h-6 w-6 transition-transform duration-300 group-hover:rotate-12',
              isPositive ? 'text-success' : 'text-destructive',
            )}
          />
        </div>
      </div>
    </Card>
  );
}
