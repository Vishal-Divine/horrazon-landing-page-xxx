export { SEOHead } from './SEOHead';
export { default } from './SEOHead';
