import { useEffect } from 'react';

interface SEOHeadProps {
  title: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  canonicalUrl?: string;
}

/**
 * SEO Component for dynamic page metadata
 * Updates document title and meta tags for each page
 */
export function SEOHead({
  title,
  description = 'Transform your marketing with AI-powered analytics, attribution modeling, and automated campaign optimization',
  keywords = 'marketing analytics, AI marketing, attribution modeling, campaign automation, advertising analytics',
  ogImage = '/favicon.png',
  canonicalUrl,
}: SEOHeadProps) {
  useEffect(() => {
    // Update document title
    document.title = `${title} | Horrazon.ai`;

    // Update or create meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);

    // Update or create meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', keywords);

    // Update OG title
    let ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', `${title} | Horrazon.ai`);
    }

    // Update OG description
    let ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', description);
    }

    // Update canonical URL if provided
    if (canonicalUrl) {
      let canonical = document.querySelector('link[rel="canonical"]');
      if (!canonical) {
        canonical = document.createElement('link');
        canonical.setAttribute('rel', 'canonical');
        document.head.appendChild(canonical);
      }
      canonical.setAttribute('href', canonicalUrl);
    }

    // Cleanup function to reset title when component unmounts
    return () => {
      document.title = 'Horrazon.ai - AI Marketing Analytics & Automation';
    };
  }, [title, description, keywords, ogImage, canonicalUrl]);

  return null;
}

export default SEOHead;
