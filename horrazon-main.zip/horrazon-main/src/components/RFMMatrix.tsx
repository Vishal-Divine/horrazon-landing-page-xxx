import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface RFMSegment {
  name: string;
  customers: number;
  revenue: string;
  color: string;
}

const rfmSegments: RFMSegment[] = [
  { name: 'Champions', customers: 342, revenue: '$124K', color: 'bg-success/20 text-success border-success/30' },
  { name: 'Loyal', customers: 521, revenue: '$89K', color: 'bg-chart-1/20 text-chart-1 border-chart-1/30' },
  {
    name: 'At Risk',
    customers: 187,
    revenue: '$45K',
    color: 'bg-destructive/20 text-destructive border-destructive/30',
  },
  { name: 'Promising', customers: 298, revenue: '$67K', color: 'bg-chart-3/20 text-chart-3 border-chart-3/30' },
  {
    name: 'Need Attention',
    customers: 156,
    revenue: '$28K',
    color: 'bg-muted-foreground/20 text-muted-foreground border-muted-foreground/30',
  },
  { name: 'Lost', customers: 98, revenue: '$12K', color: 'bg-border text-muted-foreground border-border' },
];

export default function RFMMatrix() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span>RFM Customer Segmentation</span>
          <Badge variant="secondary" className="text-xs">
            Recency • Frequency • Monetary
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {rfmSegments.map((segment) => (
            <div
              key={segment.name}
              className={cn(
                'p-4 rounded-lg border-2 transition-all hover:scale-105 hover:shadow-md cursor-pointer',
                segment.color,
              )}
            >
              <div className="space-y-2">
                <p className="font-bold text-lg">{segment.name}</p>
                <div className="space-y-1">
                  <p className="text-2xl font-bold">{segment.customers}</p>
                  <p className="text-xs opacity-80">customers</p>
                </div>
                <div className="pt-2 border-t border-current/20">
                  <p className="text-sm font-semibold">{segment.revenue}</p>
                  <p className="text-xs opacity-80">total revenue</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
