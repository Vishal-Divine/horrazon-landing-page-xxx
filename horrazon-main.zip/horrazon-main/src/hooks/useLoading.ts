import { useState, useEffect } from 'react';

/**
 * Custom hook to simulate loading state for pages
 * In production, this would be replaced with actual data fetching status
 */
export function useLoading(delay: number = 800) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, delay);

    return () => clearTimeout(timer);
  }, [delay]);

  return isLoading;
}

/**
 * Hook to manage async data loading states
 */
export function useAsyncLoading<T>(fetchFn: () => Promise<T>, deps: any[] = []) {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let cancelled = false;

    setIsLoading(true);
    fetchFn()
      .then((result) => {
        if (!cancelled) {
          setData(result);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err);
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, deps);

  return { isLoading, data, error };
}
