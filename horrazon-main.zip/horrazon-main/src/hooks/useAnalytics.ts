import { useState, useCallback, useMemo } from 'react';
import { MetricValue, DateRange, TimeSeriesDataPoint, AnomalyDetection, ForecastPoint } from '@/types/analytics';

// Calculate percentage change between two values
export const calculateChange = (
  current: number,
  previous: number,
): { change: number; changePercent: number; trend: 'up' | 'down' | 'stable' } => {
  if (previous === 0) {
    return { change: current, changePercent: current > 0 ? 100 : 0, trend: current > 0 ? 'up' : 'stable' };
  }
  const change = current - previous;
  const changePercent = (change / previous) * 100;
  const trend = changePercent > 1 ? 'up' : changePercent < -1 ? 'down' : 'stable';
  return { change, changePercent, trend };
};

// Format numbers with appropriate suffixes
export const formatNumber = (value: number, type: 'currency' | 'percent' | 'number' | 'compact' = 'number'): string => {
  if (type === 'currency') {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(1)}K`;
    return `$${value.toFixed(2)}`;
  }
  if (type === 'percent') {
    return `${value.toFixed(1)}%`;
  }
  if (type === 'compact') {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  }
  return value.toLocaleString();
};

// Calculate moving average
export const calculateMovingAverage = (data: number[], window: number): number[] => {
  const result: number[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < window - 1) {
      result.push(data[i]);
    } else {
      const windowSlice = data.slice(i - window + 1, i + 1);
      const avg = windowSlice.reduce((a, b) => a + b, 0) / window;
      result.push(avg);
    }
  }
  return result;
};

// Simple anomaly detection using Z-score
export const detectAnomalies = (data: TimeSeriesDataPoint[], threshold: number = 2): AnomalyDetection[] => {
  const values = data.map((d) => d.value);
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const stdDev = Math.sqrt(values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length);

  const anomalies: AnomalyDetection[] = [];

  data.forEach((point, index) => {
    const zScore = Math.abs((point.value - mean) / stdDev);
    if (zScore > threshold) {
      anomalies.push({
        id: `anomaly-${index}`,
        metric: 'value',
        timestamp: new Date(point.date),
        value: point.value,
        expectedValue: mean,
        deviation: zScore,
        severity: zScore > 3 ? 'critical' : zScore > 2.5 ? 'high' : 'medium',
        type: point.value > mean ? 'spike' : 'drop',
        possibleCauses: generatePossibleCauses(point.value > mean),
        recommendedActions: generateRecommendedActions(point.value > mean),
      });
    }
  });

  return anomalies;
};

const generatePossibleCauses = (isSpike: boolean): string[] => {
  if (isSpike) {
    return [
      'Viral campaign or content',
      'Seasonal peak or holiday effect',
      'Successful promotion or sale',
      'External event driving traffic',
      'Bot or spam activity',
    ];
  }
  return [
    'Technical issue or outage',
    'Campaign fatigue or saturation',
    'Competitive activity',
    'Seasonal low period',
    'Deliverability issues',
  ];
};

const generateRecommendedActions = (isSpike: boolean): string[] => {
  if (isSpike) {
    return [
      'Analyze traffic sources to identify driver',
      'Capitalize on momentum with follow-up campaigns',
      'Document successful tactics for replication',
      'Verify data quality and filter spam',
    ];
  }
  return [
    'Investigate technical issues immediately',
    'Review campaign performance metrics',
    'Analyze competitor activity',
    'Check deliverability and sender reputation',
    'Consider audience re-engagement campaign',
  ];
};

// Simple linear forecast
export const generateForecast = (historicalData: TimeSeriesDataPoint[], daysAhead: number = 14): ForecastPoint[] => {
  if (historicalData.length < 7) return [];

  const values = historicalData.map((d) => d.value);
  const n = values.length;

  // Simple linear regression
  const xMean = (n - 1) / 2;
  const yMean = values.reduce((a, b) => a + b, 0) / n;

  let numerator = 0;
  let denominator = 0;

  values.forEach((y, x) => {
    numerator += (x - xMean) * (y - yMean);
    denominator += Math.pow(x - xMean, 2);
  });

  const slope = numerator / denominator;
  const intercept = yMean - slope * xMean;

  // Calculate standard error for confidence intervals
  const predictions = values.map((_, x) => slope * x + intercept);
  const residuals = values.map((y, i) => y - predictions[i]);
  const stdError = Math.sqrt(residuals.reduce((sum, r) => sum + r * r, 0) / (n - 2));

  // Generate forecast points
  const forecast: ForecastPoint[] = [];
  const lastDate = new Date(historicalData[historicalData.length - 1].date);

  for (let i = 1; i <= daysAhead; i++) {
    const x = n + i - 1;
    const predicted = slope * x + intercept;
    const confidenceMultiplier = 1.96; // 95% confidence
    const uncertainty = stdError * Math.sqrt(1 + 1 / n + Math.pow(x - xMean, 2) / denominator);

    const forecastDate = new Date(lastDate);
    forecastDate.setDate(forecastDate.getDate() + i);

    forecast.push({
      date: forecastDate.toISOString().split('T')[0],
      predicted: Math.max(0, predicted),
      upperBound: Math.max(0, predicted + confidenceMultiplier * uncertainty),
      lowerBound: Math.max(0, predicted - confidenceMultiplier * uncertainty),
      confidence: Math.max(50, 95 - i * 2), // Decreasing confidence over time
    });
  }

  return forecast;
};

// Hook for date range management
export const useDateRange = (defaultDays: number = 30) => {
  const [dateRange, setDateRange] = useState<DateRange>(() => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - defaultDays);
    const comparisonEnd = new Date(start);
    const comparisonStart = new Date(start);
    comparisonStart.setDate(comparisonStart.getDate() - defaultDays);

    return {
      start,
      end,
      label: `Last ${defaultDays} days`,
      comparisonStart,
      comparisonEnd,
    };
  });

  const setPresetRange = useCallback((preset: '7d' | '30d' | '90d' | 'ytd' | 'custom') => {
    const end = new Date();
    const start = new Date();

    switch (preset) {
      case '7d':
        start.setDate(start.getDate() - 7);
        break;
      case '30d':
        start.setDate(start.getDate() - 30);
        break;
      case '90d':
        start.setDate(start.getDate() - 90);
        break;
      case 'ytd':
        start.setMonth(0, 1);
        break;
      default:
        return;
    }

    const daysDiff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const comparisonEnd = new Date(start);
    const comparisonStart = new Date(start);
    comparisonStart.setDate(comparisonStart.getDate() - daysDiff);

    setDateRange({
      start,
      end,
      label: preset === 'ytd' ? 'Year to date' : `Last ${daysDiff} days`,
      comparisonStart,
      comparisonEnd,
    });
  }, []);

  return { dateRange, setDateRange, setPresetRange };
};

// Hook for metric comparison
export const useMetricComparison = (current: number, previous: number) => {
  return useMemo((): MetricValue => {
    const { change, changePercent, trend } = calculateChange(current, previous);
    return {
      current,
      previous,
      change,
      changePercent,
      trend,
    };
  }, [current, previous]);
};

// Generate sparkline data
export const generateSparklineData = (
  baseValue: number,
  points: number = 14,
  volatility: number = 0.1,
  trend: 'up' | 'down' | 'stable' = 'stable',
): { value: number }[] => {
  const data: { value: number }[] = [];
  let currentValue = baseValue * (1 - volatility * 0.5);

  const trendFactor = trend === 'up' ? 1.005 : trend === 'down' ? 0.995 : 1;

  for (let i = 0; i < points; i++) {
    const randomChange = (Math.random() - 0.5) * 2 * volatility * baseValue;
    currentValue = currentValue * trendFactor + randomChange;
    currentValue = Math.max(0, currentValue);
    data.push({ value: Math.round(currentValue) });
  }

  return data;
};

// Calculate cohort retention
export const calculateCohortRetention = (
  cohortSize: number,
  months: number = 12,
  baseRetention: number = 0.7,
): number[] => {
  const retention: number[] = [100];
  let currentRetention = 100;

  for (let i = 1; i < months; i++) {
    const decay = baseRetention + (Math.random() - 0.5) * 0.1;
    currentRetention *= decay;
    retention.push(Math.round(currentRetention * 10) / 10);
  }

  return retention;
};

// RFM Scoring
export const calculateRFMScore = (
  daysSinceLastPurchase: number,
  purchaseCount: number,
  totalSpend: number,
  maxRecency: number = 365,
  maxFrequency: number = 50,
  maxMonetary: number = 10000,
): { recency: number; frequency: number; monetary: number; combined: number } => {
  // Recency: Lower is better (inverted)
  const recency = Math.max(1, Math.min(5, 6 - Math.ceil((daysSinceLastPurchase / maxRecency) * 5)));

  // Frequency: Higher is better
  const frequency = Math.max(1, Math.min(5, Math.ceil((purchaseCount / maxFrequency) * 5)));

  // Monetary: Higher is better
  const monetary = Math.max(1, Math.min(5, Math.ceil((totalSpend / maxMonetary) * 5)));

  const combined = (recency + frequency + monetary) / 3;

  return { recency, frequency, monetary, combined: Math.round(combined * 10) / 10 };
};

// Churn probability estimation
export const estimateChurnProbability = (
  daysSinceLastPurchase: number,
  avgPurchaseInterval: number,
  engagementScore: number,
  npsScore?: number,
): number => {
  // Base probability from recency
  let probability = Math.min(0.95, daysSinceLastPurchase / (avgPurchaseInterval * 3));

  // Adjust for engagement
  probability *= 1 - (engagementScore / 100) * 0.3;

  // Adjust for NPS if available
  if (npsScore !== undefined) {
    if (npsScore >= 9) probability *= 0.5;
    else if (npsScore >= 7) probability *= 0.8;
    else if (npsScore <= 6) probability *= 1.3;
  }

  return Math.max(0, Math.min(1, probability));
};
