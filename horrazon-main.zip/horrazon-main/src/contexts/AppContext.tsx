import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { toast } from '@/hooks/use-toast';

// Types
export interface WalletData {
  balance: number;
  currency: string;
  totalSpent: number;
  monthlySpent: number;
  dailySpent: number;
  pendingCharges: number;
  lastUpdated: Date;
  lowBalanceThreshold: number;
  autoRechargeEnabled: boolean;
  autoRechargeAmount: number;
  criticalBalanceThreshold: number;
}

export interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  campaign?: string;
  date: Date;
  status: 'completed' | 'pending' | 'failed';
}

export interface CampaignSpend {
  id: string;
  name: string;
  platform: string;
  spent: number;
  budget: number;
  status: 'active' | 'paused' | 'completed';
  dailyBudget: number;
  daysRemaining: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

export interface AppNotification {
  id: string;
  type: 'wallet' | 'campaign' | 'system' | 'ai';
  severity: 'info' | 'warning' | 'critical' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionLabel?: string;
  actionCallback?: () => void;
  dismissible: boolean;
}

export interface SpendingAlert {
  id: string;
  type: 'low_balance' | 'critical_balance' | 'campaign_risk' | 'budget_exceeded' | 'unusual_spend';
  message: string;
  severity: 'warning' | 'critical';
  triggeredAt: Date;
  acknowledged: boolean;
  relatedCampaignId?: string;
}

interface AppContextType {
  // Wallet
  wallet: WalletData;
  transactions: Transaction[];
  campaignSpends: CampaignSpend[];
  addFunds: (amount: number) => Promise<void>;
  refreshWallet: () => Promise<void>;
  updateAutoRecharge: (enabled: boolean, amount?: number) => void;

  // Alerts
  spendingAlerts: SpendingAlert[];
  acknowledgeAlert: (alertId: string) => void;
  dismissAllAlerts: () => void;

  // Notifications
  notifications: AppNotification[];
  addNotification: (notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  clearNotification: (notificationId: string) => void;
  unreadCount: number;

  // UI State
  isAddFundsOpen: boolean;
  setIsAddFundsOpen: (open: boolean) => void;
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial mock data
const initialWallet: WalletData = {
  balance: 12450.75,
  currency: 'USD',
  totalSpent: 45320.5,
  monthlySpent: 8240.3,
  dailySpent: 342.8,
  pendingCharges: 1250.0,
  lastUpdated: new Date(),
  lowBalanceThreshold: 5000,
  autoRechargeEnabled: true,
  autoRechargeAmount: 5000,
  criticalBalanceThreshold: 1000,
};

const initialTransactions: Transaction[] = [
  {
    id: '1',
    type: 'debit',
    amount: 450.0,
    description: 'Meta Ads - Summer Campaign',
    campaign: 'Summer Sale 2024',
    date: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: 'completed',
  },
  {
    id: '2',
    type: 'debit',
    amount: 280.5,
    description: 'Google Ads - Brand Keywords',
    campaign: 'Brand Awareness',
    date: new Date(Date.now() - 5 * 60 * 60 * 1000),
    status: 'completed',
  },
  {
    id: '3',
    type: 'credit',
    amount: 5000.0,
    description: 'Wallet Top-up via Card',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000),
    status: 'completed',
  },
  {
    id: '4',
    type: 'debit',
    amount: 125.3,
    description: 'TikTok Ads - Gen Z Campaign',
    campaign: 'Gen Z Outreach',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000),
    status: 'completed',
  },
  {
    id: '5',
    type: 'debit',
    amount: 890.0,
    description: 'LinkedIn Ads - B2B Lead Gen',
    campaign: 'Q4 Lead Generation',
    date: new Date(Date.now() - 48 * 60 * 60 * 1000),
    status: 'pending',
  },
];

const initialCampaigns: CampaignSpend[] = [
  {
    id: '1',
    name: 'Summer Sale 2024',
    platform: 'Meta',
    spent: 4520.0,
    budget: 10000.0,
    status: 'active',
    dailyBudget: 500,
    daysRemaining: 11,
    riskLevel: 'low',
  },
  {
    id: '2',
    name: 'Brand Awareness',
    platform: 'Google',
    spent: 2840.5,
    budget: 5000.0,
    status: 'active',
    dailyBudget: 300,
    daysRemaining: 7,
    riskLevel: 'medium',
  },
  {
    id: '3',
    name: 'Gen Z Outreach',
    platform: 'TikTok',
    spent: 1250.3,
    budget: 3000.0,
    status: 'active',
    dailyBudget: 200,
    daysRemaining: 8,
    riskLevel: 'low',
  },
  {
    id: '4',
    name: 'Q4 Lead Generation',
    platform: 'LinkedIn',
    spent: 1890.0,
    budget: 2000.0,
    status: 'active',
    dailyBudget: 150,
    daysRemaining: 3,
    riskLevel: 'critical',
  },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletData>(initialWallet);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [campaignSpends, setCampaignSpends] = useState<CampaignSpend[]>(initialCampaigns);
  const [spendingAlerts, setSpendingAlerts] = useState<SpendingAlert[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isAddFundsOpen, setIsAddFundsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Calculate unread count
  const unreadCount = notifications.filter((n) => !n.read).length;

  // Add notification helper
  const addNotification = useCallback((notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: AppNotification = {
      ...notification,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      read: false,
    };
    setNotifications((prev) => [newNotification, ...prev]);
  }, []);

  // Check for spending alerts
  const checkSpendingAlerts = useCallback(() => {
    const newAlerts: SpendingAlert[] = [];

    // Check low balance
    if (wallet.balance < wallet.lowBalanceThreshold && wallet.balance >= wallet.criticalBalanceThreshold) {
      const existingAlert = spendingAlerts.find((a) => a.type === 'low_balance' && !a.acknowledged);
      if (!existingAlert) {
        newAlerts.push({
          id: `alert-low-${Date.now()}`,
          type: 'low_balance',
          message: `Balance is low ($${wallet.balance.toLocaleString()}). Add funds to avoid campaign interruptions.`,
          severity: 'warning',
          triggeredAt: new Date(),
          acknowledged: false,
        });
      }
    }

    // Check critical balance
    if (wallet.balance < wallet.criticalBalanceThreshold) {
      const existingAlert = spendingAlerts.find((a) => a.type === 'critical_balance' && !a.acknowledged);
      if (!existingAlert) {
        newAlerts.push({
          id: `alert-critical-${Date.now()}`,
          type: 'critical_balance',
          message: `CRITICAL: Balance is critically low ($${wallet.balance.toLocaleString()}). Campaigns may pause soon!`,
          severity: 'critical',
          triggeredAt: new Date(),
          acknowledged: false,
        });

        // Also add notification
        addNotification({
          type: 'wallet',
          severity: 'critical',
          title: 'Critical Balance Alert',
          message: `Your wallet balance is critically low. Add funds immediately to prevent campaign interruptions.`,
          dismissible: true,
          actionLabel: 'Add Funds',
          actionCallback: () => setIsAddFundsOpen(true),
        });
      }
    }

    // Check campaign risks
    campaignSpends.forEach((campaign) => {
      if (campaign.status === 'active' && campaign.riskLevel === 'critical') {
        const existingAlert = spendingAlerts.find(
          (a) => a.type === 'campaign_risk' && a.relatedCampaignId === campaign.id && !a.acknowledged,
        );
        if (!existingAlert) {
          newAlerts.push({
            id: `alert-campaign-${campaign.id}-${Date.now()}`,
            type: 'campaign_risk',
            message: `Campaign "${campaign.name}" is at risk. Budget is ${Math.round((campaign.spent / campaign.budget) * 100)}% spent with ${campaign.daysRemaining} days remaining.`,
            severity: 'critical',
            triggeredAt: new Date(),
            acknowledged: false,
            relatedCampaignId: campaign.id,
          });
        }
      }
    });

    // Check for budget exceeded campaigns
    campaignSpends.forEach((campaign) => {
      if (campaign.spent >= campaign.budget * 0.9 && campaign.status === 'active') {
        const existingAlert = spendingAlerts.find(
          (a) => a.type === 'budget_exceeded' && a.relatedCampaignId === campaign.id && !a.acknowledged,
        );
        if (!existingAlert) {
          newAlerts.push({
            id: `alert-budget-${campaign.id}-${Date.now()}`,
            type: 'budget_exceeded',
            message: `Campaign "${campaign.name}" has used ${Math.round((campaign.spent / campaign.budget) * 100)}% of its budget.`,
            severity: 'warning',
            triggeredAt: new Date(),
            acknowledged: false,
            relatedCampaignId: campaign.id,
          });
        }
      }
    });

    if (newAlerts.length > 0) {
      setSpendingAlerts((prev) => [...newAlerts, ...prev]);
    }
  }, [wallet, campaignSpends, spendingAlerts, addNotification]);

  // Simulate real-time spending updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate random spending
      const randomSpend = Math.random() * 10;

      setWallet((prev) => ({
        ...prev,
        dailySpent: prev.dailySpent + randomSpend,
        balance: Math.max(0, prev.balance - randomSpend),
        lastUpdated: new Date(),
      }));

      // Update campaign spending
      setCampaignSpends((prev) =>
        prev.map((campaign) => {
          if (campaign.status !== 'active') return campaign;
          const spend = Math.random() * 5;
          const newSpent = campaign.spent + spend;
          const percentUsed = newSpent / campaign.budget;

          let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
          if (percentUsed > 0.9) riskLevel = 'critical';
          else if (percentUsed > 0.75) riskLevel = 'high';
          else if (percentUsed > 0.5) riskLevel = 'medium';

          return {
            ...campaign,
            spent: newSpent,
            riskLevel,
          };
        }),
      );
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, []);

  // Check alerts when wallet or campaigns change
  useEffect(() => {
    checkSpendingAlerts();
  }, [wallet.balance, checkSpendingAlerts]);

  // Add funds function
  const addFunds = async (amount: number): Promise<void> => {
    setIsLoading(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const newTransaction: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'credit',
      amount,
      description: 'Wallet Top-up via Card',
      date: new Date(),
      status: 'completed',
    };

    setWallet((prev) => ({
      ...prev,
      balance: prev.balance + amount,
      lastUpdated: new Date(),
    }));

    setTransactions((prev) => [newTransaction, ...prev]);

    addNotification({
      type: 'wallet',
      severity: 'success',
      title: 'Funds Added Successfully',
      message: `$${amount.toLocaleString()} has been added to your wallet.`,
      dismissible: true,
    });

    toast({
      title: 'Funds Added Successfully!',
      description: `$${amount.toLocaleString()} has been added to your wallet.`,
    });

    setIsLoading(false);
    setIsAddFundsOpen(false);
  };

  // Refresh wallet
  const refreshWallet = async (): Promise<void> => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setWallet((prev) => ({
      ...prev,
      lastUpdated: new Date(),
    }));
    setIsLoading(false);
  };

  // Update auto recharge settings
  const updateAutoRecharge = (enabled: boolean, amount?: number) => {
    setWallet((prev) => ({
      ...prev,
      autoRechargeEnabled: enabled,
      autoRechargeAmount: amount ?? prev.autoRechargeAmount,
    }));

    toast({
      title: enabled ? 'Auto-recharge Enabled' : 'Auto-recharge Disabled',
      description: enabled
        ? `Your wallet will automatically recharge when balance drops below $${wallet.lowBalanceThreshold.toLocaleString()}.`
        : 'Auto-recharge has been disabled.',
    });
  };

  // Acknowledge alert
  const acknowledgeAlert = (alertId: string) => {
    setSpendingAlerts((prev) => prev.map((alert) => (alert.id === alertId ? { ...alert, acknowledged: true } : alert)));
  };

  // Dismiss all alerts
  const dismissAllAlerts = () => {
    setSpendingAlerts((prev) => prev.map((alert) => ({ ...alert, acknowledged: true })));
  };

  // Mark notification as read
  const markAsRead = (notificationId: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)));
  };

  // Mark all as read
  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // Clear notification
  const clearNotification = (notificationId: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
  };

  return (
    <AppContext.Provider
      value={{
        wallet,
        transactions,
        campaignSpends,
        addFunds,
        refreshWallet,
        updateAutoRecharge,
        spendingAlerts,
        acknowledgeAlert,
        dismissAllAlerts,
        notifications,
        addNotification,
        markAsRead,
        markAllAsRead,
        clearNotification,
        unreadCount,
        isAddFundsOpen,
        setIsAddFundsOpen,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
