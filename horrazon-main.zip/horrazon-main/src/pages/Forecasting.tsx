import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  LineChart,
  Line,
  ComposedChart,
} from 'recharts';
import { TrendingUp, Calendar, Target, Sparkles, AlertCircle, Info } from 'lucide-react';

const forecastData = [
  { week: 'Week 1', projected: 15000, optimized: 18000, lower: 14000, upper: 22000 },
  { week: 'Week 2', projected: 16000, optimized: 19500, lower: 15000, upper: 24000 },
  { week: 'Week 3', projected: 15500, optimized: 19000, lower: 14500, upper: 23000 },
  { week: 'Week 4', projected: 17000, optimized: 21000, lower: 16000, upper: 26000 },
];

const scenarioData = [
  { week: 'Week 1', pessimistic: 12000, expected: 18000, optimistic: 24000 },
  { week: 'Week 2', pessimistic: 13000, expected: 19500, optimistic: 26000 },
  { week: 'Week 3', pessimistic: 12500, expected: 19000, optimistic: 25000 },
  { week: 'Week 4', pessimistic: 14000, expected: 21000, optimistic: 28000 },
];

const mmmData = [
  { spend: 0, meta: 0, google: 0, email: 0 },
  { spend: 10000, meta: 28000, google: 22000, email: 35000 },
  { spend: 20000, meta: 48000, google: 40000, email: 55000 },
  { spend: 30000, meta: 62000, google: 54000, email: 68000 },
  { spend: 40000, meta: 72000, google: 65000, email: 76000 },
  { spend: 50000, meta: 78000, google: 73000, email: 82000 },
  { spend: 60000, meta: 82000, google: 78000, email: 86000 },
];

const seasonalityData = [
  { month: 'Jan', baseline: 100, seasonal: 85 },
  { month: 'Feb', baseline: 100, seasonal: 88 },
  { month: 'Mar', baseline: 100, seasonal: 95 },
  { month: 'Apr', baseline: 100, seasonal: 102 },
  { month: 'May', baseline: 100, seasonal: 108 },
  { month: 'Jun', baseline: 100, seasonal: 115 },
  { month: 'Jul', baseline: 100, seasonal: 120 },
  { month: 'Aug', baseline: 100, seasonal: 118 },
  { month: 'Sep', baseline: 100, seasonal: 110 },
  { month: 'Oct', baseline: 100, seasonal: 105 },
  { month: 'Nov', baseline: 100, seasonal: 135 },
  { month: 'Dec', baseline: 100, seasonal: 145 },
];

export default function Forecasting() {
  const [budget, setBudget] = useState('50000');
  const [duration, setDuration] = useState('30');
  const [metric, setMetric] = useState('roas');
  const [distribution, setDistribution] = useState('ai');
  const [whatIfBudget, setWhatIfBudget] = useState([50000]);
  const [channelSplit, setChannelSplit] = useState({ meta: 40, google: 35, email: 25 });

  const predictedRevenue = Math.round(whatIfBudget[0] * 4.2);
  const predictedRoas = 4.2;

  return (
    <div className="space-y-6 p-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          Forecasting & Planning
        </h1>
        <p className="text-muted-foreground text-lg">
          AI-powered predictions with confidence intervals and scenario planning
        </p>
      </div>

      {/* Budget Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Budget & Duration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="budget">Total Budget ($)</Label>
              <Input id="budget" type="number" value={budget} onChange={(e) => setBudget(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (days)</Label>
              <Input id="duration" type="number" value={duration} onChange={(e) => setDuration(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="metric">Optimize for Metric</Label>
              <Select value={metric} onValueChange={setMetric}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="roas">ROAS</SelectItem>
                  <SelectItem value="conversion">Conversions</SelectItem>
                  <SelectItem value="revenue">Revenue</SelectItem>
                  <SelectItem value="cpa">CPA</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="distribution">Budget Distribution</Label>
              <Select value={distribution} onValueChange={setDistribution}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ai">AI Optimized</SelectItem>
                  <SelectItem value="uniform">Uniform</SelectItem>
                  <SelectItem value="weighted">Weighted by Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button className="w-full gap-2">
            <Sparkles className="h-4 w-4" />
            Generate Forecast
          </Button>
        </CardContent>
      </Card>

      <Tabs defaultValue="forecast" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="forecast">Confidence Intervals</TabsTrigger>
          <TabsTrigger value="scenarios">Scenario Planner</TabsTrigger>
          <TabsTrigger value="mmm">Marketing Mix Model</TabsTrigger>
          <TabsTrigger value="seasonality">Seasonality</TabsTrigger>
          <TabsTrigger value="whatif">What-If Simulator</TabsTrigger>
        </TabsList>

        {/* Confidence Intervals */}
        <TabsContent value="forecast">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Projected Performance with Confidence Bands</CardTitle>
                <div className="flex gap-2">
                  <Badge variant="outline" className="gap-1">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    Expected
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <div className="h-2 w-2 rounded-full bg-muted" />
                    80% CI
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <ComposedChart data={forecastData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="week" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="upper"
                    stroke="none"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.1}
                    name="Upper Bound"
                  />
                  <Area
                    type="monotone"
                    dataKey="lower"
                    stroke="none"
                    fill="hsl(var(--background))"
                    name="Lower Bound"
                  />
                  <Line
                    type="monotone"
                    dataKey="optimized"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }}
                    name="AI Optimized"
                  />
                  <Line
                    type="monotone"
                    dataKey="projected"
                    stroke="hsl(var(--muted-foreground))"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Current Projection"
                  />
                </ComposedChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="p-4 rounded-lg bg-muted/30">
                  <p className="text-sm text-muted-foreground">Conservative Estimate</p>
                  <p className="text-2xl font-bold">$59.5K</p>
                  <p className="text-xs text-muted-foreground">Lower 10th percentile</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
                  <p className="text-sm text-muted-foreground">Expected Outcome</p>
                  <p className="text-2xl font-bold text-primary">$77.5K</p>
                  <p className="text-xs text-muted-foreground">Most likely scenario</p>
                </div>
                <div className="p-4 rounded-lg bg-success/10 border border-success/30">
                  <p className="text-sm text-muted-foreground">Optimistic Estimate</p>
                  <p className="text-2xl font-bold text-success">$95K</p>
                  <p className="text-xs text-muted-foreground">Upper 90th percentile</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Scenario Planner */}
        <TabsContent value="scenarios">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Three-Scenario Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={scenarioData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="week" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="optimistic"
                    stroke="hsl(var(--success))"
                    fill="hsl(var(--success))"
                    fillOpacity={0.3}
                    name="Optimistic"
                  />
                  <Area
                    type="monotone"
                    dataKey="expected"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                    name="Expected"
                  />
                  <Area
                    type="monotone"
                    dataKey="pessimistic"
                    stroke="hsl(var(--destructive))"
                    fill="hsl(var(--destructive))"
                    fillOpacity={0.3}
                    name="Pessimistic"
                  />
                </AreaChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="p-4 rounded-lg border border-destructive/30 bg-destructive/5">
                  <p className="text-sm font-medium text-destructive">Pessimistic</p>
                  <p className="text-2xl font-bold">$51.5K</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Market downturn, increased competition, reduced consumer spending
                  </p>
                </div>
                <div className="p-4 rounded-lg border border-primary/30 bg-primary/5">
                  <p className="text-sm font-medium text-primary">Expected</p>
                  <p className="text-2xl font-bold">$77.5K</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Normal market conditions, current trends continue
                  </p>
                </div>
                <div className="p-4 rounded-lg border border-success/30 bg-success/5">
                  <p className="text-sm font-medium text-success">Optimistic</p>
                  <p className="text-2xl font-bold">$103K</p>
                  <p className="text-xs text-muted-foreground mt-2">Viral campaign, seasonal boost, competitor exit</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Marketing Mix Model */}
        <TabsContent value="mmm">
          <Card>
            <CardHeader>
              <CardTitle>Marketing Mix Model - Saturation Curves</CardTitle>
              <p className="text-sm text-muted-foreground">Diminishing returns analysis by channel</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={mmmData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="spend" className="text-xs" tickFormatter={(v) => `$${v / 1000}K`} />
                  <YAxis className="text-xs" tickFormatter={(v) => `$${v / 1000}K`} />
                  <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                  <Line type="monotone" dataKey="meta" stroke="hsl(var(--chart-1))" strokeWidth={2} name="Meta Ads" />
                  <Line
                    type="monotone"
                    dataKey="google"
                    stroke="hsl(var(--chart-2))"
                    strokeWidth={2}
                    name="Google Ads"
                  />
                  <Line type="monotone" dataKey="email" stroke="hsl(var(--chart-3))" strokeWidth={2} name="Email" />
                </LineChart>
              </ResponsiveContainer>
              <div className="mt-6 p-4 bg-muted/30 rounded-lg">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium">Optimal Budget Allocation</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Based on saturation analysis, Email shows highest efficiency at current spend levels. Meta Ads
                      approaching saturation point at $50K. Consider shifting 15% from Meta to Email for +8% overall
                      ROAS.
                    </p>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Meta Ads</p>
                  <p className="text-lg font-bold">$40K optimal</p>
                  <Badge variant="secondary" className="mt-1">
                    Approaching Saturation
                  </Badge>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Google Ads</p>
                  <p className="text-lg font-bold">$35K optimal</p>
                  <Badge variant="outline" className="mt-1">
                    Room to Scale
                  </Badge>
                </div>
                <div className="p-4 rounded-lg border border-success/30 bg-success/5">
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="text-lg font-bold">$25K optimal</p>
                  <Badge className="mt-1 bg-success">Highest Efficiency</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Seasonality */}
        <TabsContent value="seasonality">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Seasonality Detection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={seasonalityData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" domain={[70, 160]} />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="baseline"
                    stroke="hsl(var(--muted-foreground))"
                    strokeDasharray="5 5"
                    strokeWidth={2}
                    name="Baseline (100)"
                  />
                  <Bar dataKey="seasonal" fill="hsl(var(--primary))" name="Seasonal Index" />
                </ComposedChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="p-3 rounded-lg bg-success/10 border border-success/30">
                  <p className="text-xs text-muted-foreground">Peak Season</p>
                  <p className="font-bold">Nov - Dec</p>
                  <p className="text-sm text-success">+40% uplift</p>
                </div>
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30">
                  <p className="text-xs text-muted-foreground">Low Season</p>
                  <p className="font-bold">Jan - Feb</p>
                  <p className="text-sm text-destructive">-15% vs baseline</p>
                </div>
                <div className="p-3 rounded-lg border">
                  <p className="text-xs text-muted-foreground">Current Month</p>
                  <p className="font-bold">December</p>
                  <p className="text-sm text-primary">145 index</p>
                </div>
                <div className="p-3 rounded-lg border">
                  <p className="text-xs text-muted-foreground">Next Month</p>
                  <p className="font-bold">January</p>
                  <p className="text-sm text-muted-foreground">85 index</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* What-If Simulator */}
        <TabsContent value="whatif">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                What-If Budget Simulator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label>Total Budget: ${whatIfBudget[0].toLocaleString()}</Label>
                  <Slider
                    value={whatIfBudget}
                    onValueChange={setWhatIfBudget}
                    max={100000}
                    min={10000}
                    step={5000}
                    className="mt-2"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Meta Ads ({channelSplit.meta}%)</Label>
                    <Input
                      type="number"
                      value={channelSplit.meta}
                      onChange={(e) => setChannelSplit({ ...channelSplit, meta: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Google Ads ({channelSplit.google}%)</Label>
                    <Input
                      type="number"
                      value={channelSplit.google}
                      onChange={(e) => setChannelSplit({ ...channelSplit, google: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Email ({channelSplit.email}%)</Label>
                    <Input
                      type="number"
                      value={channelSplit.email}
                      onChange={(e) => setChannelSplit({ ...channelSplit, email: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-muted/30 rounded-lg">
                <div>
                  <p className="text-sm text-muted-foreground">Predicted Revenue</p>
                  <p className="text-3xl font-bold text-success">${predictedRevenue.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Predicted ROAS</p>
                  <p className="text-3xl font-bold">{predictedRoas}x</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Est. Conversions</p>
                  <p className="text-3xl font-bold">{Math.round(predictedRevenue / 85)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cost per Conv.</p>
                  <p className="text-3xl font-bold">${Math.round(whatIfBudget[0] / (predictedRevenue / 85))}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
