import { useState } from 'react';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Facebook,
  Mail,
  ShoppingBag,
  BarChart,
  Database,
  Chrome,
  Instagram,
  Youtube,
  Share2,
  Linkedin,
  Twitter,
  TrendingUp,
  Search,
  CheckCircle2,
  Clock,
  RefreshCw,
  AlertTriangle,
  Settings,
  ExternalLink,
  Zap,
  Activity,
  Shield,
  Lock,
  Key,
  Webhook,
  Code,
  ArrowRight,
  Play,
  Pause,
  Trash2,
  Download,
  Upload,
  History,
  Eye,
  FileJson,
  Server,
  Globe,
  Cpu,
  BarChart3,
  PieChart,
  LineChart,
  Sparkles,
  BookOpen,
  HelpCircle,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface Integration {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  connected: boolean;
  category: string;
  lastSync?: Date;
  syncStatus?: 'syncing' | 'synced' | 'error' | 'pending';
  dataPoints?: number;
  health?: number;
  apiVersion?: string;
  permissions?: string[];
  rateLimitUsed?: number;
  rateLimitMax?: number;
  monthlyApiCalls?: number;
  errorRate?: number;
  avgLatency?: number;
}

interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: 'active' | 'paused' | 'error';
  lastTriggered?: Date;
  successRate: number;
  totalCalls: number;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  lastUsed?: Date;
  expiresAt?: Date;
  status: 'active' | 'expired' | 'revoked';
}

const integrations: Integration[] = [
  {
    id: '1',
    name: 'Meta Ads',
    icon: Facebook,
    color: 'text-[#1877F2]',
    connected: true,
    category: 'Ad Platforms',
    lastSync: new Date(Date.now() - 300000),
    syncStatus: 'synced',
    dataPoints: 124500,
    health: 98,
    apiVersion: 'v18.0',
    permissions: ['ads_read', 'insights_read', 'pages_manage_posts'],
    rateLimitUsed: 4200,
    rateLimitMax: 5000,
    monthlyApiCalls: 1240000,
    errorRate: 0.02,
    avgLatency: 245,
  },
  {
    id: '2',
    name: 'Google Ads',
    icon: Chrome,
    color: 'text-[#4285F4]',
    connected: true,
    category: 'Ad Platforms',
    lastSync: new Date(Date.now() - 600000),
    syncStatus: 'synced',
    dataPoints: 89200,
    health: 100,
    apiVersion: 'v15',
    permissions: ['readonly', 'campaign_management'],
    rateLimitUsed: 1800,
    rateLimitMax: 10000,
    monthlyApiCalls: 890000,
    errorRate: 0.01,
    avgLatency: 180,
  },
  { id: '3', name: 'TikTok Ads', icon: Share2, color: 'text-foreground', connected: false, category: 'Ad Platforms' },
  {
    id: '4',
    name: 'LinkedIn Ads',
    icon: Linkedin,
    color: 'text-[#0A66C2]',
    connected: false,
    category: 'Ad Platforms',
  },
  {
    id: '5',
    name: 'Twitter/X Ads',
    icon: Twitter,
    color: 'text-foreground',
    connected: false,
    category: 'Ad Platforms',
  },
  {
    id: '6',
    name: 'Shopify',
    icon: ShoppingBag,
    color: 'text-[#96bf48]',
    connected: true,
    category: 'E-commerce',
    lastSync: new Date(Date.now() - 120000),
    syncStatus: 'syncing',
    dataPoints: 45600,
    health: 95,
    apiVersion: '2024-01',
    permissions: ['read_orders', 'read_products', 'read_customers'],
    rateLimitUsed: 380,
    rateLimitMax: 1000,
    monthlyApiCalls: 456000,
    errorRate: 0.05,
    avgLatency: 320,
  },
  {
    id: '7',
    name: 'WooCommerce',
    icon: ShoppingBag,
    color: 'text-[#96588A]',
    connected: false,
    category: 'E-commerce',
  },
  {
    id: '8',
    name: 'Klaviyo',
    icon: Mail,
    color: 'text-[#FF6B35]',
    connected: true,
    category: 'Marketing Automation',
    lastSync: new Date(Date.now() - 1800000),
    syncStatus: 'synced',
    dataPoints: 23400,
    health: 92,
    apiVersion: '2023-12-15',
    permissions: ['lists:read', 'profiles:read', 'campaigns:read'],
    rateLimitUsed: 450,
    rateLimitMax: 1200,
    monthlyApiCalls: 234000,
    errorRate: 0.08,
    avgLatency: 410,
  },
  {
    id: '9',
    name: 'HubSpot',
    icon: Database,
    color: 'text-[#FF7A59]',
    connected: false,
    category: 'Marketing Automation',
  },
  { id: '10', name: 'Salesforce', icon: Database, color: 'text-[#00A1E0]', connected: false, category: 'CRM' },
  {
    id: '11',
    name: 'Google Analytics',
    icon: BarChart,
    color: 'text-[#F9AB00]',
    connected: true,
    category: 'Analytics',
    lastSync: new Date(Date.now() - 900000),
    syncStatus: 'error',
    dataPoints: 567800,
    health: 78,
    apiVersion: 'GA4',
    permissions: ['analytics.readonly'],
    rateLimitUsed: 8500,
    rateLimitMax: 10000,
    monthlyApiCalls: 5678000,
    errorRate: 2.4,
    avgLatency: 890,
  },
  { id: '12', name: 'Mixpanel', icon: TrendingUp, color: 'text-[#7856FF]', connected: false, category: 'Analytics' },
  {
    id: '13',
    name: 'Instagram Creator',
    icon: Instagram,
    color: 'text-pink-500',
    connected: false,
    category: 'Influencer Platforms',
  },
  {
    id: '14',
    name: 'YouTube Partner',
    icon: Youtube,
    color: 'text-red-500',
    connected: false,
    category: 'Influencer Platforms',
  },
  {
    id: '15',
    name: 'TikTok Creator',
    icon: Share2,
    color: 'text-foreground',
    connected: false,
    category: 'Influencer Platforms',
  },
];

const webhooksData: Webhook[] = [
  {
    id: '1',
    name: 'Order Created',
    url: 'https://api.yourapp.com/webhooks/orders',
    events: ['order.created', 'order.updated'],
    status: 'active',
    lastTriggered: new Date(Date.now() - 60000),
    successRate: 99.2,
    totalCalls: 12400,
  },
  {
    id: '2',
    name: 'Campaign Alert',
    url: 'https://api.yourapp.com/webhooks/campaigns',
    events: ['campaign.paused', 'campaign.low_roas'],
    status: 'active',
    lastTriggered: new Date(Date.now() - 3600000),
    successRate: 100,
    totalCalls: 856,
  },
  {
    id: '3',
    name: 'Inventory Sync',
    url: 'https://api.yourapp.com/webhooks/inventory',
    events: ['inventory.low', 'inventory.updated'],
    status: 'error',
    lastTriggered: new Date(Date.now() - 86400000),
    successRate: 78.5,
    totalCalls: 3200,
  },
];

const apiKeysData: ApiKey[] = [
  {
    id: '1',
    name: 'Production API',
    key: 'pk_live_****************************abc',
    permissions: ['read', 'write'],
    lastUsed: new Date(Date.now() - 300000),
    status: 'active',
  },
  {
    id: '2',
    name: 'Staging API',
    key: 'pk_test_****************************xyz',
    permissions: ['read', 'write'],
    lastUsed: new Date(Date.now() - 86400000),
    status: 'active',
  },
  {
    id: '3',
    name: 'Legacy Integration',
    key: 'pk_old_****************************old',
    permissions: ['read'],
    expiresAt: new Date(Date.now() - 604800000),
    status: 'expired',
  },
];

const syncLogs = [
  { time: '2 min ago', integration: 'Meta Ads', action: 'Full sync completed', records: 1240, status: 'success' },
  { time: '5 min ago', integration: 'Shopify', action: 'Incremental sync', records: 45, status: 'success' },
  {
    time: '15 min ago',
    integration: 'Google Analytics',
    action: 'Sync failed - rate limit',
    records: 0,
    status: 'error',
  },
  { time: '30 min ago', integration: 'Klaviyo', action: 'Profile sync completed', records: 892, status: 'success' },
  { time: '1 hour ago', integration: 'Google Ads', action: 'Campaign data synced', records: 234, status: 'success' },
];

export default function Integrations() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('connections');
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [configDialogOpen, setConfigDialogOpen] = useState(false);

  const categories = Array.from(new Set(integrations.map((i) => i.category)));
  const connectedIntegrations = integrations.filter((i) => i.connected);

  const filteredIntegrations = integrations.filter((i) => i.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  const handleConnect = (name: string) => {
    toast({ title: 'Connecting...', description: `Initiating OAuth flow for ${name}` });
  };

  const handleSync = (name: string) => {
    toast({ title: 'Sync Started', description: `Syncing data from ${name}` });
  };

  const handleOpenConfig = (integration: Integration) => {
    setSelectedIntegration(integration);
    setConfigDialogOpen(true);
  };

  const getSyncIcon = (status?: string) => {
    switch (status) {
      case 'syncing':
        return <RefreshCw className="h-3 w-3 animate-spin text-primary" />;
      case 'synced':
        return <CheckCircle2 className="h-3 w-3 text-success" />;
      case 'error':
        return <AlertTriangle className="h-3 w-3 text-destructive" />;
      default:
        return <Clock className="h-3 w-3 text-muted-foreground" />;
    }
  };

  const totalApiCalls = connectedIntegrations.reduce((sum, i) => sum + (i.monthlyApiCalls || 0), 0);
  const avgHealth = connectedIntegrations.reduce((sum, i) => sum + (i.health || 0), 0) / connectedIntegrations.length;

  return (
    <div className="space-y-6 p-8">
      <SEOHead
        title="Integrations"
        description="Connect your marketing data sources and platforms for unified analytics and automation."
        keywords="marketing integrations, API connections, data sources, marketing platforms, analytics integration"
      />

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Integrations Hub
          </h1>
          <p className="text-muted-foreground text-lg">Unified data infrastructure & API management</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="text-sm py-1 px-3">
            <Zap className="h-4 w-4 mr-1 text-primary" />
            {connectedIntegrations.length} Connected
          </Badge>
          <Button variant="outline" className="gap-2">
            <BookOpen className="h-4 w-4" />
            API Docs
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Connected</p>
                <p className="text-2xl font-bold">{connectedIntegrations.length}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Records</p>
                <p className="text-2xl font-bold">
                  {(connectedIntegrations.reduce((sum, i) => sum + (i.dataPoints || 0), 0) / 1000).toFixed(0)}K
                </p>
              </div>
              <div className="h-10 w-10 rounded-full bg-chart-1/10 flex items-center justify-center">
                <Database className="h-5 w-5 text-chart-1" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">API Calls/mo</p>
                <p className="text-2xl font-bold">{(totalApiCalls / 1000000).toFixed(1)}M</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-chart-2/10 flex items-center justify-center">
                <Server className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Health</p>
                <p className="text-2xl font-bold">{avgHealth.toFixed(0)}%</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-chart-3/10 flex items-center justify-center">
                <Activity className="h-5 w-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Webhooks</p>
                <p className="text-2xl font-bold">{webhooksData.filter((w) => w.status === 'active').length}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-chart-4/10 flex items-center justify-center">
                <Webhook className="h-5 w-5 text-chart-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="connections" className="gap-2">
            <Globe className="h-4 w-4" />
            Connections
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="gap-2">
            <Webhook className="h-4 w-4" />
            Webhooks
          </TabsTrigger>
          <TabsTrigger value="api-keys" className="gap-2">
            <Key className="h-4 w-4" />
            API Keys
          </TabsTrigger>
          <TabsTrigger value="sync-logs" className="gap-2">
            <History className="h-4 w-4" />
            Sync Logs
          </TabsTrigger>
          <TabsTrigger value="data-mapping" className="gap-2">
            <FileJson className="h-4 w-4" />
            Data Mapping
          </TabsTrigger>
        </TabsList>

        {/* Connections Tab */}
        <TabsContent value="connections" className="space-y-6">
          {/* Connected Overview */}
          {connectedIntegrations.length > 0 && (
            <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Active Connections
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  {connectedIntegrations.map((integration) => (
                    <div
                      key={integration.id}
                      className="p-4 rounded-lg bg-card border border-border/50 hover:border-primary/30 transition-all cursor-pointer"
                      onClick={() => handleOpenConfig(integration)}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <integration.icon className={cn('h-5 w-5', integration.color)} />
                          <span className="font-medium text-sm">{integration.name}</span>
                        </div>
                        {getSyncIcon(integration.syncStatus)}
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Health</span>
                          <span
                            className={cn(
                              'font-medium',
                              integration.health && integration.health >= 90
                                ? 'text-success'
                                : integration.health && integration.health >= 70
                                  ? 'text-yellow-500'
                                  : 'text-destructive',
                            )}
                          >
                            {integration.health}%
                          </span>
                        </div>
                        <Progress value={integration.health} className="h-1.5" />
                        <div className="grid grid-cols-2 gap-2 text-[10px] text-muted-foreground pt-1">
                          <span>{integration.dataPoints?.toLocaleString()} records</span>
                          <span className="text-right">{integration.avgLatency}ms avg</span>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-muted-foreground">Rate Limit</span>
                          <span
                            className={cn(
                              'font-medium',
                              (integration.rateLimitUsed || 0) / (integration.rateLimitMax || 1) > 0.8
                                ? 'text-warning'
                                : 'text-muted-foreground',
                            )}
                          >
                            {integration.rateLimitUsed?.toLocaleString()}/{integration.rateLimitMax?.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Search */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search integrations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Integrations by Category */}
          {categories.map((category) => {
            const categoryIntegrations = filteredIntegrations.filter((i) => i.category === category);
            if (categoryIntegrations.length === 0) return null;

            return (
              <div key={category} className="space-y-4">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-semibold">{category}</h2>
                  <Badge variant="secondary">{categoryIntegrations.length}</Badge>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {categoryIntegrations.map((integration) => (
                    <Card
                      key={integration.id}
                      className={cn(
                        'transition-all hover:shadow-lg',
                        integration.connected && 'border-primary/30 bg-primary/5',
                      )}
                    >
                      <CardHeader className="pb-2">
                        <CardTitle className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={cn('rounded-lg p-3', integration.connected ? 'bg-primary/10' : 'bg-muted')}>
                              <integration.icon className={cn('h-6 w-6', integration.color)} />
                            </div>
                            <div>
                              <span className="text-base">{integration.name}</span>
                              {integration.connected && (
                                <div className="flex items-center gap-1 mt-0.5">
                                  {getSyncIcon(integration.syncStatus)}
                                  <span className="text-[10px] text-muted-foreground">
                                    {integration.syncStatus === 'syncing'
                                      ? 'Syncing...'
                                      : integration.syncStatus === 'error'
                                        ? 'Sync error'
                                        : `Last sync ${integration.lastSync && formatTimeAgo(integration.lastSync)}`}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                          {integration.connected && (
                            <Badge className="bg-success text-success-foreground">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Connected
                            </Badge>
                          )}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pb-3">
                        {integration.connected ? (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">API Version</span>
                              <Badge variant="outline" className="text-[10px]">
                                {integration.apiVersion}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">Error Rate</span>
                              <span
                                className={cn(
                                  'font-medium',
                                  (integration.errorRate || 0) < 1
                                    ? 'text-success'
                                    : (integration.errorRate || 0) < 5
                                      ? 'text-warning'
                                      : 'text-destructive',
                                )}
                              >
                                {integration.errorRate}%
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {integration.dataPoints?.toLocaleString()} records synced
                            </p>
                          </div>
                        ) : (
                          <p className="text-sm text-muted-foreground">
                            Connect your {integration.name} account to start syncing data
                          </p>
                        )}
                      </CardContent>
                      <CardFooter className="gap-2">
                        {integration.connected ? (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1"
                              onClick={() => handleSync(integration.name)}
                            >
                              <RefreshCw className="h-4 w-4 mr-1" /> Sync
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-9 w-9"
                              onClick={() => handleOpenConfig(integration)}
                            >
                              <Settings className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-9 w-9">
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <Button className="w-full" onClick={() => handleConnect(integration.name)}>
                            Connect
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </TabsContent>

        {/* Webhooks Tab */}
        <TabsContent value="webhooks" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Outgoing Webhooks</h2>
              <p className="text-sm text-muted-foreground">Receive real-time notifications when events occur</p>
            </div>
            <Button className="gap-2">
              <Webhook className="h-4 w-4" />
              Create Webhook
            </Button>
          </div>

          <div className="grid gap-4">
            {webhooksData.map((webhook) => (
              <Card key={webhook.id} className={cn(webhook.status === 'error' && 'border-destructive/30')}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div
                        className={cn(
                          'h-10 w-10 rounded-lg flex items-center justify-center',
                          webhook.status === 'active'
                            ? 'bg-success/10'
                            : webhook.status === 'error'
                              ? 'bg-destructive/10'
                              : 'bg-muted',
                        )}
                      >
                        <Webhook
                          className={cn(
                            'h-5 w-5',
                            webhook.status === 'active'
                              ? 'text-success'
                              : webhook.status === 'error'
                                ? 'text-destructive'
                                : 'text-muted-foreground',
                          )}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{webhook.name}</span>
                          <Badge
                            variant={
                              webhook.status === 'active'
                                ? 'default'
                                : webhook.status === 'error'
                                  ? 'destructive'
                                  : 'secondary'
                            }
                          >
                            {webhook.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground font-mono">{webhook.url}</p>
                        <div className="flex items-center gap-2 flex-wrap">
                          {webhook.events.map((event) => (
                            <Badge key={event} variant="outline" className="text-[10px]">
                              {event}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center gap-4 text-sm">
                        <div className="text-right">
                          <p className="font-medium">{webhook.successRate}%</p>
                          <p className="text-[10px] text-muted-foreground">Success Rate</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{webhook.totalCalls.toLocaleString()}</p>
                          <p className="text-[10px] text-muted-foreground">Total Calls</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          {webhook.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* API Keys Tab */}
        <TabsContent value="api-keys" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">API Keys</h2>
              <p className="text-sm text-muted-foreground">Manage access tokens for external integrations</p>
            </div>
            <Button className="gap-2">
              <Key className="h-4 w-4" />
              Generate New Key
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {apiKeysData.map((apiKey) => (
                  <div key={apiKey.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'h-10 w-10 rounded-lg flex items-center justify-center',
                          apiKey.status === 'active'
                            ? 'bg-success/10'
                            : apiKey.status === 'expired'
                              ? 'bg-warning/10'
                              : 'bg-destructive/10',
                        )}
                      >
                        <Key
                          className={cn(
                            'h-5 w-5',
                            apiKey.status === 'active'
                              ? 'text-success'
                              : apiKey.status === 'expired'
                                ? 'text-warning'
                                : 'text-destructive',
                          )}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{apiKey.name}</span>
                          <Badge
                            variant={
                              apiKey.status === 'active'
                                ? 'default'
                                : apiKey.status === 'expired'
                                  ? 'secondary'
                                  : 'destructive'
                            }
                          >
                            {apiKey.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground font-mono">{apiKey.key}</p>
                        <div className="flex items-center gap-2 mt-1">
                          {apiKey.permissions.map((perm) => (
                            <Badge key={perm} variant="outline" className="text-[10px]">
                              {perm}
                            </Badge>
                          ))}
                          {apiKey.lastUsed && (
                            <span className="text-[10px] text-muted-foreground">
                              Last used {formatTimeAgo(apiKey.lastUsed)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>View Full Key</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sync Logs Tab */}
        <TabsContent value="sync-logs" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Sync Logs</h2>
              <p className="text-sm text-muted-foreground">Recent data synchronization activity</p>
            </div>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export Logs
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {syncLogs.map((log, index) => (
                  <div key={index} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'h-8 w-8 rounded-full flex items-center justify-center',
                          log.status === 'success' ? 'bg-success/10' : 'bg-destructive/10',
                        )}
                      >
                        {log.status === 'success' ? (
                          <CheckCircle2 className="h-4 w-4 text-success" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{log.integration}</span>
                          <span className="text-sm text-muted-foreground">·</span>
                          <span className="text-sm text-muted-foreground">{log.action}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {log.records > 0 ? `${log.records.toLocaleString()} records` : 'No records'}
                        </p>
                      </div>
                    </div>
                    <span className="text-sm text-muted-foreground">{log.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Mapping Tab */}
        <TabsContent value="data-mapping" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Data Mapping & Transformations</h2>
              <p className="text-sm text-muted-foreground">Configure how data flows between systems</p>
            </div>
            <Button className="gap-2">
              <Code className="h-4 w-4" />
              Create Mapping
            </Button>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FileJson className="h-4 w-4" />
                  Field Mappings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">Shopify</Badge>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <Badge variant="outline">Internal</Badge>
                    </div>
                    <span className="text-sm font-medium">12 fields mapped</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">Meta Ads</Badge>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <Badge variant="outline">Internal</Badge>
                    </div>
                    <span className="text-sm font-medium">24 fields mapped</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">Klaviyo</Badge>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <Badge variant="outline">Internal</Badge>
                    </div>
                    <span className="text-sm font-medium">8 fields mapped</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  Data Transformations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">Currency Conversion</span>
                      <Switch defaultChecked />
                    </div>
                    <p className="text-xs text-muted-foreground">Automatically convert all amounts to USD</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">Timezone Normalization</span>
                      <Switch defaultChecked />
                    </div>
                    <p className="text-xs text-muted-foreground">Convert all timestamps to UTC</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">Deduplication</span>
                      <Switch />
                    </div>
                    <p className="text-xs text-muted-foreground">Remove duplicate records on sync</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Integration Config Dialog */}
      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent className="max-w-2xl">
          {selectedIntegration && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <selectedIntegration.icon className={cn('h-6 w-6', selectedIntegration.color)} />
                  {selectedIntegration.name} Configuration
                </DialogTitle>
                <DialogDescription>Manage connection settings, permissions, and sync preferences</DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Connection Health */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold text-success">{selectedIntegration.health}%</p>
                    <p className="text-xs text-muted-foreground">Health Score</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold">{selectedIntegration.avgLatency}ms</p>
                    <p className="text-xs text-muted-foreground">Avg Latency</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold">{selectedIntegration.errorRate}%</p>
                    <p className="text-xs text-muted-foreground">Error Rate</p>
                  </div>
                </div>

                {/* Permissions */}
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    Permissions
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedIntegration.permissions?.map((perm) => (
                      <Badge key={perm} variant="outline">
                        {perm}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Rate Limits */}
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Rate Limit Usage
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Hourly Limit</span>
                      <span>
                        {selectedIntegration.rateLimitUsed?.toLocaleString()} /{' '}
                        {selectedIntegration.rateLimitMax?.toLocaleString()}
                      </span>
                    </div>
                    <Progress
                      value={((selectedIntegration.rateLimitUsed || 0) / (selectedIntegration.rateLimitMax || 1)) * 100}
                    />
                  </div>
                </div>

                {/* Sync Settings */}
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Sync Settings
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-sm">Auto-sync enabled</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-sm">Sync interval</span>
                      <Badge variant="outline">Every 5 minutes</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-sm">Full sync on error</span>
                      <Switch />
                    </div>
                  </div>
                </div>
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setConfigDialogOpen(false)}>
                  Close
                </Button>
                <Button variant="destructive" className="gap-2">
                  <Trash2 className="h-4 w-4" />
                  Disconnect
                </Button>
                <Button className="gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Force Sync
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
