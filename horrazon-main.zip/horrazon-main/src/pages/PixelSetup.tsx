import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Code, FileCode, Box } from 'lucide-react';

export default function PixelSetup() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Install Tracking Pixel</CardTitle>
          <CardDescription>Choose how you'd like to install the QuickInsights tracking pixel</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="cursor-pointer transition-all hover:border-primary">
              <CardContent className="flex flex-col items-center gap-4 p-6">
                <Box className="h-12 w-12 text-primary" />
                <div className="text-center">
                  <h3 className="font-semibold">GTM</h3>
                  <p className="text-sm text-muted-foreground">Google Tag Manager</p>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all hover:border-primary">
              <CardContent className="flex flex-col items-center gap-4 p-6">
                <FileCode className="h-12 w-12 text-primary" />
                <div className="text-center">
                  <h3 className="font-semibold">CMS</h3>
                  <p className="text-sm text-muted-foreground">Content Management System</p>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all hover:border-primary">
              <CardContent className="flex flex-col items-center gap-4 p-6">
                <Code className="h-12 w-12 text-primary" />
                <div className="text-center">
                  <h3 className="font-semibold">HTML Code</h3>
                  <p className="text-sm text-muted-foreground">Manual Installation</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => navigate('/integrations')}>
              Skip for now
            </Button>
            <Button className="flex-1" onClick={() => navigate('/integrations')}>
              Continue
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
