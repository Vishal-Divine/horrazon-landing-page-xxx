import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

export default function CreateRule() {
  const navigate = useNavigate();
  const [rule, setRule] = useState({
    platform: '',
    metric: '',
    condition: '',
    value: '',
    duration: '',
    durationUnit: 'days',
    action: '',
  });

  const getRuleSummary = () => {
    if (!rule.platform || !rule.metric || !rule.condition || !rule.value || !rule.duration || !rule.action) {
      return 'Complete all fields to see rule summary';
    }
    return `IF ${rule.platform} ${rule.metric} ${rule.condition} ${rule.value} for ${rule.duration} ${rule.durationUnit} THEN ${rule.action}`;
  };

  return (
    <div className="space-y-6 p-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Create New Rule</h1>
        <p className="text-muted-foreground">Set up automation rules for your campaigns</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Rule Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>1. Choose Platform</Label>
              <Select value={rule.platform} onValueChange={(v) => setRule({ ...rule, platform: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Meta">Meta</SelectItem>
                  <SelectItem value="Google">Google</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>2. Choose Metric</Label>
              <Select value={rule.metric} onValueChange={(v) => setRule({ ...rule, metric: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select metric" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="CPC">CPC</SelectItem>
                  <SelectItem value="ROAS">ROAS</SelectItem>
                  <SelectItem value="CTR">CTR</SelectItem>
                  <SelectItem value="Conversions">Conversions</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>3. Operating Condition</Label>
              <Select value={rule.condition} onValueChange={(v) => setRule({ ...rule, condition: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value=">=">{'>='}</SelectItem>
                  <SelectItem value="<=">{'<='}</SelectItem>
                  <SelectItem value="=">{'='}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>4. Value</Label>
              <Input
                type="number"
                placeholder="Enter value"
                value={rule.value}
                onChange={(e) => setRule({ ...rule, value: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>5. Duration</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Duration"
                  value={rule.duration}
                  onChange={(e) => setRule({ ...rule, duration: e.target.value })}
                  className="flex-1"
                />
                <Select value={rule.durationUnit} onValueChange={(v) => setRule({ ...rule, durationUnit: v })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hours">Hours</SelectItem>
                    <SelectItem value="days">Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>6. Choose Action</Label>
              <Select value={rule.action} onValueChange={(v) => setRule({ ...rule, action: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pause Ad">Pause Ad</SelectItem>
                  <SelectItem value="Alert">Alert</SelectItem>
                  <SelectItem value="Reallocate budget">Reallocate budget</SelectItem>
                  <SelectItem value="Increase budget">Increase budget</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Rule Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg bg-muted p-6">
              <p className="text-lg font-mono">{getRuleSummary()}</p>
            </div>
            <div className="mt-6 flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => navigate('/rules')}>
                Cancel
              </Button>
              <Button className="flex-1" onClick={() => navigate('/rules')}>
                Save Rule
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
