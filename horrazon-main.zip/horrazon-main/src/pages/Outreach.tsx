import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Mail,
  MessageSquare,
  Smartphone,
  TrendingUp,
  Users,
  Clock,
  Target,
  Zap,
  BarChart3,
  Send,
  MousePointer,
  DollarSign,
  AlertTriangle,
  Calendar,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Eye,
  RefreshCw,
  Filter,
  Download,
  Bell,
  Settings,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';

// Import new analytics components
import {
  InteractiveFilters,
  PredictiveSendTimeHeatmap,
  AnomalyDetectionPanel,
  CohortRetentionChart,
  DrilldownModal,
  cohortData,
  anomalies,
  sendTimeData,
} from '@/components/analytics';
import type { FilterGroup } from '@/components/analytics/InteractiveFilters';

const outreachData = [
  {
    channel: 'Email',
    icon: Mail,
    focusArea: 'Abandoned Cart Flow',
    status: 'weak',
    insight: 'Conversion rate dropped 12%',
    action: 'A/B test CTA copy',
    sent: 24500,
    delivered: 23800,
    opened: 8420,
    clicked: 1840,
    converted: 284,
    revenue: 18420,
    openRate: 35.4,
    clickRate: 7.7,
    conversionRate: 1.19,
  },
  {
    channel: 'WhatsApp',
    icon: MessageSquare,
    focusArea: 'Post-Purchase Follow-up',
    status: 'strong',
    insight: 'Response rate at 68%',
    action: 'Scale volume by 20%',
    sent: 8400,
    delivered: 8320,
    opened: 7480,
    clicked: 2420,
    converted: 186,
    revenue: 12800,
    openRate: 89.9,
    clickRate: 29.1,
    conversionRate: 2.24,
  },
  {
    channel: 'SMS',
    icon: Smartphone,
    focusArea: 'Flash Sale Notifications',
    status: 'strong',
    insight: 'Click-through at 34%',
    action: 'Increase send frequency',
    sent: 12800,
    delivered: 12640,
    opened: 11200,
    clicked: 4280,
    converted: 342,
    revenue: 24600,
    openRate: 88.6,
    clickRate: 33.9,
    conversionRate: 2.71,
  },
  {
    channel: 'Email',
    icon: Mail,
    focusArea: 'Welcome Series',
    status: 'weak',
    insight: 'Open rate below 18%',
    action: 'Optimize subject lines',
    sent: 18200,
    delivered: 17800,
    opened: 3204,
    clicked: 642,
    converted: 98,
    revenue: 6420,
    openRate: 18.0,
    clickRate: 3.6,
    conversionRate: 0.55,
  },
  {
    channel: 'Push',
    icon: Bell,
    focusArea: 'Price Drop Alerts',
    status: 'strong',
    insight: 'CTR 24% above benchmark',
    action: 'Expand product coverage',
    sent: 42800,
    delivered: 38200,
    opened: 18400,
    clicked: 8420,
    converted: 624,
    revenue: 42800,
    openRate: 48.2,
    clickRate: 22.0,
    conversionRate: 1.63,
  },
];

const emailPerformanceTrend = [
  { date: 'Week 1', openRate: 32.4, clickRate: 6.8, conversionRate: 1.2, unsubscribeRate: 0.12 },
  { date: 'Week 2', openRate: 34.2, clickRate: 7.2, conversionRate: 1.3, unsubscribeRate: 0.1 },
  { date: 'Week 3', openRate: 33.8, clickRate: 6.9, conversionRate: 1.1, unsubscribeRate: 0.14 },
  { date: 'Week 4', openRate: 35.4, clickRate: 7.7, conversionRate: 1.19, unsubscribeRate: 0.08 },
];

const campaignPerformance = [
  {
    name: 'Summer Sale Blast',
    channel: 'Email',
    sent: 84200,
    openRate: 42.8,
    clickRate: 12.4,
    revenue: 124800,
    roas: 8.4,
    status: 'completed',
  },
  {
    name: 'Cart Recovery',
    channel: 'Email',
    sent: 12400,
    openRate: 38.2,
    clickRate: 18.6,
    revenue: 42600,
    roas: 12.8,
    status: 'active',
  },
  {
    name: 'VIP Early Access',
    channel: 'SMS',
    sent: 4200,
    openRate: 94.2,
    clickRate: 48.2,
    revenue: 86400,
    roas: 24.2,
    status: 'active',
  },
  {
    name: 'Welcome Flow',
    channel: 'Email',
    sent: 28400,
    openRate: 52.4,
    clickRate: 8.2,
    revenue: 18200,
    roas: 4.2,
    status: 'active',
  },
  {
    name: 'Loyalty Rewards',
    channel: 'WhatsApp',
    sent: 6800,
    openRate: 88.4,
    clickRate: 32.4,
    revenue: 24800,
    roas: 9.8,
    status: 'completed',
  },
];

const segmentPerformance = [
  {
    segment: 'High-Value Customers',
    openRate: 48.2,
    clickRate: 18.4,
    conversionRate: 4.2,
    avgOrderValue: 284,
    color: 'hsl(var(--chart-1))',
  },
  {
    segment: 'At-Risk Churners',
    openRate: 24.8,
    clickRate: 8.2,
    conversionRate: 1.8,
    avgOrderValue: 124,
    color: 'hsl(var(--chart-2))',
  },
  {
    segment: 'New Subscribers',
    openRate: 62.4,
    clickRate: 12.8,
    conversionRate: 2.4,
    avgOrderValue: 86,
    color: 'hsl(var(--chart-3))',
  },
  {
    segment: 'Dormant Users',
    openRate: 12.4,
    clickRate: 4.2,
    conversionRate: 0.8,
    avgOrderValue: 142,
    color: 'hsl(var(--chart-4))',
  },
  {
    segment: 'Frequent Buyers',
    openRate: 44.8,
    clickRate: 22.4,
    conversionRate: 5.8,
    avgOrderValue: 198,
    color: 'hsl(var(--chart-5))',
  },
];

const deliverabilityMetrics = {
  inboxRate: 94.2,
  spamRate: 2.8,
  bounceRate: 3.0,
  senderScore: 92,
  domainReputation: 'Excellent',
  spfPass: 99.8,
  dkimPass: 99.6,
  dmarcPass: 98.4,
};

const abTestResults = [
  {
    testName: 'Subject Line: Emoji vs No Emoji',
    variantA: 32.4,
    variantB: 38.8,
    winner: 'B',
    lift: '+19.8%',
    confidence: 98,
  },
  { testName: 'CTA: Shop Now vs Get Yours', variantA: 8.2, variantB: 9.8, winner: 'B', lift: '+19.5%', confidence: 94 },
  { testName: 'Send Time: 9 AM vs 6 PM', variantA: 42.4, variantB: 38.2, winner: 'A', lift: '+11.0%', confidence: 96 },
  {
    testName: 'Personalization: Name vs Generic',
    variantA: 44.2,
    variantB: 36.8,
    winner: 'A',
    lift: '+20.1%',
    confidence: 99,
  },
];

const journeyStages = [
  { stage: 'Subscribed', users: 124800, dropoff: 0 },
  { stage: 'Welcome Sent', users: 118200, dropoff: 5.3 },
  { stage: 'First Open', users: 72400, dropoff: 38.8 },
  { stage: 'First Click', users: 28400, dropoff: 60.8 },
  { stage: 'First Purchase', users: 12800, dropoff: 54.9 },
  { stage: 'Repeat Purchase', users: 4200, dropoff: 67.2 },
];

const channelMixRevenue = [
  { name: 'Email', value: 248000, percentage: 48 },
  { name: 'SMS', value: 124000, percentage: 24 },
  { name: 'Push', value: 86000, percentage: 17 },
  { name: 'WhatsApp', value: 58000, percentage: 11 },
];

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

// Initial filter groups
const initialFilterGroups: FilterGroup[] = [
  {
    id: 'channel',
    label: 'Channel',
    options: [
      { id: 'email', label: 'Email', checked: true },
      { id: 'sms', label: 'SMS', checked: true },
      { id: 'push', label: 'Push', checked: true },
      { id: 'whatsapp', label: 'WhatsApp', checked: true },
    ],
  },
  {
    id: 'status',
    label: 'Status',
    options: [
      { id: 'active', label: 'Active', checked: true },
      { id: 'completed', label: 'Completed', checked: true },
      { id: 'paused', label: 'Paused', checked: false },
      { id: 'draft', label: 'Draft', checked: false },
    ],
  },
  {
    id: 'segment',
    label: 'Segment',
    options: [
      { id: 'high-value', label: 'High-Value Customers', checked: false },
      { id: 'at-risk', label: 'At-Risk Churners', checked: false },
      { id: 'new', label: 'New Subscribers', checked: false },
      { id: 'dormant', label: 'Dormant Users', checked: false },
    ],
  },
];

export default function Outreach() {
  const [filterGroups, setFilterGroups] = useState<FilterGroup[]>(initialFilterGroups);
  const [selectedPreset, setSelectedPreset] = useState('30d');
  const [drilldownOpen, setDrilldownOpen] = useState(false);
  const [drilldownData, setDrilldownData] = useState<any>(null);

  const handleFilterChange = (groupId: string, optionId: string, checked: boolean) => {
    setFilterGroups((groups) =>
      groups.map((group) =>
        group.id === groupId
          ? {
              ...group,
              options: group.options.map((opt) => (opt.id === optionId ? { ...opt, checked } : opt)),
            }
          : group,
      ),
    );
  };

  const handleClearFilters = () => {
    setFilterGroups(initialFilterGroups);
  };

  const handleCampaignDrilldown = (campaign: (typeof campaignPerformance)[0]) => {
    setDrilldownData({
      title: campaign.name,
      subtitle: `${campaign.channel} Campaign • ${campaign.status}`,
      type: 'campaign',
      metrics: [
        { label: 'Sent', value: campaign.sent.toLocaleString(), change: 12, trend: 'up' as const },
        { label: 'Open Rate', value: `${campaign.openRate}%`, change: 5.2, trend: 'up' as const },
        { label: 'Click Rate', value: `${campaign.clickRate}%`, change: -2.1, trend: 'down' as const },
        { label: 'Revenue', value: `$${(campaign.revenue / 1000).toFixed(1)}K`, change: 18.4, trend: 'up' as const },
      ],
      chartData: emailPerformanceTrend.map((d) => ({
        date: d.date,
        value: d.openRate * 100,
        previous: d.openRate * 90,
      })),
      breakdownData: [
        { label: 'Desktop', value: Math.floor(campaign.sent * 0.45), percentage: 45 },
        { label: 'Mobile', value: Math.floor(campaign.sent * 0.48), percentage: 48 },
        { label: 'Tablet', value: Math.floor(campaign.sent * 0.07), percentage: 7 },
      ],
    });
    setDrilldownOpen(true);
  };

  const handleAnomalyInvestigate = (anomaly: any) => {
    setDrilldownData({
      title: `Anomaly: ${anomaly.metric}`,
      subtitle: `Detected ${new Date(anomaly.timestamp).toLocaleString()}`,
      type: 'metric',
      metrics: [
        { label: 'Actual Value', value: anomaly.value.toLocaleString() },
        { label: 'Expected Value', value: anomaly.expectedValue.toLocaleString() },
        { label: 'Deviation', value: `${anomaly.deviation.toFixed(2)}σ` },
        { label: 'Severity', value: anomaly.severity },
      ],
      chartData: Array.from({ length: 14 }, (_, i) => ({
        date: `Day ${i + 1}`,
        value: anomaly.expectedValue + (Math.random() - 0.5) * anomaly.expectedValue * 0.2,
        previous: anomaly.expectedValue,
      })),
    });
    setDrilldownOpen(true);
  };

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Outreach Intelligence</h1>
          <p className="text-muted-foreground">Advanced email, SMS & messaging analytics with AI optimization</p>
        </div>
        <Button className="gap-2">
          <Send className="h-4 w-4" />
          Create Campaign
        </Button>
      </div>

      {/* Interactive Filters */}
      <InteractiveFilters
        filterGroups={filterGroups}
        selectedPreset={selectedPreset}
        onFilterChange={handleFilterChange}
        onPresetChange={setSelectedPreset}
        onClearFilters={handleClearFilters}
        onExport={() => toast({ title: 'Export Started', description: 'Your data export is being prepared.' })}
        onRefresh={() => toast({ title: 'Data Refreshed', description: 'All metrics have been updated.' })}
      />

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setDrilldownData({
              title: 'Total Sent Analysis',
              subtitle: 'Across all channels',
              type: 'metric',
              metrics: [
                { label: 'Total Sent', value: '516K', change: 12.4, trend: 'up' as const },
                { label: 'Delivery Rate', value: '97.2%', change: 0.8, trend: 'up' as const },
                { label: 'Unique Recipients', value: '384K', change: 8.2, trend: 'up' as const },
                { label: 'Avg per Day', value: '17.2K' },
              ],
              breakdownData: channelMixRevenue.map((c) => ({
                label: c.name,
                value: Math.floor((516000 * c.percentage) / 100),
                percentage: c.percentage,
              })),
            });
            setDrilldownOpen(true);
          }}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Sent</p>
                <p className="text-2xl font-bold">516K</p>
              </div>
              <Send className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+12.4% vs last period</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Open Rate</p>
                <p className="text-2xl font-bold">42.8%</p>
              </div>
              <Eye className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-success">+3.2% vs benchmark</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Click Rate</p>
                <p className="text-2xl font-bold">12.4%</p>
              </div>
              <MousePointer className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-success">+1.8% vs last period</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <p className="text-2xl font-bold">2.4%</p>
              </div>
              <Target className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-warning">-0.2% vs last period</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">$516K</p>
              </div>
              <DollarSign className="h-8 w-8 text-chart-5" />
            </div>
            <p className="mt-2 text-xs text-success">+24.8% vs last period</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Inbox Rate</p>
                <p className="text-2xl font-bold">{deliverabilityMetrics.inboxRate}%</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Industry avg: 89%</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="flex-wrap">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="sendtime">Send Time AI</TabsTrigger>
          <TabsTrigger value="cohorts">Cohort Analysis</TabsTrigger>
          <TabsTrigger value="anomalies">Anomalies</TabsTrigger>
          <TabsTrigger value="segments">Segments</TabsTrigger>
          <TabsTrigger value="deliverability">Deliverability</TabsTrigger>
          <TabsTrigger value="abtests">A/B Testing</TabsTrigger>
          <TabsTrigger value="journey">Journey</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Channel Cards */}
          <Card>
            <CardHeader>
              <CardTitle>Channel Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {outreachData.map((item, i) => (
                  <div
                    key={i}
                    className="flex flex-col gap-4 rounded-lg border border-border bg-muted/30 p-4 transition-all hover:border-primary/50 cursor-pointer"
                    onClick={() => {
                      setDrilldownData({
                        title: `${item.channel} - ${item.focusArea}`,
                        subtitle: item.status === 'strong' ? 'Performing well' : 'Needs attention',
                        type: 'channel',
                        metrics: [
                          { label: 'Sent', value: item.sent.toLocaleString() },
                          {
                            label: 'Open Rate',
                            value: `${item.openRate}%`,
                            change: item.status === 'strong' ? 8.2 : -4.5,
                            trend: item.status === 'strong' ? ('up' as const) : ('down' as const),
                          },
                          { label: 'Click Rate', value: `${item.clickRate}%` },
                          { label: 'Revenue', value: `$${(item.revenue / 1000).toFixed(1)}K` },
                        ],
                      });
                      setDrilldownOpen(true);
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="rounded-lg bg-primary/10 p-3">
                          <item.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{item.channel}</span>
                            <Badge
                              variant={item.status === 'strong' ? 'default' : 'destructive'}
                              className={
                                item.status === 'strong' ? 'bg-success/10 text-success hover:bg-success/20' : ''
                              }
                            >
                              {item.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{item.focusArea}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-8">
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Sent</p>
                          <p className="font-bold">{(item.sent / 1000).toFixed(1)}K</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Open Rate</p>
                          <p className="font-bold text-chart-1">{item.openRate}%</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Click Rate</p>
                          <p className="font-bold text-chart-2">{item.clickRate}%</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Revenue</p>
                          <p className="font-bold text-success">${(item.revenue / 1000).toFixed(1)}K</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between rounded-lg bg-background/50 p-3">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-warning" />
                        <span className="text-sm">
                          <strong>AI Insight:</strong> {item.insight}
                        </span>
                      </div>
                      <Button size="sm" variant="outline" onClick={(e) => e.stopPropagation()}>
                        {item.action}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={emailPerformanceTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="openRate"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2}
                      name="Open Rate %"
                    />
                    <Line
                      type="monotone"
                      dataKey="clickRate"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      name="Click Rate %"
                    />
                    <Line
                      type="monotone"
                      dataKey="conversionRate"
                      stroke="hsl(var(--chart-3))"
                      strokeWidth={2}
                      name="Conversion %"
                    />
                    <Legend />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Channel Revenue Mix</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={channelMixRevenue}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percentage }) => `${name}: ${percentage}%`}
                    >
                      {channelMixRevenue.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value) => `$${(value as number).toLocaleString()}`}
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Campaign Performance</CardTitle>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Campaign</TableHead>
                    <TableHead>Channel</TableHead>
                    <TableHead>Sent</TableHead>
                    <TableHead>Open Rate</TableHead>
                    <TableHead>Click Rate</TableHead>
                    <TableHead>Revenue</TableHead>
                    <TableHead>ROAS</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {campaignPerformance.map((campaign, i) => (
                    <TableRow
                      key={i}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleCampaignDrilldown(campaign)}
                    >
                      <TableCell className="font-medium">{campaign.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{campaign.channel}</Badge>
                      </TableCell>
                      <TableCell>{campaign.sent.toLocaleString()}</TableCell>
                      <TableCell>
                        <span className={campaign.openRate > 40 ? 'text-success' : 'text-foreground'}>
                          {campaign.openRate}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={campaign.clickRate > 10 ? 'text-success' : 'text-foreground'}>
                          {campaign.clickRate}%
                        </span>
                      </TableCell>
                      <TableCell className="font-bold">${campaign.revenue.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge
                          className={campaign.roas > 10 ? 'bg-success/10 text-success' : 'bg-chart-1/10 text-chart-1'}
                        >
                          {campaign.roas}x
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                          {campaign.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sendtime" className="space-y-6">
          <PredictiveSendTimeHeatmap
            data={sendTimeData}
            onTimeSelect={(hour, day) =>
              toast({ title: 'Time Selected', description: `Optimal send time: ${day} at ${hour}:00` })
            }
          />
        </TabsContent>

        <TabsContent value="cohorts" className="space-y-6">
          <CohortRetentionChart data={cohortData} />
        </TabsContent>

        <TabsContent value="anomalies" className="space-y-6">
          <AnomalyDetectionPanel
            anomalies={anomalies}
            onAcknowledge={(id) =>
              toast({ title: 'Anomaly Acknowledged', description: `Alert ${id} has been acknowledged.` })
            }
            onInvestigate={handleAnomalyInvestigate}
          />
        </TabsContent>

        <TabsContent value="segments" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Segment Performance Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={segmentPerformance} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis
                      type="category"
                      dataKey="segment"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      width={120}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Bar dataKey="openRate" fill="hsl(var(--chart-1))" name="Open Rate %" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="clickRate" fill="hsl(var(--chart-2))" name="Click Rate %" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Segment Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {segmentPerformance.map((segment, i) => (
                    <div
                      key={i}
                      className="rounded-lg border border-border p-4 cursor-pointer hover:border-primary/50 transition-colors"
                      onClick={() => {
                        setDrilldownData({
                          title: segment.segment,
                          type: 'segment',
                          metrics: [
                            { label: 'Open Rate', value: `${segment.openRate}%` },
                            { label: 'Click Rate', value: `${segment.clickRate}%` },
                            { label: 'Conversion', value: `${segment.conversionRate}%` },
                            { label: 'Avg Order', value: `$${segment.avgOrderValue}` },
                          ],
                        });
                        setDrilldownOpen(true);
                      }}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">{segment.segment}</span>
                        <Badge variant="outline">${segment.avgOrderValue} AOV</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Open Rate</p>
                          <p className="font-bold">{segment.openRate}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Click Rate</p>
                          <p className="font-bold">{segment.clickRate}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Conversion</p>
                          <p className="font-bold text-success">{segment.conversionRate}%</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="deliverability" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="relative mx-auto h-32 w-32">
                    <svg className="h-full w-full -rotate-90 transform">
                      <circle cx="64" cy="64" r="56" fill="none" stroke="hsl(var(--muted))" strokeWidth="12" />
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke="hsl(var(--success))"
                        strokeWidth="12"
                        strokeDasharray={`${deliverabilityMetrics.inboxRate * 3.52} 352`}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold">{deliverabilityMetrics.inboxRate}%</span>
                    </div>
                  </div>
                  <p className="mt-2 font-medium">Inbox Placement Rate</p>
                  <p className="text-xs text-muted-foreground">Industry avg: 89%</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Sender Score</span>
                    <span className="font-bold">{deliverabilityMetrics.senderScore}/100</span>
                  </div>
                  <Progress value={deliverabilityMetrics.senderScore} className="h-2" />
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Domain Reputation</span>
                    <Badge className="bg-success/10 text-success">{deliverabilityMetrics.domainReputation}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      SPF Pass Rate
                    </span>
                    <span className="font-medium">{deliverabilityMetrics.spfPass}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      DKIM Pass Rate
                    </span>
                    <span className="font-medium">{deliverabilityMetrics.dkimPass}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      DMARC Pass Rate
                    </span>
                    <span className="font-medium">{deliverabilityMetrics.dmarcPass}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-2">
                      <XCircle className="h-4 w-4 text-destructive" />
                      Spam Rate
                    </span>
                    <span className="font-medium text-destructive">{deliverabilityMetrics.spamRate}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-warning" />
                      Bounce Rate
                    </span>
                    <span className="font-medium text-warning">{deliverabilityMetrics.bounceRate}%</span>
                  </div>
                  <div className="mt-4 rounded-lg bg-muted/50 p-3">
                    <p className="text-xs text-muted-foreground">
                      Keep spam rate below 0.1% to maintain good deliverability
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="abtests" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>A/B Test Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {abTestResults.map((test, i) => (
                  <div key={i} className="rounded-lg border border-border p-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-medium">{test.testName}</span>
                      <Badge className="bg-success/10 text-success">{test.confidence}% Confidence</Badge>
                    </div>
                    <div className="grid grid-cols-4 gap-4">
                      <div className="rounded-lg bg-muted/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground">Variant A</p>
                        <p className={`text-xl font-bold ${test.winner === 'A' ? 'text-success' : ''}`}>
                          {test.variantA}%
                        </p>
                        {test.winner === 'A' && <Badge className="mt-1 bg-success/10 text-success">Winner</Badge>}
                      </div>
                      <div className="rounded-lg bg-muted/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground">Variant B</p>
                        <p className={`text-xl font-bold ${test.winner === 'B' ? 'text-success' : ''}`}>
                          {test.variantB}%
                        </p>
                        {test.winner === 'B' && <Badge className="mt-1 bg-success/10 text-success">Winner</Badge>}
                      </div>
                      <div className="rounded-lg bg-muted/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground">Lift</p>
                        <p className="text-xl font-bold text-success">{test.lift}</p>
                      </div>
                      <div className="flex items-center justify-center">
                        <Button variant="outline" size="sm">
                          Apply Winner
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="journey" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customer Journey Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {journeyStages.map((stage, i) => (
                  <div
                    key={i}
                    className="relative cursor-pointer"
                    onClick={() => {
                      setDrilldownData({
                        title: stage.stage,
                        subtitle: 'Journey Stage Analysis',
                        type: 'segment',
                        metrics: [
                          { label: 'Users', value: stage.users.toLocaleString() },
                          { label: 'Drop-off', value: `${stage.dropoff}%` },
                          {
                            label: 'Conversion',
                            value: `${((stage.users / journeyStages[0].users) * 100).toFixed(1)}%`,
                          },
                        ],
                      });
                      setDrilldownOpen(true);
                    }}
                  >
                    <div
                      className="h-12 rounded-lg bg-chart-1 transition-all hover:opacity-90 flex items-center justify-between px-4"
                      style={{ width: `${(stage.users / journeyStages[0].users) * 100}%`, opacity: 1 - i * 0.12 }}
                    >
                      <span className="font-medium text-primary-foreground">{stage.stage}</span>
                      <span className="font-bold text-primary-foreground">{(stage.users / 1000).toFixed(1)}K</span>
                    </div>
                    {stage.dropoff > 0 && (
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-full pl-4">
                        <Badge variant="outline" className="text-destructive">
                          -{stage.dropoff.toFixed(1)}% dropoff
                        </Badge>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Drilldown Modal */}
      <DrilldownModal
        open={drilldownOpen}
        onOpenChange={setDrilldownOpen}
        data={drilldownData}
        onDrillDeeper={(itemId) => toast({ title: 'Drilling Deeper', description: `Exploring ${itemId}...` })}
      />
    </div>
  );
}
