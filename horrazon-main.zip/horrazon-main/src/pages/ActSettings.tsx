import { useState } from 'react';
import { Link } from 'react-router-dom';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import {
  User,
  Shield,
  Bell,
  Plug,
  Zap,
  Settings,
  Mail,
  Plus,
  Trash2,
  Edit,
  Check,
  X,
  Crown,
  UserCog,
  Eye,
  Pencil,
  Building,
  Globe,
  DollarSign,
  Clock,
  Slack,
  MessageSquare,
  Smartphone,
  AlertTriangle,
  TrendingDown,
  Wallet,
  Activity,
  FileText,
  Package,
  Target,
  Key,
  Webhook,
  Copy,
  LayoutDashboard,
  Palette,
  Moon,
  Sun,
  Monitor,
  Download,
  Upload,
  Database,
  Lock,
  CreditCard,
  History,
  LogOut,
  ChevronRight,
  ExternalLink,
  RefreshCw,
  Camera,
  Users,
  ShieldCheck,
  Fingerprint,
  KeyRound,
  Laptop,
  Smartphone as Phone,
  Trash,
  Archive,
  HardDrive,
  Cloud,
  BellOff,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useLoading } from '@/hooks/useLoading';
import { SettingsSkeleton } from '@/components/skeletons';

// Types
interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'editor' | 'viewer';
  avatar?: string;
  status: 'active' | 'pending';
  lastActive?: string;
}

interface Integration {
  id: string;
  name: string;
  category: string;
  icon: string;
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
  description?: string;
}

interface Session {
  id: string;
  device: string;
  location: string;
  lastActive: string;
  current: boolean;
  icon: 'laptop' | 'phone';
}

interface APIKey {
  id: string;
  name: string;
  key: string;
  created: string;
  lastUsed: string;
  status: 'active' | 'revoked';
}

// Mock Data
const teamMembers: TeamMember[] = [
  { id: '1', name: 'Sarah Chen', email: 'sarah@company.com', role: 'owner', status: 'active', lastActive: '2 min ago' },
  {
    id: '2',
    name: 'Michael Ross',
    email: 'michael@company.com',
    role: 'admin',
    status: 'active',
    lastActive: '1 hour ago',
  },
  {
    id: '3',
    name: 'Emily Davis',
    email: 'emily@company.com',
    role: 'editor',
    status: 'active',
    lastActive: '3 hours ago',
  },
  { id: '4', name: 'James Wilson', email: 'james@company.com', role: 'viewer', status: 'pending' },
];

const integrations: Integration[] = [
  {
    id: '1',
    name: 'Google Ads',
    category: 'Advertising',
    icon: '🎯',
    status: 'connected',
    lastSync: '5 min ago',
    description: 'Connect your Google Ads campaigns',
  },
  {
    id: '2',
    name: 'Meta Ads',
    category: 'Advertising',
    icon: '📘',
    status: 'connected',
    lastSync: '10 min ago',
    description: 'Manage Facebook & Instagram ads',
  },
  {
    id: '3',
    name: 'Amazon Ads',
    category: 'Advertising',
    icon: '📦',
    status: 'connected',
    lastSync: '15 min ago',
    description: 'Amazon advertising integration',
  },
  {
    id: '4',
    name: 'TikTok Ads',
    category: 'Advertising',
    icon: '🎵',
    status: 'disconnected',
    description: 'TikTok for Business',
  },
  {
    id: '5',
    name: 'Google Analytics',
    category: 'Analytics',
    icon: '📊',
    status: 'connected',
    lastSync: '2 min ago',
    description: 'Website analytics & insights',
  },
  {
    id: '6',
    name: 'Shopify',
    category: 'E-commerce',
    icon: '🛒',
    status: 'connected',
    lastSync: '1 min ago',
    description: 'E-commerce platform',
  },
  {
    id: '7',
    name: 'Klaviyo',
    category: 'Email',
    icon: '✉️',
    status: 'error',
    description: 'Email marketing automation',
  },
  {
    id: '8',
    name: 'Salesforce',
    category: 'CRM',
    icon: '☁️',
    status: 'disconnected',
    description: 'Customer relationship management',
  },
  {
    id: '9',
    name: 'HubSpot',
    category: 'CRM',
    icon: '🧡',
    status: 'disconnected',
    description: 'Marketing & sales platform',
  },
  {
    id: '10',
    name: 'Stripe',
    category: 'Payments',
    icon: '💳',
    status: 'connected',
    lastSync: '30 min ago',
    description: 'Payment processing',
  },
];

const sessions: Session[] = [
  {
    id: '1',
    device: 'MacBook Pro - Chrome',
    location: 'San Francisco, CA',
    lastActive: 'Now',
    current: true,
    icon: 'laptop',
  },
  {
    id: '2',
    device: 'iPhone 15 Pro - Safari',
    location: 'San Francisco, CA',
    lastActive: '2 hours ago',
    current: false,
    icon: 'phone',
  },
  {
    id: '3',
    device: 'Windows PC - Firefox',
    location: 'New York, NY',
    lastActive: '3 days ago',
    current: false,
    icon: 'laptop',
  },
];

const apiKeys: APIKey[] = [
  {
    id: '1',
    name: 'Production API Key',
    key: 'qi_prod_****...****7x9k',
    created: 'Jan 15, 2024',
    lastUsed: '2 min ago',
    status: 'active',
  },
  {
    id: '2',
    name: 'Development Key',
    key: 'qi_dev_****...****3m2n',
    created: 'Feb 20, 2024',
    lastUsed: '1 week ago',
    status: 'active',
  },
  {
    id: '3',
    name: 'Legacy Integration',
    key: 'qi_leg_****...****9p1q',
    created: 'Dec 1, 2023',
    lastUsed: 'Never',
    status: 'revoked',
  },
];

const permissionMatrix = [
  { feature: 'Smart Actions', key: 'actions' },
  { feature: 'Rules & Automation', key: 'rules' },
  { feature: 'Budget Management', key: 'budget' },
  { feature: 'Team Management', key: 'team' },
  { feature: 'Billing & Plans', key: 'billing' },
  { feature: 'Integrations', key: 'integrations' },
  { feature: 'Reports & Analytics', key: 'reports' },
  { feature: 'Settings', key: 'settings' },
];

type SettingsSection =
  | 'profile'
  | 'security'
  | 'appearance'
  | 'integrations'
  | 'notifications'
  | 'api'
  | 'data'
  | 'team'
  | 'automation'
  | 'billing';

const settingsNavItems: { id: SettingsSection; label: string; icon: React.ElementType; description: string }[] = [
  { id: 'profile', label: 'Profile', icon: User, description: 'Personal information' },
  { id: 'security', label: 'Security', icon: Shield, description: 'Password & sessions' },
  { id: 'appearance', label: 'Appearance', icon: Palette, description: 'Theme & display' },
  { id: 'notifications', label: 'Notifications', icon: Bell, description: 'Alerts & updates' },
  { id: 'integrations', label: 'Integrations', icon: Plug, description: 'Connected apps' },
  { id: 'api', label: 'API & Developers', icon: Key, description: 'Keys & webhooks' },
  { id: 'team', label: 'Team', icon: Users, description: 'Members & roles' },
  { id: 'automation', label: 'Automation', icon: Zap, description: 'AI & rules' },
  { id: 'data', label: 'Data & Privacy', icon: Database, description: 'Export & delete' },
  { id: 'billing', label: 'Billing', icon: CreditCard, description: 'Plans & payments' },
];

export default function ActSettings() {
  const [activeSection, setActiveSection] = useState<SettingsSection>('profile');
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');
  const isLoading = useLoading(400);

  // Profile states
  const [profileData, setProfileData] = useState({
    firstName: 'Sarah',
    lastName: 'Chen',
    email: 'sarah@company.com',
    phone: '+1 (555) 123-4567',
    timezone: 'pst',
    language: 'en',
    bio: 'Marketing analytics enthusiast with 10+ years of experience in digital advertising and data-driven decision making.',
  });

  // Organization states
  const [orgData, setOrgData] = useState({
    name: 'Acme Corporation',
    industry: 'ecommerce',
    adSpend: '100k-500k',
    website: 'https://acme.com',
  });

  // Automation states
  const [campaignMode, setCampaignMode] = useState('authorize');
  const [skuMode, setSkuMode] = useState('rule-based');
  const [dailyLimit, setDailyLimit] = useState('5000');
  const [weeklyLimit, setWeeklyLimit] = useState('25000');
  const [maxActionsPerDay, setMaxActionsPerDay] = useState('50');

  // Team states
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('viewer');

  // Notification states
  const [notifications, setNotifications] = useState({
    smartActions: true,
    performanceDrops: true,
    budgetAlerts: true,
    anomalyDetection: true,
    dailyPulse: true,
    wbrSummary: true,
    ruleExecutions: false,
    inventoryAlerts: true,
    competitorChanges: false,
    emailEnabled: true,
    slackEnabled: true,
    pushEnabled: false,
    smsEnabled: false,
    digestFrequency: 'daily',
    quietHoursEnabled: true,
    quietHoursStart: '22:00',
    quietHoursEnd: '08:00',
  });

  // Permissions
  const [permissions, setPermissions] = useState({
    owner: {
      actions: true,
      rules: true,
      budget: true,
      team: true,
      billing: true,
      integrations: true,
      reports: true,
      settings: true,
    },
    admin: {
      actions: true,
      rules: true,
      budget: true,
      team: true,
      billing: false,
      integrations: true,
      reports: true,
      settings: true,
    },
    editor: {
      actions: true,
      rules: true,
      budget: false,
      team: false,
      billing: false,
      integrations: false,
      reports: true,
      settings: false,
    },
    viewer: {
      actions: false,
      rules: false,
      budget: false,
      team: false,
      billing: false,
      integrations: false,
      reports: true,
      settings: false,
    },
  });

  // Security states
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [passwordLastChanged] = useState('45 days ago');

  const handleInvite = () => {
    if (!inviteEmail) return;
    toast.success(`Invitation sent to ${inviteEmail}`);
    setInviteEmail('');
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner':
        return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      case 'admin':
        return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'editor':
        return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-emerald-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-muted-foreground';
    }
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'profile':
        return (
          <ProfileSection
            profileData={profileData}
            setProfileData={setProfileData}
            orgData={orgData}
            setOrgData={setOrgData}
          />
        );
      case 'security':
        return (
          <SecuritySection
            sessions={sessions}
            twoFactorEnabled={twoFactorEnabled}
            setTwoFactorEnabled={setTwoFactorEnabled}
            passwordLastChanged={passwordLastChanged}
          />
        );
      case 'appearance':
        return <AppearanceSection theme={theme} setTheme={setTheme} />;
      case 'notifications':
        return <NotificationsSection notifications={notifications} setNotifications={setNotifications} />;
      case 'integrations':
        return <IntegrationsSection integrations={integrations} getStatusColor={getStatusColor} />;
      case 'api':
        return <APISection apiKeys={apiKeys} />;
      case 'team':
        return (
          <TeamSection
            teamMembers={teamMembers}
            permissions={permissions}
            setPermissions={setPermissions}
            permissionMatrix={permissionMatrix}
            inviteEmail={inviteEmail}
            setInviteEmail={setInviteEmail}
            inviteRole={inviteRole}
            setInviteRole={setInviteRole}
            handleInvite={handleInvite}
            getRoleBadgeColor={getRoleBadgeColor}
          />
        );
      case 'automation':
        return (
          <AutomationSection
            campaignMode={campaignMode}
            setCampaignMode={setCampaignMode}
            skuMode={skuMode}
            setSkuMode={setSkuMode}
            dailyLimit={dailyLimit}
            setDailyLimit={setDailyLimit}
            weeklyLimit={weeklyLimit}
            setWeeklyLimit={setWeeklyLimit}
            maxActionsPerDay={maxActionsPerDay}
            setMaxActionsPerDay={setMaxActionsPerDay}
          />
        );
      case 'data':
        return <DataPrivacySection />;
      case 'billing':
        return <BillingSection />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return <SettingsSkeleton />;
  }

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden animate-fade-in">
      <SEOHead
        title="Settings"
        description="Manage your account settings, team, integrations, and preferences."
        keywords="account settings, user preferences, team management, security settings, integrations"
      />
      {/* Sidebar Navigation */}
      <aside className="w-72 border-r bg-card/50 flex flex-col">
        <div className="p-6 border-b">
          <h1 className="text-xl font-bold tracking-tight">Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your account & preferences</p>
        </div>
        <ScrollArea className="flex-1">
          <nav className="p-3 space-y-1">
            {settingsNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all group',
                  activeSection === item.id
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground',
                )}
              >
                <item.icon
                  className={cn(
                    'h-5 w-5 shrink-0',
                    activeSection === item.id
                      ? 'text-primary-foreground'
                      : 'text-muted-foreground group-hover:text-foreground',
                  )}
                />
                <div className="min-w-0 flex-1">
                  <div
                    className={cn('font-medium text-sm', activeSection === item.id ? 'text-primary-foreground' : '')}
                  >
                    {item.label}
                  </div>
                  <div
                    className={cn(
                      'text-xs truncate',
                      activeSection === item.id ? 'text-primary-foreground/70' : 'text-muted-foreground',
                    )}
                  >
                    {item.description}
                  </div>
                </div>
                <ChevronRight
                  className={cn(
                    'h-4 w-4 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity',
                    activeSection === item.id && 'opacity-100',
                  )}
                />
              </button>
            ))}
          </nav>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <Avatar className="h-9 w-9">
              <AvatarImage src="" />
              <AvatarFallback className="bg-primary/10 text-primary text-sm">SC</AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <div className="font-medium text-sm truncate">Sarah Chen</div>
              <div className="text-xs text-muted-foreground truncate">sarah@company.com</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-8">{renderContent()}</div>
      </main>
    </div>
  );
}

// Profile Section Component
function ProfileSection({ profileData, setProfileData, orgData, setOrgData }: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Profile</h2>
        <p className="text-muted-foreground mt-1">Manage your personal information and preferences</p>
      </div>

      {/* Avatar Section */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="relative group">
              <Avatar className="h-24 w-24 ring-4 ring-background shadow-lg">
                <AvatarImage src="" />
                <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-semibold">
                  SC
                </AvatarFallback>
              </Avatar>
              <button className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="h-6 w-6 text-white" />
              </button>
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-semibold">
                {profileData.firstName} {profileData.lastName}
              </h3>
              <p className="text-muted-foreground">{profileData.email}</p>
              <div className="flex gap-2 mt-2">
                <Button size="sm" variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photo
                </Button>
                <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                  Remove
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Personal Information</CardTitle>
          <CardDescription>Update your personal details here</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                value={profileData.firstName}
                onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                value={profileData.lastName}
                onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={profileData.email}
              onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              value={profileData.phone}
              onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={profileData.bio}
              onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
              rows={3}
              className="resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Preferences</CardTitle>
          <CardDescription>Customize your experience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Timezone</Label>
              <Select
                value={profileData.timezone}
                onValueChange={(v) => setProfileData({ ...profileData, timezone: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pst">Pacific Time (PST)</SelectItem>
                  <SelectItem value="est">Eastern Time (EST)</SelectItem>
                  <SelectItem value="utc">UTC</SelectItem>
                  <SelectItem value="ist">India Standard Time (IST)</SelectItem>
                  <SelectItem value="gmt">Greenwich Mean Time (GMT)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Language</Label>
              <Select
                value={profileData.language}
                onValueChange={(v) => setProfileData({ ...profileData, language: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                  <SelectItem value="ja">日本語</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Organization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Building className="h-5 w-5" />
            Organization
          </CardTitle>
          <CardDescription>Your company details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Organization Name</Label>
            <Input value={orgData.name} onChange={(e) => setOrgData({ ...orgData, name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Website</Label>
            <Input value={orgData.website} onChange={(e) => setOrgData({ ...orgData, website: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Industry</Label>
              <Select value={orgData.industry} onValueChange={(v) => setOrgData({ ...orgData, industry: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ecommerce">E-commerce</SelectItem>
                  <SelectItem value="saas">SaaS</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Monthly Ad Spend</Label>
              <Select value={orgData.adSpend} onValueChange={(v) => setOrgData({ ...orgData, adSpend: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10k-50k">$10K - $50K</SelectItem>
                  <SelectItem value="50k-100k">$50K - $100K</SelectItem>
                  <SelectItem value="100k-500k">$100K - $500K</SelectItem>
                  <SelectItem value="500k+">$500K+</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-3">
        <Button variant="outline">Cancel</Button>
        <Button onClick={() => toast.success('Profile updated successfully')}>Save Changes</Button>
      </div>
    </div>
  );
}

// Security Section Component
function SecuritySection({ sessions, twoFactorEnabled, setTwoFactorEnabled, passwordLastChanged }: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Security</h2>
        <p className="text-muted-foreground mt-1">Manage your security settings and active sessions</p>
      </div>

      {/* Password */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Lock className="h-5 w-5" />
            Password
          </CardTitle>
          <CardDescription>Last changed {passwordLastChanged}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/30">
            <div>
              <p className="font-medium">Current Password</p>
              <p className="text-sm text-muted-foreground">••••••••••••</p>
            </div>
            <Button variant="outline" onClick={() => toast.info('Password change modal would open')}>
              Change Password
            </Button>
          </div>
          <div className="flex items-start gap-3 p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-sm">Password Strength</p>
              <p className="text-sm text-muted-foreground">
                We recommend changing your password every 90 days for better security.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Two-Factor Authentication */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <ShieldCheck className="h-5 w-5" />
            Two-Factor Authentication
          </CardTitle>
          <CardDescription>Add an extra layer of security to your account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div className="flex items-center gap-4">
              <div className={cn('p-3 rounded-lg', twoFactorEnabled ? 'bg-emerald-500/10' : 'bg-muted')}>
                <Fingerprint
                  className={cn('h-6 w-6', twoFactorEnabled ? 'text-emerald-500' : 'text-muted-foreground')}
                />
              </div>
              <div>
                <p className="font-medium">Authenticator App</p>
                <p className="text-sm text-muted-foreground">{twoFactorEnabled ? 'Enabled' : 'Not configured'}</p>
              </div>
            </div>
            <Switch checked={twoFactorEnabled} onCheckedChange={setTwoFactorEnabled} />
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-lg bg-muted">
                <KeyRound className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium">Security Keys</p>
                <p className="text-sm text-muted-foreground">Hardware security keys for passwordless login</p>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Add Key
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Active Sessions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Laptop className="h-5 w-5" />
                Active Sessions
              </CardTitle>
              <CardDescription>Manage your active sessions across devices</CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="text-destructive hover:text-destructive"
              onClick={() => toast.success('All other sessions terminated')}
            >
              Sign Out All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {sessions.map((session: Session) => (
            <div
              key={session.id}
              className={cn(
                'flex items-center justify-between p-4 rounded-lg border',
                session.current && 'border-primary bg-primary/5',
              )}
            >
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-lg bg-muted">
                  {session.icon === 'laptop' ? <Laptop className="h-5 w-5" /> : <Phone className="h-5 w-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{session.device}</p>
                    {session.current && (
                      <Badge variant="secondary" className="text-xs">
                        Current
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {session.location} • {session.lastActive}
                  </p>
                </div>
              </div>
              {!session.current && (
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                  <LogOut className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Login History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <History className="h-5 w-5" />
            Login History
          </CardTitle>
          <CardDescription>Recent login activity on your account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { date: 'Today, 9:45 AM', location: 'San Francisco, CA', device: 'Chrome on macOS', success: true },
              { date: 'Yesterday, 3:22 PM', location: 'San Francisco, CA', device: 'Safari on iPhone', success: true },
              { date: 'Dec 20, 11:00 AM', location: 'New York, NY', device: 'Firefox on Windows', success: true },
              { date: 'Dec 18, 8:15 PM', location: 'Unknown', device: 'Unknown Browser', success: false },
            ].map((entry, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b last:border-0">
                <div className="flex items-center gap-3">
                  <div className={cn('w-2 h-2 rounded-full', entry.success ? 'bg-emerald-500' : 'bg-red-500')} />
                  <div>
                    <p className="text-sm font-medium">{entry.date}</p>
                    <p className="text-xs text-muted-foreground">
                      {entry.device} • {entry.location}
                    </p>
                  </div>
                </div>
                <Badge variant={entry.success ? 'secondary' : 'destructive'} className="text-xs">
                  {entry.success ? 'Success' : 'Failed'}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Appearance Section Component
function AppearanceSection({ theme, setTheme }: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Appearance</h2>
        <p className="text-muted-foreground mt-1">Customize how Horrazon looks on your device</p>
      </div>

      {/* Theme Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Theme</CardTitle>
          <CardDescription>Select your preferred color scheme</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {[
              { value: 'light', label: 'Light', icon: Sun, preview: 'bg-white border-2' },
              { value: 'dark', label: 'Dark', icon: Moon, preview: 'bg-slate-900 border-2' },
              {
                value: 'system',
                label: 'System',
                icon: Monitor,
                preview: 'bg-gradient-to-r from-white to-slate-900 border-2',
              },
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => setTheme(option.value)}
                className={cn(
                  'relative flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all',
                  theme === option.value
                    ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                    : 'border-border hover:border-primary/50',
                )}
              >
                <div className={cn('w-16 h-12 rounded-lg shadow-inner', option.preview)} />
                <div className="flex items-center gap-2">
                  <option.icon className="h-4 w-4" />
                  <span className="font-medium">{option.label}</span>
                </div>
                {theme === option.value && (
                  <div className="absolute top-2 right-2">
                    <Check className="h-4 w-4 text-primary" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Display Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Display</CardTitle>
          <CardDescription>Adjust display preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Compact Mode</p>
              <p className="text-sm text-muted-foreground">Reduce spacing for more content on screen</p>
            </div>
            <Switch />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Show Sidebar Labels</p>
              <p className="text-sm text-muted-foreground">Display text labels next to navigation icons</p>
            </div>
            <Switch defaultChecked />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Animations</p>
              <p className="text-sm text-muted-foreground">Enable smooth transitions and animations</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      {/* Dashboard Customization */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Dashboard Layout</CardTitle>
          <CardDescription>Customize your default dashboard view</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Default Landing Page</Label>
            <Select defaultValue="daily-pulse">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily-pulse">Daily Pulse</SelectItem>
                <SelectItem value="action-center">Action Center</SelectItem>
                <SelectItem value="reports">Reports</SelectItem>
                <SelectItem value="analytics">Analytics</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Date Format</Label>
            <Select defaultValue="mdy">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mdy">MM/DD/YYYY</SelectItem>
                <SelectItem value="dmy">DD/MM/YYYY</SelectItem>
                <SelectItem value="ymd">YYYY-MM-DD</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Number Format</Label>
            <Select defaultValue="us">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="us">1,234.56</SelectItem>
                <SelectItem value="eu">1.234,56</SelectItem>
                <SelectItem value="in">1,23,456.78</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Notifications Section Component
function NotificationsSection({ notifications, setNotifications }: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
        <p className="text-muted-foreground mt-1">Choose how and when you want to be notified</p>
      </div>

      {/* Notification Channels */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Notification Channels</CardTitle>
          <CardDescription>Choose how you want to receive notifications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { key: 'emailEnabled', label: 'Email', icon: Mail, desc: 'Primary inbox' },
              { key: 'slackEnabled', label: 'Slack', icon: Slack, desc: '#marketing-alerts' },
              { key: 'pushEnabled', label: 'Push', icon: Bell, desc: 'Browser notifications' },
              { key: 'smsEnabled', label: 'SMS', icon: Smartphone, desc: 'Critical only' },
            ].map((channel) => (
              <button
                key={channel.key}
                onClick={() => setNotifications((prev: any) => ({ ...prev, [channel.key]: !prev[channel.key] }))}
                className={cn(
                  'relative p-4 rounded-xl border-2 transition-all text-left',
                  notifications[channel.key] ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50',
                )}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className={cn('p-2 rounded-lg', notifications[channel.key] ? 'bg-primary/10' : 'bg-muted')}>
                    <channel.icon
                      className={cn('h-5 w-5', notifications[channel.key] ? 'text-primary' : 'text-muted-foreground')}
                    />
                  </div>
                  {notifications[channel.key] && <Check className="h-4 w-4 text-primary" />}
                </div>
                <p className="font-medium text-sm">{channel.label}</p>
                <p className="text-xs text-muted-foreground">{channel.desc}</p>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Critical Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Critical Alerts
          </CardTitle>
          <CardDescription>Get notified immediately for important events</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {[
            {
              key: 'smartActions',
              label: 'Smart Action Recommendations',
              desc: 'When AI suggests high-impact actions',
              icon: Zap,
            },
            {
              key: 'performanceDrops',
              label: 'Performance Drops',
              desc: 'When metrics drop below thresholds',
              icon: TrendingDown,
            },
            {
              key: 'budgetAlerts',
              label: 'Budget Alerts',
              desc: 'Approaching or exceeding budget limits',
              icon: Wallet,
            },
            {
              key: 'anomalyDetection',
              label: 'Anomaly Detection',
              desc: 'Unusual patterns in performance data',
              icon: Activity,
            },
          ].map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent/30 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="p-2.5 rounded-lg bg-accent">
                  <item.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">{item.label}</p>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              </div>
              <Switch
                checked={notifications[item.key]}
                onCheckedChange={(checked) => setNotifications((prev: any) => ({ ...prev, [item.key]: checked }))}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Reports & Summaries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="h-5 w-5 text-blue-500" />
            Reports & Summaries
          </CardTitle>
          <CardDescription>Scheduled reports and digest notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {[
            {
              key: 'dailyPulse',
              label: 'Daily Pulse Summary',
              desc: 'Morning overview of key metrics',
              icon: LayoutDashboard,
            },
            {
              key: 'wbrSummary',
              label: 'Weekly Business Review',
              desc: 'Comprehensive weekly analysis',
              icon: FileText,
            },
            {
              key: 'ruleExecutions',
              label: 'Rule Execution Reports',
              desc: 'When automation rules are triggered',
              icon: Zap,
            },
            {
              key: 'inventoryAlerts',
              label: 'Inventory Alerts',
              desc: 'Stock level and merchandise updates',
              icon: Package,
            },
            {
              key: 'competitorChanges',
              label: 'Competitor Intelligence',
              desc: 'Changes in competitor activity',
              icon: Target,
            },
          ].map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent/30 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="p-2.5 rounded-lg bg-accent">
                  <item.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">{item.label}</p>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              </div>
              <Switch
                checked={notifications[item.key]}
                onCheckedChange={(checked) => setNotifications((prev: any) => ({ ...prev, [item.key]: checked }))}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quiet Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <BellOff className="h-5 w-5" />
            Quiet Hours
          </CardTitle>
          <CardDescription>Pause non-critical notifications during specific times</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Enable Quiet Hours</p>
              <p className="text-sm text-muted-foreground">Mute notifications during set hours</p>
            </div>
            <Switch
              checked={notifications.quietHoursEnabled}
              onCheckedChange={(checked) => setNotifications((prev: any) => ({ ...prev, quietHoursEnabled: checked }))}
            />
          </div>
          {notifications.quietHoursEnabled && (
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Select
                  value={notifications.quietHoursStart}
                  onValueChange={(v) => setNotifications((prev: any) => ({ ...prev, quietHoursStart: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {['18:00', '19:00', '20:00', '21:00', '22:00', '23:00'].map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>End Time</Label>
                <Select
                  value={notifications.quietHoursEnd}
                  onValueChange={(v) => setNotifications((prev: any) => ({ ...prev, quietHoursEnd: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {['06:00', '07:00', '08:00', '09:00', '10:00'].map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Integrations Section Component
function IntegrationsSection({ integrations, getStatusColor }: any) {
  const categories = [...new Set(integrations.map((i: Integration) => i.category))];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Integrations</h2>
          <p className="text-muted-foreground mt-1">Connect your marketing tools and platforms</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Browse All
        </Button>
      </div>

      {/* Connection Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-emerald-500/10 border-emerald-500/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-full bg-emerald-500/20">
              <Check className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-emerald-600">
                {integrations.filter((i: Integration) => i.status === 'connected').length}
              </p>
              <p className="text-sm text-muted-foreground">Connected</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-amber-500/10 border-amber-500/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-full bg-amber-500/20">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">
                {integrations.filter((i: Integration) => i.status === 'error').length}
              </p>
              <p className="text-sm text-muted-foreground">Needs Attention</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-muted/50">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-full bg-muted">
              <Plug className="h-5 w-5 text-muted-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {integrations.filter((i: Integration) => i.status === 'disconnected').length}
              </p>
              <p className="text-sm text-muted-foreground">Available</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Integration Categories */}
      {categories.map((category: string) => (
        <Card key={category}>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">{category}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {integrations
                .filter((i: Integration) => i.category === category)
                .map((integration: Integration) => (
                  <div
                    key={integration.id}
                    className={cn(
                      'flex items-center justify-between p-4 rounded-lg border transition-all hover:shadow-sm',
                      integration.status === 'connected' && 'bg-card',
                      integration.status === 'error' && 'bg-red-500/5 border-red-500/20',
                      integration.status === 'disconnected' && 'bg-muted/30',
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{integration.icon}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{integration.name}</span>
                          <div className={cn('w-2 h-2 rounded-full', getStatusColor(integration.status))} />
                        </div>
                        <p className="text-sm text-muted-foreground">{integration.description}</p>
                        {integration.lastSync && (
                          <p className="text-xs text-muted-foreground mt-1">Synced {integration.lastSync}</p>
                        )}
                      </div>
                    </div>
                    <Button
                      variant={
                        integration.status === 'connected'
                          ? 'outline'
                          : integration.status === 'error'
                            ? 'destructive'
                            : 'default'
                      }
                      size="sm"
                    >
                      {integration.status === 'connected'
                        ? 'Manage'
                        : integration.status === 'error'
                          ? 'Reconnect'
                          : 'Connect'}
                    </Button>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// API Section Component
function APISection({ apiKeys }: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">API & Developers</h2>
        <p className="text-muted-foreground mt-1">Manage API keys and webhook integrations</p>
      </div>

      {/* API Keys */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Key className="h-5 w-5" />
                API Keys
              </CardTitle>
              <CardDescription>Manage your API keys for programmatic access</CardDescription>
            </div>
            <Button onClick={() => toast.success('New API key generated')}>
              <Plus className="h-4 w-4 mr-2" />
              Generate Key
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {apiKeys.map((key: APIKey) => (
            <div key={key.id} className={cn('p-4 rounded-lg border', key.status === 'revoked' && 'opacity-60')}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="font-medium">{key.name}</span>
                  <Badge
                    variant={key.status === 'active' ? 'secondary' : 'outline'}
                    className={key.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : ''}
                  >
                    {key.status}
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.success('Copied!')}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  {key.status === 'active' && (
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <code className="flex-1 text-sm bg-muted px-3 py-2 rounded font-mono">{key.key}</code>
              </div>
              <div className="flex gap-4 text-xs text-muted-foreground">
                <span>Created: {key.created}</span>
                <span>Last used: {key.lastUsed}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Webhooks */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Webhook className="h-5 w-5" />
                Webhooks
              </CardTitle>
              <CardDescription>Receive real-time notifications via HTTP callbacks</CardDescription>
            </div>
            <Button variant="outline" onClick={() => toast.info('Webhook configuration would open')}>
              <Plus className="h-4 w-4 mr-2" />
              Add Webhook
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Webhook className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="font-medium">No webhooks configured</p>
            <p className="text-sm">Add a webhook to receive real-time event notifications</p>
          </div>
        </CardContent>
      </Card>

      {/* API Documentation */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-lg bg-primary/10">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">API Documentation</p>
                <p className="text-sm text-muted-foreground">Learn how to integrate with our REST API</p>
              </div>
            </div>
            <Button variant="outline">
              View Docs
              <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Team Section Component
function TeamSection({
  teamMembers,
  permissions,
  setPermissions,
  permissionMatrix,
  inviteEmail,
  setInviteEmail,
  inviteRole,
  setInviteRole,
  handleInvite,
  getRoleBadgeColor,
}: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Team</h2>
        <p className="text-muted-foreground mt-1">Manage team members and their permissions</p>
      </div>

      {/* Invite Member */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Invite Team Member</CardTitle>
          <CardDescription>Send an invitation to collaborate on your workspace</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <Input
              placeholder="Enter email address"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              className="flex-1"
            />
            <Select value={inviteRole} onValueChange={setInviteRole}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="editor">Editor</SelectItem>
                <SelectItem value="viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleInvite}>
              <Mail className="h-4 w-4 mr-2" />
              Send Invite
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Team Members */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="h-5 w-5" />
            Team Members
          </CardTitle>
          <CardDescription>{teamMembers.length} members in your workspace</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {teamMembers.map((member: TeamMember) => (
            <div
              key={member.id}
              className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent/30 transition-colors"
            >
              <div className="flex items-center gap-4">
                <Avatar className="h-11 w-11">
                  <AvatarImage src={member.avatar} />
                  <AvatarFallback className="bg-primary/10 text-primary font-medium">
                    {member.name
                      .split(' ')
                      .map((n) => n[0])
                      .join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{member.name}</span>
                    {member.role === 'owner' && <Crown className="h-4 w-4 text-amber-500" />}
                  </div>
                  <span className="text-sm text-muted-foreground">{member.email}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {member.lastActive && (
                  <span className="text-xs text-muted-foreground hidden md:block">{member.lastActive}</span>
                )}
                <Badge variant="outline" className={getRoleBadgeColor(member.role)}>
                  {member.role}
                </Badge>
                {member.status === 'pending' && (
                  <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
                    Pending
                  </Badge>
                )}
                {member.role !== 'owner' && (
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Role Permissions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Shield className="h-5 w-5" />
            Role Permissions
          </CardTitle>
          <CardDescription>Configure what each role can access</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-medium">Feature</th>
                  <th className="text-center py-3 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <Crown className="h-4 w-4 text-amber-500" />
                      Owner
                    </div>
                  </th>
                  <th className="text-center py-3 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <UserCog className="h-4 w-4 text-purple-500" />
                      Admin
                    </div>
                  </th>
                  <th className="text-center py-3 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <Pencil className="h-4 w-4 text-blue-500" />
                      Editor
                    </div>
                  </th>
                  <th className="text-center py-3 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <Eye className="h-4 w-4 text-muted-foreground" />
                      Viewer
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {permissionMatrix.map((item: any) => (
                  <tr key={item.key} className="border-b last:border-0 hover:bg-accent/30 transition-colors">
                    <td className="py-3 px-4 font-medium">{item.feature}</td>
                    {(['owner', 'admin', 'editor', 'viewer'] as const).map((role) => (
                      <td key={role} className="text-center py-3 px-4">
                        <Checkbox
                          checked={permissions[role][item.key]}
                          disabled={role === 'owner'}
                          onCheckedChange={(checked) => {
                            if (role !== 'owner') {
                              setPermissions((prev: any) => ({
                                ...prev,
                                [role]: { ...prev[role], [item.key]: checked },
                              }));
                            }
                          }}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Automation Section Component
function AutomationSection({
  campaignMode,
  setCampaignMode,
  skuMode,
  setSkuMode,
  dailyLimit,
  setDailyLimit,
  weeklyLimit,
  setWeeklyLimit,
  maxActionsPerDay,
  setMaxActionsPerDay,
}: any) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Automation</h2>
        <p className="text-muted-foreground mt-1">Configure AI behavior and automation guardrails</p>
      </div>

      {/* Automation Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Zap className="h-5 w-5 text-amber-500" />
            AI Automation Level
          </CardTitle>
          <CardDescription>Configure how AI handles optimizations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-base mb-4 block">Campaign Optimizations</Label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: 'auto', label: 'Fully Automatic', desc: 'AI makes changes without approval' },
                { value: 'rule-based', label: 'Rule-Based', desc: 'Follows your predefined rules' },
                { value: 'authorize', label: 'Manual Approval', desc: 'Review and approve each action' },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setCampaignMode(option.value)}
                  className={cn(
                    'p-4 rounded-lg border-2 text-left transition-all',
                    campaignMode === option.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50',
                  )}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className={cn(
                        'w-3 h-3 rounded-full',
                        campaignMode === option.value ? 'bg-primary' : 'bg-muted-foreground',
                      )}
                    />
                    <span className="font-medium text-sm">{option.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{option.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <Label className="text-base mb-4 block">Product/SKU Level Changes</Label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: 'auto', label: 'Fully Automatic', desc: 'AI makes changes without approval' },
                { value: 'rule-based', label: 'Rule-Based', desc: 'Follows your predefined rules' },
                { value: 'authorize', label: 'Manual Approval', desc: 'Review and approve each action' },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setSkuMode(option.value)}
                  className={cn(
                    'p-4 rounded-lg border-2 text-left transition-all',
                    skuMode === option.value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50',
                  )}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className={cn(
                        'w-3 h-3 rounded-full',
                        skuMode === option.value ? 'bg-primary' : 'bg-muted-foreground',
                      )}
                    />
                    <span className="font-medium text-sm">{option.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{option.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Guardrails & Limits */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Shield className="h-5 w-5 text-blue-500" />
            Guardrails & Limits
          </CardTitle>
          <CardDescription>Set boundaries for AI-driven actions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="daily-limit">Daily Spend Limit ($)</Label>
              <Input
                id="daily-limit"
                type="number"
                value={dailyLimit}
                onChange={(e) => setDailyLimit(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Maximum autonomous daily spend</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="weekly-limit">Weekly Spend Limit ($)</Label>
              <Input
                id="weekly-limit"
                type="number"
                value={weeklyLimit}
                onChange={(e) => setWeeklyLimit(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Maximum autonomous weekly spend</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="max-actions">Max Actions Per Day</Label>
              <Input
                id="max-actions"
                type="number"
                value={maxActionsPerDay}
                onChange={(e) => setMaxActionsPerDay(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Limit on daily automatic actions</p>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <Label className="text-base">Additional Safeguards</Label>
            <div className="space-y-3">
              {[
                { label: 'Require approval for spend changes > 20%', default: true },
                { label: 'Alert before pausing high-performing campaigns', default: true },
                { label: 'Prevent changes during peak hours', default: false },
                { label: 'Require dual approval for budget increases', default: false },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg border">
                  <span className="text-sm font-medium">{item.label}</span>
                  <Switch defaultChecked={item.default} />
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => toast.success('Automation settings saved')}>Save Automation Settings</Button>
      </div>
    </div>
  );
}

// Data & Privacy Section Component
function DataPrivacySection() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Data & Privacy</h2>
        <p className="text-muted-foreground mt-1">Manage your data, exports, and privacy settings</p>
      </div>

      {/* Data Export */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Download className="h-5 w-5" />
            Export Data
          </CardTitle>
          <CardDescription>Download your data in various formats</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {[
              { format: 'CSV', desc: 'Spreadsheet format', icon: FileText },
              { format: 'JSON', desc: 'Developer-friendly', icon: Database },
              { format: 'PDF', desc: 'Printable reports', icon: FileText },
              { format: 'Excel', desc: 'Microsoft Excel', icon: FileText },
            ].map((option) => (
              <button
                key={option.format}
                onClick={() => toast.success(`${option.format} export started`)}
                className="flex items-center gap-4 p-4 rounded-lg border hover:bg-accent/30 transition-all text-left"
              >
                <div className="p-2 rounded-lg bg-muted">
                  <option.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">{option.format}</p>
                  <p className="text-sm text-muted-foreground">{option.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Storage Usage */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <HardDrive className="h-5 w-5" />
            Storage Usage
          </CardTitle>
          <CardDescription>Monitor your data storage</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Used: 4.2 GB</span>
              <span>Total: 10 GB</span>
            </div>
            <Progress value={42} className="h-2" />
          </div>
          <div className="grid grid-cols-3 gap-4 pt-2">
            {[
              { label: 'Reports', size: '2.1 GB', color: 'bg-blue-500' },
              { label: 'Exports', size: '1.5 GB', color: 'bg-emerald-500' },
              { label: 'Backups', size: '0.6 GB', color: 'bg-amber-500' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2">
                <div className={cn('w-3 h-3 rounded-full', item.color)} />
                <div>
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.size}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Data Retention */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Archive className="h-5 w-5" />
            Data Retention
          </CardTitle>
          <CardDescription>Configure how long we keep your data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Keep historical data for</Label>
            <Select defaultValue="24">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6">6 months</SelectItem>
                <SelectItem value="12">12 months</SelectItem>
                <SelectItem value="24">24 months</SelectItem>
                <SelectItem value="36">36 months</SelectItem>
                <SelectItem value="forever">Forever</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div>
              <p className="font-medium">Auto-archive old data</p>
              <p className="text-sm text-muted-foreground">Automatically compress data older than retention period</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg text-destructive">
            <Trash className="h-5 w-5" />
            Danger Zone
          </CardTitle>
          <CardDescription>Irreversible actions - proceed with caution</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg border border-destructive/30 bg-destructive/5">
            <div>
              <p className="font-medium">Delete All Data</p>
              <p className="text-sm text-muted-foreground">Permanently delete all your analytics data</p>
            </div>
            <Button variant="destructive" size="sm">
              Delete Data
            </Button>
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg border border-destructive/30 bg-destructive/5">
            <div>
              <p className="font-medium">Delete Account</p>
              <p className="text-sm text-muted-foreground">Permanently delete your account and all associated data</p>
            </div>
            <Button variant="destructive" size="sm">
              Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Billing Section Component
function BillingSection() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Billing</h2>
          <p className="text-muted-foreground mt-1">Manage your subscription and payment methods</p>
        </div>
        <Link to="/billing-settings">
          <Button variant="outline" className="gap-2">
            <ExternalLink className="h-4 w-4" />
            Full Billing Dashboard
          </Button>
        </Link>
      </div>

      {/* Current Plan */}
      <Card className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <Badge className="mb-2 bg-primary text-primary-foreground">Current Plan</Badge>
              <h3 className="text-2xl font-bold flex items-center gap-2">
                Business Pro
                <Crown className="h-5 w-5 text-amber-500" />
              </h3>
              <p className="text-muted-foreground mt-1">$499/month • Billed annually</p>
              <p className="text-sm text-muted-foreground mt-2">
                Includes unlimited users, priority support, and advanced analytics
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Next billing date</p>
              <p className="font-semibold">January 15, 2025</p>
              <div className="flex gap-2 mt-3">
                <Button variant="outline" size="sm">
                  Change Plan
                </Button>
                <Button size="sm">Upgrade</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Plan Comparison */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Available Plans</CardTitle>
          <CardDescription>Compare features and choose the best plan for your needs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {[
              {
                name: 'Starter',
                price: '$99',
                features: ['5 team members', '10K API calls', 'Basic analytics'],
                current: false,
              },
              {
                name: 'Business Pro',
                price: '$499',
                features: ['Unlimited users', '100K API calls', 'Advanced analytics', 'Priority support'],
                current: true,
              },
              {
                name: 'Enterprise',
                price: 'Custom',
                features: ['Custom limits', 'Dedicated support', 'SLA guarantee', 'Custom integrations'],
                current: false,
              },
            ].map((plan) => (
              <div
                key={plan.name}
                className={cn(
                  'p-4 rounded-lg border-2 transition-all',
                  plan.current ? 'border-primary bg-primary/5' : 'border-border',
                )}
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold">{plan.name}</h4>
                  {plan.current && <Badge variant="secondary">Current</Badge>}
                </div>
                <p className="text-2xl font-bold mb-4">
                  {plan.price}
                  <span className="text-sm font-normal text-muted-foreground">/mo</span>
                </p>
                <ul className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-emerald-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Usage Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Usage This Month</CardTitle>
          <CardDescription>Track your resource consumption</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { label: 'API Calls', used: 45000, limit: 100000, unit: 'calls', icon: Zap },
            { label: 'Data Processed', used: 2.4, limit: 5, unit: 'GB', icon: Database },
            { label: 'Active Integrations', used: 8, limit: 15, unit: 'connections', icon: Plug },
            { label: 'Team Members', used: 4, limit: 10, unit: 'seats', icon: Users },
          ].map((item) => (
            <div key={item.label} className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <item.icon className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{item.label}</span>
                </div>
                <span className="text-muted-foreground">
                  {item.used.toLocaleString()} / {item.limit.toLocaleString()} {item.unit}
                </span>
              </div>
              <Progress value={(item.used / item.limit) * 100} className="h-2" />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Payment Method Summary */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg">
                <CreditCard className="h-5 w-5" />
                Payment Method
              </CardTitle>
              <CardDescription>Manage your payment options</CardDescription>
            </div>
            <Link to="/billing-settings">
              <Button variant="outline" size="sm">
                Manage
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/30">
            <div className="flex items-center gap-4">
              <div className="p-2 rounded bg-background">
                <CreditCard className="h-6 w-6" />
              </div>
              <div>
                <p className="font-medium">Visa •••• 4242</p>
                <p className="text-sm text-muted-foreground">Expires 12/2025</p>
              </div>
            </div>
            <Badge variant="secondary">Default</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Link to="/billing-settings" className="block">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-primary/10">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">View Invoices</p>
                <p className="text-sm text-muted-foreground">Download past invoices and receipts</p>
              </div>
              <ChevronRight className="h-5 w-5 ml-auto text-muted-foreground" />
            </CardContent>
          </Card>
        </Link>
        <Link to="/billing-settings" className="block">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-amber-500/10">
                <Crown className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <p className="font-medium">Upgrade Plan</p>
                <p className="text-sm text-muted-foreground">Get access to more features</p>
              </div>
              <ChevronRight className="h-5 w-5 ml-auto text-muted-foreground" />
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
