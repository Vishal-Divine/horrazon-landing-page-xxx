import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Activity,
  Users,
  DollarSign,
  MousePointerClick,
  Eye,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Code,
  Copy,
  Download,
  Settings,
  Smartphone,
  Monitor,
  Globe,
  ShieldCheck,
  Zap,
  Clock,
  Target,
  BarChart3,
  GitBranch,
  Layers,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Sankey,
  FunnelChart,
  Funnel,
  LabelList,
} from 'recharts';

// Real-time tracking data
const realTimeEvents = [
  {
    time: 'Just now',
    event: 'Page View',
    page: '/products/summer-dress',
    device: 'Mobile',
    country: 'US',
    value: null,
  },
  {
    time: '2s ago',
    event: 'Add to Cart',
    page: '/products/running-shoes',
    device: 'Desktop',
    country: 'UK',
    value: 89.99,
  },
  { time: '5s ago', event: 'Purchase', page: '/checkout/complete', device: 'Mobile', country: 'CA', value: 249.99 },
  { time: '8s ago', event: 'Page View', page: '/', device: 'Tablet', country: 'AU', value: null },
  {
    time: '12s ago',
    event: 'Add to Cart',
    page: '/products/headphones',
    device: 'Desktop',
    country: 'US',
    value: 199.99,
  },
  { time: '15s ago', event: 'Initiate Checkout', page: '/checkout', device: 'Mobile', country: 'US', value: 324.99 },
  {
    time: '18s ago',
    event: 'Page View',
    page: '/collections/new-arrivals',
    device: 'Mobile',
    country: 'DE',
    value: null,
  },
  { time: '22s ago', event: 'Purchase', page: '/checkout/complete', device: 'Desktop', country: 'US', value: 189.5 },
];

const pixelHealthData = {
  status: 'healthy',
  lastPing: '2 seconds ago',
  eventsToday: 124892,
  matchRate: 94.2,
  serverSideEvents: 89.4,
  browserEvents: 98.2,
  deduplicationRate: 12.4,
  avgLatency: 142,
};

const eventBreakdown = [
  { event: 'PageView', count: 84200, percentage: 42, trend: '+8%' },
  { event: 'AddToCart', count: 12400, percentage: 12, trend: '+14%' },
  { event: 'InitiateCheckout', count: 4800, percentage: 8, trend: '+6%' },
  { event: 'Purchase', count: 2840, percentage: 6, trend: '+12%' },
  { event: 'ViewContent', count: 28400, percentage: 24, trend: '+4%' },
  { event: 'Search', count: 8200, percentage: 8, trend: '+18%' },
];

const customerJourneyData = [
  { name: 'Awareness', value: 100000, fill: 'hsl(var(--chart-1))' },
  { name: 'Interest', value: 48000, fill: 'hsl(var(--chart-2))' },
  { name: 'Consideration', value: 24000, fill: 'hsl(var(--chart-3))' },
  { name: 'Intent', value: 12000, fill: 'hsl(var(--chart-4))' },
  { name: 'Purchase', value: 4800, fill: 'hsl(var(--chart-5))' },
];

const cohortData = [
  { cohort: 'Jan 2024', week1: 100, week2: 42, week3: 28, week4: 22, ltv: 124 },
  { cohort: 'Feb 2024', week1: 100, week2: 45, week3: 32, week4: 26, ltv: 138 },
  { cohort: 'Mar 2024', week1: 100, week2: 48, week3: 35, week4: 29, ltv: 152 },
  { cohort: 'Apr 2024', week1: 100, week2: 52, week3: 38, week4: 32, ltv: 168 },
  { cohort: 'May 2024', week1: 100, week2: 54, week3: 41, week4: 35, ltv: 178 },
];

const trafficSources = [
  { source: 'Meta Ads', sessions: 42800, conversions: 1240, revenue: 124800, convRate: 2.9 },
  { source: 'Google Ads', sessions: 38200, conversions: 980, revenue: 98400, convRate: 2.6 },
  { source: 'Direct', sessions: 24800, conversions: 720, revenue: 68400, convRate: 2.9 },
  { source: 'Organic', sessions: 18400, conversions: 420, revenue: 38200, convRate: 2.3 },
  { source: 'Email', sessions: 12400, conversions: 380, revenue: 42800, convRate: 3.1 },
  { source: 'TikTok', sessions: 8200, conversions: 280, revenue: 24200, convRate: 3.4 },
];

const deviceData = [
  { device: 'Mobile', sessions: 68400, percentage: 58, conversions: 1820, convRate: 2.7 },
  { device: 'Desktop', sessions: 42200, percentage: 36, conversions: 1420, convRate: 3.4 },
  { device: 'Tablet', sessions: 7200, percentage: 6, conversions: 180, convRate: 2.5 },
];

const eventTrendData = [
  { time: '12 AM', pageViews: 2400, addToCart: 120, purchases: 28 },
  { time: '4 AM', pageViews: 1200, addToCart: 60, purchases: 12 },
  { time: '8 AM', pageViews: 4800, addToCart: 280, purchases: 68 },
  { time: '12 PM', pageViews: 8200, addToCart: 420, purchases: 124 },
  { time: '4 PM', pageViews: 9800, addToCart: 520, purchases: 168 },
  { time: '8 PM', pageViews: 12400, addToCart: 680, purchases: 224 },
];

const profitCalculatorData = {
  revenue: 248900,
  cogs: 99560,
  adSpend: 42800,
  shippingCost: 18200,
  transactionFees: 7467,
  grossProfit: 80873,
  profitMargin: 32.5,
  netROAS: 5.81,
  breakEvenROAS: 2.8,
};

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function PixelTracking() {
  const [showCode, setShowCode] = useState(false);

  const pixelCode = `<!-- Horrazon First-Party Pixel -->
<script>
  !function(q,i,p,x,e,l){q.HZ=q.HZ||function(){
    (q.HZ.q=q.HZ.q||[]).push(arguments)};
    q.HZ.l=1*new Date();e=i.createElement(p);
    l=i.getElementsByTagName(p)[0];e.async=1;
    e.src=x;l.parentNode.insertBefore(e,l)
  }(window,document,'script','https://pixel.horrazon.ai/hz.js');
  
  HZ('init', 'HZ-XXXXXXXX');
  HZ('track', 'PageView');
</script>`;

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">First-Party Pixel Tracking</h1>
          <p className="text-muted-foreground">Real-time customer tracking, journey analytics & profit calculation</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setShowCode(!showCode)}>
            <Code className="h-4 w-4" />
            {showCode ? 'Hide Code' : 'View Pixel Code'}
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Data
          </Button>
          <Button className="gap-2">
            <Settings className="h-4 w-4" />
            Configure Pixel
          </Button>
        </div>
      </div>

      {/* Pixel Code Display */}
      {showCode && (
        <Card className="border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Pixel Installation Code</CardTitle>
            <Button variant="ghost" size="sm" className="gap-2">
              <Copy className="h-4 w-4" />
              Copy Code
            </Button>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted/50 p-4 rounded-lg text-xs overflow-x-auto">
              <code>{pixelCode}</code>
            </pre>
          </CardContent>
        </Card>
      )}

      {/* Pixel Health Status */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card
          className={`border-2 ${pixelHealthData.status === 'healthy' ? 'border-success/50' : 'border-destructive/50'}`}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              {pixelHealthData.status === 'healthy' ? (
                <CheckCircle2 className="h-10 w-10 text-success" />
              ) : (
                <XCircle className="h-10 w-10 text-destructive" />
              )}
              <div>
                <p className="text-sm text-muted-foreground">Pixel Status</p>
                <p className="text-xl font-bold capitalize">{pixelHealthData.status}</p>
                <p className="text-xs text-muted-foreground">Last ping: {pixelHealthData.lastPing}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Events Today</p>
                <p className="text-2xl font-bold">{(pixelHealthData.eventsToday / 1000).toFixed(1)}K</p>
              </div>
              <Activity className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+12% vs yesterday</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Match Rate</p>
                <p className="text-2xl font-bold">{pixelHealthData.matchRate}%</p>
              </div>
              <Target className="h-8 w-8 text-chart-2" />
            </div>
            <Progress value={pixelHealthData.matchRate} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Server-Side</p>
                <p className="text-2xl font-bold">{pixelHealthData.serverSideEvents}%</p>
              </div>
              <ShieldCheck className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Post-iOS14 compliant</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Deduplication</p>
                <p className="text-2xl font-bold">{pixelHealthData.deduplicationRate}%</p>
              </div>
              <Layers className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-success">Duplicate events filtered</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Latency</p>
                <p className="text-2xl font-bold">{pixelHealthData.avgLatency}ms</p>
              </div>
              <Clock className="h-8 w-8 text-chart-5" />
            </div>
            <p className="mt-2 text-xs text-success">Excellent performance</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="realtime" className="space-y-6">
        <TabsList>
          <TabsTrigger value="realtime">Real-Time Events</TabsTrigger>
          <TabsTrigger value="journey">Customer Journey</TabsTrigger>
          <TabsTrigger value="cohorts">Cohort Analysis</TabsTrigger>
          <TabsTrigger value="profit">Profit Calculator</TabsTrigger>
          <TabsTrigger value="sources">Traffic Sources</TabsTrigger>
          <TabsTrigger value="events">Event Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="realtime" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-success"></span>
                    </span>
                    Live Event Stream
                  </CardTitle>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Auto-refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[400px] overflow-auto">
                  {realTimeEvents.map((event, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-lg border border-border bg-muted/30 p-3 transition-all hover:border-primary/50"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`rounded-full p-2 ${
                            event.event === 'Purchase'
                              ? 'bg-success/10'
                              : event.event === 'Add to Cart'
                                ? 'bg-chart-1/10'
                                : event.event === 'Initiate Checkout'
                                  ? 'bg-chart-2/10'
                                  : 'bg-muted'
                          }`}
                        >
                          {event.event === 'Purchase' ? (
                            <DollarSign className="h-4 w-4 text-success" />
                          ) : event.event === 'Add to Cart' ? (
                            <MousePointerClick className="h-4 w-4 text-chart-1" />
                          ) : event.event === 'Initiate Checkout' ? (
                            <Target className="h-4 w-4 text-chart-2" />
                          ) : (
                            <Eye className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{event.event}</span>
                            <Badge variant="outline" className="text-xs">
                              {event.device}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground truncate max-w-[200px]">{event.page}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        {event.value && <p className="font-bold text-success">${event.value.toFixed(2)}</p>}
                        <p className="text-xs text-muted-foreground">
                          {event.time} • {event.country}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Event Distribution Today</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {eventBreakdown.map((item, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{item.event}</span>
                          <Badge variant="outline" className="text-xs text-success">
                            {item.trend}
                          </Badge>
                        </div>
                        <span className="text-sm font-bold">{item.count.toLocaleString()}</span>
                      </div>
                      <Progress value={item.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Event Trend (Today)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={eventTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="pageViews"
                    stackId="1"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.3}
                    name="Page Views"
                  />
                  <Area
                    type="monotone"
                    dataKey="addToCart"
                    stackId="2"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.3}
                    name="Add to Cart"
                  />
                  <Area
                    type="monotone"
                    dataKey="purchases"
                    stackId="3"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    fillOpacity={0.3}
                    name="Purchases"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="journey" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Customer Journey Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {customerJourneyData.map((stage, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{stage.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold">{stage.value.toLocaleString()}</span>
                          {i > 0 && (
                            <Badge variant="outline" className="text-xs">
                              {((stage.value / customerJourneyData[i - 1].value) * 100).toFixed(0)}% conv
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="h-8 rounded-lg transition-all"
                        style={{
                          width: `${(stage.value / customerJourneyData[0].value) * 100}%`,
                          backgroundColor: stage.fill,
                        }}
                      />
                    </div>
                  ))}
                </div>
                <div className="mt-6 p-4 rounded-lg bg-muted/50">
                  <p className="text-sm font-medium">Overall Conversion Rate</p>
                  <p className="text-3xl font-bold text-success">
                    {((customerJourneyData[4].value / customerJourneyData[0].value) * 100).toFixed(2)}%
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Device Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {deviceData.map((device, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 rounded-lg border border-border bg-muted/30">
                      <div className="rounded-full p-3 bg-primary/10">
                        {device.device === 'Mobile' ? (
                          <Smartphone className="h-6 w-6 text-primary" />
                        ) : device.device === 'Desktop' ? (
                          <Monitor className="h-6 w-6 text-primary" />
                        ) : (
                          <Globe className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{device.device}</span>
                          <span className="text-sm font-bold">{device.percentage}%</span>
                        </div>
                        <Progress value={device.percentage} className="h-2" />
                        <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                          <span>{device.sessions.toLocaleString()} sessions</span>
                          <span>{device.convRate}% conv rate</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cohorts" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Cohort Retention Analysis</CardTitle>
                <Select defaultValue="weekly">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cohort</TableHead>
                    <TableHead className="text-center">Week 1</TableHead>
                    <TableHead className="text-center">Week 2</TableHead>
                    <TableHead className="text-center">Week 3</TableHead>
                    <TableHead className="text-center">Week 4</TableHead>
                    <TableHead className="text-center">LTV</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cohortData.map((row, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{row.cohort}</TableCell>
                      <TableCell className="text-center">
                        <div className="mx-auto h-8 w-16 rounded flex items-center justify-center bg-chart-1 text-white font-medium">
                          {row.week1}%
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div
                          className="mx-auto h-8 w-16 rounded flex items-center justify-center text-white font-medium"
                          style={{ backgroundColor: `hsl(var(--chart-1) / ${row.week2 / 100})` }}
                        >
                          {row.week2}%
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div
                          className="mx-auto h-8 w-16 rounded flex items-center justify-center text-white font-medium"
                          style={{ backgroundColor: `hsl(var(--chart-1) / ${row.week3 / 100})` }}
                        >
                          {row.week3}%
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div
                          className="mx-auto h-8 w-16 rounded flex items-center justify-center text-white font-medium"
                          style={{ backgroundColor: `hsl(var(--chart-1) / ${row.week4 / 100})` }}
                        >
                          {row.week4}%
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-bold text-success">${row.ltv}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cohort LTV Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={cohortData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="cohort" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                    formatter={(value) => [`$${value}`, 'LTV']}
                  />
                  <Bar dataKey="ltv" fill="hsl(var(--chart-1))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profit" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Profit Calculator
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-success/10">
                    <span className="font-medium">Total Revenue</span>
                    <span className="text-xl font-bold text-success">
                      ${profitCalculatorData.revenue.toLocaleString()}
                    </span>
                  </div>

                  <div className="border-l-4 border-destructive/50 pl-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Cost of Goods Sold</span>
                      <span className="font-medium text-destructive">
                        -${profitCalculatorData.cogs.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Ad Spend</span>
                      <span className="font-medium text-destructive">
                        -${profitCalculatorData.adSpend.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Shipping Costs</span>
                      <span className="font-medium text-destructive">
                        -${profitCalculatorData.shippingCost.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Transaction Fees</span>
                      <span className="font-medium text-destructive">
                        -${profitCalculatorData.transactionFees.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-chart-1/10 border-t-2 border-chart-1">
                    <span className="font-medium">Gross Profit</span>
                    <span className="text-xl font-bold text-chart-1">
                      ${profitCalculatorData.grossProfit.toLocaleString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 rounded-lg border border-border bg-muted/30">
                    <p className="text-sm text-muted-foreground">Profit Margin</p>
                    <p className="text-3xl font-bold">{profitCalculatorData.profitMargin}%</p>
                    <Progress value={profitCalculatorData.profitMargin} className="mt-2 h-2" />
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-muted/30">
                    <p className="text-sm text-muted-foreground">Net ROAS</p>
                    <p className="text-3xl font-bold text-success">{profitCalculatorData.netROAS}x</p>
                    <p className="text-xs text-muted-foreground mt-1">After all costs</p>
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-muted/30">
                    <p className="text-sm text-muted-foreground">Break-Even ROAS</p>
                    <p className="text-3xl font-bold">{profitCalculatorData.breakEvenROAS}x</p>
                    <p className="text-xs text-muted-foreground mt-1">Minimum to be profitable</p>
                  </div>
                  <div className="p-4 rounded-lg border border-success bg-success/10">
                    <p className="text-sm text-muted-foreground">Profit per Order</p>
                    <p className="text-3xl font-bold text-success">$28.47</p>
                    <p className="text-xs text-muted-foreground mt-1">Avg across all orders</p>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-gradient-to-r from-primary/10 to-chart-1/10 border border-primary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="h-5 w-5 text-primary" />
                    <span className="font-medium">AI Insight</span>
                  </div>
                  <p className="text-sm">
                    Your profit margin of {profitCalculatorData.profitMargin}% is above industry average (28%). Consider
                    reinvesting 15% of profits into scaling high-ROAS campaigns.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sources" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Traffic Source Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source</TableHead>
                    <TableHead className="text-right">Sessions</TableHead>
                    <TableHead className="text-right">Conversions</TableHead>
                    <TableHead className="text-right">Conv. Rate</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">% of Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {trafficSources.map((source, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{source.source}</TableCell>
                      <TableCell className="text-right">{source.sessions.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{source.conversions.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant="outline" className={source.convRate > 3 ? 'text-success border-success' : ''}>
                          {source.convRate}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-bold">${source.revenue.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Progress
                            value={(source.revenue / trafficSources.reduce((a, b) => a + b.revenue, 0)) * 100}
                            className="w-16 h-2"
                          />
                          <span className="text-sm">
                            {((source.revenue / trafficSources.reduce((a, b) => a + b.revenue, 0)) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Event Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {['PageView', 'ViewContent', 'AddToCart', 'InitiateCheckout', 'AddPaymentInfo', 'Purchase'].map(
                  (event, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-lg border border-border hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">{event}</span>
                        <Badge variant="outline" className="text-success border-success">
                          Active
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>Last 24h</span>
                        <span className="font-medium text-foreground">
                          {Math.floor(Math.random() * 10000 + 1000).toLocaleString()} events
                        </span>
                      </div>
                    </div>
                  ),
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
