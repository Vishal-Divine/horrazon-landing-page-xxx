import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  RefreshCw,
  Download,
  Filter,
  MoreHorizontal,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Zap,
  Target,
  PieChart,
  BarChart3,
  ArrowRight,
  Shield,
  CreditCard,
  Building,
  Send,
  Pause,
  Play,
  Eye,
  Settings,
  Bell,
  ChevronRight,
  Sparkles,
  Activity,
  CircleDollarSign,
  Landmark,
  Receipt,
  History,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { format, subDays, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { toast } from '@/hooks/use-toast';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart as RechartsPie,
  Pie,
  Cell,
} from 'recharts';
import { cn } from '@/lib/utils';
import { useLoading } from '@/hooks/useLoading';
import { WalletSkeleton } from '@/components/skeletons';
import {
  BudgetForecastCard,
  SpendingInsightsCard,
  QuickPaymentMethods,
  WalletQuickActions,
  FinancialHealthScore,
  SavingsGoalsCard,
  MoneyFlowWidget,
  VirtualCardsManager,
  SmartBudgetAutopilot,
  RecurringPaymentsManager,
  SpendingAnomalyDetector,
  CashFlowPredictor,
  WalletOverviewHub,
  TransactionHistoryAdvanced,
  SpendingLimitsManager,
  CurrencyConverterWidget,
  PaymentSecurityCenter,
  WalletFeatureTabs,
  AIFinancialAdvisor,
  AISmartAlerts,
  AIInsightsPanel,
  WalletConnectionsPanel,
  WalletSyncLogs,
  WalletDataMapping,
} from '@/components/wallet';

// Mock spending data for charts
const spendingTrendData = Array.from({ length: 30 }, (_, i) => ({
  date: format(subDays(new Date(), 29 - i), 'MMM dd'),
  spending: Math.floor(Math.random() * 500) + 200,
  budget: 450,
}));

const platformSpendData = [
  { name: 'Meta Ads', value: 4520, color: 'hsl(var(--chart-1))' },
  { name: 'Google Ads', value: 2840, color: 'hsl(var(--chart-2))' },
  { name: 'TikTok Ads', value: 1250, color: 'hsl(var(--chart-3))' },
  { name: 'LinkedIn Ads', value: 1890, color: 'hsl(var(--chart-4))' },
];

const weeklySpendData = [
  { week: 'Week 1', meta: 1200, google: 800, tiktok: 400, linkedin: 500 },
  { week: 'Week 2', meta: 1400, google: 900, tiktok: 350, linkedin: 450 },
  { week: 'Week 3', meta: 1100, google: 750, tiktok: 300, linkedin: 600 },
  { week: 'Week 4', meta: 820, google: 390, tiktok: 200, linkedin: 340 },
];

// Fund allocation presets
const allocationPresets = [
  {
    id: 'balanced',
    name: 'Balanced',
    meta: 40,
    google: 30,
    tiktok: 15,
    linkedin: 15,
  },
  {
    id: 'meta-heavy',
    name: 'Meta Heavy',
    meta: 60,
    google: 25,
    tiktok: 10,
    linkedin: 5,
  },
  {
    id: 'google-focus',
    name: 'Google Focus',
    meta: 25,
    google: 50,
    tiktok: 15,
    linkedin: 10,
  },
  { id: 'custom', name: 'Custom', meta: 0, google: 0, tiktok: 0, linkedin: 0 },
];

export default function WalletPage() {
  const {
    wallet,
    transactions,
    campaignSpends,
    setIsAddFundsOpen,
    refreshWallet,
    spendingAlerts,
    acknowledgeAlert,
    isLoading: appLoading,
  } = useApp();
  const [dateRange, setDateRange] = useState('30d');
  const [transactionFilter, setTransactionFilter] = useState('all');
  const [selectedPreset, setSelectedPreset] = useState('balanced');
  const [customAllocation, setCustomAllocation] = useState({
    meta: 40,
    google: 30,
    tiktok: 15,
    linkedin: 15,
  });
  const [transferAmount, setTransferAmount] = useState('');
  const [selectedCampaign, setSelectedCampaign] = useState('');
  const [activeFeatureTab, setActiveFeatureTab] = useState('connections');
  const isLoading = useLoading(600);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatCompactCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`;
    return `$${amount.toFixed(0)}`;
  };

  // Calculate stats
  const avgDailySpend = wallet.monthlySpent / 30;
  const runwayDays = Math.floor(wallet.balance / (avgDailySpend || 1));
  const projectedMonthlySpend = avgDailySpend * 30;
  const spendingTrend = ((wallet.monthlySpent - wallet.totalSpent * 0.2) / (wallet.totalSpent * 0.2)) * 100;

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (transactionFilter === 'all') return true;
      return tx.type === transactionFilter;
    });
  }, [transactions, transactionFilter]);

  // Active alerts count
  const activeAlertsCount = spendingAlerts.filter((a) => !a.acknowledged).length;

  // Get risk color
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'critical':
        return 'text-destructive bg-destructive/10';
      case 'high':
        return 'text-orange-500 bg-orange-500/10';
      case 'medium':
        return 'text-amber-500 bg-amber-500/10';
      default:
        return 'text-emerald-500 bg-emerald-500/10';
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'meta':
        return '📘';
      case 'google':
        return '🎯';
      case 'tiktok':
        return '🎵';
      case 'linkedin':
        return '💼';
      default:
        return '📊';
    }
  };

  const handleTransferFunds = () => {
    if (!transferAmount || !selectedCampaign) {
      toast({
        title: 'Error',
        description: 'Please select campaign and enter amount',
        variant: 'destructive',
      });
      return;
    }
    toast({
      title: 'Funds Allocated',
      description: `${formatCurrency(parseFloat(transferAmount))} allocated to ${selectedCampaign}`,
    });
    setTransferAmount('');
    setSelectedCampaign('');
  };

  if (isLoading) {
    return <WalletSkeleton />;
  }

  return (
    <div className="space-y-6 p-8 animate-fade-in">
      <SEOHead
        title="Campaign Wallet"
        description="Manage your advertising spend, fund campaigns, and track budget allocations across all marketing platforms."
        keywords="campaign wallet, ad spend management, budget allocation, marketing budget, advertising funds"
      />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10">
              <Wallet className="h-7 w-7 text-primary" />
            </div>
            Campaign Wallet
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your advertising spend, fund campaigns, and track allocations
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={() => refreshWallet()} disabled={appLoading}>
            <RefreshCw className={cn('h-4 w-4 mr-2', appLoading && 'animate-spin')} />
            Refresh
          </Button>
          <Button onClick={() => setIsAddFundsOpen(true)} className="gap-2 bg-gradient-to-r from-primary to-primary/80">
            <Plus className="h-4 w-4" />
            Add Funds
          </Button>
        </div>
      </div>

      {/* Active Alerts Banner */}
      {activeAlertsCount > 0 && (
        <Card className="border-amber-500/50 bg-amber-500/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-amber-500/20">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <p className="font-medium text-amber-600">
                    {activeAlertsCount} Active Alert
                    {activeAlertsCount > 1 ? 's' : ''}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {spendingAlerts.find((a) => !a.acknowledged)?.message}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => acknowledgeAlert(spendingAlerts.find((a) => !a.acknowledged)?.id || '')}
                >
                  Dismiss
                </Button>
                <Button size="sm" onClick={() => setIsAddFundsOpen(true)}>
                  Add Funds
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Primary Hub Row - Wallet Overview + Quick Actions */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <WalletOverviewHub />
        </div>
        <div className="space-y-6">
          <WalletQuickActions
            onAddFunds={() => setIsAddFundsOpen(true)}
            pendingAmount={wallet.pendingCharges}
            recentActivityCount={transactions.filter((t) => t.status === 'pending').length}
          />
          <CurrencyConverterWidget />
        </div>
      </div>

      {/* Feature Tabs Row - Like Reference Image */}
      <Card className="border-border/50 bg-card/50">
        <CardContent className="p-4">
          <WalletFeatureTabs activeTab={activeFeatureTab} onTabChange={setActiveFeatureTab} />
        </CardContent>
      </Card>

      {/* Feature Tab Content */}
      {activeFeatureTab === 'connections' && <WalletConnectionsPanel />}
      {activeFeatureTab === 'ai-advisor' && <AIFinancialAdvisor />}
      {activeFeatureTab === 'alerts' && <AISmartAlerts />}
      {activeFeatureTab === 'sync-logs' && <WalletSyncLogs />}
      {activeFeatureTab === 'data-mapping' && <WalletDataMapping />}
      {activeFeatureTab === 'security' && <PaymentSecurityCenter />}
      {activeFeatureTab === 'insights' && <AIInsightsPanel />}

      {/* Analytics & Predictions Row */}
      <div className="grid gap-6 lg:grid-cols-3">
        <CashFlowPredictor />
        <SpendingAnomalyDetector />
        <SpendingInsightsCard />
      </div>

      {/* Budget Management Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        <SpendingLimitsManager />
        <BudgetForecastCard />
      </div>

      {/* Smart Automation Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        <SmartBudgetAutopilot />
        <RecurringPaymentsManager />
      </div>

      {/* Security & Financial Health Row */}
      <div className="grid gap-6 lg:grid-cols-3">
        <FinancialHealthScore />
        <SavingsGoalsCard />
        <MoneyFlowWidget />
      </div>

      {/* Transaction History - Full Width */}
      <TransactionHistoryAdvanced />

      {/* Cards Row */}
      <VirtualCardsManager />

      {/* Main Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="overview" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="gap-2">
            <Target className="h-4 w-4" />
            Campaign Funding
          </TabsTrigger>
          <TabsTrigger value="transactions" className="gap-2">
            <History className="h-4 w-4" />
            Transactions
          </TabsTrigger>
          <TabsTrigger value="allocations" className="gap-2">
            <PieChart className="h-4 w-4" />
            Allocations
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2">
            <Settings className="h-4 w-4" />
            Wallet Settings
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Spending Trend Chart */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Spending Trend</CardTitle>
                    <CardDescription>Daily advertising spend over time</CardDescription>
                  </div>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7d">Last 7 days</SelectItem>
                      <SelectItem value="30d">Last 30 days</SelectItem>
                      <SelectItem value="90d">Last 90 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={spendingTrendData}>
                      <defs>
                        <linearGradient id="colorSpending" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <YAxis
                        className="text-xs"
                        tick={{ fill: 'hsl(var(--muted-foreground))' }}
                        tickFormatter={(v) => `$${v}`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                        formatter={(value: number) => [formatCurrency(value), 'Spending']}
                      />
                      <Area
                        type="monotone"
                        dataKey="spending"
                        stroke="hsl(var(--primary))"
                        fillOpacity={1}
                        fill="url(#colorSpending)"
                        strokeWidth={2}
                      />
                      <Line
                        type="monotone"
                        dataKey="budget"
                        stroke="hsl(var(--muted-foreground))"
                        strokeDasharray="5 5"
                        strokeWidth={1}
                        dot={false}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Platform Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Platform Distribution</CardTitle>
                <CardDescription>Spend by advertising platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48 mb-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPie>
                      <Pie
                        data={platformSpendData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {platformSpendData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2">
                  {platformSpendData.map((platform) => (
                    <div key={platform.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: platform.color }} />
                        <span>{platform.name}</span>
                      </div>
                      <span className="font-medium">{formatCurrency(platform.value)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Campaign Health Overview */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Campaign Health</CardTitle>
                  <CardDescription>Budget utilization and risk assessment</CardDescription>
                </div>
                <Link to="/budget">
                  <Button variant="outline" size="sm">
                    View All <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {campaignSpends.map((campaign) => (
                  <div key={campaign.id} className="p-4 rounded-lg border hover:bg-accent/30 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{getPlatformIcon(campaign.platform)}</span>
                        <div>
                          <p className="font-medium">{campaign.name}</p>
                          <p className="text-sm text-muted-foreground">{campaign.platform}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className={getRiskColor(campaign.riskLevel)}>
                          {campaign.riskLevel.toUpperCase()}
                        </Badge>
                        <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                          {campaign.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Budget Used</span>
                        <span className="font-medium">
                          {formatCurrency(campaign.spent)} / {formatCurrency(campaign.budget)}
                        </span>
                      </div>
                      <Progress value={(campaign.spent / campaign.budget) * 100} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{Math.round((campaign.spent / campaign.budget) * 100)}% used</span>
                        <span>{campaign.daysRemaining} days remaining</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Campaign Funding Tab */}
        <TabsContent value="campaigns" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Fund Transfer Card */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Send className="h-5 w-5" />
                  Allocate Funds
                </CardTitle>
                <CardDescription>Transfer funds to campaigns</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <p className="text-sm text-muted-foreground">Available Balance</p>
                  <p className="text-2xl font-bold text-primary">{formatCurrency(wallet.balance)}</p>
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label>Select Campaign</Label>
                    <Select value={selectedCampaign} onValueChange={setSelectedCampaign}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a campaign" />
                      </SelectTrigger>
                      <SelectContent>
                        {campaignSpends.map((campaign) => (
                          <SelectItem key={campaign.id} value={campaign.name}>
                            <div className="flex items-center gap-2">
                              <span>{getPlatformIcon(campaign.platform)}</span>
                              <span>{campaign.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Amount</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={transferAmount}
                        onChange={(e) => setTransferAmount(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {[500, 1000, 2500].map((amount) => (
                      <Button
                        key={amount}
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => setTransferAmount(amount.toString())}
                      >
                        ${amount}
                      </Button>
                    ))}
                  </div>

                  <Button className="w-full" onClick={handleTransferFunds}>
                    <Send className="h-4 w-4 mr-2" />
                    Allocate Funds
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Campaign List */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Active Campaigns</CardTitle>
                    <CardDescription>Manage campaign budgets and funding</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    New Campaign
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Budget</TableHead>
                      <TableHead>Spent</TableHead>
                      <TableHead>Daily</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {campaignSpends.map((campaign) => (
                      <TableRow key={campaign.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{getPlatformIcon(campaign.platform)}</span>
                            <div>
                              <p className="font-medium">{campaign.name}</p>
                              <p className="text-xs text-muted-foreground">{campaign.platform}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(campaign.budget)}</TableCell>
                        <TableCell>
                          <div>
                            <p>{formatCurrency(campaign.spent)}</p>
                            <p className="text-xs text-muted-foreground">
                              {Math.round((campaign.spent / campaign.budget) * 100)}%
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(campaign.dailyBudget)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={campaign.status === 'active' ? 'default' : 'secondary'}
                            className={
                              campaign.status === 'active'
                                ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                                : ''
                            }
                          >
                            {campaign.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Plus className="h-4 w-4 mr-2" />
                                Add Funds
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                {campaign.status === 'active' ? (
                                  <>
                                    <Pause className="h-4 w-4 mr-2" />
                                    Pause
                                  </>
                                ) : (
                                  <>
                                    <Play className="h-4 w-4 mr-2" />
                                    Resume
                                  </>
                                )}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Weekly Platform Spending */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Weekly Spending by Platform</CardTitle>
              <CardDescription>Compare spending across platforms over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklySpendData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="week" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `$${v}`} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => formatCurrency(value)}
                    />
                    <Bar dataKey="meta" name="Meta" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="google" name="Google" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="tiktok" name="TikTok" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="linkedin" name="LinkedIn" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Receipt className="h-5 w-5" />
                    Transaction History
                  </CardTitle>
                  <CardDescription>View all wallet transactions and campaign charges</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Select value={transactionFilter} onValueChange={setTransactionFilter}>
                    <SelectTrigger className="w-32">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="credit">Credits</SelectItem>
                      <SelectItem value="debit">Debits</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {filteredTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent/30 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div
                          className={cn(
                            'p-2.5 rounded-full',
                            tx.type === 'credit'
                              ? 'bg-emerald-500/10 text-emerald-500'
                              : 'bg-destructive/10 text-destructive',
                          )}
                        >
                          {tx.type === 'credit' ? (
                            <ArrowDownLeft className="h-5 w-5" />
                          ) : (
                            <ArrowUpRight className="h-5 w-5" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{tx.description}</p>
                          {tx.campaign && <p className="text-sm text-muted-foreground">{tx.campaign}</p>}
                          <p className="text-xs text-muted-foreground">{format(tx.date, "MMM d, yyyy 'at' h:mm a")}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p
                          className={cn(
                            'font-semibold text-lg',
                            tx.type === 'credit' ? 'text-emerald-500' : 'text-destructive',
                          )}
                        >
                          {tx.type === 'credit' ? '+' : '-'}
                          {formatCurrency(tx.amount)}
                        </p>
                        <Badge
                          variant={
                            tx.status === 'completed'
                              ? 'secondary'
                              : tx.status === 'pending'
                                ? 'outline'
                                : 'destructive'
                          }
                          className="text-[10px]"
                        >
                          {tx.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Allocations Tab */}
        <TabsContent value="allocations" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Allocation Presets */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Sparkles className="h-5 w-5" />
                  Smart Allocation
                </CardTitle>
                <CardDescription>Choose or customize your budget distribution</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {allocationPresets.slice(0, -1).map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => {
                        setSelectedPreset(preset.id);
                        setCustomAllocation({
                          meta: preset.meta,
                          google: preset.google,
                          tiktok: preset.tiktok,
                          linkedin: preset.linkedin,
                        });
                      }}
                      className={cn(
                        'p-4 rounded-lg border-2 text-left transition-all',
                        selectedPreset === preset.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50',
                      )}
                    >
                      <p className="font-medium">{preset.name}</p>
                      <div className="mt-2 flex gap-1">
                        <div className="h-2 rounded-full bg-chart-1" style={{ width: `${preset.meta}%` }} />
                        <div className="h-2 rounded-full bg-chart-2" style={{ width: `${preset.google}%` }} />
                        <div className="h-2 rounded-full bg-chart-3" style={{ width: `${preset.tiktok}%` }} />
                        <div className="h-2 rounded-full bg-chart-4" style={{ width: `${preset.linkedin}%` }} />
                      </div>
                    </button>
                  ))}
                </div>

                <Separator />

                <div className="space-y-4">
                  <p className="font-medium">Custom Allocation</p>
                  {[
                    { key: 'meta', label: 'Meta Ads', color: 'chart-1' },
                    { key: 'google', label: 'Google Ads', color: 'chart-2' },
                    { key: 'tiktok', label: 'TikTok Ads', color: 'chart-3' },
                    {
                      key: 'linkedin',
                      label: 'LinkedIn Ads',
                      color: 'chart-4',
                    },
                  ].map((platform) => (
                    <div key={platform.key} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>{platform.label}</Label>
                        <span className="text-sm font-medium">
                          {customAllocation[platform.key as keyof typeof customAllocation]}%
                        </span>
                      </div>
                      <Input
                        type="range"
                        min="0"
                        max="100"
                        value={customAllocation[platform.key as keyof typeof customAllocation]}
                        onChange={(e) => {
                          setCustomAllocation((prev) => ({
                            ...prev,
                            [platform.key]: parseInt(e.target.value),
                          }));
                          setSelectedPreset('custom');
                        }}
                        className="w-full"
                      />
                    </div>
                  ))}

                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex justify-between text-sm">
                      <span>Total Allocation</span>
                      <span
                        className={cn(
                          'font-medium',
                          customAllocation.meta +
                            customAllocation.google +
                            customAllocation.tiktok +
                            customAllocation.linkedin ===
                            100
                            ? 'text-emerald-500'
                            : 'text-destructive',
                        )}
                      >
                        {customAllocation.meta +
                          customAllocation.google +
                          customAllocation.tiktok +
                          customAllocation.linkedin}
                        %
                      </span>
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    onClick={() =>
                      toast({
                        title: 'Allocation Saved',
                        description: 'Your budget allocation has been updated.',
                      })
                    }
                  >
                    Apply Allocation
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Current Allocation Visual */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Current Allocation</CardTitle>
                <CardDescription>How your budget is distributed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPie>
                      <Pie
                        data={[
                          {
                            name: 'Meta',
                            value: customAllocation.meta,
                            color: 'hsl(var(--chart-1))',
                          },
                          {
                            name: 'Google',
                            value: customAllocation.google,
                            color: 'hsl(var(--chart-2))',
                          },
                          {
                            name: 'TikTok',
                            value: customAllocation.tiktok,
                            color: 'hsl(var(--chart-3))',
                          },
                          {
                            name: 'LinkedIn',
                            value: customAllocation.linkedin,
                            color: 'hsl(var(--chart-4))',
                          },
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={3}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {[
                          { color: 'hsl(var(--chart-1))' },
                          { color: 'hsl(var(--chart-2))' },
                          { color: 'hsl(var(--chart-3))' },
                          { color: 'hsl(var(--chart-4))' },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => `${value}%`} />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-3">
                  {[
                    {
                      label: 'Meta Ads',
                      value: customAllocation.meta,
                      amount: wallet.balance * (customAllocation.meta / 100),
                      color: 'bg-chart-1',
                    },
                    {
                      label: 'Google Ads',
                      value: customAllocation.google,
                      amount: wallet.balance * (customAllocation.google / 100),
                      color: 'bg-chart-2',
                    },
                    {
                      label: 'TikTok Ads',
                      value: customAllocation.tiktok,
                      amount: wallet.balance * (customAllocation.tiktok / 100),
                      color: 'bg-chart-3',
                    },
                    {
                      label: 'LinkedIn Ads',
                      value: customAllocation.linkedin,
                      amount: wallet.balance * (customAllocation.linkedin / 100),
                      color: 'bg-chart-4',
                    },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                      <div className="flex items-center gap-3">
                        <div className={cn('w-3 h-3 rounded-full', item.color)} />
                        <span className="font-medium">{item.label}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(item.amount)}</p>
                        <p className="text-xs text-muted-foreground">{item.value}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Wallet Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Auto-Recharge */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <RefreshCw className="h-5 w-5" />
                  Auto-Recharge
                </CardTitle>
                <CardDescription>Automatically add funds when balance is low</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 rounded-lg border">
                  <div>
                    <p className="font-medium">Enable Auto-Recharge</p>
                    <p className="text-sm text-muted-foreground">Never run out of campaign funds</p>
                  </div>
                  <Switch checked={wallet.autoRechargeEnabled} />
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Recharge when balance falls below</Label>
                    <Select defaultValue={wallet.lowBalanceThreshold.toString()}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1000">$1,000</SelectItem>
                        <SelectItem value="2500">$2,500</SelectItem>
                        <SelectItem value="5000">$5,000</SelectItem>
                        <SelectItem value="10000">$10,000</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Recharge amount</Label>
                    <Select defaultValue={wallet.autoRechargeAmount.toString()}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1000">$1,000</SelectItem>
                        <SelectItem value="2500">$2,500</SelectItem>
                        <SelectItem value="5000">$5,000</SelectItem>
                        <SelectItem value="10000">$10,000</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {wallet.autoRechargeEnabled && (
                  <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-emerald-600">
                      <CheckCircle2 className="h-4 w-4" />
                      <span className="text-sm font-medium">Auto-recharge is active</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Spending Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Bell className="h-5 w-5" />
                  Spending Alerts
                </CardTitle>
                <CardDescription>Get notified about important spending events</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  {
                    label: 'Low Balance Alert',
                    desc: `When balance drops below ${formatCurrency(wallet.lowBalanceThreshold)}`,
                    enabled: true,
                  },
                  {
                    label: 'Critical Balance Alert',
                    desc: `When balance drops below ${formatCurrency(wallet.criticalBalanceThreshold)}`,
                    enabled: true,
                  },
                  {
                    label: 'High Spending Alert',
                    desc: 'When daily spend exceeds budget',
                    enabled: true,
                  },
                  {
                    label: 'Campaign Risk Alert',
                    desc: 'When campaigns are at budget risk',
                    enabled: true,
                  },
                  {
                    label: 'Unusual Activity Alert',
                    desc: 'When spending patterns are abnormal',
                    enabled: false,
                  },
                ].map((alert, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-lg border">
                    <div>
                      <p className="font-medium">{alert.label}</p>
                      <p className="text-sm text-muted-foreground">{alert.desc}</p>
                    </div>
                    <Switch defaultChecked={alert.enabled} />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <CreditCard className="h-5 w-5" />
                      Payment Method
                    </CardTitle>
                    <CardDescription>Manage your payment options</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    Add New
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/30">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded bg-background">
                      <CreditCard className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="font-medium">Visa •••• 4242</p>
                      <p className="text-sm text-muted-foreground">Expires 12/2025</p>
                    </div>
                  </div>
                  <Badge variant="secondary">Default</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Spending Limits */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Shield className="h-5 w-5" />
                  Spending Limits
                </CardTitle>
                <CardDescription>Set guardrails for your ad spend</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Daily Spending Limit</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input type="number" defaultValue="1000" className="pl-9" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Monthly Spending Limit</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input type="number" defaultValue="25000" className="pl-9" />
                  </div>
                </div>
                <Button
                  className="w-full"
                  onClick={() =>
                    toast({
                      title: 'Limits Updated',
                      description: 'Your spending limits have been saved.',
                    })
                  }
                >
                  Save Limits
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
