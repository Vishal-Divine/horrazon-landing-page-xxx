import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Phone,
  PhoneCall,
  PhoneMissed,
  PhoneOff,
  Clock,
  DollarSign,
  TrendingUp,
  Users,
  Target,
  Zap,
  Play,
  Pause,
  BarChart3,
  MessageSquare,
  UserCheck,
  Calendar,
  Download,
  Settings,
  Volume2,
  VolumeX,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Mic,
  Brain,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

// Call Data
const recentCalls = [
  {
    id: 1,
    caller: '+1 (555) 123-4567',
    duration: '4:32',
    status: 'completed',
    source: 'Meta Ads',
    campaign: 'Black Friday Sale',
    agent: 'Sarah M.',
    outcome: 'sale',
    revenue: 249.99,
    sentiment: 'positive',
    timestamp: '2 min ago',
    recordingUrl: '#',
  },
  {
    id: 2,
    caller: '+1 (555) 234-5678',
    duration: '2:18',
    status: 'completed',
    source: 'Google Ads',
    campaign: 'Brand Search',
    agent: 'Mike T.',
    outcome: 'lead',
    revenue: 0,
    sentiment: 'neutral',
    timestamp: '8 min ago',
    recordingUrl: '#',
  },
  {
    id: 3,
    caller: '+1 (555) 345-6789',
    duration: '0:45',
    status: 'missed',
    source: 'TikTok Ads',
    campaign: 'Product Demo',
    agent: null,
    outcome: 'missed',
    revenue: 0,
    sentiment: null,
    timestamp: '15 min ago',
    recordingUrl: null,
  },
  {
    id: 4,
    caller: '+1 (555) 456-7890',
    duration: '6:12',
    status: 'completed',
    source: 'Meta Ads',
    campaign: 'Retargeting',
    agent: 'Emily R.',
    outcome: 'sale',
    revenue: 189.5,
    sentiment: 'positive',
    timestamp: '22 min ago',
    recordingUrl: '#',
  },
  {
    id: 5,
    caller: '+1 (555) 567-8901',
    duration: '3:45',
    status: 'completed',
    source: 'Organic',
    campaign: null,
    agent: 'Sarah M.',
    outcome: 'follow-up',
    revenue: 0,
    sentiment: 'positive',
    timestamp: '35 min ago',
    recordingUrl: '#',
  },
];

const callMetrics = {
  totalCalls: 1248,
  answeredCalls: 1092,
  missedCalls: 156,
  avgDuration: '3:42',
  conversionRate: 18.4,
  revenuePerCall: 42.8,
  totalRevenue: 53414,
  callbackRate: 72,
};

const callsBySource = [
  { source: 'Meta Ads', calls: 428, conversions: 82, revenue: 18420, convRate: 19.2, costPerCall: 8.4 },
  { source: 'Google Ads', calls: 324, conversions: 58, revenue: 12840, convRate: 17.9, costPerCall: 12.2 },
  { source: 'TikTok Ads', calls: 186, conversions: 42, revenue: 8240, convRate: 22.6, costPerCall: 6.8 },
  { source: 'Organic', calls: 182, conversions: 28, revenue: 6420, convRate: 15.4, costPerCall: 0 },
  { source: 'Direct', calls: 128, conversions: 18, revenue: 4200, convRate: 14.1, costPerCall: 0 },
];

const callTrendData = [
  { hour: '8 AM', calls: 42, answered: 38, conversions: 8 },
  { hour: '9 AM', calls: 68, answered: 62, conversions: 14 },
  { hour: '10 AM', calls: 84, answered: 78, conversions: 18 },
  { hour: '11 AM', calls: 92, answered: 86, conversions: 22 },
  { hour: '12 PM', calls: 78, answered: 72, conversions: 16 },
  { hour: '1 PM', calls: 65, answered: 58, conversions: 12 },
  { hour: '2 PM', calls: 88, answered: 82, conversions: 20 },
  { hour: '3 PM', calls: 96, answered: 90, conversions: 24 },
  { hour: '4 PM', calls: 108, answered: 98, conversions: 28 },
  { hour: '5 PM', calls: 86, answered: 78, conversions: 18 },
];

const agentPerformance = [
  { name: 'Sarah M.', calls: 284, conversions: 62, revenue: 14820, avgDuration: '4:12', satisfaction: 4.8 },
  { name: 'Mike T.', calls: 248, conversions: 48, revenue: 11240, avgDuration: '3:45', satisfaction: 4.6 },
  { name: 'Emily R.', calls: 226, conversions: 52, revenue: 12480, avgDuration: '4:28', satisfaction: 4.9 },
  { name: 'David K.', calls: 198, conversions: 38, revenue: 8420, avgDuration: '3:18', satisfaction: 4.4 },
  { name: 'Lisa W.', calls: 186, conversions: 44, revenue: 9840, avgDuration: '3:52', satisfaction: 4.7 },
];

const sentimentBreakdown = [
  { sentiment: 'Positive', value: 68, color: 'hsl(var(--success))' },
  { sentiment: 'Neutral', value: 24, color: 'hsl(var(--warning))' },
  { sentiment: 'Negative', value: 8, color: 'hsl(var(--destructive))' },
];

const callOutcomes = [
  { outcome: 'Sale', value: 42, color: 'hsl(var(--chart-1))' },
  { outcome: 'Lead', value: 28, color: 'hsl(var(--chart-2))' },
  { outcome: 'Follow-up', value: 18, color: 'hsl(var(--chart-3))' },
  { outcome: 'No Interest', value: 12, color: 'hsl(var(--chart-4))' },
];

const aiInsights = [
  { insight: 'Peak call volume detected between 3-5 PM', impact: 'Schedule more agents', priority: 'high' },
  { insight: 'Meta Ads driving highest quality calls', impact: 'Increase budget by 20%', priority: 'medium' },
  { insight: 'Emily R. has 32% higher close rate than avg', impact: 'Use her scripts as template', priority: 'medium' },
  { insight: '12% missed calls during lunch hours', impact: 'Add callback automation', priority: 'high' },
];

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

export default function CallTracking() {
  const [playingCall, setPlayingCall] = useState<number | null>(null);

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Call Tracking & Attribution</h1>
          <p className="text-muted-foreground">Track calls, analyze conversations & attribute revenue to campaigns</p>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="7d">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button className="gap-2">
            <Settings className="h-4 w-4" />
            Configure
          </Button>
        </div>
      </div>

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Calls</p>
                <p className="text-2xl font-bold">{callMetrics.totalCalls.toLocaleString()}</p>
              </div>
              <Phone className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+18% vs last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Answer Rate</p>
                <p className="text-2xl font-bold">
                  {((callMetrics.answeredCalls / callMetrics.totalCalls) * 100).toFixed(0)}%
                </p>
              </div>
              <PhoneCall className="h-8 w-8 text-success" />
            </div>
            <Progress value={(callMetrics.answeredCalls / callMetrics.totalCalls) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Duration</p>
                <p className="text-2xl font-bold">{callMetrics.avgDuration}</p>
              </div>
              <Clock className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Target: 4:00</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <p className="text-2xl font-bold">{callMetrics.conversionRate}%</p>
              </div>
              <Target className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-success">+3.2% vs last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue/Call</p>
                <p className="text-2xl font-bold">${callMetrics.revenuePerCall}</p>
              </div>
              <DollarSign className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-success">+$8.40 vs avg</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">${(callMetrics.totalRevenue / 1000).toFixed(1)}K</p>
              </div>
              <TrendingUp className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-success">From phone calls</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="calls" className="space-y-6">
        <TabsList>
          <TabsTrigger value="calls">Recent Calls</TabsTrigger>
          <TabsTrigger value="attribution">Call Attribution</TabsTrigger>
          <TabsTrigger value="agents">Agent Performance</TabsTrigger>
          <TabsTrigger value="analytics">Call Analytics</TabsTrigger>
          <TabsTrigger value="ai">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="calls" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-success"></span>
                  </span>
                  Live Call Feed
                </CardTitle>
                <div className="flex gap-2">
                  <Input placeholder="Search calls..." className="w-64" />
                  <Select defaultValue="all">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Calls</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="missed">Missed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Caller</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Campaign</TableHead>
                    <TableHead>Agent</TableHead>
                    <TableHead>Outcome</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-center">Recording</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentCalls.map((call) => (
                    <TableRow key={call.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{call.caller}</p>
                          <p className="text-xs text-muted-foreground">{call.timestamp}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {call.status === 'completed' ? (
                            <CheckCircle2 className="h-4 w-4 text-success" />
                          ) : (
                            <PhoneMissed className="h-4 w-4 text-destructive" />
                          )}
                          {call.duration}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{call.source}</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{call.campaign || '—'}</TableCell>
                      <TableCell>{call.agent || '—'}</TableCell>
                      <TableCell>
                        <Badge
                          className={
                            call.outcome === 'sale'
                              ? 'bg-success/10 text-success'
                              : call.outcome === 'lead'
                                ? 'bg-chart-1/10 text-chart-1'
                                : call.outcome === 'follow-up'
                                  ? 'bg-warning/10 text-warning'
                                  : 'bg-muted text-muted-foreground'
                          }
                        >
                          {call.outcome}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {call.sentiment ? (
                          <Badge
                            variant="outline"
                            className={
                              call.sentiment === 'positive'
                                ? 'border-success text-success'
                                : call.sentiment === 'neutral'
                                  ? 'border-warning text-warning'
                                  : 'border-destructive text-destructive'
                            }
                          >
                            {call.sentiment}
                          </Badge>
                        ) : (
                          '—'
                        )}
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        {call.revenue > 0 ? `$${call.revenue.toFixed(2)}` : '—'}
                      </TableCell>
                      <TableCell className="text-center">
                        {call.recordingUrl ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setPlayingCall(playingCall === call.id ? null : call.id)}
                          >
                            {playingCall === call.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                        ) : (
                          <VolumeX className="h-4 w-4 text-muted-foreground mx-auto" />
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attribution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Call Attribution by Source</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source</TableHead>
                    <TableHead className="text-right">Calls</TableHead>
                    <TableHead className="text-right">Conversions</TableHead>
                    <TableHead className="text-right">Conv Rate</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Cost/Call</TableHead>
                    <TableHead className="text-right">ROAS</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {callsBySource.map((source, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{source.source}</TableCell>
                      <TableCell className="text-right">{source.calls}</TableCell>
                      <TableCell className="text-right">{source.conversions}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant="outline" className={source.convRate > 20 ? 'text-success border-success' : ''}>
                          {source.convRate}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-bold">${source.revenue.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        {source.costPerCall > 0 ? `$${source.costPerCall.toFixed(2)}` : 'Free'}
                      </TableCell>
                      <TableCell className="text-right font-bold text-success">
                        {source.costPerCall > 0
                          ? `${(source.revenue / (source.calls * source.costPerCall)).toFixed(1)}x`
                          : '∞'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Call Outcomes</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={callOutcomes}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ outcome, value }) => `${outcome}: ${value}%`}
                    >
                      {callOutcomes.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sentiment Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={sentimentBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ sentiment, value }) => `${sentiment}: ${value}%`}
                    >
                      {sentimentBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="agents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Agent Performance Leaderboard</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Agent</TableHead>
                    <TableHead className="text-right">Calls</TableHead>
                    <TableHead className="text-right">Conversions</TableHead>
                    <TableHead className="text-right">Conv Rate</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Avg Duration</TableHead>
                    <TableHead className="text-right">Satisfaction</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {agentPerformance.map((agent, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                            {agent.name
                              .split(' ')
                              .map((n) => n[0])
                              .join('')}
                          </div>
                          <span className="font-medium">{agent.name}</span>
                          {i === 0 && <Badge className="bg-warning/10 text-warning">Top</Badge>}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">{agent.calls}</TableCell>
                      <TableCell className="text-right">{agent.conversions}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant="outline">{((agent.conversions / agent.calls) * 100).toFixed(1)}%</Badge>
                      </TableCell>
                      <TableCell className="text-right font-bold">${agent.revenue.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{agent.avgDuration}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <span className="font-medium">{agent.satisfaction}</span>
                          <span className="text-warning">★</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Call Volume by Hour</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={callTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="hour" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="calls"
                    stackId="1"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.3}
                    name="Total Calls"
                  />
                  <Area
                    type="monotone"
                    dataKey="answered"
                    stackId="2"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.3}
                    name="Answered"
                  />
                  <Area
                    type="monotone"
                    dataKey="conversions"
                    stackId="3"
                    stroke="hsl(var(--success))"
                    fill="hsl(var(--success))"
                    fillOpacity={0.3}
                    name="Conversions"
                  />
                  <Legend />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                AI-Powered Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiInsights.map((insight, i) => (
                <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-background/50 border border-border/50">
                  <div
                    className={`p-2 rounded-full ${
                      insight.priority === 'high' ? 'bg-destructive/10' : 'bg-warning/10'
                    }`}
                  >
                    {insight.priority === 'high' ? (
                      <AlertTriangle
                        className={`h-5 w-5 ${insight.priority === 'high' ? 'text-destructive' : 'text-warning'}`}
                      />
                    ) : (
                      <Zap className="h-5 w-5 text-warning" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{insight.insight}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      <span className="text-primary font-medium">Recommended: </span>
                      {insight.impact}
                    </p>
                  </div>
                  <Button size="sm" variant="outline">
                    Apply
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mic className="h-5 w-5" />
                  Conversation Intelligence
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg border border-border">
                  <p className="text-sm font-medium">Top Keywords in Successful Calls</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['discount', 'free shipping', 'quality', 'warranty', 'delivery', 'bundle'].map((word, i) => (
                      <Badge key={i} variant="secondary">
                        {word}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="p-4 rounded-lg border border-border">
                  <p className="text-sm font-medium">Common Objections</p>
                  <div className="space-y-2 mt-2">
                    <div className="flex justify-between text-sm">
                      <span>"Too expensive"</span>
                      <span className="font-medium">34%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>"Need to think about it"</span>
                      <span className="font-medium">28%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>"Shipping time"</span>
                      <span className="font-medium">18%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>AI Call Scoring</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Average Call Quality Score</span>
                    <span className="text-2xl font-bold text-success">84/100</span>
                  </div>
                  <Progress value={84} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Script Adherence</p>
                    <p className="text-lg font-bold">78%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Objection Handling</p>
                    <p className="text-lg font-bold">86%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Closing Rate</p>
                    <p className="text-lg font-bold">72%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Customer Satisfaction</p>
                    <p className="text-lg font-bold">91%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
