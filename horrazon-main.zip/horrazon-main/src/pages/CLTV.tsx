import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  ComposedChart,
  AreaChart,
  Area,
  LineChart,
} from 'recharts';
import {
  Users,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Clock,
  Heart,
  Target,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const cltvData = [
  { month: 'Jan', ltv: 1200, cac: 250, ratio: 4.8 },
  { month: 'Feb', ltv: 1350, cac: 280, ratio: 4.82 },
  { month: 'Mar', ltv: 1500, cac: 300, ratio: 5.0 },
  { month: 'Apr', ltv: 1650, cac: 320, ratio: 5.16 },
  { month: 'May', ltv: 1800, cac: 340, ratio: 5.29 },
  { month: 'Jun', ltv: 1950, cac: 360, ratio: 5.42 },
];

const rfmSegments = [
  {
    name: 'Champions',
    r: 5,
    f: 5,
    m: 5,
    customers: 342,
    revenue: '$124K',
    churnRisk: 2,
    color: 'bg-success/20 text-success border-success/30',
  },
  {
    name: 'Loyal',
    r: 4,
    f: 4,
    m: 4,
    customers: 521,
    revenue: '$89K',
    churnRisk: 8,
    color: 'bg-chart-1/20 text-chart-1 border-chart-1/30',
  },
  {
    name: 'Potential Loyalist',
    r: 4,
    f: 3,
    m: 3,
    customers: 298,
    revenue: '$67K',
    churnRisk: 15,
    color: 'bg-chart-3/20 text-chart-3 border-chart-3/30',
  },
  {
    name: 'At Risk',
    r: 2,
    f: 3,
    m: 4,
    customers: 187,
    revenue: '$45K',
    churnRisk: 65,
    color: 'bg-destructive/20 text-destructive border-destructive/30',
  },
  {
    name: 'Hibernating',
    r: 2,
    f: 2,
    m: 2,
    customers: 156,
    revenue: '$28K',
    churnRisk: 78,
    color: 'bg-muted-foreground/20 text-muted-foreground border-muted-foreground/30',
  },
  {
    name: 'Lost',
    r: 1,
    f: 1,
    m: 1,
    customers: 98,
    revenue: '$12K',
    churnRisk: 95,
    color: 'bg-border text-muted-foreground border-border',
  },
];

const cohortRetention = [
  { month: 'M0', jan: 100, feb: 100, mar: 100, apr: 100, may: 100, jun: 100 },
  { month: 'M1', jan: 68, feb: 72, mar: 70, apr: 74, may: 71, jun: 75 },
  { month: 'M2', jan: 52, feb: 55, mar: 54, apr: 58, may: 56, jun: null },
  { month: 'M3', jan: 41, feb: 44, mar: 43, apr: 47, may: null, jun: null },
  { month: 'M4', jan: 35, feb: 38, mar: 37, apr: null, may: null, jun: null },
  { month: 'M5', jan: 31, feb: 34, mar: null, apr: null, may: null, jun: null },
  { month: 'M6', jan: 28, feb: null, mar: null, apr: null, may: null, jun: null },
];

const churnPredictions = [
  {
    name: 'Sarah Johnson',
    email: 'sarah.j@email.com',
    probability: 89,
    lastPurchase: '45 days ago',
    ltv: '$2,450',
    segment: 'At Risk',
  },
  {
    name: 'Mike Chen',
    email: 'mike.c@email.com',
    probability: 76,
    lastPurchase: '38 days ago',
    ltv: '$1,820',
    segment: 'Hibernating',
  },
  {
    name: 'Emily Davis',
    email: 'emily.d@email.com',
    probability: 72,
    lastPurchase: '52 days ago',
    ltv: '$980',
    segment: 'At Risk',
  },
  {
    name: 'James Wilson',
    email: 'james.w@email.com',
    probability: 68,
    lastPurchase: '41 days ago',
    ltv: '$1,540',
    segment: 'Hibernating',
  },
  {
    name: 'Lisa Anderson',
    email: 'lisa.a@email.com',
    probability: 64,
    lastPurchase: '35 days ago',
    ltv: '$2,120',
    segment: 'At Risk',
  },
];

const customerHealthData = [
  { month: 'Jan', healthy: 65, warning: 25, critical: 10 },
  { month: 'Feb', healthy: 68, warning: 22, critical: 10 },
  { month: 'Mar', healthy: 70, warning: 20, critical: 10 },
  { month: 'Apr', healthy: 72, warning: 19, critical: 9 },
  { month: 'May', healthy: 74, warning: 18, critical: 8 },
  { month: 'Jun', healthy: 76, warning: 17, critical: 7 },
];

export default function CLTV() {
  const avgCac = 310;
  const avgLtv = 1575;
  const paybackMonths = 4.2;
  const nrr = 108;

  return (
    <div className="space-y-8 p-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          Customer Lifetime Value
        </h1>
        <p className="text-muted-foreground text-lg">CLTV analysis, segmentation, and churn prediction</p>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Average LTV</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${avgLtv.toLocaleString()}</div>
            <div className="flex items-center gap-1 mt-1">
              <ArrowUpRight className="h-3 w-3 text-success" />
              <span className="text-xs text-success">+12% vs last quarter</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">CAC Payback</CardTitle>
            <Clock className="h-4 w-4 text-chart-1" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{paybackMonths} months</div>
            <p className="text-xs text-muted-foreground mt-1">Average time to recover CAC</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">LTV:CAC Ratio</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-success">5.1x</div>
            <p className="text-xs text-muted-foreground mt-1">Target: 3x minimum</p>
            <Progress value={85} className="h-1 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Net Revenue Retention</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-success">{nrr}%</div>
            <p className="text-xs text-muted-foreground mt-1">Expansion &gt; Churn</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rfm" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="rfm">RFM Segmentation</TabsTrigger>
          <TabsTrigger value="churn">Churn Prediction</TabsTrigger>
          <TabsTrigger value="cohort">Cohort Retention</TabsTrigger>
          <TabsTrigger value="health">Customer Health</TabsTrigger>
          <TabsTrigger value="ltvcac">LTV:CAC Analysis</TabsTrigger>
        </TabsList>

        {/* RFM Segmentation */}
        <TabsContent value="rfm" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                RFM Customer Segmentation Matrix
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {rfmSegments.map((segment) => (
                  <div
                    key={segment.name}
                    className={cn(
                      'p-4 rounded-lg border-2 transition-all hover:scale-105 hover:shadow-md cursor-pointer',
                      segment.color,
                    )}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-lg">{segment.name}</p>
                        <Badge variant="outline" className="text-xs">
                          R{segment.r}F{segment.f}M{segment.m}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-2xl font-bold">{segment.customers}</p>
                          <p className="text-xs opacity-80">customers</p>
                        </div>
                        <div>
                          <p className="text-xl font-semibold">{segment.revenue}</p>
                          <p className="text-xs opacity-80">revenue</p>
                        </div>
                      </div>
                      <div className="pt-2 border-t border-current/20">
                        <div className="flex items-center justify-between">
                          <span className="text-xs">Churn Risk</span>
                          <span className="text-sm font-semibold">{segment.churnRisk}%</span>
                        </div>
                        <Progress value={segment.churnRisk} className="h-1 mt-1" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Churn Prediction */}
        <TabsContent value="churn" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                  High-Risk Churn Predictions
                </CardTitle>
                <Button size="sm">Export for Retention Campaign</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {churnPredictions.map((customer, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-destructive/20 flex items-center justify-center">
                        <span className="text-sm font-bold text-destructive">{customer.probability}%</span>
                      </div>
                      <div>
                        <p className="font-semibold">{customer.name}</p>
                        <p className="text-sm text-muted-foreground">{customer.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Last Purchase</p>
                        <p className="font-medium">{customer.lastPurchase}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">LTV</p>
                        <p className="font-semibold text-success">{customer.ltv}</p>
                      </div>
                      <Badge variant={customer.segment === 'At Risk' ? 'destructive' : 'secondary'}>
                        {customer.segment}
                      </Badge>
                      <Button size="sm" variant="outline">
                        Send Winback
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cohort Retention */}
        <TabsContent value="cohort" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cohort Retention Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr>
                      <th className="text-left p-2 font-medium">Month</th>
                      <th className="text-center p-2 font-medium">Jan Cohort</th>
                      <th className="text-center p-2 font-medium">Feb Cohort</th>
                      <th className="text-center p-2 font-medium">Mar Cohort</th>
                      <th className="text-center p-2 font-medium">Apr Cohort</th>
                      <th className="text-center p-2 font-medium">May Cohort</th>
                      <th className="text-center p-2 font-medium">Jun Cohort</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cohortRetention.map((row) => (
                      <tr key={row.month}>
                        <td className="p-2 font-medium">{row.month}</td>
                        {['jan', 'feb', 'mar', 'apr', 'may', 'jun'].map((cohort) => {
                          const value = row[cohort as keyof typeof row];
                          if (value === null)
                            return (
                              <td key={cohort} className="p-2 text-center">
                                -
                              </td>
                            );
                          const numValue = value as number;
                          const bgOpacity = numValue / 100;
                          return (
                            <td key={cohort} className="p-2 text-center">
                              <span
                                className="inline-block px-3 py-1 rounded text-sm font-medium"
                                style={{
                                  backgroundColor: `hsl(var(--success) / ${bgOpacity * 0.5})`,
                                  color: numValue > 50 ? 'hsl(var(--success))' : 'inherit',
                                }}
                              >
                                {numValue}%
                              </span>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-6">
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={cohortRetention}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" domain={[0, 100]} />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="jan"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2}
                      name="Jan Cohort"
                    />
                    <Line
                      type="monotone"
                      dataKey="feb"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      name="Feb Cohort"
                    />
                    <Line
                      type="monotone"
                      dataKey="mar"
                      stroke="hsl(var(--chart-3))"
                      strokeWidth={2}
                      name="Mar Cohort"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Customer Health */}
        <TabsContent value="health" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-destructive" />
                Customer Health Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={customerHealthData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="healthy"
                    stackId="1"
                    stroke="hsl(var(--success))"
                    fill="hsl(var(--success))"
                    name="Healthy"
                  />
                  <Area
                    type="monotone"
                    dataKey="warning"
                    stackId="1"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    name="Warning"
                  />
                  <Area
                    type="monotone"
                    dataKey="critical"
                    stackId="1"
                    stroke="hsl(var(--destructive))"
                    fill="hsl(var(--destructive))"
                    name="Critical"
                  />
                </AreaChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="p-4 rounded-lg bg-success/10 border border-success/30">
                  <p className="text-2xl font-bold text-success">76%</p>
                  <p className="text-sm text-muted-foreground">Healthy Customers</p>
                </div>
                <div className="p-4 rounded-lg bg-chart-3/10 border border-chart-3/30">
                  <p className="text-2xl font-bold text-chart-3">17%</p>
                  <p className="text-sm text-muted-foreground">Needs Attention</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30">
                  <p className="text-2xl font-bold text-destructive">7%</p>
                  <p className="text-sm text-muted-foreground">At Risk</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* LTV:CAC Analysis */}
        <TabsContent value="ltvcac" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>LTV:CAC Ratio Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={cltvData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis yAxisId="left" className="text-xs" />
                  <YAxis yAxisId="right" orientation="right" className="text-xs" />
                  <Tooltip />
                  <Bar yAxisId="left" dataKey="ltv" fill="hsl(var(--chart-1))" name="LTV" />
                  <Bar yAxisId="left" dataKey="cac" fill="hsl(var(--chart-3))" name="CAC" />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="ratio"
                    stroke="hsl(var(--success))"
                    strokeWidth={2}
                    name="LTV:CAC Ratio"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>CAC Payback Period Calculator</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Customer Acquisition Cost</p>
                  <p className="text-3xl font-bold">${avgCac}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Monthly Revenue per Customer</p>
                  <p className="text-3xl font-bold">$74</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Payback Period</p>
                  <p className="text-3xl font-bold text-success">{paybackMonths} months</p>
                </div>
              </div>
              <div className="mt-6 p-4 bg-muted/30 rounded-lg">
                <p className="text-sm">
                  <strong>Insight:</strong> Your CAC payback period of {paybackMonths} months is excellent. Industry
                  benchmark is 12 months. You're recovering acquisition costs 3x faster than average.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
