import { useState } from 'react';
import { Database, Search, AlertOctagon, UserX, Users, Sparkles, RefreshCw } from 'lucide-react';
import { SEOHead } from '@/components/seo';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DataUnificationPanel,
  DiscoveryGapTracker,
  TechnicalDebtMonitor,
  FollowUpAutomationPanel,
  ChangeAdoptionPanel,
} from '@/components/commandcenter';

export default function MarketingCommandCenter() {
  const [activeTab, setActiveTab] = useState('data-unification');

  return (
    <div className="space-y-6 p-8 animate-fade-in">
      <SEOHead
        title="Marketing Command Center"
        description="Unified marketing intelligence hub with data health monitoring, discovery gap tracking, and follow-up automation."
        keywords="marketing command center, data unification, technical debt, follow-up automation, change management"
      />

      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
              Marketing Command Center
            </h1>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Sparkles className="h-3 w-3 mr-1" />
              AI-Powered
            </Badge>
          </div>
          <p className="text-muted-foreground text-lg">
            Single Source of Truth for marketing operations health & performance
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <RefreshCw className="h-4 w-4" />
          Sync All Sources
        </Button>
      </div>

      {/* Research-Driven Insights Banner */}
      <div className="p-4 rounded-lg bg-gradient-to-r from-primary/5 via-accent/10 to-primary/5 border border-primary/20">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">📊 Powered by Salesforce 2025 Research:</span> Addressing the
          top implementation failures — 40% skip discovery, only 31% have unified data, and follow-up failures cost
          billions in lost revenue.
        </p>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50 p-1 h-auto flex-wrap">
          <TabsTrigger value="data-unification" className="gap-2 data-[state=active]:bg-background">
            <Database className="h-4 w-4" />
            Data Unification
          </TabsTrigger>
          <TabsTrigger value="discovery-gap" className="gap-2 data-[state=active]:bg-background">
            <Search className="h-4 w-4" />
            Discovery Gap
          </TabsTrigger>
          <TabsTrigger value="tech-debt" className="gap-2 data-[state=active]:bg-background">
            <AlertOctagon className="h-4 w-4" />
            Technical Debt
          </TabsTrigger>
          <TabsTrigger value="follow-up" className="gap-2 data-[state=active]:bg-background">
            <UserX className="h-4 w-4" />
            Follow-Up Automation
          </TabsTrigger>
          <TabsTrigger value="adoption" className="gap-2 data-[state=active]:bg-background">
            <Users className="h-4 w-4" />
            Change Adoption
          </TabsTrigger>
        </TabsList>

        <TabsContent value="data-unification">
          <DataUnificationPanel />
        </TabsContent>

        <TabsContent value="discovery-gap">
          <DiscoveryGapTracker />
        </TabsContent>

        <TabsContent value="tech-debt">
          <TechnicalDebtMonitor />
        </TabsContent>

        <TabsContent value="follow-up">
          <FollowUpAutomationPanel />
        </TabsContent>

        <TabsContent value="adoption">
          <ChangeAdoptionPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}
