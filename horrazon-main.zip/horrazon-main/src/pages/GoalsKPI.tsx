import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  Target,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Trophy,
  Users,
  Plus,
  Calendar,
  CheckCircle2,
  Clock,
  Flame,
  Star,
  Award,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Bell,
  Sparkles,
  Flag,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadialBarChart,
  RadialBar,
} from 'recharts';
import { useState } from 'react';

const goals = [
  {
    id: 1,
    name: 'Q4 Revenue Target',
    category: 'Revenue',
    target: 1200000,
    current: 892400,
    progress: 74.4,
    deadline: 'Dec 31, 2024',
    daysRemaining: 27,
    status: 'on-track',
    trend: 'up',
    trendValue: 8.2,
    owner: { name: 'Sarah Chen', avatar: 'SC' },
    milestones: [
      { name: '$300K', target: 300000, achieved: true },
      { name: '$600K', target: 600000, achieved: true },
      { name: '$900K', target: 900000, achieved: false },
      { name: '$1.2M', target: 1200000, achieved: false },
    ],
  },
  {
    id: 2,
    name: 'Customer Acquisition',
    category: 'Growth',
    target: 5000,
    current: 4280,
    progress: 85.6,
    deadline: 'Dec 31, 2024',
    daysRemaining: 27,
    status: 'ahead',
    trend: 'up',
    trendValue: 12.4,
    owner: { name: 'Mike Johnson', avatar: 'MJ' },
    milestones: [
      { name: '1,000', target: 1000, achieved: true },
      { name: '2,500', target: 2500, achieved: true },
      { name: '4,000', target: 4000, achieved: true },
      { name: '5,000', target: 5000, achieved: false },
    ],
  },
  {
    id: 3,
    name: 'ROAS Improvement',
    category: 'Efficiency',
    target: 5.5,
    current: 4.8,
    progress: 87.3,
    deadline: 'Dec 31, 2024',
    daysRemaining: 27,
    status: 'on-track',
    trend: 'up',
    trendValue: 4.2,
    owner: { name: 'Emily Davis', avatar: 'ED' },
    milestones: [
      { name: '4.0x', target: 4.0, achieved: true },
      { name: '4.5x', target: 4.5, achieved: true },
      { name: '5.0x', target: 5.0, achieved: false },
      { name: '5.5x', target: 5.5, achieved: false },
    ],
  },
  {
    id: 4,
    name: 'CAC Reduction',
    category: 'Efficiency',
    target: 28,
    current: 34,
    progress: 64.3,
    deadline: 'Dec 31, 2024',
    daysRemaining: 27,
    status: 'at-risk',
    trend: 'down',
    trendValue: -2.8,
    owner: { name: 'Alex Kim', avatar: 'AK' },
    milestones: [
      { name: '$45', target: 45, achieved: true },
      { name: '$38', target: 38, achieved: true },
      { name: '$32', target: 32, achieved: false },
      { name: '$28', target: 28, achieved: false },
    ],
  },
  {
    id: 5,
    name: 'Email List Growth',
    category: 'Marketing',
    target: 50000,
    current: 52400,
    progress: 104.8,
    deadline: 'Dec 31, 2024',
    daysRemaining: 27,
    status: 'completed',
    trend: 'up',
    trendValue: 18.6,
    owner: { name: 'Jordan Lee', avatar: 'JL' },
    milestones: [
      { name: '15K', target: 15000, achieved: true },
      { name: '30K', target: 30000, achieved: true },
      { name: '45K', target: 45000, achieved: true },
      { name: '50K', target: 50000, achieved: true },
    ],
  },
];

const progressTrendData = [
  { week: 'W1', revenue: 42, customers: 48, roas: 65, cac: 72 },
  { week: 'W2', revenue: 48, customers: 54, roas: 68, cac: 68 },
  { week: 'W3', revenue: 52, customers: 62, roas: 72, cac: 65 },
  { week: 'W4', revenue: 58, customers: 68, roas: 78, cac: 64 },
  { week: 'W5', revenue: 64, customers: 74, roas: 82, cac: 66 },
  { week: 'W6', revenue: 68, customers: 78, roas: 84, cac: 65 },
  { week: 'W7', revenue: 72, customers: 82, roas: 86, cac: 64 },
  { week: 'W8', revenue: 74, customers: 86, roas: 87, cac: 64 },
];

const teamMembers = [
  {
    name: 'Sarah Chen',
    role: 'Revenue Lead',
    avatar: 'SC',
    goalsOwned: 3,
    goalsOnTrack: 3,
    contribution: 32,
    streak: 12,
  },
  {
    name: 'Mike Johnson',
    role: 'Growth Manager',
    avatar: 'MJ',
    goalsOwned: 4,
    goalsOnTrack: 3,
    contribution: 28,
    streak: 8,
  },
  {
    name: 'Emily Davis',
    role: 'Performance Analyst',
    avatar: 'ED',
    goalsOwned: 2,
    goalsOnTrack: 2,
    contribution: 18,
    streak: 15,
  },
  {
    name: 'Alex Kim',
    role: 'Acquisition Lead',
    avatar: 'AK',
    goalsOwned: 3,
    goalsOnTrack: 1,
    contribution: 14,
    streak: 4,
  },
  {
    name: 'Jordan Lee',
    role: 'Email Marketing',
    avatar: 'JL',
    goalsOwned: 2,
    goalsOnTrack: 2,
    contribution: 8,
    streak: 22,
  },
];

const milestoneAlerts = [
  { goal: 'Q4 Revenue Target', milestone: '$900K (75%)', dueIn: '5 days', current: '$892K', status: 'approaching' },
  {
    goal: 'Customer Acquisition',
    milestone: '5,000 customers',
    dueIn: '27 days',
    current: '4,280',
    status: 'on-track',
  },
  { goal: 'CAC Reduction', milestone: '$32 CAC', dueIn: '12 days', current: '$34', status: 'at-risk' },
];

const categoryData = [
  { name: 'Revenue', value: 2, onTrack: 2 },
  { name: 'Growth', value: 3, onTrack: 2 },
  { name: 'Efficiency', value: 4, onTrack: 3 },
  { name: 'Marketing', value: 3, onTrack: 3 },
];

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function GoalsKPI() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showNewGoalDialog, setShowNewGoalDialog] = useState(false);

  const totalGoals = goals.length;
  const onTrackGoals = goals.filter(
    (g) => g.status === 'on-track' || g.status === 'ahead' || g.status === 'completed',
  ).length;
  const atRiskGoals = goals.filter((g) => g.status === 'at-risk').length;
  const completedGoals = goals.filter((g) => g.status === 'completed').length;

  const filteredGoals =
    selectedCategory === 'all' ? goals : goals.filter((g) => g.category.toLowerCase() === selectedCategory);

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Goals & KPI Tracking</h1>
          <p className="text-muted-foreground">Set, track, and achieve your marketing objectives</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="revenue">Revenue</SelectItem>
              <SelectItem value="growth">Growth</SelectItem>
              <SelectItem value="efficiency">Efficiency</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={showNewGoalDialog} onOpenChange={setShowNewGoalDialog}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Goal
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Goal</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Goal Name</Label>
                  <Input placeholder="e.g., Q1 Revenue Target" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="revenue">Revenue</SelectItem>
                        <SelectItem value="growth">Growth</SelectItem>
                        <SelectItem value="efficiency">Efficiency</SelectItem>
                        <SelectItem value="marketing">Marketing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Target Value</Label>
                    <Input type="number" placeholder="1000000" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Deadline</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>Owner</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Assign" />
                      </SelectTrigger>
                      <SelectContent>
                        {teamMembers.map((member) => (
                          <SelectItem key={member.name} value={member.name}>
                            {member.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Milestones (comma-separated)</Label>
                  <Input placeholder="e.g., 250000, 500000, 750000, 1000000" />
                </div>
                <Button className="w-full">Create Goal</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Goals</p>
                <p className="text-3xl font-bold">{totalGoals}</p>
              </div>
              <Target className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{categoryData.length} categories</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">On Track</p>
                <p className="text-3xl font-bold text-success">{onTrackGoals}</p>
              </div>
              <CheckCircle2 className="h-10 w-10 text-success" />
            </div>
            <Progress value={(onTrackGoals / totalGoals) * 100} className="h-2 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">At Risk</p>
                <p className="text-3xl font-bold text-destructive">{atRiskGoals}</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-destructive" />
            </div>
            <p className="mt-2 text-xs text-destructive">Needs attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold">{completedGoals}</p>
              </div>
              <Trophy className="h-10 w-10 text-warning" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              +2 this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Progress</p>
                <p className="text-3xl font-bold">83%</p>
              </div>
              <BarChart3 className="h-10 w-10 text-chart-4" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <ArrowUpRight className="h-3 w-3" />
              +6% vs last week
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Milestone Alerts */}
      {milestoneAlerts.length > 0 && (
        <Card className="border-warning/30 bg-warning/5">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Bell className="h-5 w-5 text-warning" />
              <span className="font-semibold">Upcoming Milestones</span>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              {milestoneAlerts.map((alert, i) => (
                <div key={i} className="flex items-start gap-3 rounded-lg bg-background/50 p-3">
                  <Flag
                    className={`h-5 w-5 mt-0.5 ${
                      alert.status === 'at-risk'
                        ? 'text-destructive'
                        : alert.status === 'approaching'
                          ? 'text-warning'
                          : 'text-success'
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{alert.goal}</p>
                    <p className="text-xs text-muted-foreground">{alert.milestone}</p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs">Current: {alert.current}</span>
                      <Badge
                        variant={
                          alert.status === 'at-risk'
                            ? 'destructive'
                            : alert.status === 'approaching'
                              ? 'default'
                              : 'secondary'
                        }
                        className="text-xs"
                      >
                        {alert.dueIn}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="goals" className="space-y-6">
        <TabsList>
          <TabsTrigger value="goals">Active Goals</TabsTrigger>
          <TabsTrigger value="progress">Progress Trends</TabsTrigger>
          <TabsTrigger value="team">Team Performance</TabsTrigger>
          <TabsTrigger value="analytics">Goal Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="goals" className="space-y-6">
          <div className="grid gap-4">
            {filteredGoals.map((goal) => (
              <Card
                key={goal.id}
                className={`transition-all hover:shadow-md ${
                  goal.status === 'at-risk'
                    ? 'border-destructive/30'
                    : goal.status === 'completed'
                      ? 'border-success/30'
                      : ''
                }`}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div
                        className={`p-3 rounded-lg ${
                          goal.status === 'completed'
                            ? 'bg-success/10'
                            : goal.status === 'at-risk'
                              ? 'bg-destructive/10'
                              : goal.status === 'ahead'
                                ? 'bg-chart-1/10'
                                : 'bg-primary/10'
                        }`}
                      >
                        {goal.status === 'completed' ? (
                          <Trophy className="h-6 w-6 text-success" />
                        ) : goal.status === 'at-risk' ? (
                          <AlertTriangle className="h-6 w-6 text-destructive" />
                        ) : (
                          <Target className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-semibold text-lg">{goal.name}</h3>
                          <Badge variant="outline">{goal.category}</Badge>
                          <Badge
                            variant={
                              goal.status === 'completed'
                                ? 'default'
                                : goal.status === 'ahead'
                                  ? 'default'
                                  : goal.status === 'at-risk'
                                    ? 'destructive'
                                    : 'secondary'
                            }
                            className={
                              goal.status === 'completed' || goal.status === 'ahead'
                                ? 'bg-success text-success-foreground'
                                : ''
                            }
                          >
                            {goal.status}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-6 text-sm text-muted-foreground mb-4">
                          <div className="flex items-center gap-1">
                            <Avatar className="h-5 w-5">
                              <AvatarFallback className="text-[10px]">{goal.owner.avatar}</AvatarFallback>
                            </Avatar>
                            <span>{goal.owner.name}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>{goal.deadline}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            <span>{goal.daysRemaining} days left</span>
                          </div>
                          <div
                            className={`flex items-center gap-1 ${goal.trend === 'up' ? 'text-success' : 'text-destructive'}`}
                          >
                            {goal.trend === 'up' ? (
                              <TrendingUp className="h-4 w-4" />
                            ) : (
                              <TrendingDown className="h-4 w-4" />
                            )}
                            <span>
                              {goal.trendValue > 0 ? '+' : ''}
                              {goal.trendValue}% this week
                            </span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="font-medium">
                              {typeof goal.current === 'number' && goal.current >= 1000
                                ? `$${(goal.current / 1000).toFixed(0)}K`
                                : goal.current.toLocaleString()}
                              {' / '}
                              {typeof goal.target === 'number' && goal.target >= 1000
                                ? `$${(goal.target / 1000).toFixed(0)}K`
                                : goal.target.toLocaleString()}
                            </span>
                            <span className="font-bold">{goal.progress.toFixed(1)}%</span>
                          </div>
                          <Progress value={Math.min(goal.progress, 100)} className="h-3" />
                        </div>

                        <div className="flex items-center gap-2 mt-4">
                          <span className="text-xs text-muted-foreground">Milestones:</span>
                          {goal.milestones.map((ms, i) => (
                            <div
                              key={i}
                              className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
                                ms.achieved ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                              }`}
                            >
                              {ms.achieved ? <CheckCircle2 className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                              {ms.name}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Goal Progress Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={progressTrendData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="week" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `${v}%`} />
                  <Tooltip formatter={(value) => [`${value}%`, '']} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.3}
                    name="Revenue"
                  />
                  <Area
                    type="monotone"
                    dataKey="customers"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.3}
                    name="Customers"
                  />
                  <Area
                    type="monotone"
                    dataKey="roas"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    fillOpacity={0.3}
                    name="ROAS"
                  />
                  <Area
                    type="monotone"
                    dataKey="cac"
                    stroke="hsl(var(--chart-4))"
                    fill="hsl(var(--chart-4))"
                    fillOpacity={0.3}
                    name="CAC"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Goal Completion Velocity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {goals.slice(0, 4).map((goal) => {
                    const velocity = goal.progress / (30 - goal.daysRemaining || 1);
                    const requiredVelocity = (100 - goal.progress) / goal.daysRemaining;
                    const isOnPace = velocity >= requiredVelocity;

                    return (
                      <div key={goal.id} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>{goal.name}</span>
                          <span className={isOnPace ? 'text-success' : 'text-destructive'}>
                            {velocity.toFixed(1)}%/day {isOnPace ? '✓' : '⚠'}
                          </span>
                        </div>
                        <div className="flex gap-1 h-2">
                          <div className="flex-1 rounded-l bg-success/20">
                            <div
                              className="h-full rounded-l bg-success"
                              style={{ width: `${Math.min((velocity / (requiredVelocity * 2)) * 100, 100)}%` }}
                            />
                          </div>
                          <div className="w-px bg-muted-foreground" />
                          <div className="flex-1 rounded-r bg-muted" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Need {requiredVelocity.toFixed(1)}%/day to hit target
                        </p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Category Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={categoryData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis type="number" className="text-xs" />
                    <YAxis dataKey="name" type="category" className="text-xs" width={80} />
                    <Tooltip />
                    <Bar dataKey="onTrack" fill="hsl(var(--success))" name="On Track" />
                    <Bar dataKey="value" fill="hsl(var(--muted))" name="Total" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Team Leaderboard</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rank</TableHead>
                      <TableHead>Team Member</TableHead>
                      <TableHead>Goals Owned</TableHead>
                      <TableHead>On Track</TableHead>
                      <TableHead>Contribution</TableHead>
                      <TableHead>Streak</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teamMembers
                      .sort((a, b) => b.contribution - a.contribution)
                      .map((member, i) => (
                        <TableRow key={member.name}>
                          <TableCell>
                            {i === 0 ? (
                              <Trophy className="h-5 w-5 text-yellow-500" />
                            ) : i === 1 ? (
                              <Trophy className="h-5 w-5 text-gray-400" />
                            ) : i === 2 ? (
                              <Trophy className="h-5 w-5 text-amber-700" />
                            ) : (
                              <span className="text-muted-foreground">#{i + 1}</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback>{member.avatar}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{member.name}</p>
                                <p className="text-xs text-muted-foreground">{member.role}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{member.goalsOwned}</TableCell>
                          <TableCell>
                            <Badge variant={member.goalsOnTrack === member.goalsOwned ? 'default' : 'secondary'}>
                              {member.goalsOnTrack}/{member.goalsOwned}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={member.contribution} className="h-2 w-16" />
                              <span className="text-sm font-medium">{member.contribution}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Flame
                                className={`h-4 w-4 ${member.streak >= 10 ? 'text-orange-500' : 'text-muted-foreground'}`}
                              />
                              <span className="text-sm">{member.streak} days</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Award className="h-5 w-5 text-warning" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-warning/10">
                  <Star className="h-8 w-8 text-warning" />
                  <div>
                    <p className="font-medium">Goal Crusher</p>
                    <p className="text-xs text-muted-foreground">Jordan Lee - Exceeded email target by 4.8%</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-success/10">
                  <Flame className="h-8 w-8 text-orange-500" />
                  <div>
                    <p className="font-medium">22-Day Streak</p>
                    <p className="text-xs text-muted-foreground">Jordan Lee - Longest active streak</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-chart-1/10">
                  <TrendingUp className="h-8 w-8 text-chart-1" />
                  <div>
                    <p className="font-medium">Top Performer</p>
                    <p className="text-xs text-muted-foreground">Sarah Chen - 32% team contribution</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-chart-2/10">
                  <Users className="h-8 w-8 text-chart-2" />
                  <div>
                    <p className="font-medium">Growth Champion</p>
                    <p className="text-xs text-muted-foreground">Mike Johnson - +12.4% customer growth</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Goal Success Rate by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RePieChart>
                    <Pie
                      data={categoryData.map((c) => ({ name: c.name, value: c.onTrack }))}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {categoryData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RePieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  AI Goal Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-lg bg-success/10 border border-success/20">
                  <p className="text-sm font-medium text-success">Strong Performance</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Customer Acquisition goal is 12% ahead of pace. Consider increasing target by 15% for next quarter.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-sm font-medium text-destructive">Attention Needed</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    CAC Reduction goal requires 2.8x velocity improvement. Recommend pausing low-performing channels.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-chart-1/10 border border-chart-1/20">
                  <p className="text-sm font-medium">Optimization Opportunity</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Shifting 10% budget to TikTok could accelerate Revenue goal by 8 days based on current ROAS trends.
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-muted">
                  <p className="text-sm font-medium">Forecast</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    At current velocity, 4 of 5 goals will be achieved by deadline. Overall success probability: 86%
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
