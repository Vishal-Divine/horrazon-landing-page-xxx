import { useState } from 'react';
import { Link } from 'react-router-dom';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  CreditCard,
  Download,
  FileText,
  Plus,
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  Calendar,
  Check,
  Crown,
  Zap,
  Shield,
  DollarSign,
  Building,
  Users,
  BarChart3,
  RefreshCw,
  CheckCircle2,
  ArrowLeft,
  PieChart,
} from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { format } from 'date-fns';
import { toast } from '@/hooks/use-toast';
import { UsageAnalytics, CostComparisonChart, SmartRecommendations, UsageSummaryCard } from '@/components/billing';

// Mock data for invoices
const invoices = [
  {
    id: 'INV-2024-012',
    date: new Date(2024, 11, 1),
    amount: 299.0,
    status: 'paid',
    description: 'Pro Plan - December 2024',
  },
  {
    id: 'INV-2024-011',
    date: new Date(2024, 10, 1),
    amount: 299.0,
    status: 'paid',
    description: 'Pro Plan - November 2024',
  },
  {
    id: 'INV-2024-010',
    date: new Date(2024, 9, 1),
    amount: 299.0,
    status: 'paid',
    description: 'Pro Plan - October 2024',
  },
  {
    id: 'INV-2024-009',
    date: new Date(2024, 8, 1),
    amount: 199.0,
    status: 'paid',
    description: 'Starter Plan - September 2024',
  },
  {
    id: 'INV-2024-008',
    date: new Date(2024, 7, 1),
    amount: 199.0,
    status: 'paid',
    description: 'Starter Plan - August 2024',
  },
  {
    id: 'INV-2024-007',
    date: new Date(2024, 6, 1),
    amount: 199.0,
    status: 'paid',
    description: 'Starter Plan - July 2024',
  },
];

// Mock payment methods
const paymentMethods = [
  { id: '1', type: 'card', brand: 'Visa', last4: '4242', expiry: '12/26', isDefault: true },
  { id: '2', type: 'card', brand: 'Mastercard', last4: '8888', expiry: '03/25', isDefault: false },
];

// Subscription plans
const plans = [
  {
    id: 'starter',
    name: 'Starter',
    price: 199,
    period: 'month',
    features: [
      'Up to $50K monthly ad spend tracking',
      '5 team members',
      'Basic AI recommendations',
      'Email support',
      '7-day data retention',
    ],
    recommended: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 299,
    period: 'month',
    features: [
      'Up to $500K monthly ad spend tracking',
      'Unlimited team members',
      'Advanced AI automation',
      'Priority support',
      '90-day data retention',
      'Custom reports',
      'API access',
    ],
    recommended: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 799,
    period: 'month',
    features: [
      'Unlimited ad spend tracking',
      'Unlimited team members',
      'Custom AI models',
      'Dedicated success manager',
      'Unlimited data retention',
      'White-label options',
      'SLA guarantee',
      'Custom integrations',
    ],
    recommended: false,
  },
];

export default function BillingSettings() {
  const { wallet, transactions, setIsAddFundsOpen } = useApp();
  const [currentPlan] = useState('pro');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [autoRechargeEnabled, setAutoRechargeEnabled] = useState(true);
  const [autoRechargeThreshold, setAutoRechargeThreshold] = useState('5000');
  const [autoRechargeAmount, setAutoRechargeAmount] = useState('5000');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const handleDownloadInvoice = (invoiceId: string) => {
    toast({
      title: 'Downloading Invoice',
      description: `${invoiceId}.pdf is being downloaded...`,
    });
  };

  const handleUpgradePlan = (planId: string) => {
    toast({
      title: 'Plan Upgrade Initiated',
      description: `You're upgrading to the ${planId.charAt(0).toUpperCase() + planId.slice(1)} plan.`,
    });
  };

  const currentPlanData = plans.find((p) => p.id === currentPlan);
  const nextBillingDate = new Date(2025, 0, 1);
  const daysUntilRenewal = Math.ceil((nextBillingDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

  return (
    <div className="space-y-6 p-8">
      <SEOHead
        title="Billing & Subscription"
        description="Manage your subscription plan, payment methods, and billing history."
        keywords="billing, subscription, payment methods, invoices, pricing plans"
      />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/settings">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Billing & Subscription</h1>
            <p className="text-muted-foreground">Manage your plan, payment methods, and billing history</p>
          </div>
        </div>
        <Button onClick={() => setIsAddFundsOpen(true)} className="gap-2 bg-gradient-to-r from-success to-emerald-500">
          <Plus className="h-4 w-4" />
          Add Funds
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Wallet Balance</p>
                <p className="text-2xl font-bold text-primary">{formatCurrency(wallet.balance)}</p>
              </div>
              <div className="p-3 rounded-xl bg-primary/10">
                <Wallet className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Badge variant="outline" className="text-[10px]">
                {Math.round(wallet.balance / (wallet.dailySpent || 1))} days runway
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Spend</p>
                <p className="text-2xl font-bold">{formatCurrency(wallet.monthlySpent)}</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-3/10">
                <TrendingUp className="h-6 w-6 text-chart-3" />
              </div>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              <span className="text-success">+12%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Current Plan</p>
                <p className="text-2xl font-bold flex items-center gap-2">
                  Pro
                  <Crown className="h-5 w-5 text-warning" />
                </p>
              </div>
              <div className="p-3 rounded-xl bg-warning/10">
                <Zap className="h-6 w-6 text-warning" />
              </div>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Renews in {daysUntilRenewal} days</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Next Invoice</p>
                <p className="text-2xl font-bold">{formatCurrency(currentPlanData?.price || 299)}</p>
              </div>
              <div className="p-3 rounded-xl bg-muted">
                <Calendar className="h-6 w-6 text-muted-foreground" />
              </div>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Due {format(nextBillingDate, 'MMM d, yyyy')}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <PieChart className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="subscription" className="gap-2">
            <Crown className="h-4 w-4" />
            Subscription
          </TabsTrigger>
          <TabsTrigger value="wallet" className="gap-2">
            <Wallet className="h-4 w-4" />
            Wallet
          </TabsTrigger>
          <TabsTrigger value="invoices" className="gap-2">
            <FileText className="h-4 w-4" />
            Invoices
          </TabsTrigger>
          <TabsTrigger value="payment-methods" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Payment Methods
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Current Plan Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-warning" />
                    Current Plan
                  </span>
                  <Badge className="bg-warning/10 text-warning border-warning/20">Pro</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div>
                    <p className="font-semibold text-lg">{formatCurrency(currentPlanData?.price || 299)}/month</p>
                    <p className="text-sm text-muted-foreground">Billed monthly</p>
                  </div>
                  <Button variant="outline">Change Plan</Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Ad Spend Tracked</span>
                    <span className="font-medium">{formatCurrency(wallet.totalSpent)} / $500K</span>
                  </div>
                  <Progress value={(wallet.totalSpent / 500000) * 100} className="h-2" />
                </div>

                <Separator />

                <div className="space-y-2">
                  <p className="text-sm font-medium">Plan Features:</p>
                  <ul className="space-y-1">
                    {currentPlanData?.features.slice(0, 4).map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Spending Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-chart-1" />
                  Spending Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Today</p>
                    <p className="text-xl font-bold">{formatCurrency(wallet.dailySpent)}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">This Week</p>
                    <p className="text-xl font-bold">{formatCurrency(wallet.dailySpent * 5.2)}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">This Month</p>
                    <p className="text-xl font-bold">{formatCurrency(wallet.monthlySpent)}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Total Spent</p>
                    <p className="text-xl font-bold">{formatCurrency(wallet.totalSpent)}</p>
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <p className="text-sm font-medium">Recent Activity</p>
                  {transactions.slice(0, 3).map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={`p-1.5 rounded-full ${
                            tx.type === 'credit' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                          }`}
                        >
                          {tx.type === 'credit' ? (
                            <ArrowDownLeft className="h-3 w-3" />
                          ) : (
                            <ArrowUpRight className="h-3 w-3" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{tx.description}</p>
                          <p className="text-xs text-muted-foreground">{format(tx.date, 'MMM d, h:mm a')}</p>
                        </div>
                      </div>
                      <span className={`font-semibold ${tx.type === 'credit' ? 'text-success' : 'text-destructive'}`}>
                        {tx.type === 'credit' ? '+' : '-'}
                        {formatCurrency(tx.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <UsageAnalytics />
        </TabsContent>

        {/* Subscription Tab */}
        <TabsContent value="subscription" className="space-y-6">
          {/* Billing Cycle Toggle */}
          <div className="flex items-center justify-center gap-4 p-4 rounded-lg bg-muted/50">
            <span className={billingCycle === 'monthly' ? 'font-medium' : 'text-muted-foreground'}>Monthly</span>
            <Switch
              checked={billingCycle === 'yearly'}
              onCheckedChange={(checked) => setBillingCycle(checked ? 'yearly' : 'monthly')}
            />
            <span className={billingCycle === 'yearly' ? 'font-medium' : 'text-muted-foreground'}>
              Yearly
              <Badge className="ml-2 bg-success/10 text-success">Save 20%</Badge>
            </span>
          </div>

          {/* Plans Grid */}
          <div className="grid gap-6 md:grid-cols-3">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`relative ${
                  plan.recommended ? 'border-primary shadow-lg shadow-primary/10' : ''
                } ${currentPlan === plan.id ? 'ring-2 ring-primary' : ''}`}
              >
                {plan.recommended && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                  </div>
                )}
                {currentPlan === plan.id && (
                  <div className="absolute -top-3 right-4">
                    <Badge variant="outline" className="bg-background">
                      Current Plan
                    </Badge>
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {plan.name}
                    {plan.id === 'enterprise' && <Building className="h-5 w-5 text-muted-foreground" />}
                    {plan.id === 'pro' && <Crown className="h-5 w-5 text-warning" />}
                  </CardTitle>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold">
                      ${billingCycle === 'yearly' ? Math.round(plan.price * 0.8) : plan.price}
                    </span>
                    <span className="text-muted-foreground">/{plan.period}</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 text-success shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full"
                    variant={currentPlan === plan.id ? 'outline' : plan.recommended ? 'default' : 'outline'}
                    disabled={currentPlan === plan.id}
                    onClick={() => handleUpgradePlan(plan.id)}
                  >
                    {currentPlan === plan.id ? 'Current Plan' : plan.id === 'enterprise' ? 'Contact Sales' : 'Upgrade'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Wallet Tab */}
        <TabsContent value="wallet" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Wallet Balance Card */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Wallet className="h-5 w-5" />
                    Wallet Balance
                  </span>
                  <Button onClick={() => setIsAddFundsOpen(true)} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Funds
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 rounded-xl bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 border border-primary/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Available Balance</p>
                      <p className="text-4xl font-bold text-primary">{formatCurrency(wallet.balance)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Pending</p>
                      <p className="text-xl font-semibold text-chart-3">{formatCurrency(wallet.pendingCharges)}</p>
                    </div>
                  </div>
                  <Separator className="my-4" />
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-xs text-muted-foreground">Today</p>
                      <p className="font-semibold">{formatCurrency(wallet.dailySpent)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">This Month</p>
                      <p className="font-semibold">{formatCurrency(wallet.monthlySpent)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Est. Runway</p>
                      <p className="font-semibold text-primary">
                        {Math.round(wallet.balance / (wallet.dailySpent || 1))} days
                      </p>
                    </div>
                  </div>
                </div>

                {/* Transaction History */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold">Recent Transactions</h3>
                    <Button variant="ghost" size="sm">
                      View All
                    </Button>
                  </div>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {transactions.map((tx) => (
                        <div
                          key={tx.id}
                          className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`p-2 rounded-full ${
                                tx.type === 'credit'
                                  ? 'bg-success/10 text-success'
                                  : 'bg-destructive/10 text-destructive'
                              }`}
                            >
                              {tx.type === 'credit' ? (
                                <ArrowDownLeft className="h-4 w-4" />
                              ) : (
                                <ArrowUpRight className="h-4 w-4" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium">{tx.description}</p>
                              {tx.campaign && <p className="text-xs text-muted-foreground">{tx.campaign}</p>}
                              <p className="text-xs text-muted-foreground">
                                {format(tx.date, "MMM d, yyyy 'at' h:mm a")}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p
                              className={`font-semibold ${tx.type === 'credit' ? 'text-success' : 'text-destructive'}`}
                            >
                              {tx.type === 'credit' ? '+' : '-'}
                              {formatCurrency(tx.amount)}
                            </p>
                            <Badge
                              variant={tx.status === 'completed' ? 'secondary' : 'outline'}
                              className="text-[10px]"
                            >
                              {tx.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>

            {/* Auto-Recharge Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="h-5 w-5" />
                  Auto-Recharge
                </CardTitle>
                <CardDescription>Automatically add funds when balance is low</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Enable Auto-Recharge</p>
                    <p className="text-sm text-muted-foreground">Never run out of funds</p>
                  </div>
                  <Switch checked={autoRechargeEnabled} onCheckedChange={setAutoRechargeEnabled} />
                </div>

                {autoRechargeEnabled && (
                  <>
                    <Separator />
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Recharge when balance falls below</Label>
                        <Select value={autoRechargeThreshold} onValueChange={setAutoRechargeThreshold}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1000">$1,000</SelectItem>
                            <SelectItem value="2500">$2,500</SelectItem>
                            <SelectItem value="5000">$5,000</SelectItem>
                            <SelectItem value="10000">$10,000</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Recharge amount</Label>
                        <Select value={autoRechargeAmount} onValueChange={setAutoRechargeAmount}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1000">$1,000</SelectItem>
                            <SelectItem value="2500">$2,500</SelectItem>
                            <SelectItem value="5000">$5,000</SelectItem>
                            <SelectItem value="10000">$10,000</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="p-3 rounded-lg bg-success/5 border border-success/20">
                        <div className="flex items-center gap-2 text-success">
                          <CheckCircle2 className="h-4 w-4" />
                          <span className="text-sm font-medium">Auto-recharge is active</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          We'll charge ${parseInt(autoRechargeAmount).toLocaleString()} when balance drops below $
                          {parseInt(autoRechargeThreshold).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </>
                )}

                <Separator />

                <div className="space-y-2">
                  <Label>Low Balance Alert</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified when your balance falls below ${wallet.lowBalanceThreshold.toLocaleString()}
                  </p>
                  <Button variant="outline" className="w-full">
                    Configure Alerts
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Invoices Tab */}
        <TabsContent value="invoices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Invoice History
                </span>
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Download All
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.id}</TableCell>
                      <TableCell>{format(invoice.date, 'MMM d, yyyy')}</TableCell>
                      <TableCell>{invoice.description}</TableCell>
                      <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          {invoice.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDownloadInvoice(invoice.id)}
                          className="gap-2"
                        >
                          <Download className="h-4 w-4" />
                          PDF
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Billing Address */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Billing Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Company Name</Label>
                    <Input defaultValue="Acme Corporation" />
                  </div>
                  <div className="space-y-2">
                    <Label>Billing Email</Label>
                    <Input defaultValue="billing@acme.com" type="email" />
                  </div>
                  <div className="space-y-2">
                    <Label>Tax ID / VAT Number</Label>
                    <Input placeholder="Optional" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Address</Label>
                    <Input defaultValue="123 Business Ave" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>City</Label>
                      <Input defaultValue="San Francisco" />
                    </div>
                    <div className="space-y-2">
                      <Label>ZIP Code</Label>
                      <Input defaultValue="94105" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Country</Label>
                    <Select defaultValue="us">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us">United States</SelectItem>
                        <SelectItem value="uk">United Kingdom</SelectItem>
                        <SelectItem value="ca">Canada</SelectItem>
                        <SelectItem value="au">Australia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <Button>Save Billing Info</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Methods Tab */}
        <TabsContent value="payment-methods" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Methods
                </span>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add Payment Method
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Payment Method</DialogTitle>
                      <DialogDescription>Add a new credit or debit card for payments</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label>Card Number</Label>
                        <Input placeholder="4242 4242 4242 4242" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Expiry Date</Label>
                          <Input placeholder="MM/YY" />
                        </div>
                        <div className="space-y-2">
                          <Label>CVV</Label>
                          <Input placeholder="123" type="password" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Name on Card</Label>
                        <Input placeholder="John Doe" />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="default-card" />
                        <Label htmlFor="default-card">Set as default payment method</Label>
                      </div>
                      <Button className="w-full">Add Card</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      method.isDefault ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                    } transition-colors`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-muted">
                        <CreditCard className="h-6 w-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">
                            {method.brand} •••• {method.last4}
                          </p>
                          {method.isDefault && (
                            <Badge variant="outline" className="text-[10px]">
                              Default
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">Expires {method.expiry}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!method.isDefault && (
                        <Button variant="outline" size="sm">
                          Set as Default
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="my-6" />

              <div className="flex items-center gap-2 p-4 rounded-lg bg-muted/50">
                <Shield className="h-5 w-5 text-success" />
                <div>
                  <p className="font-medium">Your payment information is secure</p>
                  <p className="text-sm text-muted-foreground">All transactions are encrypted with 256-bit SSL</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
