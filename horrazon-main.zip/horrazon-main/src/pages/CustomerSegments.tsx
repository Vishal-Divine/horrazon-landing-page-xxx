import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { useState } from 'react';
import {
  Users,
  Plus,
  Target,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Filter,
  BarChart3,
  PieChart,
  RefreshCw,
  Download,
  Edit,
  Trash2,
  Copy,
  UserPlus,
  Eye,
  Zap,
  DollarSign,
  ShoppingCart,
  Calendar,
  MapPin,
  Smartphone,
  Globe,
  Heart,
  Tag,
  ArrowRight,
  ChevronRight,
  Search,
} from 'lucide-react';
import {
  PieChart as RechartsPie,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from 'recharts';
import { toast } from 'sonner';

interface Segment {
  id: string;
  name: string;
  size: number;
  revenue: number;
  cltv: number;
  conversionRate: number;
  aov: number;
  growth: number;
  color: string;
  type: 'behavioral' | 'demographic' | 'lookalike' | 'custom';
  status: 'active' | 'draft';
}

const segments: Segment[] = [
  {
    id: '1',
    name: 'High-Value Loyalists',
    size: 12500,
    revenue: 2850000,
    cltv: 1250,
    conversionRate: 8.4,
    aov: 185,
    growth: 12,
    color: '#6366f1',
    type: 'behavioral',
    status: 'active',
  },
  {
    id: '2',
    name: 'Gen Z Trendsetters',
    size: 45000,
    revenue: 1620000,
    cltv: 420,
    conversionRate: 4.2,
    aov: 78,
    growth: 28,
    color: '#22c55e',
    type: 'demographic',
    status: 'active',
  },
  {
    id: '3',
    name: 'Millennial Parents',
    size: 32000,
    revenue: 2240000,
    cltv: 680,
    conversionRate: 5.8,
    aov: 142,
    growth: 8,
    color: '#f59e0b',
    type: 'demographic',
    status: 'active',
  },
  {
    id: '4',
    name: 'Deal Seekers',
    size: 58000,
    revenue: 1160000,
    cltv: 280,
    conversionRate: 3.2,
    aov: 52,
    growth: -4,
    color: '#ef4444',
    type: 'behavioral',
    status: 'active',
  },
  {
    id: '5',
    name: 'Lookalike - VIP',
    size: 28000,
    revenue: 840000,
    cltv: 520,
    conversionRate: 4.8,
    aov: 95,
    growth: 22,
    color: '#8b5cf6',
    type: 'lookalike',
    status: 'active',
  },
  {
    id: '6',
    name: 'Cart Abandoners',
    size: 15000,
    revenue: 450000,
    cltv: 320,
    conversionRate: 2.1,
    aov: 88,
    growth: -8,
    color: '#ec4899',
    type: 'behavioral',
    status: 'active',
  },
];

const behaviorClusters = [
  { name: 'Browse Only', value: 35 },
  { name: 'One-Time Buyer', value: 28 },
  { name: 'Repeat Customer', value: 22 },
  { name: 'VIP Loyalist', value: 15 },
];

const clusterColors = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444'];

const segmentComparison = [
  { metric: 'ROAS', segment1: 4.2, segment2: 3.1, segment3: 2.8 },
  { metric: 'CTR', segment1: 3.8, segment2: 2.9, segment3: 2.2 },
  { metric: 'CVR', segment1: 8.4, segment2: 5.8, segment3: 3.2 },
  { metric: 'AOV', segment1: 185, segment2: 142, segment3: 52 },
  { metric: 'Retention', segment1: 72, segment2: 58, segment3: 34 },
];

const radarData = [
  { attribute: 'Purchase Freq', A: 85, B: 65, C: 45 },
  { attribute: 'Avg Order', A: 92, B: 72, C: 38 },
  { attribute: 'Engagement', A: 78, B: 58, C: 42 },
  { attribute: 'Brand Affinity', A: 88, B: 62, C: 35 },
  { attribute: 'Recency', A: 95, B: 75, C: 55 },
  { attribute: 'Lifetime Value', A: 90, B: 68, C: 32 },
];

const builderConditions = [
  { category: 'Demographics', options: ['Age Range', 'Gender', 'Location', 'Income Level', 'Education'] },
  {
    category: 'Behavior',
    options: ['Purchase Frequency', 'Last Purchase', 'Browse History', 'Cart Activity', 'Email Engagement'],
  },
  {
    category: 'Transaction',
    options: ['Total Spend', 'Avg Order Value', 'Product Categories', 'Discount Usage', 'Return Rate'],
  },
  {
    category: 'Channel',
    options: ['Acquisition Source', 'Device Type', 'Platform Preference', 'Social Media Activity'],
  },
];

export default function CustomerSegments() {
  const [selectedSegment, setSelectedSegment] = useState(segments[0]);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [builderRules, setBuilderRules] = useState([
    { condition: 'Total Spend', operator: 'greater than', value: '$500' },
    { condition: 'Purchase Frequency', operator: 'at least', value: '3 orders' },
  ]);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSegments = segments.filter((s) => s.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const totalCustomers = segments.reduce((acc, s) => acc + s.size, 0);
  const totalRevenue = segments.reduce((acc, s) => acc + s.revenue, 0);

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Customer Segments</h1>
          <p className="text-muted-foreground">Build, analyze, and target high-value customer groups</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={isBuilderOpen} onOpenChange={setIsBuilderOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Segment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  Segment Builder
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="space-y-2">
                  <Label>Segment Name</Label>
                  <Input placeholder="e.g., High-Intent Browsers" />
                </div>

                <div className="space-y-3">
                  <Label>Conditions</Label>
                  {builderRules.map((rule, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-3 rounded-lg border bg-accent/20">
                      <Select defaultValue={rule.condition}>
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {builderConditions
                            .flatMap((c) => c.options)
                            .map((opt) => (
                              <SelectItem key={opt} value={opt}>
                                {opt}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <Select defaultValue={rule.operator}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="greater than">greater than</SelectItem>
                          <SelectItem value="less than">less than</SelectItem>
                          <SelectItem value="equals">equals</SelectItem>
                          <SelectItem value="at least">at least</SelectItem>
                          <SelectItem value="contains">contains</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input className="flex-1" defaultValue={rule.value} />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setBuilderRules((rules) => rules.filter((_, i) => i !== idx))}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() =>
                      setBuilderRules((rules) => [...rules, { condition: 'Age Range', operator: 'equals', value: '' }])
                    }
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Condition
                  </Button>
                </div>

                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-medium">Estimated Segment Size</span>
                    <Badge variant="outline">Calculating...</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold">~18,500</p>
                      <p className="text-xs text-muted-foreground">Customers</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">$1.2M</p>
                      <p className="text-xs text-muted-foreground">Est. Revenue</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">9.2%</p>
                      <p className="text-xs text-muted-foreground">of Total Base</p>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-emerald-500" />
                    <span className="text-sm font-medium">AI Suggestion</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Adding "Email Engagement &gt; 50%" could increase segment value by 15% while only reducing size by
                    8%.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsBuilderOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    toast.success('Segment created successfully');
                    setIsBuilderOpen(false);
                  }}
                >
                  Create Segment
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Segments</p>
                <p className="text-3xl font-bold">{segments.length}</p>
              </div>
              <div className="p-3 rounded-full bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Segmented Customers</p>
                <p className="text-3xl font-bold">{(totalCustomers / 1000).toFixed(1)}K</p>
              </div>
              <div className="p-3 rounded-full bg-emerald-500/10">
                <UserPlus className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Segment Revenue</p>
                <p className="text-3xl font-bold">${(totalRevenue / 1000000).toFixed(1)}M</p>
              </div>
              <div className="p-3 rounded-full bg-blue-500/10">
                <DollarSign className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Segment CLTV</p>
                <p className="text-3xl font-bold">
                  ${Math.round(segments.reduce((a, s) => a + s.cltv, 0) / segments.length)}
                </p>
              </div>
              <div className="p-3 rounded-full bg-amber-500/10">
                <Heart className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="segments" className="space-y-6">
        <TabsList>
          <TabsTrigger value="segments" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Segments
          </TabsTrigger>
          <TabsTrigger value="clustering" className="flex items-center gap-2">
            <PieChart className="h-4 w-4" />
            Behavioral Clustering
          </TabsTrigger>
          <TabsTrigger value="lookalike" className="flex items-center gap-2">
            <Copy className="h-4 w-4" />
            Lookalike Audiences
          </TabsTrigger>
          <TabsTrigger value="comparison" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Comparison
          </TabsTrigger>
        </TabsList>

        {/* Segments Tab */}
        <TabsContent value="segments" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search segments..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                {filteredSegments.map((segment) => (
                  <div
                    key={segment.id}
                    onClick={() => setSelectedSegment(segment)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedSegment.id === segment.id ? 'border-primary bg-primary/5' : 'hover:bg-accent/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: segment.color }} />
                        <span className="font-medium">{segment.name}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {segment.type}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Size:</span> {(segment.size / 1000).toFixed(1)}K
                      </div>
                      <div>
                        <span className="text-muted-foreground">Revenue:</span> $
                        {(segment.revenue / 1000000).toFixed(2)}M
                      </div>
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      {segment.growth >= 0 ? (
                        <TrendingUp className="h-3 w-3 text-emerald-500" />
                      ) : (
                        <TrendingDown className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${segment.growth >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                        {segment.growth >= 0 ? '+' : ''}
                        {segment.growth}% growth
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: selectedSegment.color }} />
                        {selectedSegment.name}
                      </CardTitle>
                      <CardDescription>Segment performance overview</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button size="sm">
                        <Target className="h-4 w-4 mr-1" />
                        Target
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-lg bg-accent/30">
                      <p className="text-sm text-muted-foreground">Segment Size</p>
                      <p className="text-2xl font-bold">{selectedSegment.size.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">
                        {((selectedSegment.size / totalCustomers) * 100).toFixed(1)}% of total
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/30">
                      <p className="text-sm text-muted-foreground">Revenue</p>
                      <p className="text-2xl font-bold">${(selectedSegment.revenue / 1000000).toFixed(2)}M</p>
                      <p className="text-xs text-muted-foreground">
                        {((selectedSegment.revenue / totalRevenue) * 100).toFixed(1)}% of total
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/30">
                      <p className="text-sm text-muted-foreground">Avg. CLTV</p>
                      <p className="text-2xl font-bold">${selectedSegment.cltv}</p>
                      <p className={`text-xs ${selectedSegment.growth >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                        {selectedSegment.growth >= 0 ? '+' : ''}
                        {selectedSegment.growth}% vs last period
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/30">
                      <p className="text-sm text-muted-foreground">Conversion Rate</p>
                      <p className="text-2xl font-bold">{selectedSegment.conversionRate}%</p>
                      <p className="text-xs text-muted-foreground">AOV: ${selectedSegment.aov}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    AI Segment Insights
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <p className="text-sm font-medium">High-Value Opportunity</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      This segment shows 23% higher engagement with video ads. Consider increasing video creative
                      allocation for this audience.
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                    <p className="text-sm font-medium">Cross-Sell Potential</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      42% of this segment purchased in "Electronics" but haven't explored "Accessories". Recommend
                      targeted cross-sell campaigns.
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <p className="text-sm font-medium">Churn Risk Alert</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      8% of segment members show declining engagement. Trigger re-engagement workflow before churn.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Behavioral Clustering */}
        <TabsContent value="clustering" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Customer Behavior Distribution</CardTitle>
                <CardDescription>AI-powered clustering based on purchase patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPie>
                      <Pie
                        data={behaviorClusters}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {behaviorClusters.map((_, idx) => (
                          <Cell key={idx} fill={clusterColors[idx]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {behaviorClusters.map((cluster, idx) => (
                    <div key={cluster.name} className="flex items-center gap-2 p-2 rounded-lg bg-accent/30">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: clusterColors[idx] }} />
                      <span className="text-sm">{cluster.name}</span>
                      <span className="text-sm font-medium ml-auto">{cluster.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Segment Attribute Comparison</CardTitle>
                <CardDescription>Radar comparison of key attributes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid className="stroke-muted" />
                      <PolarAngleAxis dataKey="attribute" className="text-xs" />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} className="text-xs" />
                      <Radar name="High-Value" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.3} />
                      <Radar name="Mid-Tier" dataKey="B" stroke="#22c55e" fill="#22c55e" fillOpacity={0.3} />
                      <Radar name="At-Risk" dataKey="C" stroke="#ef4444" fill="#ef4444" fillOpacity={0.3} />
                      <Legend />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Lookalike Audiences */}
        <TabsContent value="lookalike" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Copy className="h-5 w-5" />
                  Lookalike Audience Builder
                </CardTitle>
                <CardDescription>Create audiences similar to your best customers</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Source Segment</Label>
                    <Select defaultValue="high-value">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high-value">High-Value Loyalists</SelectItem>
                        <SelectItem value="gen-z">Gen Z Trendsetters</SelectItem>
                        <SelectItem value="millennial">Millennial Parents</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Target Platform</Label>
                    <Select defaultValue="meta">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="meta">Meta Ads</SelectItem>
                        <SelectItem value="google">Google Ads</SelectItem>
                        <SelectItem value="tiktok">TikTok Ads</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Similarity Level: 3%</Label>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-muted-foreground">Higher Quality</span>
                    <Progress value={30} className="flex-1" />
                    <span className="text-xs text-muted-foreground">Larger Reach</span>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-accent/30">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold">2.4M</p>
                      <p className="text-xs text-muted-foreground">Estimated Reach</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">87%</p>
                      <p className="text-xs text-muted-foreground">Match Quality</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">$4.20</p>
                      <p className="text-xs text-muted-foreground">Est. ROAS</p>
                    </div>
                  </div>
                </div>

                <Button className="w-full">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Lookalike Audience
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Lookalikes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {['Lookalike - VIP 1%', 'Lookalike - Converters 2%', 'Lookalike - Engagers 3%'].map((name, idx) => (
                  <div key={name} className="p-3 rounded-lg border hover:bg-accent/30 cursor-pointer transition-all">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{name}</span>
                      <Badge variant="outline" className="text-xs">
                        Active
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <span>Reach: {(1.2 + idx * 0.8).toFixed(1)}M</span>
                      <span className="mx-2">•</span>
                      <span>ROAS: {(4.5 - idx * 0.4).toFixed(1)}x</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Comparison Tab */}
        <TabsContent value="comparison" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Segment Performance Comparison</CardTitle>
              <CardDescription>Compare key metrics across your top segments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={segmentComparison} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis type="number" className="text-xs" />
                    <YAxis dataKey="metric" type="category" className="text-xs" width={80} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                    />
                    <Legend />
                    <Bar dataKey="segment1" name="High-Value Loyalists" fill="#6366f1" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="segment2" name="Millennial Parents" fill="#22c55e" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="segment3" name="Deal Seekers" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
