import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { SEOHead } from '@/components/seo';
import EnhancedKPICard from '@/components/EnhancedKPICard';
import PeriodSelector from '@/components/PeriodSelector';
import QuickActionAlert from '@/components/QuickActionAlert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { useLoading } from '@/hooks/useLoading';
import { DailyPulseSkeleton } from '@/components/skeletons';

import { RealtimeMetricsBar } from '@/components/dailypulse/RealtimeMetricsBar';
import { CampaignsTable } from '@/components/dailypulse/CampaignsTable';
import { CampaignDrilldown } from '@/components/dailypulse/CampaignDrilldown';
import { ForecastPanel } from '@/components/dailypulse/ForecastPanel';
import { AutomationPanel } from '@/components/dailypulse/AutomationPanel';
import { CollaborationPanel } from '@/components/dailypulse/CollaborationPanel';
import { CommandCenterSummary } from '@/components/commandcenter';
import { WastedSpendWidget, NetMarginWidget, CreativeGallery } from '@/components/analytics';
import {
  kpisData,
  alertsData,
  insightsData,
  externalFactorsData,
  realtimeMetrics,
} from '@/components/dailypulse/mockData';
import { CampaignData } from '@/components/dailypulse/types';

export default function DailyPulse() {
  const [comparisonPeriod, setComparisonPeriod] = useState('previous_period');
  const [selectedCampaign, setSelectedCampaign] = useState<CampaignData | null>(null);
  const isLoading = useLoading(700);
  const [drilldownOpen, setDrilldownOpen] = useState(false);

  const handleCampaignClick = (campaign: CampaignData) => {
    setSelectedCampaign(campaign);
    setDrilldownOpen(true);
  };

  const alerts = alertsData.map((alert) => ({
    ...alert,
    action: {
      ...alert.action,
      onClick: () => toast({ title: 'Action Applied', description: `${alert.action.label} executed successfully` }),
    },
  }));

  if (isLoading) {
    return <DailyPulseSkeleton />;
  }

  return (
    <div className="space-y-6 p-8 animate-fade-in">
      <SEOHead
        title="Daily Pulse"
        description="Real-time marketing performance intelligence with AI-powered insights and campaign analytics."
        keywords="marketing dashboard, real-time analytics, campaign performance, KPI tracking, marketing intelligence"
      />
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Daily Pulse
          </h1>
          <p className="text-muted-foreground text-lg">Real-time marketing performance intelligence</p>
        </div>
        <PeriodSelector value={comparisonPeriod} onChange={setComparisonPeriod} />
      </div>

      {/* Real-time Metrics Bar */}
      <RealtimeMetricsBar metrics={realtimeMetrics} />

      {/* External Factors Banner */}
      <div className="flex items-center gap-3 p-4 rounded-lg bg-gradient-to-r from-primary/5 via-accent/10 to-primary/5 border border-primary/20 overflow-x-auto">
        {externalFactorsData.map((factor, i) => (
          <div
            key={i}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-card border border-border/50 shrink-0"
          >
            <factor.icon className={`h-4 w-4 ${factor.color}`} />
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-foreground">{factor.label}</span>
              <span className="text-xs text-muted-foreground">{factor.impact}</span>
            </div>
            <Badge variant="outline" className="text-[10px] ml-1">
              {factor.confidence}%
            </Badge>
          </div>
        ))}
      </div>

      {/* Command Center Summary */}
      <CommandCenterSummary />

      {/* Enhanced KPI Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 animate-in fade-in duration-500">
        {kpisData.map((kpi) => (
          <EnhancedKPICard
            key={kpi.title}
            {...kpi}
            comparisonPeriod={comparisonPeriod === 'previous_period' ? 'vs last period' : 'vs last year'}
          />
        ))}
      </div>

      {/* Profit Intelligence Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        <WastedSpendWidget />
        <NetMarginWidget />
      </div>

      {/* Campaigns Table with Drilldown */}
      <CampaignsTable onCampaignClick={handleCampaignClick} />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Forecasting Panel */}
        <ForecastPanel />

        {/* Quick Action Alerts */}
        <Card className="border-border/50 shadow-md">
          <CardHeader className="border-b border-border/50 bg-gradient-to-r from-card to-destructive/5">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-destructive"></span>
                </span>
                Action Required
              </CardTitle>
              <Badge variant="destructive" className="text-xs animate-pulse">
                {alerts.length} Alerts
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3 pt-6">
            {alerts.map((alert, i) => (
              <QuickActionAlert key={i} {...alert} />
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Automation Panel */}
        <AutomationPanel />

        {/* Collaboration Panel */}
        <CollaborationPanel />
      </div>

      {/* Creative Gallery - Above AI Insights */}
      <CreativeGallery />

      {/* AI Insights */}
      <Card className="border-primary/20 bg-gradient-to-br from-card via-primary/5 to-accent/10 shadow-lg shadow-primary/5">
        <CardHeader className="border-b border-primary/10">
          <CardTitle className="flex items-center gap-2">
            <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Sparkles className="h-5 w-5 text-primary animate-pulse" strokeWidth={2.5} />
            </div>
            <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent font-bold">
              AI-Generated Insights
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          {insightsData.map((insight) => (
            <div
              key={insight.id}
              className="group flex gap-3 rounded-lg bg-card/50 p-4 backdrop-blur-sm border border-border/30 transition-all hover:border-primary/30 hover:shadow-md hover:bg-card/70"
            >
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-primary/10 text-xs font-bold text-primary ring-1 ring-primary/20">
                {insight.impact === 'high' ? '!' : insight.impact === 'medium' ? '~' : '-'}
              </div>
              <div className="flex-1">
                <p className="text-sm leading-relaxed text-foreground">{insight.content}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-[10px]">
                    {insight.category}
                  </Badge>
                  <Badge variant={insight.impact === 'high' ? 'default' : 'secondary'} className="text-[10px]">
                    {insight.impact} impact
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Campaign Drilldown Modal */}
      <CampaignDrilldown campaign={selectedCampaign} open={drilldownOpen} onOpenChange={setDrilldownOpen} />
    </div>
  );
}
