import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  Sparkles,
  FileText,
  Palette,
  MessageSquare,
  Settings,
  Plus,
  Copy,
  Download,
  Upload,
  Zap,
  Target,
  BookOpen,
  Mic,
  Globe,
  Users,
  TrendingUp,
  CheckCircle2,
  Edit,
  Trash2,
  Play,
  RefreshCw,
  Star,
  Brain,
  Lightbulb,
  LayoutTemplate,
} from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Brand Voice Configuration
const brandVoiceProfiles = [
  {
    id: 1,
    name: 'Primary Brand Voice',
    tone: 'Professional yet approachable',
    personality: 'Confident, Helpful, Innovative',
    audience: 'Marketing professionals, Business owners',
    doList: ['Use active voice', 'Be concise', 'Include data points', 'Use industry terms'],
    dontList: ['Be overly casual', 'Use jargon without context', 'Make exaggerated claims'],
    examples: [
      'Transform your marketing with AI-powered insights that drive real results.',
      'Our platform helps you make smarter decisions, faster.',
    ],
    isActive: true,
  },
  {
    id: 2,
    name: 'Social Media Voice',
    tone: 'Casual and engaging',
    personality: 'Friendly, Witty, Relatable',
    audience: 'Social media followers, Gen Z & Millennials',
    doList: ['Use emojis sparingly', 'Be conversational', 'Ask questions', 'Use trending formats'],
    dontList: ['Be too formal', 'Use long paragraphs', 'Ignore trends'],
    examples: ["Marketing got you stressed? We've got you covered 💪", 'POV: Your ROAS just doubled 📈'],
    isActive: true,
  },
];

const contentTemplates = [
  {
    id: 1,
    name: 'Email Subject Lines',
    category: 'Email',
    uses: 1240,
    rating: 4.8,
    prompt: 'Generate compelling email subject lines for...',
  },
  {
    id: 2,
    name: 'Social Media Captions',
    category: 'Social',
    uses: 2840,
    rating: 4.9,
    prompt: 'Create engaging social media captions for...',
  },
  {
    id: 3,
    name: 'Product Descriptions',
    category: 'E-commerce',
    uses: 892,
    rating: 4.7,
    prompt: 'Write product descriptions that highlight...',
  },
  {
    id: 4,
    name: 'Ad Headlines',
    category: 'Ads',
    uses: 1680,
    rating: 4.8,
    prompt: 'Generate attention-grabbing ad headlines for...',
  },
  {
    id: 5,
    name: 'Blog Intros',
    category: 'Content',
    uses: 624,
    rating: 4.6,
    prompt: 'Write compelling blog introductions about...',
  },
  {
    id: 6,
    name: 'Landing Page Copy',
    category: 'Web',
    uses: 428,
    rating: 4.7,
    prompt: 'Create persuasive landing page copy for...',
  },
  {
    id: 7,
    name: 'Push Notifications',
    category: 'Mobile',
    uses: 1120,
    rating: 4.5,
    prompt: 'Write concise push notifications for...',
  },
  {
    id: 8,
    name: 'SMS Messages',
    category: 'SMS',
    uses: 780,
    rating: 4.6,
    prompt: 'Compose SMS marketing messages for...',
  },
];

const knowledgeBase = [
  { id: 1, name: 'Product Catalog', type: 'Document', size: '2.4 MB', items: 1240, lastUpdated: '2 hours ago' },
  { id: 2, name: 'Brand Guidelines', type: 'PDF', size: '8.2 MB', items: 1, lastUpdated: '1 week ago' },
  { id: 3, name: 'Customer FAQs', type: 'Database', size: '1.8 MB', items: 428, lastUpdated: '1 day ago' },
  { id: 4, name: 'Competitor Analysis', type: 'Document', size: '3.2 MB', items: 12, lastUpdated: '3 days ago' },
  { id: 5, name: 'Campaign History', type: 'Database', size: '12.4 MB', items: 2840, lastUpdated: 'Just now' },
];

const generatedContent = [
  {
    id: 1,
    type: 'Email Subject',
    content: '🚀 Your Q4 Marketing Playbook is Ready',
    score: 94,
    sentiment: 'Positive',
    readability: 'Grade 6',
    createdAt: '10 min ago',
  },
  {
    id: 2,
    type: 'Social Caption',
    content:
      "Marketing isn't just about selling—it's about connecting. Here's how AI is changing the game 🎯 #MarketingTips",
    score: 89,
    sentiment: 'Engaging',
    readability: 'Grade 5',
    createdAt: '25 min ago',
  },
  {
    id: 3,
    type: 'Ad Headline',
    content: 'Double Your ROAS in 30 Days—See How',
    score: 92,
    sentiment: 'Action-oriented',
    readability: 'Grade 4',
    createdAt: '1 hour ago',
  },
];

const contentAnalytics = {
  totalGenerated: 12480,
  avgScore: 87.4,
  topPerforming: 'Email Subject Lines',
  brandConsistency: 94,
  engagementLift: '+24%',
  conversionImpact: '+18%',
};

const styleGuide = {
  colors: [
    { name: 'Primary', hex: '#6366F1', usage: 'CTAs, Headers' },
    { name: 'Secondary', hex: '#8B5CF6', usage: 'Accents, Links' },
    { name: 'Success', hex: '#10B981', usage: 'Positive metrics' },
    { name: 'Warning', hex: '#F59E0B', usage: 'Alerts, Highlights' },
  ],
  typography: [
    { type: 'Heading', font: 'Inter Bold', size: '24-48px' },
    { type: 'Body', font: 'Inter Regular', size: '14-16px' },
    { type: 'Caption', font: 'Inter Medium', size: '12px' },
  ],
  terminology: [
    { term: 'ROAS', preferred: 'Return on Ad Spend', avoid: 'ROI for ads' },
    { term: 'CPC', preferred: 'Cost per Click', avoid: 'Click cost' },
    { term: 'Attribution', preferred: 'Multi-touch attribution', avoid: 'Credit assignment' },
  ],
};

export default function BrandVoice() {
  const [generatingContent, setGeneratingContent] = useState(false);
  const [prompt, setPrompt] = useState('');

  const handleGenerate = () => {
    setGeneratingContent(true);
    setTimeout(() => setGeneratingContent(false), 2000);
  };

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            Brand Voice & AI Content
            <Badge className="bg-gradient-to-r from-chart-1 to-chart-2 text-white">AI Powered</Badge>
          </h1>
          <p className="text-muted-foreground">
            Maintain brand consistency with AI-generated content that matches your voice
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Upload className="h-4 w-4" />
            Import Assets
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            New Voice Profile
          </Button>
        </div>
      </div>

      {/* Analytics Summary */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Content Generated</p>
                <p className="text-2xl font-bold">{(contentAnalytics.totalGenerated / 1000).toFixed(1)}K</p>
              </div>
              <FileText className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">+42% this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Quality Score</p>
                <p className="text-2xl font-bold">{contentAnalytics.avgScore}</p>
              </div>
              <Star className="h-8 w-8 text-chart-2" />
            </div>
            <Progress value={contentAnalytics.avgScore} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Brand Consistency</p>
                <p className="text-2xl font-bold">{contentAnalytics.brandConsistency}%</p>
              </div>
              <Target className="h-8 w-8 text-chart-3" />
            </div>
            <Progress value={contentAnalytics.brandConsistency} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Top Template</p>
                <p className="text-lg font-bold">Email Subjects</p>
              </div>
              <LayoutTemplate className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">1,240 uses</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Engagement Lift</p>
                <p className="text-2xl font-bold text-success">{contentAnalytics.engagementLift}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">vs non-AI content</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversion Impact</p>
                <p className="text-2xl font-bold text-success">{contentAnalytics.conversionImpact}</p>
              </div>
              <Zap className="h-8 w-8 text-warning" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">AI-optimized copy</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="generator" className="space-y-6">
        <TabsList>
          <TabsTrigger value="generator">AI Generator</TabsTrigger>
          <TabsTrigger value="voices">Brand Voices</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
          <TabsTrigger value="style">Style Guide</TabsTrigger>
          <TabsTrigger value="history">Content History</TabsTrigger>
        </TabsList>

        <TabsContent value="generator" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    AI Content Generator
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Content Type</Label>
                      <Select defaultValue="email">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">Email Subject Line</SelectItem>
                          <SelectItem value="social">Social Media Caption</SelectItem>
                          <SelectItem value="ad">Ad Headline</SelectItem>
                          <SelectItem value="product">Product Description</SelectItem>
                          <SelectItem value="blog">Blog Introduction</SelectItem>
                          <SelectItem value="sms">SMS Message</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Brand Voice</Label>
                      <Select defaultValue="primary">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="primary">Primary Brand Voice</SelectItem>
                          <SelectItem value="social">Social Media Voice</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Describe what you want to create</Label>
                    <Textarea
                      placeholder="E.g., Create an email subject line for our Black Friday sale with 40% off all products..."
                      className="min-h-[120px]"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button className="gap-2" onClick={handleGenerate} disabled={generatingContent}>
                      {generatingContent ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : (
                        <Sparkles className="h-4 w-4" />
                      )}
                      {generatingContent ? 'Generating...' : 'Generate Content'}
                    </Button>
                    <Button variant="outline" className="gap-2">
                      <RefreshCw className="h-4 w-4" />
                      Regenerate
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Generated Results */}
              <Card>
                <CardHeader>
                  <CardTitle>Generated Variations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { text: "🚀 Black Friday: 40% OFF Everything - Don't Miss Out!", score: 94 },
                    { text: 'Your Exclusive Black Friday Access: 40% Off Sitewide', score: 91 },
                    { text: "FINAL HOURS: Grab 40% Off Before It's Gone", score: 88 },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-lg border border-border bg-muted/30 hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <p className="font-medium">{item.text}</p>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-success/10 text-success">{item.score}%</Badge>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Badge variant="outline">Urgency: High</Badge>
                        <Badge variant="outline">Emotion: Excitement</Badge>
                        <Badge variant="outline">CTA: Strong</Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Quick Templates</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {contentTemplates.slice(0, 5).map((template) => (
                    <Button key={template.id} variant="outline" className="w-full justify-start gap-2 h-auto py-3">
                      <LayoutTemplate className="h-4 w-4" />
                      <div className="text-left">
                        <p className="font-medium">{template.name}</p>
                        <p className="text-xs text-muted-foreground">{template.uses} uses</p>
                      </div>
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-warning" />
                    AI Suggestions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-warning/10 text-sm">
                    <p className="font-medium">Trending: Emoji in subject lines</p>
                    <p className="text-xs text-muted-foreground mt-1">+18% higher open rates</p>
                  </div>
                  <div className="p-3 rounded-lg bg-chart-1/10 text-sm">
                    <p className="font-medium">Best performing time</p>
                    <p className="text-xs text-muted-foreground mt-1">Tuesday 10 AM for emails</p>
                  </div>
                  <div className="p-3 rounded-lg bg-success/10 text-sm">
                    <p className="font-medium">Power words to use</p>
                    <p className="text-xs text-muted-foreground mt-1">Exclusive, Limited, Free</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="voices" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {brandVoiceProfiles.map((profile) => (
              <Card key={profile.id} className={profile.isActive ? 'border-primary/50' : ''}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Mic className="h-5 w-5" />
                      {profile.name}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {profile.isActive && <Badge className="bg-success/10 text-success">Active</Badge>}
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="text-xs text-muted-foreground">Tone</Label>
                      <p className="font-medium">{profile.tone}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Personality</Label>
                      <p className="font-medium">{profile.personality}</p>
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground">Target Audience</Label>
                    <p className="font-medium">{profile.audience}</p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="p-3 rounded-lg bg-success/10">
                      <Label className="text-xs text-success">Do</Label>
                      <ul className="mt-2 space-y-1">
                        {profile.doList.map((item, i) => (
                          <li key={i} className="text-xs flex items-center gap-1">
                            <CheckCircle2 className="h-3 w-3 text-success" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-3 rounded-lg bg-destructive/10">
                      <Label className="text-xs text-destructive">Don't</Label>
                      <ul className="mt-2 space-y-1">
                        {profile.dontList.map((item, i) => (
                          <li key={i} className="text-xs flex items-center gap-1">
                            <Trash2 className="h-3 w-3 text-destructive" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground">Example Copy</Label>
                    <div className="mt-2 space-y-2">
                      {profile.examples.map((example, i) => (
                        <p key={i} className="text-sm italic text-muted-foreground p-2 rounded bg-muted/50">
                          "{example}"
                        </p>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Content Templates Library</CardTitle>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Create Template
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Template Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-center">Uses</TableHead>
                    <TableHead className="text-center">Rating</TableHead>
                    <TableHead>Prompt Preview</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contentTemplates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell className="font-medium">{template.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{template.category}</Badge>
                      </TableCell>
                      <TableCell className="text-center">{template.uses.toLocaleString()}</TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Star className="h-4 w-4 text-warning fill-warning" />
                          {template.rating}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">
                        {template.prompt}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="sm">
                            Use
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="knowledge" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Knowledge Base
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">Train the AI on your brand's specific knowledge</p>
                </div>
                <Button className="gap-2">
                  <Upload className="h-4 w-4" />
                  Upload Documents
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead className="text-center">Items</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {knowledgeBase.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.type}</Badge>
                      </TableCell>
                      <TableCell>{item.size}</TableCell>
                      <TableCell className="text-center">{item.items.toLocaleString()}</TableCell>
                      <TableCell className="text-muted-foreground">{item.lastUpdated}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Training Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Knowledge Base Size</span>
                  <span className="font-bold">28.4 MB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Total Documents</span>
                  <span className="font-bold">4,521</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Last Training</span>
                  <span className="font-bold">2 hours ago</span>
                </div>
                <Progress value={100} className="h-2" />
                <Badge className="bg-success/10 text-success">Fully Trained</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="style" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Brand Colors
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {styleGuide.colors.map((color, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg border border-border" style={{ backgroundColor: color.hex }} />
                    <div>
                      <p className="font-medium">{color.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {color.hex} • {color.usage}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Typography</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {styleGuide.typography.map((item, i) => (
                  <div key={i} className="p-3 rounded-lg border border-border">
                    <p className="font-medium">{item.type}</p>
                    <p className="text-sm text-muted-foreground">{item.font}</p>
                    <p className="text-xs text-muted-foreground">{item.size}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Terminology</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {styleGuide.terminology.map((item, i) => (
                  <div key={i} className="p-3 rounded-lg border border-border">
                    <p className="font-bold">{item.term}</p>
                    <p className="text-sm text-success mt-1">✓ {item.preferred}</p>
                    <p className="text-sm text-destructive">✗ {item.avoid}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Generated Content</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Content</TableHead>
                    <TableHead className="text-center">Quality</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Readability</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {generatedContent.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <Badge variant="outline">{item.type}</Badge>
                      </TableCell>
                      <TableCell className="max-w-[300px]">
                        <p className="truncate">{item.content}</p>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge
                          className={item.score >= 90 ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}
                        >
                          {item.score}%
                        </Badge>
                      </TableCell>
                      <TableCell>{item.sentiment}</TableCell>
                      <TableCell>{item.readability}</TableCell>
                      <TableCell className="text-muted-foreground">{item.createdAt}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
