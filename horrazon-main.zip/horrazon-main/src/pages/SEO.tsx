import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Globe,
  Zap,
  Eye,
  Search,
  FileText,
  Link2,
  AlertTriangle,
  CheckCircle2,
  Bot,
  Sparkles,
} from 'lucide-react';

const keywords = [
  {
    keyword: 'summer dresses online',
    google: 3,
    chatgpt: 1,
    perplexity: 2,
    bingCopilot: 2,
    sge: true,
    trend: 'up',
    volume: 12400,
    difficulty: 45,
  },
  {
    keyword: 'best running shoes',
    google: 8,
    chatgpt: 5,
    perplexity: 4,
    bingCopilot: 6,
    sge: true,
    trend: 'up',
    volume: 89000,
    difficulty: 72,
  },
  {
    keyword: 'wireless headphones review',
    google: 12,
    chatgpt: 8,
    perplexity: 10,
    bingCopilot: 9,
    sge: false,
    trend: 'down',
    volume: 45000,
    difficulty: 65,
  },
  {
    keyword: 'yoga mat for beginners',
    google: 5,
    chatgpt: 3,
    perplexity: 4,
    bingCopilot: 4,
    sge: true,
    trend: 'same',
    volume: 8900,
    difficulty: 38,
  },
  {
    keyword: 'protein powder best',
    google: 15,
    chatgpt: 12,
    perplexity: 8,
    bingCopilot: 11,
    sge: true,
    trend: 'up',
    volume: 74000,
    difficulty: 68,
  },
];

const coreWebVitals = {
  lcp: { value: 2.1, status: 'good', target: 2.5 },
  fid: { value: 45, status: 'good', target: 100 },
  cls: { value: 0.08, status: 'needs-improvement', target: 0.1 },
  fcp: { value: 1.4, status: 'good', target: 1.8 },
  ttfb: { value: 0.6, status: 'good', target: 0.8 },
};

const serpFeatures = [
  { feature: 'Featured Snippet', keywords: 12, captured: 5, opportunity: 'high' },
  { feature: 'People Also Ask', keywords: 28, captured: 8, opportunity: 'medium' },
  { feature: 'Image Pack', keywords: 15, captured: 12, opportunity: 'low' },
  { feature: 'Video Carousel', keywords: 8, captured: 2, opportunity: 'high' },
  { feature: 'Local Pack', keywords: 6, captured: 6, opportunity: 'captured' },
  { feature: 'Knowledge Panel', keywords: 3, captured: 1, opportunity: 'medium' },
];

const contentGaps = [
  { topic: 'Sustainable fashion guide', competitorRank: 3, yourRank: null, searchVolume: 14200, priority: 'high' },
  { topic: 'Workout gear comparison', competitorRank: 5, yourRank: 42, searchVolume: 28500, priority: 'high' },
  { topic: 'Home fitness equipment', competitorRank: 8, yourRank: 35, searchVolume: 19800, priority: 'medium' },
  { topic: 'Athletic wear trends 2024', competitorRank: 2, yourRank: null, searchVolume: 8400, priority: 'medium' },
];

const contentFocus = [
  'Create buying guides for top-performing product categories',
  'Optimize product descriptions with target keywords',
  'Develop FAQ pages for high-intent search queries',
  'Build comparison content for competitive keywords',
  'Create video content for AI search visibility',
];

export default function SEO() {
  return (
    <div className="space-y-6 p-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          SEO & AI Search Performance
        </h1>
        <p className="text-muted-foreground text-lg">Rankings across Google, AI assistants, and search features</p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-success/20 flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold">68%</p>
              <p className="text-sm text-muted-foreground">Organic Visibility</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Bot className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">42%</p>
              <p className="text-sm text-muted-foreground">AI Search Presence</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-chart-3/20 flex items-center justify-center">
              <Eye className="h-6 w-6 text-chart-3" />
            </div>
            <div>
              <p className="text-2xl font-bold">5</p>
              <p className="text-sm text-muted-foreground">SERP Features Won</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-chart-1/20 flex items-center justify-center">
              <Zap className="h-6 w-6 text-chart-1" />
            </div>
            <div>
              <p className="text-2xl font-bold">Good</p>
              <p className="text-sm text-muted-foreground">Core Web Vitals</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rankings" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="rankings">AI & Search Rankings</TabsTrigger>
          <TabsTrigger value="vitals">Core Web Vitals</TabsTrigger>
          <TabsTrigger value="serp">SERP Features</TabsTrigger>
          <TabsTrigger value="gaps">Content Gaps</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        {/* AI & Search Rankings */}
        <TabsContent value="rankings">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Keyword Ranking Performance
              </CardTitle>
              <CardDescription>Track visibility across traditional and AI-powered search</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Keyword</TableHead>
                    <TableHead className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Globe className="h-3 w-3" />
                        Google
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Sparkles className="h-3 w-3" />
                        SGE
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Bot className="h-3 w-3" />
                        ChatGPT
                      </div>
                    </TableHead>
                    <TableHead className="text-center">Perplexity</TableHead>
                    <TableHead className="text-center">Bing Copilot</TableHead>
                    <TableHead className="text-right">Volume</TableHead>
                    <TableHead>Trend</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {keywords.map((row) => (
                    <TableRow key={row.keyword}>
                      <TableCell className="font-medium">{row.keyword}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant={row.google <= 10 ? 'default' : 'secondary'}>{row.google}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {row.sge ? (
                          <Badge className="bg-success/20 text-success">Cited</Badge>
                        ) : (
                          <Badge variant="outline">No</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline">{row.chatgpt}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline">{row.perplexity}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline">{row.bingCopilot}</Badge>
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">{row.volume.toLocaleString()}</TableCell>
                      <TableCell>
                        {row.trend === 'up' && <TrendingUp className="h-4 w-4 text-success" />}
                        {row.trend === 'down' && <TrendingDown className="h-4 w-4 text-destructive" />}
                        {row.trend === 'same' && <Minus className="h-4 w-4 text-muted-foreground" />}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Core Web Vitals */}
        <TabsContent value="vitals">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Core Web Vitals Dashboard
              </CardTitle>
              <CardDescription>Page experience metrics affecting search rankings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(coreWebVitals).map(([key, data]) => (
                  <div key={key} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-sm text-muted-foreground uppercase">{key}</p>
                        <p className="text-2xl font-bold">
                          {data.value}
                          {key === 'cls' ? '' : key === 'fid' ? 'ms' : 's'}
                        </p>
                      </div>
                      {data.status === 'good' ? (
                        <CheckCircle2 className="h-6 w-6 text-success" />
                      ) : (
                        <AlertTriangle className="h-6 w-6 text-chart-3" />
                      )}
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>
                          Target: {data.target}
                          {key === 'cls' ? '' : key === 'fid' ? 'ms' : 's'}
                        </span>
                        <Badge variant={data.status === 'good' ? 'default' : 'secondary'} className="text-xs">
                          {data.status === 'good' ? 'Good' : 'Needs Work'}
                        </Badge>
                      </div>
                      <Progress
                        value={Math.min((data.target / data.value) * 100, 100)}
                        className={`h-2 ${data.status === 'good' ? '' : ''}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 p-4 bg-muted/30 rounded-lg">
                <p className="text-sm">
                  <strong>Overall Assessment:</strong> Your Core Web Vitals are passing. CLS needs minor improvement -
                  consider lazy loading images and reserving space for dynamic content.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SERP Features */}
        <TabsContent value="serp">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                SERP Feature Tracking
              </CardTitle>
              <CardDescription>Opportunities to capture rich search results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {serpFeatures.map((feature) => (
                  <div key={feature.feature} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-medium">{feature.feature}</p>
                      <Badge
                        variant={
                          feature.opportunity === 'captured'
                            ? 'default'
                            : feature.opportunity === 'high'
                              ? 'destructive'
                              : 'secondary'
                        }
                        className={feature.opportunity === 'captured' ? 'bg-success' : ''}
                      >
                        {feature.opportunity === 'captured' ? 'Won' : `${feature.opportunity} opp.`}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>
                        {feature.captured}/{feature.keywords} captured
                      </span>
                      <Progress value={(feature.captured / feature.keywords) * 100} className="w-20 h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Gaps */}
        <TabsContent value="gaps">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Content Gap Analysis
              </CardTitle>
              <CardDescription>Topics where competitors outrank you</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Topic</TableHead>
                    <TableHead className="text-center">Competitor Rank</TableHead>
                    <TableHead className="text-center">Your Rank</TableHead>
                    <TableHead className="text-right">Search Volume</TableHead>
                    <TableHead>Priority</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contentGaps.map((gap) => (
                    <TableRow key={gap.topic}>
                      <TableCell className="font-medium">{gap.topic}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="bg-destructive/10 text-destructive">
                          #{gap.competitorRank}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {gap.yourRank ? (
                          <Badge variant="secondary">#{gap.yourRank}</Badge>
                        ) : (
                          <Badge variant="outline">Not ranking</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">{gap.searchVolume.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={gap.priority === 'high' ? 'destructive' : 'secondary'}>{gap.priority}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Recommendations */}
        <TabsContent value="recommendations">
          <Card>
            <CardHeader>
              <CardTitle>Content Recommendations for Improved Discoverability</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {contentFocus.map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground">
                      {i + 1}
                    </div>
                    <p className="pt-0.5">{item}</p>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
