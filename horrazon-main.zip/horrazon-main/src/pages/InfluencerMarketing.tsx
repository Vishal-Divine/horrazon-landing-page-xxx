import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import {
  Instagram,
  Youtube,
  TrendingUp,
  Users,
  DollarSign,
  Eye,
  Heart,
  Share2,
  MessageCircle,
  Star,
  AlertTriangle,
  Target,
  Brain,
  TrendingDown,
  Filter,
  Search,
  Award,
  ShieldCheck,
  BarChart3,
  PieChart,
  Sparkles,
  Scale,
  Calculator,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ScatterChart,
  Scatter,
  ZAxis,
} from 'recharts';
import {
  AIRecommendationsPanel,
  InfluencerDiscoveryPanel,
  FraudRiskIntelligence,
  CampaignROIPredictor,
  ContractNegotiationInsights,
} from '@/components/influencer';
const influencers = [
  {
    id: 1,
    name: '@fitnessguru_sarah',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    platform: 'Instagram',
    followers: '284K',
    engagement: '4.8%',
    campaigns: 3,
    revenue: 24200,
    roas: 6.2,
    status: 'active',
    tier: 'Macro',
    niche: 'Fitness & Wellness',
    audienceQuality: 94,
    fakeFollowers: 2.1,
    avgViews: 18200,
    storyViews: 12400,
    emv: 42800,
    brandLift: 18,
    sentiment: 96,
    demographics: { female: 68, male: 32, age2534: 42, age1824: 38 },
    topCountries: ['US 54%', 'UK 18%', 'CA 12%'],
    cpm: 12.4,
    cpe: 0.28,
    authenticity: 97,
    responsivenessScore: 92,
  },
  {
    id: 2,
    name: '@techreviews_mike',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    platform: 'YouTube',
    followers: '520K',
    engagement: '3.2%',
    campaigns: 2,
    revenue: 18400,
    roas: 5.8,
    status: 'active',
    tier: 'Macro',
    niche: 'Technology',
    audienceQuality: 91,
    fakeFollowers: 3.8,
    avgViews: 82400,
    storyViews: 0,
    emv: 124000,
    brandLift: 24,
    sentiment: 94,
    demographics: { female: 22, male: 78, age2534: 48, age1824: 24 },
    topCountries: ['US 62%', 'IN 14%', 'UK 10%'],
    cpm: 18.2,
    cpe: 0.42,
    authenticity: 93,
    responsivenessScore: 88,
  },
  {
    id: 3,
    name: '@beautybyemma',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    platform: 'TikTok',
    followers: '892K',
    engagement: '7.2%',
    campaigns: 5,
    revenue: 32800,
    roas: 8.4,
    status: 'active',
    tier: 'Mega',
    niche: 'Beauty & Skincare',
    audienceQuality: 96,
    fakeFollowers: 1.4,
    avgViews: 284000,
    storyViews: 0,
    emv: 186000,
    brandLift: 32,
    sentiment: 98,
    demographics: { female: 86, male: 14, age2534: 38, age1824: 52 },
    topCountries: ['US 48%', 'UK 22%', 'AU 12%'],
    cpm: 8.8,
    cpe: 0.18,
    authenticity: 98,
    responsivenessScore: 96,
  },
  {
    id: 4,
    name: '@foodie_alex',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    platform: 'Instagram',
    followers: '128K',
    engagement: '5.4%',
    campaigns: 2,
    revenue: 12400,
    roas: 4.2,
    status: 'paused',
    tier: 'Micro',
    niche: 'Food & Lifestyle',
    audienceQuality: 89,
    fakeFollowers: 5.2,
    avgViews: 8400,
    storyViews: 6200,
    emv: 22400,
    brandLift: 12,
    sentiment: 92,
    demographics: { female: 58, male: 42, age2534: 44, age1824: 28 },
    topCountries: ['US 44%', 'CA 24%', 'UK 16%'],
    cpm: 16.8,
    cpe: 0.38,
    authenticity: 86,
    responsivenessScore: 84,
  },
];

const performanceData = [
  { month: 'Jan', revenue: 18200, spend: 3200, roas: 5.7 },
  { month: 'Feb', revenue: 22400, spend: 3800, roas: 5.9 },
  { month: 'Mar', revenue: 28900, spend: 4200, roas: 6.9 },
  { month: 'Apr', revenue: 24200, spend: 3900, roas: 6.2 },
  { month: 'May', revenue: 32800, spend: 4500, roas: 7.3 },
  { month: 'Jun', revenue: 38400, spend: 5100, roas: 7.5 },
];

const contentPerformance = [
  {
    influencer: '@beautybyemma',
    postType: 'Product Review',
    platform: 'TikTok',
    impressions: 892000,
    engagement: 64200,
    clicks: 12400,
    conversions: 284,
    revenue: 8520,
    emv: 26840,
    sentiment: 98,
    viralScore: 94,
    saveRate: 8.2,
    shareRate: 4.8,
  },
  {
    influencer: '@fitnessguru_sarah',
    postType: 'Unboxing',
    platform: 'Instagram',
    impressions: 284000,
    engagement: 13632,
    clicks: 4260,
    conversions: 92,
    revenue: 5520,
    emv: 8520,
    sentiment: 96,
    viralScore: 78,
    saveRate: 6.4,
    shareRate: 3.2,
  },
  {
    influencer: '@techreviews_mike',
    postType: 'Tutorial',
    platform: 'YouTube',
    impressions: 520000,
    engagement: 16640,
    clicks: 8320,
    conversions: 148,
    revenue: 7400,
    emv: 15600,
    sentiment: 94,
    viralScore: 82,
    saveRate: 12.4,
    shareRate: 2.8,
  },
];

const industryBenchmarks = {
  instagram: { avgEngagement: 1.94, avgCPM: 15.2, avgCPE: 0.52 },
  tiktok: { avgEngagement: 4.25, avgCPM: 9.8, avgCPE: 0.24 },
  youtube: { avgEngagement: 1.63, avgCPM: 22.4, avgCPE: 0.68 },
};

const audienceOverlap = [
  { influencer1: '@beautybyemma', influencer2: '@fitnessguru_sarah', overlap: 12.4 },
  { influencer1: '@techreviews_mike', influencer2: '@foodie_alex', overlap: 8.2 },
];

const predictiveData = [
  { month: 'Jul', predicted: 42800, confidence: 94, lower: 38200, upper: 47400 },
  { month: 'Aug', predicted: 48200, confidence: 91, lower: 42800, upper: 53600 },
  { month: 'Sep', predicted: 54800, confidence: 88, lower: 48200, upper: 61400 },
];

const creatorScores = influencers.map((inf) => ({
  name: inf.name,
  performance: inf.roas * 10,
  authenticity: inf.authenticity,
  engagement: parseFloat(inf.engagement) * 10,
  quality: inf.audienceQuality,
}));

const demographicsData = [
  { age: '13-17', value: 8 },
  { age: '18-24', value: 38 },
  { age: '25-34', value: 42 },
  { age: '35-44', value: 10 },
  { age: '45+', value: 2 },
];

const contentTypeROI = [
  { type: 'Product Review', roi: 8.4, posts: 24 },
  { type: 'Tutorial', roi: 7.2, posts: 18 },
  { type: 'Unboxing', roi: 6.8, posts: 22 },
  { type: 'Lifestyle', roi: 5.4, posts: 16 },
  { type: 'Giveaway', roi: 4.2, posts: 12 },
];

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function InfluencerMarketing() {
  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Influencer Marketing Intelligence</h1>
          <p className="text-muted-foreground">Advanced creator analytics, fraud detection & predictive insights</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search influencers..." className="w-64 pl-9" />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="instagram">Instagram</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
              <SelectItem value="youtube">YouTube</SelectItem>
            </SelectContent>
          </Select>
          <Button className="gap-2">
            <Users className="h-4 w-4" />
            Add Influencer
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-5">
        <Card className="hover-scale transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total EMV</p>
                <p className="text-3xl font-bold">$376K</p>
              </div>
              <TrendingUp className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              +28% vs industry avg
            </p>
          </CardContent>
        </Card>

        <Card className="hover-scale transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Brand Lift</p>
                <p className="text-3xl font-bold">+24%</p>
              </div>
              <Brain className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Avg. across campaigns</p>
          </CardContent>
        </Card>

        <Card className="hover-scale transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Authenticity</p>
                <p className="text-3xl font-bold">94%</p>
              </div>
              <ShieldCheck className="h-10 w-10 text-chart-3" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <AlertTriangle className="h-3 w-3" />
              2.8% avg fake followers
            </p>
          </CardContent>
        </Card>

        <Card className="hover-scale transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Influencer ROAS</p>
                <p className="text-3xl font-bold">7.2x</p>
              </div>
              <DollarSign className="h-10 w-10 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-success">+18% vs last month</p>
          </CardContent>
        </Card>

        <Card className="hover-scale transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Sentiment Score</p>
                <p className="text-3xl font-bold">95%</p>
              </div>
              <Heart className="h-10 w-10 text-chart-5" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Positive brand mentions</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="influencers" className="space-y-6">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="influencers">Influencer Database</TabsTrigger>
          <TabsTrigger value="discovery" className="gap-1">
            <Search className="h-3 w-3" />
            Discovery
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="gap-1">
            <Sparkles className="h-3 w-3" />
            AI Recommendations
          </TabsTrigger>
          <TabsTrigger value="roi" className="gap-1">
            <Calculator className="h-3 w-3" />
            ROI Predictor
          </TabsTrigger>
          <TabsTrigger value="fraud" className="gap-1">
            <ShieldCheck className="h-3 w-3" />
            Fraud Detection
          </TabsTrigger>
          <TabsTrigger value="contracts" className="gap-1">
            <Scale className="h-3 w-3" />
            Contracts
          </TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="audience">Audience</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
          <TabsTrigger value="forecast">Forecast</TabsTrigger>
        </TabsList>

        <TabsContent value="influencers" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Active Influencer Partners</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="h-4 w-4" />
                    Filter
                  </Button>
                  <Button variant="outline" size="sm">
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Influencer</TableHead>
                    <TableHead>Platform</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead>Followers</TableHead>
                    <TableHead>Engagement</TableHead>
                    <TableHead>Quality Score</TableHead>
                    <TableHead>Authenticity</TableHead>
                    <TableHead>EMV</TableHead>
                    <TableHead>Revenue</TableHead>
                    <TableHead>ROAS</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {influencers.map((influencer) => (
                    <TableRow key={influencer.id} className="group hover:bg-muted/50">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10 ring-2 ring-border">
                            <AvatarImage src={influencer.avatar} />
                            <AvatarFallback>{influencer.name.slice(1, 3).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{influencer.name}</p>
                            <p className="text-xs text-muted-foreground">{influencer.niche}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {influencer.platform === 'Instagram' && <Instagram className="h-4 w-4 text-pink-500" />}
                          {influencer.platform === 'YouTube' && <Youtube className="h-4 w-4 text-red-500" />}
                          {influencer.platform === 'TikTok' && <Share2 className="h-4 w-4" />}
                          <span className="text-sm">{influencer.platform}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{influencer.tier}</Badge>
                      </TableCell>
                      <TableCell className="font-medium">{influencer.followers}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            parseFloat(influencer.engagement) > 5
                              ? 'border-success text-success'
                              : parseFloat(influencer.engagement) > 3
                                ? 'border-warning text-warning'
                                : 'border-destructive text-destructive'
                          }
                        >
                          {influencer.engagement}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={influencer.audienceQuality} className="h-2 w-16" />
                          <span className="text-sm font-medium">{influencer.audienceQuality}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <ShieldCheck
                            className={`h-4 w-4 ${
                              influencer.authenticity > 95
                                ? 'text-success'
                                : influencer.authenticity > 90
                                  ? 'text-warning'
                                  : 'text-destructive'
                            }`}
                          />
                          <span className="text-sm">{influencer.authenticity}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-chart-1">${(influencer.emv / 1000).toFixed(1)}K</TableCell>
                      <TableCell className="font-bold">${influencer.revenue.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge
                          className={
                            influencer.roas > 7
                              ? 'bg-success/10 text-success'
                              : influencer.roas > 5
                                ? 'bg-warning/10 text-warning'
                                : 'bg-destructive/10 text-destructive'
                          }
                        >
                          {influencer.roas}x
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={influencer.status === 'active' ? 'default' : 'secondary'}>
                          {influencer.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  Fraud Detection Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start justify-between rounded-lg border border-warning/20 bg-warning/5 p-3">
                    <div className="flex-1">
                      <p className="text-sm font-medium">@foodie_alex</p>
                      <p className="text-xs text-muted-foreground">5.2% fake followers detected</p>
                    </div>
                    <Badge variant="outline" className="border-warning text-warning">
                      Review
                    </Badge>
                  </div>
                  <div className="flex items-start justify-between rounded-lg border border-success/20 bg-success/5 p-3">
                    <div className="flex-1">
                      <p className="text-sm font-medium">@beautybyemma</p>
                      <p className="text-xs text-muted-foreground">98% authentic audience</p>
                    </div>
                    <Badge variant="outline" className="border-success text-success">
                      Verified
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Award className="h-5 w-5 text-chart-3" />
                  Top Performer This Month
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 ring-2 ring-chart-3">
                      <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Emma" />
                    </Avatar>
                    <div>
                      <p className="font-medium">@beautybyemma</p>
                      <p className="text-xs text-muted-foreground">Beauty & Skincare</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">ROAS</p>
                      <p className="font-bold text-success">8.4x</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">EMV</p>
                      <p className="font-bold">$186K</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="h-5 w-5 text-chart-4" />
                  Recommended Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="mt-0.5 h-2 w-2 rounded-full bg-chart-1" />
                    <p>Increase budget for @beautybyemma (+45% ROI potential)</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="mt-0.5 h-2 w-2 rounded-full bg-chart-2" />
                    <p>Review @foodie_alex audience quality</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="mt-0.5 h-2 w-2 rounded-full bg-chart-3" />
                    <p>Test TikTok creators for higher engagement</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="discovery">
          <InfluencerDiscoveryPanel />
        </TabsContent>

        <TabsContent value="recommendations">
          <AIRecommendationsPanel />
        </TabsContent>

        <TabsContent value="roi">
          <CampaignROIPredictor />
        </TabsContent>

        <TabsContent value="fraud">
          <FraudRiskIntelligence />
        </TabsContent>

        <TabsContent value="contracts">
          <ContractNegotiationInsights />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Creator Performance Matrix</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <RadarChart data={creatorScores.slice(0, 3)}>
                    <PolarGrid stroke="hsl(var(--border))" />
                    <PolarAngleAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <PolarRadiusAxis stroke="hsl(var(--muted-foreground))" />
                    <Radar
                      name="Performance"
                      dataKey="performance"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.3}
                    />
                    <Radar
                      name="Authenticity"
                      dataKey="authenticity"
                      stroke="hsl(var(--chart-2))"
                      fill="hsl(var(--chart-2))"
                      fillOpacity={0.3}
                    />
                    <Radar
                      name="Engagement"
                      dataKey="engagement"
                      stroke="hsl(var(--chart-3))"
                      fill="hsl(var(--chart-3))"
                      fillOpacity={0.3}
                    />
                    <Radar
                      name="Quality"
                      dataKey="quality"
                      stroke="hsl(var(--chart-4))"
                      fill="hsl(var(--chart-4))"
                      fillOpacity={0.3}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Earned Media Value Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <RePieChart>
                    <Pie
                      data={influencers.map((inf) => ({ name: inf.name, value: inf.emv }))}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name}: $${(entry.value / 1000).toFixed(0)}K`}
                      outerRadius={100}
                      fill="hsl(var(--chart-1))"
                      dataKey="value"
                    >
                      {influencers.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                      formatter={(value: number) => `$${value.toLocaleString()}`}
                    />
                  </RePieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Content Type ROI Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {contentTypeROI.map((type, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{type.type}</span>
                        <span className="font-bold text-chart-1">{type.roi}x</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Progress value={(type.roi / 10) * 100} className="h-2" />
                        <span className="text-xs text-muted-foreground">{type.posts} posts</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Platform Cost Efficiency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <Instagram className="h-4 w-4 text-pink-500" />
                        Instagram
                      </span>
                      <span className="font-medium">$12.40 CPM</span>
                    </div>
                    <p className="mt-1 text-xs text-success">18% below industry avg</p>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <Share2 className="h-4 w-4" />
                        TikTok
                      </span>
                      <span className="font-medium">$8.80 CPM</span>
                    </div>
                    <p className="mt-1 text-xs text-success">10% below industry avg</p>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <Youtube className="h-4 w-4 text-red-500" />
                        YouTube
                      </span>
                      <span className="font-medium">$18.20 CPM</span>
                    </div>
                    <p className="mt-1 text-xs text-warning">19% below industry avg</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Brand Lift by Creator</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {influencers.slice(0, 3).map((inf, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{inf.name}</span>
                        <span className="font-bold text-chart-2">+{inf.brandLift}%</span>
                      </div>
                      <Progress value={inf.brandLift * 3} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="audience" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Audience Demographics Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={demographicsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="age" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Bar dataKey="value" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Primary Age Group</p>
                    <p className="text-lg font-bold">25-34 (42%)</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Gender Split</p>
                    <p className="text-lg font-bold">58% F / 42% M</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Audience Overlap Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Identify shared audience segments to optimize influencer mix and avoid oversaturation
                </p>
                {audienceOverlap.map((overlap, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={influencers.find((i) => i.name === overlap.influencer1)?.avatar} />
                        </Avatar>
                        <span>{overlap.influencer1}</span>
                        <span className="text-muted-foreground">↔</span>
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={influencers.find((i) => i.name === overlap.influencer2)?.avatar} />
                        </Avatar>
                        <span>{overlap.influencer2}</span>
                      </div>
                      <Badge variant="outline">{overlap.overlap}% overlap</Badge>
                    </div>
                    <Progress value={overlap.overlap} className="h-2" />
                  </div>
                ))}
                <div className="rounded-lg border border-success/20 bg-success/5 p-3 text-sm">
                  <p className="font-medium text-success">✓ Optimal Diversification</p>
                  <p className="text-muted-foreground">
                    Your influencer mix reaches unique audiences with minimal overlap
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Audience Insights by Creator</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Influencer</TableHead>
                    <TableHead>Quality Score</TableHead>
                    <TableHead>Fake Followers</TableHead>
                    <TableHead>Gender Split</TableHead>
                    <TableHead>Primary Age</TableHead>
                    <TableHead>Top Locations</TableHead>
                    <TableHead>Responsiveness</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {influencers.map((inf) => (
                    <TableRow key={inf.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={inf.avatar} />
                          </Avatar>
                          <span className="font-medium">{inf.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={inf.audienceQuality} className="h-2 w-20" />
                          <span className="text-sm font-medium">{inf.audienceQuality}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            inf.fakeFollowers < 3
                              ? 'border-success text-success'
                              : inf.fakeFollowers < 5
                                ? 'border-warning text-warning'
                                : 'border-destructive text-destructive'
                          }
                        >
                          {inf.fakeFollowers}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {inf.demographics.female}% F / {inf.demographics.male}% M
                      </TableCell>
                      <TableCell className="text-sm">25-34 ({inf.demographics.age2534}%)</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {inf.topCountries.slice(0, 2).map((country, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {country}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-3 w-3 text-chart-3" />
                          <span className="text-sm">{inf.responsivenessScore}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Content Performance Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Influencer</TableHead>
                    <TableHead>Content Type</TableHead>
                    <TableHead>Platform</TableHead>
                    <TableHead>Impressions</TableHead>
                    <TableHead>Engagement</TableHead>
                    <TableHead>EMV</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Viral Score</TableHead>
                    <TableHead>Revenue</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contentPerformance.map((content, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{content.influencer}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{content.postType}</Badge>
                      </TableCell>
                      <TableCell>{content.platform}</TableCell>
                      <TableCell>{content.impressions.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Heart className="h-3 w-3 text-red-500" />
                          {content.engagement.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-chart-1">${(content.emv / 1000).toFixed(1)}K</TableCell>
                      <TableCell>
                        <Badge className="bg-success/10 text-success">{content.sentiment}%</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={content.viralScore} className="h-2 w-16" />
                          <span className="text-sm">{content.viralScore}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-bold text-success">${content.revenue.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Content Type Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Product Reviews</span>
                      <span className="font-bold">4.2% CVR</span>
                    </div>
                    <div className="flex gap-2 text-xs text-muted-foreground">
                      <span>Save: 8.2%</span>
                      <span>Share: 4.8%</span>
                    </div>
                    <Progress value={84} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Tutorials/How-To</span>
                      <span className="font-bold">3.8% CVR</span>
                    </div>
                    <div className="flex gap-2 text-xs text-muted-foreground">
                      <span>Save: 12.4%</span>
                      <span>Share: 2.8%</span>
                    </div>
                    <Progress value={76} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Unboxing</span>
                      <span className="font-bold">3.2% CVR</span>
                    </div>
                    <div className="flex gap-2 text-xs text-muted-foreground">
                      <span>Save: 6.4%</span>
                      <span>Share: 3.2%</span>
                    </div>
                    <Progress value={64} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Sentiment Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-3xl font-bold">96%</p>
                    <p className="text-sm text-muted-foreground">Positive Brand Sentiment</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Positive</span>
                      <span className="font-medium text-success">96%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Neutral</span>
                      <span className="font-medium">3%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Negative</span>
                      <span className="font-medium text-destructive">1%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Best Posting Times</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="rounded-lg border bg-muted/50 p-3">
                    <p className="font-medium">Instagram</p>
                    <p className="text-sm text-muted-foreground">Tue-Thu, 6-9 PM EST</p>
                  </div>
                  <div className="rounded-lg border bg-muted/50 p-3">
                    <p className="font-medium">TikTok</p>
                    <p className="text-sm text-muted-foreground">Wed-Fri, 7-10 PM EST</p>
                  </div>
                  <div className="rounded-lg border bg-muted/50 p-3">
                    <p className="font-medium">YouTube</p>
                    <p className="text-sm text-muted-foreground">Sat-Sun, 12-3 PM EST</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="benchmarks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Industry Benchmarks & Competitive Analysis</CardTitle>
              <p className="text-sm text-muted-foreground">
                Compare your performance against industry standards and optimize your strategy
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                <div>
                  <p className="mb-2 text-sm font-medium">Instagram Performance</p>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Your Avg Engagement</span>
                      <span className="font-bold text-success">4.8%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Industry Average</span>
                      <span className="font-medium text-muted-foreground">1.94%</span>
                    </div>
                    <div className="rounded-lg border border-success/20 bg-success/5 p-2 text-center text-sm">
                      <span className="font-bold text-success">+147% above benchmark</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Your CPM</span>
                        <span className="font-medium">$12.40</span>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Industry CPM</span>
                        <span>$15.20</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="mb-2 text-sm font-medium">TikTok Performance</p>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Your Avg Engagement</span>
                      <span className="font-bold text-success">7.2%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Industry Average</span>
                      <span className="font-medium text-muted-foreground">4.25%</span>
                    </div>
                    <div className="rounded-lg border border-success/20 bg-success/5 p-2 text-center text-sm">
                      <span className="font-bold text-success">+69% above benchmark</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Your CPM</span>
                        <span className="font-medium">$8.80</span>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Industry CPM</span>
                        <span>$9.80</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="mb-2 text-sm font-medium">YouTube Performance</p>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Your Avg Engagement</span>
                      <span className="font-bold text-success">3.2%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Industry Average</span>
                      <span className="font-medium text-muted-foreground">1.63%</span>
                    </div>
                    <div className="rounded-lg border border-success/20 bg-success/5 p-2 text-center text-sm">
                      <span className="font-bold text-success">+96% above benchmark</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Your CPM</span>
                        <span className="font-medium">$18.20</span>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Industry CPM</span>
                        <span>$22.40</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Tier-Based ROI Benchmarks</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      { tier: 'Nano', yourROAS: 5.2, industryROAS: 3.8 },
                      { tier: 'Micro', yourROAS: 6.8, industryROAS: 4.5 },
                      { tier: 'Macro', yourROAS: 8.1, industryROAS: 5.2 },
                      { tier: 'Mega', yourROAS: 7.4, industryROAS: 4.8 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="tier" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Bar dataKey="yourROAS" fill="hsl(var(--chart-1))" name="Your ROAS" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="industryROAS" fill="hsl(var(--chart-2))" name="Industry ROAS" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Insights & Recommendations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg border border-success/20 bg-success/5 p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-success" />
                    <p className="font-medium text-success">Exceptional Performance</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Your influencer program outperforms industry benchmarks by 78% on average. Focus on scaling top
                    performers.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <Brain className="h-5 w-5 text-chart-3" />
                    <p className="font-medium">Strategic Recommendation</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Micro-influencers show 28% better ROAS than macro. Consider reallocating 15% budget to micro tier.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <Target className="h-5 w-5 text-chart-4" />
                    <p className="font-medium">Optimization Opportunity</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    TikTok campaigns deliver 45% lower CPM. Expand TikTok presence for cost-efficient reach.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Predictive Revenue Forecasting</CardTitle>
              <p className="text-sm text-muted-foreground">
                AI-powered predictions based on historical performance, seasonality, and market trends
              </p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={[...performanceData, ...predictiveData]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    name="Actual Revenue"
                  />
                  <Line
                    type="monotone"
                    dataKey="predicted"
                    stroke="hsl(var(--chart-2))"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Predicted Revenue"
                  />
                  <Line
                    type="monotone"
                    dataKey="upper"
                    stroke="hsl(var(--chart-3))"
                    strokeWidth={1}
                    strokeDasharray="3 3"
                    name="Upper Bound"
                  />
                  <Line
                    type="monotone"
                    dataKey="lower"
                    stroke="hsl(var(--chart-4))"
                    strokeWidth={1}
                    strokeDasharray="3 3"
                    name="Lower Bound"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">90-Day Forecast</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-3xl font-bold">$145.8K</p>
                    <p className="text-sm text-muted-foreground">Predicted influencer revenue</p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Conservative</span>
                      <span className="font-medium">$129.2K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Optimistic</span>
                      <span className="font-medium">$162.4K</span>
                    </div>
                  </div>
                  <Badge className="bg-chart-2/10 text-chart-2">91% Confidence</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Growth Projections</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Revenue Growth</span>
                      <span className="font-bold text-success">+42%</span>
                    </div>
                    <Progress value={42} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">ROAS Improvement</span>
                      <span className="font-bold text-success">+18%</span>
                    </div>
                    <Progress value={18} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Reach Expansion</span>
                      <span className="font-bold text-success">+56%</span>
                    </div>
                    <Progress value={56} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Trend Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-2 rounded-lg border border-success/20 bg-success/5 p-3">
                  <TrendingUp className="mt-0.5 h-4 w-4 text-success" />
                  <div>
                    <p className="text-sm font-medium">Strong Upward Trend</p>
                    <p className="text-xs text-muted-foreground">Consistent 28% MoM growth</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 rounded-lg border p-3">
                  <Brain className="mt-0.5 h-4 w-4 text-chart-3" />
                  <div>
                    <p className="text-sm font-medium">Seasonality Detected</p>
                    <p className="text-xs text-muted-foreground">Q4 shows 32% performance boost</p>
                  </div>
                </div>
                <div className="flex items-start gap-2 rounded-lg border p-3">
                  <Star className="mt-0.5 h-4 w-4 text-chart-4" />
                  <div>
                    <p className="text-sm font-medium">High Confidence</p>
                    <p className="text-xs text-muted-foreground">Based on 12 months of data</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
