import { useState, useRef, useEffect } from 'react';
import { SEOHead } from '@/components/seo';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Send,
  Sparkles,
  Lightbulb,
  ChevronRight,
  Pencil,
  Trash2,
  Check,
  X,
  Bot,
  User,
  Mic,
  ArrowUp,
  RefreshCw,
  Star,
  BookOpen,
  Zap,
  FileText,
  Upload,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useLoading } from '@/hooks/useLoading';
import { AskPogeeSkeleton } from '@/components/skeletons';

// Import components
import { QuickInsightsHeader } from '@/components/askpogee/QuickInsightsHeader';
import { RightSidebar } from '@/components/askpogee/RightSidebar';
import { ResultVisualization } from '@/components/askpogee/ResultVisualization';
import { AIInsightsPanel } from '@/components/askpogee/AIInsightsPanel';
import { ExportOptions } from '@/components/askpogee/ExportOptions';
import { RelatedTopics } from '@/components/askpogee/RelatedTopics';
import { SmartSuggestions } from '@/components/askpogee/SmartSuggestions';
import { TemplateLibrary } from '@/components/askpogee/TemplateLibrary';
import { SaveQueryDialog } from '@/components/askpogee/SaveQueryDialog';
import { DrilldownModal } from '@/components/askpogee/DrilldownModal';
import { DynamicChartMessage } from '@/components/askpogee/DynamicChartMessage';
import { DocumentIntelligence } from '@/components/askpogee/DocumentIntelligence';

// Import types and data
import {
  OutputFormat,
  Message,
  DataPoint,
  SavedQuery,
  ConversationHistory,
  ExtractedDocumentData,
} from '@/components/askpogee/types';
import {
  quickInsights,
  templateQueries,
  followUpQuestions,
  relatedTopics,
  initialSavedQueries,
  initialConversationHistory,
  generateMockAnalysis,
  detectSuggestedFormat,
} from '@/components/askpogee/mockData';

export default function AskPogee() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [preferredFormat, setPreferredFormat] = useState<OutputFormat>('table');
  const [conversationHistory, setConversationHistory] = useState<ConversationHistory[]>(initialConversationHistory);
  const [savedQueries, setSavedQueries] = useState<SavedQuery[]>(initialSavedQueries);
  const [isTyping, setIsTyping] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isLoading = useLoading(500);

  // Dialog states
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingChatId, setDeletingChatId] = useState<string | null>(null);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [saveQuery, setSaveQuery] = useState('');
  const [drilldownItem, setDrilldownItem] = useState<DataPoint | null>(null);
  const [drilldownOpen, setDrilldownOpen] = useState(false);
  const [showDocumentUpload, setShowDocumentUpload] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    submitQuery(input);
  };

  const submitQuery = (query: string) => {
    const newId = Date.now().toString();
    const analysis = generateMockAnalysis(query);
    const suggestedFormat = detectSuggestedFormat(query);

    setMessages((prev) => [...prev, { id: newId, role: 'user', content: query, timestamp: new Date() }]);

    setInput('');
    setShowSuggestions(false);
    setIsTyping(true);

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: `${newId}-response`,
          role: 'assistant',
          content: analysis.text,
          timestamp: new Date(),
          format: suggestedFormat,
          analysis,
          chartData: {
            suggestedFormat,
            data: analysis.data,
            title: `Analysis: ${query.slice(0, 50)}...`,
            followUpSuggestions: [
              'Would you like to see how this compares to last month?',
              'Should I identify the top 3 performers?',
              'Export this as a report?',
            ],
          },
        },
      ]);
      setIsTyping(false);

      setConversationHistory((prev) => [
        { id: newId, query, time: 'Just now', response: analysis.text.slice(0, 50), format: suggestedFormat },
        ...prev.slice(0, 9),
      ]);
    }, 1500);
  };

  const handleDocumentExtracted = (data: ExtractedDocumentData) => {
    const newId = Date.now().toString();
    const insights = data.insights || [];

    // Generate a response based on extracted document data
    setMessages((prev) => [
      ...prev,
      {
        id: newId,
        role: 'user',
        content: `📄 Uploaded document: ${data.title}`,
        timestamp: new Date(),
      },
      {
        id: `${newId}-response`,
        role: 'assistant',
        content: `I've analyzed your ${data.type}. ${insights[0] || 'Here are the extracted details.'}`,
        timestamp: new Date(),
        documentData: {
          fileName: data.title,
          extractedData: data,
          mergedInsight: insights.length > 0 ? `Key insight: ${insights[0]}` : undefined,
        },
      },
    ]);
  };

  const handleEditChat = (id: string, content: string) => {
    setEditingChatId(id);
    setEditingContent(content);
  };

  const handleSaveEdit = () => {
    if (!editingChatId) return;
    setMessages(messages.map((msg) => (msg.id === editingChatId ? { ...msg, content: editingContent } : msg)));
    setEditingChatId(null);
    setEditingContent('');
    toast.success('Chat updated');
  };

  const handleDeleteChat = (id: string) => {
    setDeletingChatId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteChat = () => {
    if (!deletingChatId) return;
    setMessages(messages.filter((msg) => !msg.id.startsWith(deletingChatId)));
    setConversationHistory(conversationHistory.filter((item) => item.id !== deletingChatId));
    setDeleteDialogOpen(false);
    setDeletingChatId(null);
    toast.success('Chat deleted');
  };

  const handleDrilldown = (item: DataPoint) => {
    setDrilldownItem(item);
    setDrilldownOpen(true);
  };

  const handleSaveQuery = (saved: Omit<SavedQuery, 'id' | 'lastRun'>) => {
    const newSaved: SavedQuery = {
      ...saved,
      id: Date.now().toString(),
      lastRun: 'Just now',
    };
    setSavedQueries((prev) => [newSaved, ...prev]);
    toast.success('Query saved!');
  };

  const getRelatedTopics = (query: string): string[] => {
    const lower = query.toLowerCase();
    if (lower.includes('campaign')) return relatedTopics.campaign;
    if (lower.includes('revenue') || lower.includes('sales')) return relatedTopics.revenue;
    if (lower.includes('customer')) return relatedTopics.customer;
    return relatedTopics.default;
  };

  if (isLoading) {
    return <AskPogeeSkeleton />;
  }

  return (
    <div className="flex h-full flex-col animate-fade-in">
      <SEOHead
        title="Ask - AI Marketing Assistant"
        description="Get instant answers about your marketing performance, customers, and revenue with AI-powered insights."
        keywords="AI marketing assistant, marketing analytics, data insights, natural language queries, marketing AI"
      />
      {/* Header */}
      <QuickInsightsHeader
        insights={quickInsights}
        onNewChat={() => setMessages([])}
        onSettings={() => toast.info('Settings coming soon')}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Main Chat Area */}
        <div className="flex flex-1 flex-col">
          <ScrollArea className="flex-1 px-8">
            {messages.length === 0 ? (
              <div className="flex min-h-[60vh] flex-col items-center justify-center py-12">
                <div className="w-full max-w-2xl space-y-8">
                  {/* Welcome */}
                  <div className="flex flex-col items-center gap-4 text-center">
                    <div className="relative">
                      <div className="flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-500 via-purple-500 to-fuchsia-500 shadow-2xl shadow-purple-500/30">
                        <Sparkles className="h-12 w-12 text-white" />
                      </div>
                      <div className="absolute -right-2 -top-2 rounded-full bg-background p-1">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500">
                          <Zap className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-3xl font-bold">How can I help you today?</h2>
                      <p className="text-muted-foreground">Ask anything about your marketing, customers, or revenue</p>
                    </div>
                  </div>

                  {/* Example Prompts Grid */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-muted-foreground">Popular questions:</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="gap-1.5 text-xs"
                        onClick={() => setTemplateDialogOpen(true)}
                      >
                        <BookOpen className="h-3.5 w-3.5" />
                        Browse All Templates
                      </Button>
                    </div>
                    <div className="grid gap-3 md:grid-cols-2">
                      {templateQueries.slice(0, 4).map((template) => (
                        <button
                          key={template.id}
                          onClick={() => setInput(template.text)}
                          className="group flex items-start gap-3 rounded-xl border border-border/50 bg-card/50 p-4 text-left transition-all hover:border-primary/50 hover:bg-muted/50 hover:shadow-lg"
                        >
                          <div className="rounded-lg bg-primary/10 p-2 transition-colors group-hover:bg-primary/20">
                            <template.icon className="h-4 w-4 text-primary" />
                          </div>
                          <div className="flex-1">
                            <Badge variant="secondary" className="mb-1.5 text-[10px] font-medium capitalize">
                              {template.category}
                            </Badge>
                            <p className="text-sm leading-relaxed text-muted-foreground group-hover:text-foreground transition-colors">
                              {template.text}
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Tip */}
                  <div className="flex items-center justify-center gap-2 rounded-xl bg-amber-500/10 px-4 py-3 text-sm text-amber-700 dark:text-amber-400">
                    <Lightbulb className="h-4 w-4 shrink-0" />
                    <span>Pro tip: Be specific about time periods and metrics for more accurate insights</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-3xl space-y-6 py-8">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn('flex gap-4 animate-fade-in', msg.role === 'user' ? 'flex-row-reverse' : '')}
                  >
                    <div
                      className={cn(
                        'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                        msg.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white',
                      )}
                    >
                      {msg.role === 'user' ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                    </div>

                    {msg.role === 'assistant' && msg.analysis ? (
                      <div className="flex-1 space-y-4">
                        <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg">
                          <CardContent className="p-5 space-y-5">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold">Pogee AI</span>
                                <Badge
                                  variant="secondary"
                                  className="text-[10px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                                >
                                  {msg.analysis.confidence}% confidence
                                </Badge>
                              </div>
                              <div className="flex items-center">
                                <ExportOptions
                                  onExport={(f) => toast.success(`Exporting as ${f.toUpperCase()}`)}
                                  onCopy={() => navigator.clipboard.writeText(msg.content)}
                                />
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() =>
                                    submitQuery(
                                      messages.find((m) => m.id === msg.id.replace('-response', ''))?.content || '',
                                    )
                                  }
                                >
                                  <RefreshCw className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setSaveQuery(
                                      messages.find((m) => m.id === msg.id.replace('-response', ''))?.content || '',
                                    );
                                    setSaveDialogOpen(true);
                                  }}
                                >
                                  <Star className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>

                            <p className="text-sm leading-relaxed">{msg.content}</p>

                            {/* Dynamic Chart Rendering */}
                            {msg.chartData && (
                              <DynamicChartMessage
                                query={messages.find((m) => m.id === msg.id.replace('-response', ''))?.content || ''}
                                data={msg.chartData.data}
                                suggestedFormat={msg.chartData.suggestedFormat}
                                onDrilldown={handleDrilldown}
                                onFollowUp={submitQuery}
                              />
                            )}

                            <AIInsightsPanel
                              insights={msg.analysis.insights}
                              recommendations={msg.analysis.recommendations}
                              metrics={msg.analysis.metrics}
                            />

                            <Separator />
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">Sources:</span>
                                {msg.analysis.sources.map((s, j) => (
                                  <Badge key={j} variant="outline" className="text-[10px]">
                                    {s}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            <RelatedTopics topics={getRelatedTopics(msg.content)} onTopicClick={submitQuery} />

                            <div className="flex flex-wrap gap-2 pt-2">
                              {followUpQuestions.slice(0, 4).map((q, j) => (
                                <Button
                                  key={j}
                                  variant="outline"
                                  size="sm"
                                  className="h-8 text-xs"
                                  onClick={() => submitQuery(q)}
                                >
                                  {q}
                                  <ChevronRight className="h-3 w-3 ml-1" />
                                </Button>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    ) : (
                      <div className="group relative">
                        {editingChatId === msg.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              value={editingContent}
                              onChange={(e) => setEditingContent(e.target.value)}
                              className="min-w-[300px]"
                              autoFocus
                            />
                            <Button size="icon" variant="ghost" onClick={handleSaveEdit} className="h-8 w-8">
                              <Check className="h-4 w-4 text-emerald-500" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => setEditingChatId(null)}
                              className="h-8 w-8"
                            >
                              <X className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        ) : (
                          <>
                            <div className="rounded-2xl rounded-tr-sm bg-primary px-4 py-3 text-primary-foreground shadow-lg">
                              {msg.content}
                            </div>
                            <div className="absolute -left-16 top-1/2 -translate-y-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => handleEditChat(msg.id, msg.content)}
                              >
                                <Pencil className="h-3 w-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-destructive"
                                onClick={() => handleDeleteChat(msg.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                ))}

                {isTyping && (
                  <div className="flex gap-4 animate-fade-in">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
                      <Bot className="h-5 w-5" />
                    </div>
                    <div className="flex items-center gap-1 rounded-2xl bg-muted px-4 py-3">
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:-0.3s]" />
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:-0.15s]" />
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce" />
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>

          {/* Input Area */}
          <div className="border-t border-border/50 bg-gradient-to-t from-muted/50 to-transparent p-4">
            {/* Document Upload Panel */}
            {showDocumentUpload && (
              <div className="mx-auto max-w-3xl mb-4">
                <DocumentIntelligence
                  onDataExtracted={handleDocumentExtracted}
                  onInsightGenerated={(insight) => toast.info(insight)}
                />
              </div>
            )}

            <form onSubmit={handleSubmit} className="mx-auto max-w-3xl relative">
              <SmartSuggestions
                input={input}
                onSelect={(s) => {
                  setInput(s);
                  setShowSuggestions(false);
                }}
                visible={showSuggestions && input.length >= 3}
              />
              <div className="relative flex items-center gap-2">
                <Button
                  type="button"
                  variant={showDocumentUpload ? 'secondary' : 'outline'}
                  size="icon"
                  className="h-14 w-14 rounded-2xl shrink-0"
                  onClick={() => setShowDocumentUpload(!showDocumentUpload)}
                >
                  <FileText className="h-5 w-5" />
                </Button>
                <div className="relative flex-1">
                  <Input
                    value={input}
                    onChange={(e) => {
                      setInput(e.target.value);
                      setShowSuggestions(true);
                    }}
                    onFocus={() => setShowSuggestions(true)}
                    placeholder="Ask anything about your marketing data..."
                    className="h-14 rounded-2xl border-border/50 bg-background pl-5 pr-14 text-base shadow-lg"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-3 top-1/2 -translate-y-1/2 h-9 w-9"
                  >
                    <Mic className="h-5 w-5" />
                  </Button>
                </div>
                <Button
                  type="submit"
                  size="icon"
                  className="h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg"
                  disabled={!input.trim() || isTyping}
                >
                  <ArrowUp className="h-5 w-5" />
                </Button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Sidebar */}
        <RightSidebar
          preferredFormat={preferredFormat}
          onFormatChange={setPreferredFormat}
          conversationHistory={conversationHistory}
          savedQueries={savedQueries}
          onSelectHistory={setInput}
          onSelectSaved={setInput}
          onDeleteHistory={(id) => setConversationHistory((prev) => prev.filter((h) => h.id !== id))}
          onDeleteSaved={(id) => setSavedQueries((prev) => prev.filter((s) => s.id !== id))}
          onTogglePin={(id) =>
            setSavedQueries((prev) => prev.map((s) => (s.id === id ? { ...s, pinned: !s.pinned } : s)))
          }
          onOpenTemplates={() => setTemplateDialogOpen(true)}
        />
      </div>

      {/* Dialogs */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Chat</DialogTitle>
            <DialogDescription>This will remove this message and its response.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDeleteChat}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
        <DialogContent className="sm:max-w-lg p-0 overflow-hidden">
          <TemplateLibrary
            templates={templateQueries}
            onSelectTemplate={(q) => {
              setInput(q);
              setTemplateDialogOpen(false);
            }}
          />
        </DialogContent>
      </Dialog>

      <SaveQueryDialog
        open={saveDialogOpen}
        onOpenChange={setSaveDialogOpen}
        query={saveQuery}
        onSave={handleSaveQuery}
      />
      <DrilldownModal
        open={drilldownOpen}
        onOpenChange={setDrilldownOpen}
        item={drilldownItem}
        onDeepDive={submitQuery}
      />
    </div>
  );
}
