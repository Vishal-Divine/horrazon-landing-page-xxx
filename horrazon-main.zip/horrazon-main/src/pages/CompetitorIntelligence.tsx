import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import {
  Target,
  TrendingUp,
  TrendingDown,
  Eye,
  DollarSign,
  Users,
  Search,
  AlertTriangle,
  Brain,
  BarChart3,
  PieChart,
  Radar,
  Image,
  Video,
  Share2,
  Globe,
  Zap,
  Shield,
  ArrowUpRight,
  ArrowDownRight,
  Megaphone,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar as ReRadar,
  AreaChart,
  Area,
} from 'recharts';

const competitors = [
  {
    id: 1,
    name: 'CompetitorA Pro',
    logo: '🔵',
    marketShare: 28.4,
    shareChange: 2.1,
    estimatedSpend: 284000,
    spendChange: 18,
    channels: { google: 42, meta: 35, tiktok: 15, other: 8 },
    shareOfVoice: 32.4,
    sentiment: 78,
    brandStrength: 84,
    activeCampaigns: 12,
    newCreatives: 28,
    topKeywords: ['best fitness app', 'workout tracker', 'home gym'],
    threatLevel: 'high',
  },
  {
    id: 2,
    name: 'MarketLeader Inc',
    logo: '🟢',
    marketShare: 34.2,
    shareChange: -1.4,
    estimatedSpend: 420000,
    spendChange: -8,
    channels: { google: 48, meta: 28, tiktok: 12, other: 12 },
    shareOfVoice: 38.6,
    sentiment: 82,
    brandStrength: 92,
    activeCampaigns: 18,
    newCreatives: 42,
    topKeywords: ['premium fitness', 'personal trainer', 'nutrition plan'],
    threatLevel: 'medium',
  },
  {
    id: 3,
    name: 'Emerging Startup',
    logo: '🟡',
    marketShare: 12.8,
    shareChange: 4.2,
    estimatedSpend: 128000,
    spendChange: 42,
    channels: { google: 22, meta: 28, tiktok: 42, other: 8 },
    shareOfVoice: 18.4,
    sentiment: 88,
    brandStrength: 68,
    activeCampaigns: 8,
    newCreatives: 64,
    topKeywords: ['viral fitness', '30 day challenge', 'tiktok workout'],
    threatLevel: 'rising',
  },
  {
    id: 4,
    name: 'Legacy Brand',
    logo: '🔴',
    marketShare: 18.6,
    shareChange: -2.8,
    estimatedSpend: 186000,
    spendChange: -12,
    channels: { google: 58, meta: 32, tiktok: 4, other: 6 },
    shareOfVoice: 22.4,
    sentiment: 72,
    brandStrength: 78,
    activeCampaigns: 6,
    newCreatives: 12,
    topKeywords: ['trusted fitness', 'gym equipment', 'classic workout'],
    threatLevel: 'low',
  },
];

const yourBrand = {
  marketShare: 24.8,
  estimatedSpend: 248000,
  shareOfVoice: 28.2,
  sentiment: 86,
  brandStrength: 82,
};

const spendTrendData = [
  { month: 'Jan', you: 42, competitorA: 48, marketLeader: 68, emerging: 18, legacy: 32 },
  { month: 'Feb', you: 45, competitorA: 52, marketLeader: 72, emerging: 24, legacy: 30 },
  { month: 'Mar', you: 48, competitorA: 54, marketLeader: 70, emerging: 32, legacy: 28 },
  { month: 'Apr', you: 52, competitorA: 48, marketLeader: 68, emerging: 38, legacy: 26 },
  { month: 'May', you: 55, competitorA: 52, marketLeader: 65, emerging: 42, legacy: 24 },
  { month: 'Jun', you: 58, competitorA: 56, marketLeader: 62, emerging: 48, legacy: 22 },
];

const shareOfVoiceData = [
  { category: 'Brand', you: 28, competitorA: 32, marketLeader: 38 },
  { category: 'Generic', you: 24, competitorA: 28, marketLeader: 42 },
  { category: 'Competitor', you: 32, competitorA: 18, marketLeader: 22 },
  { category: 'Long-tail', you: 38, competitorA: 24, marketLeader: 28 },
];

const marketPositionData = [
  { subject: 'Brand Awareness', you: 82, competitorA: 84, marketLeader: 92, fullMark: 100 },
  { subject: 'Customer Loyalty', you: 78, competitorA: 72, marketLeader: 88, fullMark: 100 },
  { subject: 'Innovation', you: 86, competitorA: 74, marketLeader: 68, fullMark: 100 },
  { subject: 'Price Value', you: 80, competitorA: 76, marketLeader: 72, fullMark: 100 },
  { subject: 'Social Presence', you: 74, competitorA: 82, marketLeader: 78, fullMark: 100 },
  { subject: 'Market Reach', you: 72, competitorA: 78, marketLeader: 94, fullMark: 100 },
];

const creativeLibrary = [
  {
    id: 1,
    competitor: 'CompetitorA Pro',
    type: 'Video',
    platform: 'Meta',
    firstSeen: '2 days ago',
    engagement: 'High',
    theme: 'UGC Testimonial',
    cta: 'Start Free Trial',
  },
  {
    id: 2,
    competitor: 'MarketLeader Inc',
    type: 'Image',
    platform: 'Google',
    firstSeen: '1 week ago',
    engagement: 'Medium',
    theme: 'Product Feature',
    cta: 'Learn More',
  },
  {
    id: 3,
    competitor: 'Emerging Startup',
    type: 'Video',
    platform: 'TikTok',
    firstSeen: '1 day ago',
    engagement: 'Viral',
    theme: 'Challenge',
    cta: 'Join Now',
  },
  {
    id: 4,
    competitor: 'CompetitorA Pro',
    type: 'Carousel',
    platform: 'Meta',
    firstSeen: '3 days ago',
    engagement: 'High',
    theme: 'Before/After',
    cta: 'Get Started',
  },
  {
    id: 5,
    competitor: 'Legacy Brand',
    type: 'Image',
    platform: 'Google',
    firstSeen: '2 weeks ago',
    engagement: 'Low',
    theme: 'Brand Awareness',
    cta: 'Shop Now',
  },
  {
    id: 6,
    competitor: 'Emerging Startup',
    type: 'Video',
    platform: 'Meta',
    firstSeen: '5 hours ago',
    engagement: 'High',
    theme: 'Influencer',
    cta: 'Download App',
  },
];

const keywordGaps = [
  { keyword: 'fitness tracker app', yourRank: 8, topCompetitorRank: 2, volume: 12400, opportunity: 'high' },
  { keyword: 'home workout routine', yourRank: 12, topCompetitorRank: 3, volume: 8600, opportunity: 'high' },
  { keyword: 'calorie counter', yourRank: 15, topCompetitorRank: 5, volume: 18200, opportunity: 'medium' },
  { keyword: 'meal prep ideas', yourRank: null, topCompetitorRank: 4, volume: 22400, opportunity: 'high' },
  { keyword: 'weight loss program', yourRank: 22, topCompetitorRank: 1, volume: 32800, opportunity: 'medium' },
];

const marketAlerts = [
  { type: 'warning', message: 'CompetitorA increased TikTok spend by 45% this week', time: '2h ago' },
  { type: 'info', message: 'Emerging Startup launched new influencer campaign', time: '5h ago' },
  { type: 'success', message: "Your share of voice increased 2.4% in 'fitness app' category", time: '1d ago' },
  { type: 'warning', message: 'MarketLeader testing new pricing strategy', time: '2d ago' },
];

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function CompetitorIntelligence() {
  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Competitor Intelligence</h1>
          <p className="text-muted-foreground">Track competitor spend, share of voice, and market positioning</p>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Competitors</SelectItem>
              <SelectItem value="direct">Direct Only</SelectItem>
              <SelectItem value="indirect">Indirect</SelectItem>
            </SelectContent>
          </Select>
          <Button className="gap-2">
            <Target className="h-4 w-4" />
            Add Competitor
          </Button>
        </div>
      </div>

      {/* Market Alerts */}
      <Card className="border-warning/30 bg-warning/5">
        <CardContent className="pt-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <span className="font-semibold">Market Intelligence Alerts</span>
          </div>
          <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
            {marketAlerts.map((alert, i) => (
              <div key={i} className="flex items-start gap-2 rounded-lg bg-background/50 p-3">
                <div
                  className={`h-2 w-2 rounded-full mt-1.5 ${
                    alert.type === 'warning' ? 'bg-warning' : alert.type === 'success' ? 'bg-success' : 'bg-primary'
                  }`}
                />
                <div>
                  <p className="text-sm">{alert.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{alert.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Your Market Share</p>
                <p className="text-3xl font-bold">{yourBrand.marketShare}%</p>
              </div>
              <PieChart className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              +1.8% vs last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Share of Voice</p>
                <p className="text-3xl font-bold">{yourBrand.shareOfVoice}%</p>
              </div>
              <Megaphone className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">#3 in market</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Brand Strength</p>
                <p className="text-3xl font-bold">{yourBrand.brandStrength}</p>
              </div>
              <Shield className="h-10 w-10 text-chart-3" />
            </div>
            <Progress value={yourBrand.brandStrength} className="h-2 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Sentiment Score</p>
                <p className="text-3xl font-bold">{yourBrand.sentiment}%</p>
              </div>
              <Brain className="h-10 w-10 text-chart-4" />
            </div>
            <p className="mt-2 flex items-center gap-1 text-xs text-success">
              <TrendingUp className="h-3 w-3" />
              +4% vs competitors avg
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Threat Index</p>
                <p className="text-3xl font-bold">Medium</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-warning" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">2 high-priority threats</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Market Overview</TabsTrigger>
          <TabsTrigger value="spend">Spend Analysis</TabsTrigger>
          <TabsTrigger value="sov">Share of Voice</TabsTrigger>
          <TabsTrigger value="creative">Creative Library</TabsTrigger>
          <TabsTrigger value="keywords">Keyword Gaps</TabsTrigger>
          <TabsTrigger value="positioning">Market Position</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Competitor Landscape</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Competitor</TableHead>
                    <TableHead>Market Share</TableHead>
                    <TableHead>Est. Monthly Spend</TableHead>
                    <TableHead>Share of Voice</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Brand Strength</TableHead>
                    <TableHead>Active Campaigns</TableHead>
                    <TableHead>Threat Level</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="bg-primary/5">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span>🎯</span>
                        <span>Your Brand</span>
                        <Badge variant="outline" className="text-xs">
                          You
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>{yourBrand.marketShare}%</TableCell>
                    <TableCell>${(yourBrand.estimatedSpend / 1000).toFixed(0)}K</TableCell>
                    <TableCell>{yourBrand.shareOfVoice}%</TableCell>
                    <TableCell>{yourBrand.sentiment}%</TableCell>
                    <TableCell>
                      <Progress value={yourBrand.brandStrength} className="h-2 w-16" />
                    </TableCell>
                    <TableCell>-</TableCell>
                    <TableCell>-</TableCell>
                  </TableRow>
                  {competitors.map((comp) => (
                    <TableRow key={comp.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <span>{comp.logo}</span>
                          <span>{comp.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {comp.marketShare}%
                          <span
                            className={`text-xs flex items-center ${comp.shareChange > 0 ? 'text-destructive' : 'text-success'}`}
                          >
                            {comp.shareChange > 0 ? (
                              <ArrowUpRight className="h-3 w-3" />
                            ) : (
                              <ArrowDownRight className="h-3 w-3" />
                            )}
                            {Math.abs(comp.shareChange)}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          ${(comp.estimatedSpend / 1000).toFixed(0)}K
                          <span
                            className={`text-xs flex items-center ${comp.spendChange > 0 ? 'text-destructive' : 'text-success'}`}
                          >
                            {comp.spendChange > 0 ? (
                              <ArrowUpRight className="h-3 w-3" />
                            ) : (
                              <ArrowDownRight className="h-3 w-3" />
                            )}
                            {Math.abs(comp.spendChange)}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{comp.shareOfVoice}%</TableCell>
                      <TableCell>{comp.sentiment}%</TableCell>
                      <TableCell>
                        <Progress value={comp.brandStrength} className="h-2 w-16" />
                      </TableCell>
                      <TableCell>{comp.activeCampaigns}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            comp.threatLevel === 'high'
                              ? 'destructive'
                              : comp.threatLevel === 'rising'
                                ? 'default'
                                : comp.threatLevel === 'medium'
                                  ? 'secondary'
                                  : 'outline'
                          }
                        >
                          {comp.threatLevel}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Channel Distribution Comparison</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {competitors.slice(0, 3).map((comp) => (
                  <div key={comp.id}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">
                        {comp.logo} {comp.name}
                      </span>
                    </div>
                    <div className="flex h-4 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${comp.channels.google}%` }}
                        className="bg-chart-1"
                        title={`Google: ${comp.channels.google}%`}
                      />
                      <div
                        style={{ width: `${comp.channels.meta}%` }}
                        className="bg-chart-2"
                        title={`Meta: ${comp.channels.meta}%`}
                      />
                      <div
                        style={{ width: `${comp.channels.tiktok}%` }}
                        className="bg-chart-3"
                        title={`TikTok: ${comp.channels.tiktok}%`}
                      />
                      <div
                        style={{ width: `${comp.channels.other}%` }}
                        className="bg-chart-4"
                        title={`Other: ${comp.channels.other}%`}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Google {comp.channels.google}%</span>
                      <span>Meta {comp.channels.meta}%</span>
                      <span>TikTok {comp.channels.tiktok}%</span>
                      <span>Other {comp.channels.other}%</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top Competitor Keywords</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {competitors.slice(0, 3).map((comp) => (
                  <div key={comp.id} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span>{comp.logo}</span>
                      <span className="text-sm font-medium">{comp.name}</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {comp.topKeywords.map((kw, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {kw}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="spend" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Estimated Ad Spend Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={spendTrendData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `$${v}K`} />
                  <Tooltip formatter={(value) => [`$${value}K`, '']} />
                  <Area
                    type="monotone"
                    dataKey="you"
                    stackId="1"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.6}
                    name="Your Brand"
                  />
                  <Area
                    type="monotone"
                    dataKey="competitorA"
                    stackId="2"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.4}
                    name="CompetitorA"
                  />
                  <Area
                    type="monotone"
                    dataKey="marketLeader"
                    stackId="3"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    fillOpacity={0.4}
                    name="MarketLeader"
                  />
                  <Area
                    type="monotone"
                    dataKey="emerging"
                    stackId="4"
                    stroke="hsl(var(--chart-4))"
                    fill="hsl(var(--chart-4))"
                    fillOpacity={0.4}
                    name="Emerging"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sov" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Share of Voice by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={shareOfVoiceData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" tickFormatter={(v) => `${v}%`} />
                  <YAxis dataKey="category" type="category" className="text-xs" width={100} />
                  <Tooltip formatter={(value) => [`${value}%`, '']} />
                  <Bar dataKey="you" fill="hsl(var(--chart-1))" name="Your Brand" />
                  <Bar dataKey="competitorA" fill="hsl(var(--chart-2))" name="CompetitorA" />
                  <Bar dataKey="marketLeader" fill="hsl(var(--chart-3))" name="MarketLeader" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="creative" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Competitor Creative Library</CardTitle>
                <Badge variant="secondary">{creativeLibrary.length} new creatives this week</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Competitor</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Platform</TableHead>
                    <TableHead>Theme</TableHead>
                    <TableHead>CTA</TableHead>
                    <TableHead>First Seen</TableHead>
                    <TableHead>Engagement</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {creativeLibrary.map((creative) => (
                    <TableRow key={creative.id}>
                      <TableCell className="font-medium">{creative.competitor}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {creative.type === 'Video' ? <Video className="h-4 w-4" /> : <Image className="h-4 w-4" />}
                          {creative.type}
                        </div>
                      </TableCell>
                      <TableCell>{creative.platform}</TableCell>
                      <TableCell>{creative.theme}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{creative.cta}</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{creative.firstSeen}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            creative.engagement === 'Viral'
                              ? 'destructive'
                              : creative.engagement === 'High'
                                ? 'default'
                                : creative.engagement === 'Medium'
                                  ? 'secondary'
                                  : 'outline'
                          }
                        >
                          {creative.engagement}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="ghost">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="keywords" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Keyword Gap Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Keyword</TableHead>
                    <TableHead>Your Rank</TableHead>
                    <TableHead>Top Competitor Rank</TableHead>
                    <TableHead>Search Volume</TableHead>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {keywordGaps.map((kw, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{kw.keyword}</TableCell>
                      <TableCell>{kw.yourRank || <span className="text-muted-foreground">Not ranking</span>}</TableCell>
                      <TableCell className="text-success">#{kw.topCompetitorRank}</TableCell>
                      <TableCell>{kw.volume.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={kw.opportunity === 'high' ? 'destructive' : 'secondary'}>
                          {kw.opportunity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline" className="gap-1">
                          <Target className="h-3 w-3" />
                          Target
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="positioning" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Market Positioning Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={marketPositionData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="subject" className="text-xs" />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} />
                  <ReRadar
                    name="Your Brand"
                    dataKey="you"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.5}
                  />
                  <ReRadar
                    name="CompetitorA"
                    dataKey="competitorA"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.3}
                  />
                  <ReRadar
                    name="MarketLeader"
                    dataKey="marketLeader"
                    stroke="hsl(var(--chart-3))"
                    fill="hsl(var(--chart-3))"
                    fillOpacity={0.3}
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
