import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import RFMMatrix from '@/components/RFMMatrix';
import ProductMatrix from '@/components/ProductMatrix';
import {
  AlertTriangle,
  Package,
  TrendingDown,
  Clock,
  DollarSign,
  Percent,
  ShoppingCart,
  AlertCircle,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const products = [
  {
    name: 'Summer Dress',
    revenue: 12400,
    units: 342,
    roas: 5.8,
    stock: 'high',
    daysOfSupply: 45,
    sellThrough: 78,
    margin: 42,
    stockoutRisk: 'low',
    promotionalLift: 22,
    velocity: 'fast',
  },
  {
    name: 'Running Shoes',
    revenue: 8900,
    units: 187,
    roas: 4.2,
    stock: 'critical',
    daysOfSupply: 5,
    sellThrough: 92,
    margin: 38,
    stockoutRisk: 'critical',
    promotionalLift: 15,
    velocity: 'fast',
  },
  {
    name: 'Wireless Headphones',
    revenue: 15200,
    units: 256,
    roas: 6.1,
    stock: 'high',
    daysOfSupply: 52,
    sellThrough: 65,
    margin: 55,
    stockoutRisk: 'low',
    promotionalLift: 28,
    velocity: 'medium',
  },
  {
    name: 'Yoga Mat',
    revenue: 3400,
    units: 89,
    roas: 3.5,
    stock: 'warning',
    daysOfSupply: 12,
    sellThrough: 84,
    margin: 45,
    stockoutRisk: 'medium',
    promotionalLift: 8,
    velocity: 'medium',
  },
  {
    name: 'Protein Powder',
    revenue: 6700,
    units: 145,
    roas: 4.8,
    stock: 'high',
    daysOfSupply: 38,
    sellThrough: 71,
    margin: 48,
    stockoutRisk: 'low',
    promotionalLift: 35,
    velocity: 'fast',
  },
  {
    name: 'Fitness Tracker',
    revenue: 2100,
    units: 34,
    roas: 2.1,
    stock: 'dead',
    daysOfSupply: 180,
    sellThrough: 12,
    margin: 28,
    stockoutRisk: 'none',
    promotionalLift: -5,
    velocity: 'dead',
  },
];

export default function Merchandise() {
  const criticalStock = products.filter((p) => p.stock === 'critical').length;
  const deadStock = products.filter((p) => p.stock === 'dead').length;
  const avgMargin = (products.reduce((sum, p) => sum + p.margin, 0) / products.length).toFixed(1);

  return (
    <div className="space-y-8 p-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          Merchandise Intelligence
        </h1>
        <p className="text-muted-foreground text-lg">Advanced SKU analytics and inventory optimization</p>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-destructive/30 bg-destructive/5">
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Critical Stock</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive animate-pulse" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">{criticalStock}</div>
            <p className="text-xs text-muted-foreground mt-1">Immediate action required</p>
            <Button
              size="sm"
              variant="destructive"
              className="mt-3 h-7 text-xs"
              onClick={() =>
                toast({ title: 'Campaigns Paused', description: '2 campaigns targeting low-stock items paused' })
              }
            >
              Pause Ads
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Dead Stock Items</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{deadStock}</div>
            <p className="text-xs text-muted-foreground mt-1">Slow-moving inventory</p>
            <Badge variant="secondary" className="mt-3 text-xs">
              -${(deadStock * 2100).toLocaleString()} tied up
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Avg Margin</CardTitle>
            <Percent className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-success">{avgMargin}%</div>
            <p className="text-xs text-muted-foreground mt-1">Across all SKUs</p>
            <div className="mt-3">
              <Progress value={parseFloat(avgMargin)} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Total SKUs</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">248</div>
            <p className="text-xs text-muted-foreground mt-1">In active catalog</p>
            <Badge variant="outline" className="mt-3 text-xs">
              +12 vs last month
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* RFM Customer Segmentation */}
      <RFMMatrix />

      {/* Product Performance Matrix */}
      <ProductMatrix />

      {/* Detailed Inventory Intelligence */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Inventory Intelligence Dashboard</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Real-time stock metrics and optimization recommendations
              </p>
            </div>
            <Button variant="outline" size="sm">
              Export Report
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead className="text-right">Revenue</TableHead>
                <TableHead className="text-right">Units</TableHead>
                <TableHead className="text-right">ROAS</TableHead>
                <TableHead className="text-right">Margin %</TableHead>
                <TableHead className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    Days Supply
                  </div>
                </TableHead>
                <TableHead className="text-right">Sell-Through</TableHead>
                <TableHead>Velocity</TableHead>
                <TableHead>Risk</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.name} className="hover:bg-muted/30">
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell className="text-right font-semibold">${(product.revenue / 1000).toFixed(1)}K</TableCell>
                  <TableCell className="text-right">{product.units}</TableCell>
                  <TableCell className="text-right">
                    <span className="font-medium text-success">{product.roas.toFixed(1)}x</span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="space-y-1">
                      <span className="font-medium">{product.margin}%</span>
                      <Progress value={product.margin} className="h-1 w-12" />
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Badge variant={product.daysOfSupply < 10 ? 'destructive' : 'secondary'} className="font-mono">
                      {product.daysOfSupply}d
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="space-y-1">
                      <span className="text-sm font-medium">{product.sellThrough}%</span>
                      <Progress value={product.sellThrough} className="h-1 w-12" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        product.velocity === 'fast'
                          ? 'default'
                          : product.velocity === 'medium'
                            ? 'secondary'
                            : 'outline'
                      }
                      className="text-xs"
                    >
                      {product.velocity}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        product.stockoutRisk === 'critical'
                          ? 'destructive'
                          : product.stockoutRisk === 'medium'
                            ? 'secondary'
                            : 'outline'
                      }
                      className="text-xs"
                    >
                      {product.stockoutRisk}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
