import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  Plus,
  Zap,
  TrendingUp,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Play,
  Pause,
  Settings,
  BarChart3,
  Activity,
  Target,
  DollarSign,
  Sparkles,
  Copy,
  Edit,
  Trash2,
  RefreshCw,
  History,
  Filter,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const rules = [
  {
    id: 1,
    name: 'Low ROAS Pause',
    description: 'IF Meta ROAS < 0.8 for 3 days THEN Pause',
    platform: 'Meta',
    status: 'Active',
    executions: 24,
    savings: 8420,
    successRate: 92,
    lastTriggered: '2 hours ago',
    type: 'protective',
  },
  {
    id: 2,
    name: 'High CPC Alert',
    description: 'IF Google CPC > $5 for 2 days THEN Alert',
    platform: 'Google',
    status: 'Active',
    executions: 18,
    savings: 3200,
    successRate: 100,
    lastTriggered: '1 day ago',
    type: 'alert',
  },
  {
    id: 3,
    name: 'Budget Reallocation',
    description: 'IF Campaign ROAS > 6 for 5 days THEN Increase Budget 20%',
    platform: 'Meta',
    status: 'Paused',
    executions: 12,
    savings: 0,
    successRate: 88,
    lastTriggered: '1 week ago',
    type: 'scaling',
  },
  {
    id: 4,
    name: 'Creative Fatigue Detection',
    description: 'IF CTR drops >20% vs 7d avg THEN Alert & suggest refresh',
    platform: 'All',
    status: 'Active',
    executions: 42,
    savings: 12800,
    successRate: 78,
    lastTriggered: '3 hours ago',
    type: 'creative',
  },
  {
    id: 5,
    name: 'Weekend Budget Boost',
    description: 'IF Saturday/Sunday AND ROAS > 4 THEN Increase budget 15%',
    platform: 'TikTok',
    status: 'Active',
    executions: 8,
    savings: 0,
    successRate: 100,
    lastTriggered: '4 days ago',
    type: 'scaling',
  },
  {
    id: 6,
    name: 'Audience Saturation Warning',
    description: 'IF Frequency > 3 AND CTR < 1% THEN Alert',
    platform: 'Meta',
    status: 'Active',
    executions: 15,
    savings: 6200,
    successRate: 86,
    lastTriggered: '12 hours ago',
    type: 'protective',
  },
];

const rulePerformanceTrend = [
  { date: 'Week 1', executions: 42, savings: 4200, prevented: 8 },
  { date: 'Week 2', executions: 56, savings: 6800, prevented: 12 },
  { date: 'Week 3', executions: 48, savings: 5400, prevented: 10 },
  { date: 'Week 4', executions: 62, savings: 8420, prevented: 15 },
];

const executionLog = [
  {
    time: 'Today, 2:34 PM',
    rule: 'Low ROAS Pause',
    action: "Paused campaign 'Summer_Retarget_V2'",
    impact: '-$240/day saved',
    status: 'success',
  },
  {
    time: 'Today, 11:22 AM',
    rule: 'Creative Fatigue Detection',
    action: "Alert sent for 'Hero_Banner_June'",
    impact: 'CTR -24% detected',
    status: 'alert',
  },
  {
    time: 'Yesterday, 6:45 PM',
    rule: 'High CPC Alert',
    action: "Alert sent for 'Brand_Search_US'",
    impact: 'CPC $6.42 detected',
    status: 'alert',
  },
  {
    time: 'Yesterday, 2:12 PM',
    rule: 'Budget Reallocation',
    action: "Increased budget for 'TOF_Lookalike'",
    impact: '+$120/day allocated',
    status: 'success',
  },
  {
    time: '2 days ago',
    rule: 'Audience Saturation Warning',
    action: "Alert sent for 'Retarget_30d'",
    impact: 'Frequency 3.8 detected',
    status: 'alert',
  },
];

const ruleTemplates = [
  {
    name: 'Stop Loss Protection',
    description: 'Pause campaigns when ROAS falls below threshold',
    category: 'Protective',
    popularity: 94,
  },
  {
    name: 'Scaling Winner',
    description: 'Automatically increase budget for top performers',
    category: 'Growth',
    popularity: 88,
  },
  {
    name: 'Creative Rotation',
    description: 'Rotate creatives when performance drops',
    category: 'Creative',
    popularity: 76,
  },
  {
    name: 'Dayparting Optimizer',
    description: 'Adjust bids based on time of day performance',
    category: 'Optimization',
    popularity: 82,
  },
  {
    name: 'Competitor Alert',
    description: 'Get notified when CPMs spike significantly',
    category: 'Monitoring',
    popularity: 71,
  },
  {
    name: 'Budget Pacing',
    description: 'Ensure spend is distributed evenly throughout the period',
    category: 'Budget',
    popularity: 79,
  },
];

const aiSuggestions = [
  {
    title: 'Create a frequency cap rule',
    reason: '5 campaigns have frequency > 4 without any protection',
    impact: 'Estimated $2,400/mo savings',
    confidence: 94,
  },
  {
    title: 'Add weekend budget adjustment',
    reason: 'Your ROAS is 28% higher on weekends',
    impact: 'Estimated +$4,200/mo revenue',
    confidence: 89,
  },
  {
    title: 'Set up CTR monitoring for TikTok',
    reason: 'TikTok CTR variance is 3x higher than other platforms',
    impact: 'Earlier fatigue detection',
    confidence: 86,
  },
];

const typeColors: Record<string, string> = {
  protective: 'bg-destructive/10 text-destructive',
  alert: 'bg-warning/10 text-warning',
  scaling: 'bg-success/10 text-success',
  creative: 'bg-chart-1/10 text-chart-1',
};

export default function Rules() {
  const navigate = useNavigate();

  const totalSavings = rules.reduce((sum, r) => sum + r.savings, 0);
  const totalExecutions = rules.reduce((sum, r) => sum + r.executions, 0);
  const avgSuccessRate = rules.reduce((sum, r) => sum + r.successRate, 0) / rules.length;

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Rules & Automation</h1>
          <p className="text-muted-foreground">AI-powered automation rules with performance tracking</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Sparkles className="h-4 w-4" />
            AI Suggest Rules
          </Button>
          <Button onClick={() => navigate('/create-rule')} className="gap-2">
            <Plus className="h-4 w-4" />
            Create New Rule
          </Button>
        </div>
      </div>

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Rules</p>
                <p className="text-3xl font-bold">{rules.filter((r) => r.status === 'Active').length}</p>
              </div>
              <Zap className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{rules.length} total rules</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Executions</p>
                <p className="text-3xl font-bold">{totalExecutions}</p>
              </div>
              <Activity className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-success">Last 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Money Saved</p>
                <p className="text-3xl font-bold">${(totalSavings / 1000).toFixed(1)}K</p>
              </div>
              <DollarSign className="h-10 w-10 text-success" />
            </div>
            <p className="mt-2 text-xs text-success">From wasteful spend</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-3xl font-bold">{avgSuccessRate.toFixed(0)}%</p>
              </div>
              <Target className="h-10 w-10 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Avg across all rules</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Issues Prevented</p>
                <p className="text-3xl font-bold">45</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-warning" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rules" className="space-y-6">
        <TabsList>
          <TabsTrigger value="rules">Active Rules</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="logs">Execution Log</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="ai">AI Suggestions</TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>All Rules</CardTitle>
                <div className="flex gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="protective">Protective</SelectItem>
                      <SelectItem value="scaling">Scaling</SelectItem>
                      <SelectItem value="alert">Alert</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="h-4 w-4" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rule Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Platform</TableHead>
                    <TableHead>Executions</TableHead>
                    <TableHead>Success Rate</TableHead>
                    <TableHead>Savings</TableHead>
                    <TableHead>Last Triggered</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rules.map((rule) => (
                    <TableRow key={rule.id} className="group">
                      <TableCell>
                        <div>
                          <p className="font-medium">{rule.name}</p>
                          <p className="text-xs text-muted-foreground max-w-xs truncate">{rule.description}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={typeColors[rule.type]}>{rule.type}</Badge>
                      </TableCell>
                      <TableCell>{rule.platform}</TableCell>
                      <TableCell className="font-medium">{rule.executions}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={rule.successRate} className="h-2 w-16" />
                          <span className="text-sm">{rule.successRate}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-success">
                        {rule.savings > 0 ? `$${rule.savings.toLocaleString()}` : '-'}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{rule.lastTriggered}</TableCell>
                      <TableCell>
                        <Badge variant={rule.status === 'Active' ? 'default' : 'secondary'}>{rule.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            {rule.status === 'Active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Rule Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={rulePerformanceTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="executions"
                      stackId="1"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.3}
                      name="Executions"
                    />
                    <Area
                      type="monotone"
                      dataKey="prevented"
                      stackId="2"
                      stroke="hsl(var(--chart-2))"
                      fill="hsl(var(--chart-2))"
                      fillOpacity={0.3}
                      name="Issues Prevented"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Savings Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={rulePerformanceTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                      formatter={(value) => `$${value.toLocaleString()}`}
                    />
                    <Bar dataKey="savings" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} name="Savings ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Rule Effectiveness Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {rules
                  .filter((r) => r.status === 'Active')
                  .slice(0, 3)
                  .map((rule) => (
                    <div key={rule.id} className="rounded-lg border border-border p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">{rule.name}</span>
                        <Badge className={typeColors[rule.type]}>{rule.type}</Badge>
                      </div>
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Success Rate</span>
                            <span className="font-medium">{rule.successRate}%</span>
                          </div>
                          <Progress value={rule.successRate} className="h-2" />
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground">Executions</p>
                            <p className="font-bold">{rule.executions}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Savings</p>
                            <p className="font-bold text-success">${rule.savings.toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Execution Log
                </CardTitle>
                <Button variant="outline" size="sm" className="gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {executionLog.map((log, i) => (
                  <div key={i} className="flex items-start gap-4 rounded-lg border border-border p-4">
                    <div className={`rounded-full p-2 ${log.status === 'success' ? 'bg-success/10' : 'bg-warning/10'}`}>
                      {log.status === 'success' ? (
                        <CheckCircle2 className="h-4 w-4 text-success" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-warning" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{log.rule}</span>
                        <span className="text-sm text-muted-foreground">{log.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{log.action}</p>
                      <Badge variant="outline" className="mt-2">
                        {log.impact}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Rule Templates</CardTitle>
              <p className="text-sm text-muted-foreground">Pre-built automation rules you can customize</p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {ruleTemplates.map((template, i) => (
                  <div
                    key={i}
                    className="rounded-lg border border-border p-4 hover:border-primary/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <Badge variant="outline">{template.category}</Badge>
                      <span className="text-xs text-muted-foreground">{template.popularity}% use this</span>
                    </div>
                    <h3 className="font-medium mb-1">{template.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                    <Button variant="outline" size="sm" className="w-full gap-2">
                      <Plus className="h-4 w-4" />
                      Use Template
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-warning" />
                AI-Suggested Rules
              </CardTitle>
              <p className="text-sm text-muted-foreground">Based on your account performance patterns</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiSuggestions.map((suggestion, i) => (
                  <div key={i} className="rounded-lg border border-border p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="rounded-full bg-warning/10 p-2">
                          <Sparkles className="h-5 w-5 text-warning" />
                        </div>
                        <div>
                          <h3 className="font-medium">{suggestion.title}</h3>
                          <p className="text-sm text-muted-foreground">{suggestion.reason}</p>
                        </div>
                      </div>
                      <Badge className="bg-chart-1/10 text-chart-1">{suggestion.confidence}% confidence</Badge>
                    </div>
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                      <span className="text-sm text-success font-medium">{suggestion.impact}</span>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          Dismiss
                        </Button>
                        <Button size="sm" className="gap-2">
                          <Plus className="h-4 w-4" />
                          Create Rule
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
