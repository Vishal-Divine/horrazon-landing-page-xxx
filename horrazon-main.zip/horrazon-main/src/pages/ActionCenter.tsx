import { useState } from 'react';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import {
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  X,
  Bell,
  Clock,
  Target,
  Zap,
  Users,
  DollarSign,
  BarChart3,
  CheckCircle2,
  Timer,
  Layers,
  Play,
  Pause,
  Brain,
  History,
  ChevronRight,
  Sparkles,
  Filter,
  ArrowUpDown,
  LayoutGrid,
  List,
} from 'lucide-react';
import CustomizeActionDialog from '@/components/CustomizeActionDialog';
import { toast } from '@/hooks/use-toast';
import {
  actions as mockActions,
  actionHistory,
  aiInsights,
  bulkActionGroups,
} from '@/components/actioncenter/mockData';
import { Action } from '@/components/actioncenter/types';
import { ImpactSimulator } from '@/components/actioncenter/ImpactSimulator';
import { AIExplanationPanel } from '@/components/actioncenter/AIExplanationPanel';
import { ActionHistoryTimeline } from '@/components/actioncenter/ActionHistoryTimeline';
import { BulkActions } from '@/components/actioncenter/BulkActions';
import { ActionFeed } from '@/components/actioncenter/ActionFeed';
import { useLoading } from '@/hooks/useLoading';
import { ActionCenterSkeleton } from '@/components/skeletons';

export default function ActionCenter() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedInsight, setSelectedInsight] = useState('');
  const [selectedActions, setSelectedActions] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState('all');
  const [expandedAction, setExpandedAction] = useState<string | null>(null);
  const [showSimulator, setShowSimulator] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const isLoading = useLoading(650);

  const handleCustomize = (insight: string) => {
    setSelectedInsight(insight);
    setDialogOpen(true);
  };

  const toggleActionSelection = (id: string) => {
    setSelectedActions((prev) => (prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]));
  };

  const handleBulkApply = () => {
    toast({
      title: 'Actions Applied',
      description: `${selectedActions.length} actions have been executed successfully.`,
    });
    setSelectedActions([]);
  };

  const handleRollback = (id: string) => {
    toast({
      title: 'Rollback Initiated',
      description: 'The action is being reverted to its previous state.',
    });
  };

  const filteredActions =
    activeCategory === 'all' ? mockActions : mockActions.filter((a) => a.category === activeCategory);

  const categoryIcons = {
    budget: DollarSign,
    creative: Layers,
    audience: Users,
    bidding: BarChart3,
  };

  const successRate = Math.round(
    (actionHistory.filter((a) => a.status === 'success').length / actionHistory.length) * 100,
  );

  if (isLoading) {
    return <ActionCenterSkeleton />;
  }

  return (
    <div className="space-y-6 p-8 animate-fade-in">
      <SEOHead
        title="Action Center"
        description="AI-powered marketing action recommendations with automated campaign optimization and bulk operations."
        keywords="marketing automation, action center, campaign optimization, AI recommendations, marketing actions"
      />
      <CustomizeActionDialog open={dialogOpen} onOpenChange={setDialogOpen} insight={selectedInsight} />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Action Center
          </h1>
          <p className="text-muted-foreground text-lg">AI-powered recommendations with impact simulation</p>
        </div>
        <div className="flex items-center gap-3">
          {selectedActions.length > 0 && (
            <>
              <Badge variant="secondary" className="text-sm py-1 px-3">
                {selectedActions.length} selected
              </Badge>
              <Button onClick={handleBulkApply} className="gap-2">
                <Play className="h-4 w-4" />
                Apply Selected
              </Button>
              <Button variant="outline" onClick={() => setSelectedActions([])}>
                Clear
              </Button>
            </>
          )}
          <div className="flex items-center border rounded-lg">
            <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('list')}>
              <List className="h-4 w-4" />
            </Button>
            <Button variant={viewMode === 'grid' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('grid')}>
              <LayoutGrid className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-destructive/20 flex items-center justify-center">
              <AlertTriangle className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockActions.filter((a) => a.severity === 'high').length}</p>
              <p className="text-sm text-muted-foreground">Critical</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-chart-3/20 flex items-center justify-center">
              <Clock className="h-6 w-6 text-chart-3" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockActions.filter((a) => a.severity === 'medium').length}</p>
              <p className="text-sm text-muted-foreground">Pending</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-success/30 bg-success/5">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-success/20 flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockActions.filter((a) => a.severity === 'positive').length}</p>
              <p className="text-sm text-muted-foreground">Opportunities</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Target className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {Math.round(mockActions.reduce((s, a) => s + a.confidence, 0) / mockActions.length)}%
              </p>
              <p className="text-sm text-muted-foreground">Avg Confidence</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-chart-1/20 flex items-center justify-center">
              <CheckCircle2 className="h-6 w-6 text-chart-1" />
            </div>
            <div>
              <p className="text-2xl font-bold">{successRate}%</p>
              <p className="text-sm text-muted-foreground">Success Rate</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Insights Banner */}
      <Card className="border-chart-1/20 bg-gradient-to-r from-chart-1/5 to-chart-2/5">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-chart-1/20 flex items-center justify-center shrink-0">
              <Sparkles className="h-5 w-5 text-chart-1" />
            </div>
            <div className="flex-1">
              <p className="font-medium">{aiInsights[0].title}</p>
              <p className="text-sm text-muted-foreground">{aiInsights[0].description}</p>
            </div>
            <Badge variant="outline" className="gap-1">
              <Brain className="h-3 w-3" />
              {aiInsights[0].confidence}% confidence
            </Badge>
            <Button size="sm" variant="outline">
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Smart Action Feed - Tinder Style */}
        <div className="lg:col-span-1">
          <ActionFeed />
        </div>

        {/* Main Actions Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Category Tabs */}
          <Tabs value={activeCategory} onValueChange={setActiveCategory}>
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="budget" className="gap-2">
                  <DollarSign className="h-4 w-4" /> Budget
                </TabsTrigger>
                <TabsTrigger value="creative" className="gap-2">
                  <Layers className="h-4 w-4" /> Creative
                </TabsTrigger>
                <TabsTrigger value="audience" className="gap-2">
                  <Users className="h-4 w-4" /> Audience
                </TabsTrigger>
                <TabsTrigger value="bidding" className="gap-2">
                  <BarChart3 className="h-4 w-4" /> Bidding
                </TabsTrigger>
              </TabsList>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-2">
                  <Filter className="h-4 w-4" /> Filter
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <ArrowUpDown className="h-4 w-4" /> Sort
                </Button>
              </div>
            </div>

            <TabsContent value={activeCategory} className="mt-6">
              <Card className="border-accent/20 bg-gradient-to-br from-card to-accent/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-primary" />
                    Smart Action Feed
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {filteredActions.map((action) => {
                    const CategoryIcon = categoryIcons[action.category];
                    const isExpanded = expandedAction === action.id;
                    const isSimulating = showSimulator === action.id;

                    return (
                      <div key={action.id} className="space-y-4">
                        <div
                          className={`flex flex-col gap-4 rounded-lg border bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg ${
                            selectedActions.includes(action.id)
                              ? 'border-primary ring-2 ring-primary/20'
                              : 'border-border'
                          }`}
                        >
                          <div className="flex items-start gap-4">
                            <Checkbox
                              checked={selectedActions.includes(action.id)}
                              onCheckedChange={() => toggleActionSelection(action.id)}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1 space-y-2">
                                  <div className="flex items-center gap-2">
                                    {action.severity === 'high' && (
                                      <TrendingDown className="h-5 w-5 text-destructive" />
                                    )}
                                    {action.severity === 'medium' && <AlertTriangle className="h-5 w-5 text-chart-3" />}
                                    {action.severity === 'positive' && <TrendingUp className="h-5 w-5 text-success" />}
                                    <h3 className="text-lg font-semibold">{action.insight}</h3>
                                    <Badge variant="outline" className="gap-1">
                                      <CategoryIcon className="h-3 w-3" />
                                      {action.category}
                                    </Badge>
                                  </div>
                                  <p className="text-sm text-muted-foreground">{action.details}</p>

                                  <div className="flex gap-2 flex-wrap">
                                    {action.channels.map((channel) => (
                                      <Badge key={channel} variant="secondary" className="text-xs">
                                        {channel}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>

                                <div
                                  className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
                                    action.urgencyMinutes <= 360 ? 'bg-destructive/10' : 'bg-muted'
                                  }`}
                                >
                                  <Timer
                                    className={`h-4 w-4 ${
                                      action.urgencyMinutes <= 360
                                        ? 'text-destructive animate-pulse'
                                        : 'text-muted-foreground'
                                    }`}
                                  />
                                  <span
                                    className={`text-sm font-medium ${
                                      action.urgencyMinutes <= 360 ? 'text-destructive' : ''
                                    }`}
                                  >
                                    {action.urgency}
                                  </span>
                                </div>
                              </div>

                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                                <div className="space-y-1">
                                  <p className="text-xs text-muted-foreground">Confidence</p>
                                  <div className="flex items-center gap-2">
                                    <Progress value={action.confidence} className="h-2 flex-1" />
                                    <span className="text-sm font-semibold">{action.confidence}%</span>
                                  </div>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-xs text-muted-foreground">Success Prob.</p>
                                  <div className="flex items-center gap-2">
                                    <Progress value={action.successProbability} className="h-2 flex-1" />
                                    <span className="text-sm font-semibold text-success">
                                      {action.successProbability}%
                                    </span>
                                  </div>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground">Recommendation</p>
                                  <p className="font-medium">{action.recommendation}</p>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground">Est. Impact</p>
                                  <p className="font-medium text-primary">{action.impact}</p>
                                </div>
                              </div>

                              {action.crossChannelImpact && (
                                <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                                    <Layers className="h-3 w-3" />
                                    Cross-Channel Impact
                                  </p>
                                  <p className="text-sm">{action.crossChannelImpact}</p>
                                </div>
                              )}

                              <div className="flex items-center justify-between gap-2 mt-4">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="gap-1"
                                  onClick={() => setExpandedAction(isExpanded ? null : action.id)}
                                >
                                  <Brain className="h-4 w-4" />
                                  AI Explanation
                                  <ChevronRight
                                    className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                                  />
                                </Button>
                                <div className="flex items-center gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="gap-1"
                                    onClick={() => setShowSimulator(isSimulating ? null : action.id)}
                                  >
                                    <Zap className="h-4 w-4" />
                                    Simulate
                                  </Button>
                                  <Button size="sm" className="gap-2">
                                    <CheckCircle2 className="h-4 w-4" />
                                    Apply
                                  </Button>
                                  <Button variant="outline" size="sm" onClick={() => handleCustomize(action.insight)}>
                                    Customize
                                  </Button>
                                  <Button variant="ghost" size="sm">
                                    <Bell className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm">
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Expanded AI Panel */}
                        {isExpanded && <AIExplanationPanel action={action} />}

                        {/* Impact Simulator */}
                        {isSimulating && <ImpactSimulator action={action} onClose={() => setShowSimulator(null)} />}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Bulk Actions */}
          <BulkActions
            groups={bulkActionGroups}
            selectedActions={selectedActions}
            onApply={(groupId) => {
              const group = bulkActionGroups.find((g) => g.id === groupId);
              if (group) {
                setSelectedActions([]);
              }
            }}
          />

          {/* Action History */}
          <ActionHistoryTimeline history={actionHistory} onRollback={handleRollback} />
        </div>
      </div>
    </div>
  );
}
