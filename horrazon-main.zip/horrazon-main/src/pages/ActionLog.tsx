import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Facebook,
  Chrome,
  Search,
  Filter,
  Download,
  TrendingUp,
  TrendingDown,
  Calendar,
  BarChart3,
  PieChart,
  ArrowUpDown,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Clock,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPie,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { format } from 'date-fns';

const actionHistory = [
  {
    id: '1',
    platform: 'Meta',
    campaign: 'Summer Collection',
    action: 'Paused Ad',
    trigger: 'AI Recommendation',
    date: '2025-01-15',
    expected: '+18% ROAS',
    actual: '+22% ROAS',
    status: 'success',
    category: 'budget',
    roi: 2400,
  },
  {
    id: '2',
    platform: 'Google',
    campaign: 'Brand Terms',
    action: 'Lower Bid',
    trigger: 'AI Recommendation',
    date: '2025-01-14',
    expected: '-$420/day',
    actual: '-$385/day',
    status: 'success',
    category: 'bidding',
    roi: 385,
  },
  {
    id: '3',
    platform: 'Meta',
    campaign: 'Retargeting Q4',
    action: 'Increased Budget',
    trigger: 'Manual',
    date: '2025-01-13',
    expected: '+$2.4K revenue',
    actual: '+$2.8K revenue',
    status: 'success',
    category: 'budget',
    roi: 2800,
  },
  {
    id: '4',
    platform: 'TikTok',
    campaign: 'Holiday Push',
    action: 'Creative Swap',
    trigger: 'AI Recommendation',
    date: '2025-01-12',
    expected: '+15% CTR',
    actual: '+8% CTR',
    status: 'partial',
    category: 'creative',
    roi: 890,
  },
  {
    id: '5',
    platform: 'Meta',
    campaign: 'Lookalike Test',
    action: 'Audience Expansion',
    trigger: 'Manual',
    date: '2025-01-11',
    expected: '+25% reach',
    actual: 'Pending',
    status: 'pending',
    category: 'audience',
    roi: 0,
  },
  {
    id: '6',
    platform: 'Google',
    campaign: 'Shopping Feed',
    action: 'Bid Adjustment',
    trigger: 'AI Recommendation',
    date: '2025-01-10',
    expected: '+12% conversions',
    actual: '+14% conversions',
    status: 'success',
    category: 'bidding',
    roi: 1240,
  },
  {
    id: '7',
    platform: 'Meta',
    campaign: 'Video Ads Q1',
    action: 'Paused Ad',
    trigger: 'AI Recommendation',
    date: '2025-01-09',
    expected: '-$180/day waste',
    actual: '-$210/day',
    status: 'success',
    category: 'budget',
    roi: 210,
  },
  {
    id: '8',
    platform: 'TikTok',
    campaign: 'Influencer Collab',
    action: 'Scale Budget',
    trigger: 'Manual',
    date: '2025-01-08',
    expected: '+$1.2K revenue',
    actual: '+$980',
    status: 'partial',
    category: 'budget',
    roi: 980,
  },
];

const performanceTrend = [
  { date: 'Jan 8', actions: 3, successRate: 85, roi: 1200 },
  { date: 'Jan 9', actions: 2, successRate: 90, roi: 890 },
  { date: 'Jan 10', actions: 4, successRate: 88, roi: 2100 },
  { date: 'Jan 11', actions: 2, successRate: 75, roi: 650 },
  { date: 'Jan 12', actions: 3, successRate: 92, roi: 1800 },
  { date: 'Jan 13', actions: 5, successRate: 95, roi: 3200 },
  { date: 'Jan 14', actions: 2, successRate: 88, roi: 1400 },
  { date: 'Jan 15', actions: 3, successRate: 91, roi: 2400 },
];

const categoryBreakdown = [
  { name: 'Budget', value: 45, color: 'hsl(var(--chart-1))' },
  { name: 'Bidding', value: 25, color: 'hsl(var(--chart-2))' },
  { name: 'Creative', value: 18, color: 'hsl(var(--chart-3))' },
  { name: 'Audience', value: 12, color: 'hsl(var(--chart-4))' },
];

const platformStats = [
  { platform: 'Meta', actions: 42, successRate: 89, totalROI: 12400 },
  { platform: 'Google', actions: 28, successRate: 92, totalROI: 8600 },
  { platform: 'TikTok', actions: 15, successRate: 78, totalROI: 3200 },
];

export default function ActionLog() {
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [triggerFilter, setTriggerFilter] = useState('all');

  const filteredHistory = actionHistory.filter((item) => {
    const matchesSearch =
      item.campaign.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.action.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPlatform = platformFilter === 'all' || item.platform === platformFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesTrigger = triggerFilter === 'all' || item.trigger === triggerFilter;
    return matchesSearch && matchesPlatform && matchesStatus && matchesTrigger;
  });

  const totalROI = actionHistory.reduce((sum, a) => sum + a.roi, 0);
  const successRate = Math.round(
    (actionHistory.filter((a) => a.status === 'success').length / actionHistory.length) * 100,
  );
  const aiActions = actionHistory.filter((a) => a.trigger === 'AI Recommendation').length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-4 w-4 text-success" />;
      case 'partial':
        return <AlertCircle className="h-4 w-4 text-warning" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Action History</h1>
          <p className="text-muted-foreground">Deep analytics on all automated and manual campaign actions</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Actions</p>
                <p className="text-3xl font-bold">{actionHistory.length}</p>
              </div>
              <BarChart3 className="h-10 w-10 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        <Card className="border-success/30 bg-success/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-3xl font-bold">{successRate}%</p>
              </div>
              <TrendingUp className="h-10 w-10 text-success" />
            </div>
            <p className="mt-2 text-xs text-success">+5% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total ROI</p>
                <p className="text-3xl font-bold">${(totalROI / 1000).toFixed(1)}K</p>
              </div>
              <TrendingUp className="h-10 w-10 text-primary" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">From action outcomes</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">AI Actions</p>
                <p className="text-3xl font-bold">{aiActions}</p>
              </div>
              <PieChart className="h-10 w-10 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {Math.round((aiActions / actionHistory.length) * 100)}% of total
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="log" className="space-y-6">
        <TabsList>
          <TabsTrigger value="log">Action Log</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
        </TabsList>

        <TabsContent value="log" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-4">
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search campaigns or actions..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <Select value={platformFilter} onValueChange={setPlatformFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Platforms</SelectItem>
                    <SelectItem value="Meta">Meta</SelectItem>
                    <SelectItem value="Google">Google</SelectItem>
                    <SelectItem value="TikTok">TikTok</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="partial">Partial</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={triggerFilter} onValueChange={setTriggerFilter}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Trigger" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Triggers</SelectItem>
                    <SelectItem value="AI Recommendation">AI</SelectItem>
                    <SelectItem value="Manual">Manual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Table */}
          <Card>
            <CardContent className="pt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Platform</TableHead>
                    <TableHead>Campaign</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Trigger</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Expected</TableHead>
                    <TableHead>Actual</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">ROI</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {item.platform === 'Meta' ? (
                            <Facebook className="h-4 w-4 text-[#1877F2]" />
                          ) : item.platform === 'Google' ? (
                            <Chrome className="h-4 w-4 text-[#4285F4]" />
                          ) : (
                            <span className="h-4 w-4 rounded bg-gradient-to-r from-pink-500 to-purple-500" />
                          )}
                          {item.platform}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{item.campaign}</TableCell>
                      <TableCell>{item.action}</TableCell>
                      <TableCell>
                        <Badge variant={item.trigger === 'AI Recommendation' ? 'default' : 'secondary'}>
                          {item.trigger === 'AI Recommendation' ? 'AI' : 'Manual'}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.date}</TableCell>
                      <TableCell>{item.expected}</TableCell>
                      <TableCell
                        className={
                          item.status === 'success'
                            ? 'text-success font-medium'
                            : item.status === 'partial'
                              ? 'text-warning'
                              : ''
                        }
                      >
                        {item.actual}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(item.status)}
                          <span className="capitalize">{item.status}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {item.roi > 0 ? `$${item.roi.toLocaleString()}` : '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="successRate"
                      stroke="hsl(var(--success))"
                      strokeWidth={2}
                      name="Success Rate %"
                    />
                    <Line
                      type="monotone"
                      dataKey="actions"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      name="Actions"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPie>
                    <Pie
                      data={categoryBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPie>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Platform Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {platformStats.map((stat) => (
                  <div key={stat.platform} className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-3">
                      {stat.platform === 'Meta' ? (
                        <Facebook className="h-5 w-5 text-[#1877F2]" />
                      ) : stat.platform === 'Google' ? (
                        <Chrome className="h-5 w-5 text-[#4285F4]" />
                      ) : (
                        <span className="h-5 w-5 rounded bg-gradient-to-r from-pink-500 to-purple-500" />
                      )}
                      <span className="font-medium">{stat.platform}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-2xl font-bold">{stat.actions}</p>
                        <p className="text-xs text-muted-foreground">Actions</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-success">{stat.successRate}%</p>
                        <p className="text-xs text-muted-foreground">Success</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">${(stat.totalROI / 1000).toFixed(1)}K</p>
                        <p className="text-xs text-muted-foreground">ROI</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
