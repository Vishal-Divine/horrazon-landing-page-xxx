import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { useState } from 'react';
import {
  FlaskConical,
  Plus,
  Play,
  Pause,
  CheckCircle2,
  XCircle,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Target,
  Users,
  Clock,
  Zap,
  Trophy,
  AlertTriangle,
  ArrowRight,
  Settings,
  RefreshCw,
  Eye,
  Lightbulb,
  Calculator,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  Cell,
} from 'recharts';
import { toast } from 'sonner';

interface Experiment {
  id: string;
  name: string;
  status: 'running' | 'completed' | 'paused' | 'draft';
  platform: string;
  metric: string;
  progress: number;
  startDate: string;
  variants: number;
  confidence?: number;
  winner?: string;
  lift?: number;
}

const experiments: Experiment[] = [
  {
    id: '1',
    name: 'Homepage Hero Banner Test',
    status: 'running',
    platform: 'Google Ads',
    metric: 'CTR',
    progress: 68,
    startDate: 'Nov 15',
    variants: 3,
    confidence: 87,
  },
  {
    id: '2',
    name: 'CTA Button Color',
    status: 'completed',
    platform: 'Meta Ads',
    metric: 'Conversion Rate',
    progress: 100,
    startDate: 'Oct 28',
    variants: 2,
    winner: 'Variant B',
    lift: 12.4,
    confidence: 96,
  },
  {
    id: '3',
    name: 'Product Description Length',
    status: 'running',
    platform: 'Amazon Ads',
    metric: 'ROAS',
    progress: 45,
    startDate: 'Nov 20',
    variants: 2,
    confidence: 72,
  },
  {
    id: '4',
    name: 'Audience Segmentation Test',
    status: 'paused',
    platform: 'TikTok Ads',
    metric: 'CPA',
    progress: 32,
    startDate: 'Nov 10',
    variants: 4,
  },
  {
    id: '5',
    name: 'Video vs Static Creative',
    status: 'draft',
    platform: 'Meta Ads',
    metric: 'Engagement',
    progress: 0,
    startDate: '-',
    variants: 2,
  },
];

const variantData = [
  {
    name: 'Control',
    impressions: 125000,
    clicks: 4500,
    ctr: 3.6,
    conversions: 450,
    convRate: 10.0,
    roas: 4.2,
    revenue: 52500,
    color: '#6366f1',
  },
  {
    name: 'Variant A',
    impressions: 123500,
    clicks: 4850,
    ctr: 3.93,
    conversions: 510,
    convRate: 10.5,
    roas: 4.6,
    revenue: 58650,
    color: '#22c55e',
  },
  {
    name: 'Variant B',
    impressions: 124200,
    clicks: 5100,
    ctr: 4.11,
    conversions: 540,
    convRate: 10.6,
    roas: 4.8,
    revenue: 61560,
    color: '#f59e0b',
  },
];

const trendData = [
  { day: 'Day 1', control: 3.2, variantA: 3.1, variantB: 3.4 },
  { day: 'Day 3', control: 3.4, variantA: 3.5, variantB: 3.7 },
  { day: 'Day 5', control: 3.5, variantA: 3.7, variantB: 3.9 },
  { day: 'Day 7', control: 3.6, variantA: 3.8, variantB: 4.0 },
  { day: 'Day 10', control: 3.5, variantA: 3.9, variantB: 4.1 },
  { day: 'Day 14', control: 3.6, variantA: 3.93, variantB: 4.11 },
];

const testTemplates = [
  { name: 'Creative Format', desc: 'Video vs Image vs Carousel', icon: '🎨', metric: 'CTR' },
  { name: 'CTA Optimization', desc: 'Test different call-to-action text', icon: '🎯', metric: 'CVR' },
  { name: 'Audience Segmentation', desc: 'Compare audience performance', icon: '👥', metric: 'ROAS' },
  { name: 'Pricing Display', desc: 'Price presentation variations', icon: '💰', metric: 'Revenue' },
  { name: 'Ad Copy Length', desc: 'Short vs medium vs long copy', icon: '📝', metric: 'CTR' },
  { name: 'Landing Page', desc: 'Different landing experiences', icon: '🏠', metric: 'CVR' },
];

export default function Experiments() {
  const [selectedExperiment, setSelectedExperiment] = useState(experiments[0]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [trafficSplit, setTrafficSplit] = useState([50]);
  const [newExperiment, setNewExperiment] = useState({
    name: '',
    platform: 'google',
    metric: 'ctr',
    minSample: '10000',
    confidence: '95',
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'running':
        return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">Running</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">Completed</Badge>;
      case 'paused':
        return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20">Paused</Badge>;
      default:
        return <Badge variant="outline">Draft</Badge>;
    }
  };

  const calculateSignificance = (confidence: number) => {
    if (confidence >= 95) return { status: 'Significant', color: 'text-emerald-500' };
    if (confidence >= 85) return { status: 'Trending', color: 'text-amber-500' };
    return { status: 'Inconclusive', color: 'text-muted-foreground' };
  };

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">A/B Experiments</h1>
          <p className="text-muted-foreground">Test, measure, and optimize your marketing performance</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Experiment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FlaskConical className="h-5 w-5" />
                Create New Experiment
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Experiment Name</Label>
                <Input
                  placeholder="e.g., Homepage Banner Test"
                  value={newExperiment.name}
                  onChange={(e) => setNewExperiment((prev) => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Platform</Label>
                  <Select
                    value={newExperiment.platform}
                    onValueChange={(v) => setNewExperiment((prev) => ({ ...prev, platform: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="google">Google Ads</SelectItem>
                      <SelectItem value="meta">Meta Ads</SelectItem>
                      <SelectItem value="amazon">Amazon Ads</SelectItem>
                      <SelectItem value="tiktok">TikTok Ads</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Primary Metric</Label>
                  <Select
                    value={newExperiment.metric}
                    onValueChange={(v) => setNewExperiment((prev) => ({ ...prev, metric: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ctr">Click-Through Rate</SelectItem>
                      <SelectItem value="cvr">Conversion Rate</SelectItem>
                      <SelectItem value="roas">ROAS</SelectItem>
                      <SelectItem value="cpa">CPA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>
                  Traffic Split: {trafficSplit[0]}% / {100 - trafficSplit[0]}%
                </Label>
                <Slider value={trafficSplit} onValueChange={setTrafficSplit} max={80} min={20} step={5} />
                <p className="text-xs text-muted-foreground">Control vs Variant traffic allocation</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Min Sample Size</Label>
                  <Input
                    type="number"
                    value={newExperiment.minSample}
                    onChange={(e) => setNewExperiment((prev) => ({ ...prev, minSample: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Confidence Level</Label>
                  <Select
                    value={newExperiment.confidence}
                    onValueChange={(v) => setNewExperiment((prev) => ({ ...prev, confidence: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="90">90%</SelectItem>
                      <SelectItem value="95">95%</SelectItem>
                      <SelectItem value="99">99%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 text-sm">
                  <Lightbulb className="h-4 w-4 text-blue-500" />
                  <span className="font-medium">AI Recommendation</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on your traffic volume, we recommend running this test for ~14 days to reach statistical
                  significance.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  toast.success('Experiment created successfully');
                  setIsCreateOpen(false);
                }}
              >
                Create Experiment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Tests</p>
                <p className="text-3xl font-bold">4</p>
              </div>
              <div className="p-3 rounded-full bg-emerald-500/10">
                <Play className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold">12</p>
              </div>
              <div className="p-3 rounded-full bg-blue-500/10">
                <CheckCircle2 className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Lift</p>
                <p className="text-3xl font-bold text-emerald-500">+8.3%</p>
              </div>
              <div className="p-3 rounded-full bg-emerald-500/10">
                <TrendingUp className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue Impact</p>
                <p className="text-3xl font-bold">$47.2K</p>
              </div>
              <div className="p-3 rounded-full bg-primary/10">
                <Trophy className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Experiment List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FlaskConical className="h-5 w-5" />
              Experiments
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {experiments.map((exp) => (
              <div
                key={exp.id}
                onClick={() => setSelectedExperiment(exp)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedExperiment.id === exp.id ? 'border-primary bg-primary/5' : 'hover:bg-accent/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm">{exp.name}</span>
                  {getStatusBadge(exp.status)}
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>{exp.platform}</span>
                  <span>{exp.metric}</span>
                  <span>{exp.variants} variants</span>
                </div>
                {exp.status !== 'draft' && (
                  <div className="mt-2">
                    <Progress value={exp.progress} className="h-1" />
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Experiment Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>{selectedExperiment.name}</CardTitle>
                  <CardDescription className="flex items-center gap-4 mt-1">
                    <span>{selectedExperiment.platform}</span>
                    <span>•</span>
                    <span>Primary: {selectedExperiment.metric}</span>
                    <span>•</span>
                    <span>Started: {selectedExperiment.startDate}</span>
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  {selectedExperiment.status === 'running' ? (
                    <Button variant="outline" size="sm">
                      <Pause className="h-4 w-4 mr-1" />
                      Pause
                    </Button>
                  ) : selectedExperiment.status === 'paused' ? (
                    <Button size="sm">
                      <Play className="h-4 w-4 mr-1" />
                      Resume
                    </Button>
                  ) : null}
                  <Button variant="outline" size="icon">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Variant Comparison Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-2 font-medium">Variant</th>
                      <th className="text-right py-3 px-2 font-medium">Impressions</th>
                      <th className="text-right py-3 px-2 font-medium">Clicks</th>
                      <th className="text-right py-3 px-2 font-medium">CTR</th>
                      <th className="text-right py-3 px-2 font-medium">Conv.</th>
                      <th className="text-right py-3 px-2 font-medium">CVR</th>
                      <th className="text-right py-3 px-2 font-medium">ROAS</th>
                      <th className="text-right py-3 px-2 font-medium">Lift</th>
                    </tr>
                  </thead>
                  <tbody>
                    {variantData.map((variant, idx) => (
                      <tr key={variant.name} className="border-b last:border-0 hover:bg-accent/30">
                        <td className="py-3 px-2">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: variant.color }} />
                            <span className="font-medium">{variant.name}</span>
                            {idx === 2 && <Trophy className="h-4 w-4 text-amber-500" />}
                          </div>
                        </td>
                        <td className="text-right py-3 px-2">{variant.impressions.toLocaleString()}</td>
                        <td className="text-right py-3 px-2">{variant.clicks.toLocaleString()}</td>
                        <td className="text-right py-3 px-2">{variant.ctr}%</td>
                        <td className="text-right py-3 px-2">{variant.conversions}</td>
                        <td className="text-right py-3 px-2">{variant.convRate}%</td>
                        <td className="text-right py-3 px-2">{variant.roas}x</td>
                        <td className="text-right py-3 px-2">
                          {idx === 0 ? (
                            <span className="text-muted-foreground">Baseline</span>
                          ) : (
                            <span className="text-emerald-500 font-medium">
                              +{(((variant.ctr - variantData[0].ctr) / variantData[0].ctr) * 100).toFixed(1)}%
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Statistical Significance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Statistical Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 rounded-lg bg-accent/30">
                  <p className="text-sm text-muted-foreground mb-1">Confidence Level</p>
                  <p className="text-2xl font-bold">{selectedExperiment.confidence || 87}%</p>
                  <p className={`text-sm ${calculateSignificance(selectedExperiment.confidence || 87).color}`}>
                    {calculateSignificance(selectedExperiment.confidence || 87).status}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30">
                  <p className="text-sm text-muted-foreground mb-1">Sample Size</p>
                  <p className="text-2xl font-bold">372.7K</p>
                  <Progress value={68} className="h-1 mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">68% of target</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30">
                  <p className="text-sm text-muted-foreground mb-1">Projected Winner</p>
                  <p className="text-2xl font-bold text-emerald-500">Variant B</p>
                  <p className="text-sm text-muted-foreground">+14.2% lift vs control</p>
                </div>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="day" className="text-xs" />
                    <YAxis domain={[3, 4.5]} className="text-xs" tickFormatter={(v) => `${v}%`} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                      formatter={(value: number) => [`${value}%`, '']}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="control"
                      stroke="#6366f1"
                      strokeWidth={2}
                      dot={false}
                      name="Control"
                    />
                    <Line
                      type="monotone"
                      dataKey="variantA"
                      stroke="#22c55e"
                      strokeWidth={2}
                      dot={false}
                      name="Variant A"
                    />
                    <Line
                      type="monotone"
                      dataKey="variantB"
                      stroke="#f59e0b"
                      strokeWidth={2}
                      dot={false}
                      name="Variant B"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* AI Recommendations */}
          <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                AI Insights & Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Variant B Shows Strong Performance</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Variant B is outperforming control by 14.2% in CTR with 87% confidence. Continue running for 4
                      more days to reach 95% statistical significance.
                    </p>
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" onClick={() => toast.success('Winner applied to campaign')}>
                        Apply Winner
                      </Button>
                      <Button size="sm" variant="outline">
                        Continue Test
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Early Signal Detected</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Variant A shows higher engagement on mobile devices (+18% vs control). Consider creating a
                      device-specific variant for the next test.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Test Templates */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Quick Test Templates
          </CardTitle>
          <CardDescription>Start with proven testing frameworks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {testTemplates.map((template) => (
              <div
                key={template.name}
                className="p-4 rounded-lg border hover:border-primary/50 hover:bg-accent/30 cursor-pointer transition-all text-center group"
                onClick={() => {
                  setNewExperiment((prev) => ({ ...prev, name: template.name }));
                  setIsCreateOpen(true);
                }}
              >
                <span className="text-3xl">{template.icon}</span>
                <p className="font-medium mt-2 text-sm">{template.name}</p>
                <p className="text-xs text-muted-foreground">{template.desc}</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  {template.metric}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
