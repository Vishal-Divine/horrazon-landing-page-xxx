import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  TrendingUp,
  Target,
  Zap,
  BarChart3,
  Users,
  ShoppingBag,
  Crown,
  Sparkles,
  ArrowRight,
  LineChart,
  PieChart,
  Activity,
  Megaphone,
  UserCheck,
} from 'lucide-react';
import { useLoading } from '@/hooks/useLoading';
import { DashboardSkeleton } from '@/components/skeletons';

const Index = () => {
  const navigate = useNavigate();
  const isLoading = useLoading(600);

  const features = [
    {
      icon: Activity,
      title: 'Daily Pulse',
      description: 'Real-time performance monitoring with AI-powered insights',
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
      route: '/daily-pulse',
    },
    {
      icon: PieChart,
      title: 'Attribution',
      description: 'Multi-touch attribution models with incrementality analysis',
      color: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
      route: '/attribution',
    },
    {
      icon: UserCheck,
      title: 'Influencer Marketing',
      description: 'Track creator partnerships with fraud detection & EMV',
      color: 'text-chart-3',
      bgColor: 'bg-chart-3/10',
      route: '/influencer-marketing',
    },
    {
      icon: Target,
      title: 'Action Center',
      description: 'Automated optimization rules and campaign actions',
      color: 'text-chart-4',
      bgColor: 'bg-chart-4/10',
      route: '/action-center',
    },
    {
      icon: LineChart,
      title: 'Forecasting',
      description: 'Predictive analytics with confidence intervals',
      color: 'text-chart-5',
      bgColor: 'bg-chart-5/10',
      route: '/forecasting',
    },
    {
      icon: ShoppingBag,
      title: 'CLTV Analysis',
      description: 'Customer lifetime value & cohort tracking',
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
      route: '/cltv',
    },
  ];

  const stats = [
    { icon: TrendingUp, label: 'Revenue Growth', value: '+142%', color: 'text-success' },
    { icon: Zap, label: 'Time Saved', value: '18hrs/wk', color: 'text-chart-3' },
    { icon: Target, label: 'ROAS Improvement', value: '+64%', color: 'text-chart-1' },
    { icon: Users, label: 'Active Users', value: '2.4K+', color: 'text-chart-2' },
  ];

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-background p-8">
      <div className="mx-auto max-w-7xl space-y-12 animate-fade-in">
        {/* Hero Section */}
        <div className="space-y-6 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <Crown className="h-4 w-4" />
            Marketing Intelligence Platform
          </div>
          <h1 className="text-5xl font-bold tracking-tight md:text-6xl">
            <span className="bg-gradient-to-r from-foreground via-primary to-foreground/70 bg-clip-text text-transparent">
              Pogee AI
            </span>
          </h1>
          <p className="mx-auto max-w-2xl text-xl text-muted-foreground">
            Advanced marketing analytics powered by AI. Track performance, optimize campaigns, and predict outcomes with
            precision.
          </p>
          <div className="flex items-center justify-center gap-4 pt-4">
            <Button size="lg" onClick={() => navigate('/daily-pulse')} className="gap-2 group">
              <Sparkles className="h-5 w-5 group-hover:rotate-12 transition-transform" />
              Get Started
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/action-center')}>
              View Features
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-4">
          {stats.map((stat, index) => (
            <Card key={index} className="hover-scale border-border/50 transition-all hover:shadow-lg">
              <CardContent className="flex items-center gap-4 p-6">
                <div className={`rounded-lg bg-muted/50 p-3 ${stat.color}`}>
                  <stat.icon className="h-6 w-6" strokeWidth={2.5} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Features Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Powerful Features</h2>
              <p className="text-muted-foreground">Everything you need to scale your marketing</p>
            </div>
            <Button variant="ghost" onClick={() => navigate('/daily-pulse')} className="gap-2">
              View All
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="group cursor-pointer border-border/50 transition-all hover:border-primary/30 hover:shadow-xl hover:-translate-y-1"
                onClick={() => navigate(feature.route)}
              >
                <CardHeader>
                  <div
                    className={`inline-flex h-12 w-12 items-center justify-center rounded-lg ${feature.bgColor} mb-4 ring-1 ring-border/30 transition-transform group-hover:scale-110 group-hover:rotate-3`}
                  >
                    <feature.icon className={`h-6 w-6 ${feature.color}`} strokeWidth={2.5} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                  <div className="mt-4 flex items-center gap-2 text-sm font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
                    Explore
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-primary/10 to-accent/10">
          <CardContent className="flex flex-col items-center gap-6 p-12 text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/20 px-4 py-2">
              <Megaphone className="h-5 w-5 text-primary" />
              <span className="font-medium text-primary">Start Optimizing Today</span>
            </div>
            <h3 className="text-3xl font-bold">Ready to 10x Your Marketing ROI?</h3>
            <p className="max-w-xl text-muted-foreground">
              Join thousands of marketers using Pogee AI to make data-driven decisions and achieve exceptional results.
            </p>
            <Button size="lg" onClick={() => navigate('/create-account')} className="gap-2 group">
              <Users className="h-5 w-5" />
              Get Started Free
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;
