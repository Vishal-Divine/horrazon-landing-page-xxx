import { useState } from 'react';
import { SEOHead } from '@/components/seo';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  FileText,
  Download,
  Plus,
  Calendar,
  Mail,
  Clock,
  Palette,
  GripVertical,
  BarChart3,
  PieChart,
  LineChart,
  Table,
  Users,
  DollarSign,
  TrendingUp,
  Eye,
  Send,
  Settings,
  Brain,
  Layout,
  CalendarClock,
  Sparkles,
  FileDown,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import {
  AIExecutiveSummary,
  AdvancedReportBuilder,
  ReportScheduler,
  WhiteLabelStudio,
  DataExportCenter,
} from '@/components/reports';
import { useLoading } from '@/hooks/useLoading';
import { ReportsSkeleton } from '@/components/skeletons';

const reportTemplates = [
  {
    id: 'wbr',
    name: 'Weekly Business Report',
    description: 'High-level KPIs and week-over-week performance',
    frequency: 'Weekly',
    recipients: 5,
  },
  {
    id: 'mbr',
    name: 'Monthly Business Report',
    description: 'Comprehensive monthly analysis with trends',
    frequency: 'Monthly',
    recipients: 12,
  },
  {
    id: 'qbr',
    name: 'Quarterly Business Report',
    description: 'Strategic review with quarterly goals progress',
    frequency: 'Quarterly',
    recipients: 8,
  },
  {
    id: 'investor',
    name: 'Investor Update',
    description: 'Key metrics and growth story for stakeholders',
    frequency: 'Monthly',
    recipients: 3,
  },
  {
    id: 'board',
    name: 'Board Deck',
    description: 'Executive summary for board presentations',
    frequency: 'Quarterly',
    recipients: 6,
  },
];

export default function Reports() {
  const isLoading = useLoading(500);

  const handleDownload = () => {
    toast({ title: 'Download Started', description: 'Your report is being generated and will download shortly.' });
  };

  if (isLoading) {
    return <ReportsSkeleton />;
  }

  return (
    <div className="space-y-6 p-8 animate-fade-in">
      <SEOHead
        title="Reports & Intelligence"
        description="AI-powered marketing reports, custom report builder, and automated delivery for data-driven insights."
        keywords="marketing reports, AI analytics, report builder, business intelligence, marketing insights"
      />
      <div>
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          Reports & Intelligence
        </h1>
        <p className="text-muted-foreground text-lg">
          AI-powered insights, custom report builder, and automated delivery
        </p>
      </div>

      <Tabs defaultValue="ai-summary" className="space-y-6">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="ai-summary" className="gap-1">
            <Brain className="h-3 w-3" />
            AI Summary
          </TabsTrigger>
          <TabsTrigger value="builder" className="gap-1">
            <Layout className="h-3 w-3" />
            Report Builder
          </TabsTrigger>
          <TabsTrigger value="export" className="gap-1">
            <FileDown className="h-3 w-3" />
            Export Center
          </TabsTrigger>
          <TabsTrigger value="scheduled" className="gap-1">
            <CalendarClock className="h-3 w-3" />
            Scheduled
          </TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="whitelabel" className="gap-1">
            <Palette className="h-3 w-3" />
            White Label
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ai-summary">
          <AIExecutiveSummary />
        </TabsContent>

        <TabsContent value="builder">
          <AdvancedReportBuilder />
        </TabsContent>

        <TabsContent value="export">
          <DataExportCenter />
        </TabsContent>

        <TabsContent value="scheduled">
          <ReportScheduler />
        </TabsContent>

        <TabsContent value="templates">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reportTemplates.map((template) => (
              <Card key={template.id} className="hover:border-primary/50 transition-all cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      <CardDescription className="mt-1">{template.description}</CardDescription>
                    </div>
                    <FileText className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {template.frequency}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {template.recipients}
                      </span>
                    </div>
                    <Button size="sm" variant="outline">
                      Use Template
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Card className="border-dashed hover:border-primary/50 transition-all cursor-pointer flex items-center justify-center min-h-[180px]">
              <div className="text-center">
                <Plus className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="font-medium">Create Custom Template</p>
                <p className="text-sm text-muted-foreground">Build from scratch</p>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="whitelabel">
          <WhiteLabelStudio />
        </TabsContent>
      </Tabs>
    </div>
  );
}
