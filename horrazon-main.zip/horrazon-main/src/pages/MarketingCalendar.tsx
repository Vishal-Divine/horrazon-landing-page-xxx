import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import {
  Calendar as CalendarIcon,
  Plus,
  ChevronLeft,
  ChevronRight,
  Target,
  DollarSign,
  Users,
  TrendingUp,
  Clock,
  Zap,
  AlertTriangle,
  CheckCircle2,
  Mail,
  Smartphone,
  Globe,
  Share2,
  Video,
  Image,
  FileText,
  Gift,
  ShoppingBag,
  Sparkles,
  Filter,
  Download,
  Settings,
} from 'lucide-react';

// Calendar Events Data
const calendarEvents = [
  {
    id: 1,
    title: 'Black Friday Campaign Launch',
    date: '2024-11-29',
    type: 'campaign',
    channel: ['Meta', 'Google', 'Email'],
    budget: 45000,
    status: 'scheduled',
    color: 'hsl(var(--chart-1))',
    description: 'Annual Black Friday sale with 40% off sitewide',
    expectedROAS: 6.2,
    targetRevenue: 280000,
  },
  {
    id: 2,
    title: 'Winter Collection Email Blast',
    date: '2024-11-25',
    type: 'email',
    channel: ['Email'],
    budget: 500,
    status: 'scheduled',
    color: 'hsl(var(--chart-2))',
    description: 'New winter collection announcement',
    expectedROAS: 12.4,
    targetRevenue: 6200,
  },
  {
    id: 3,
    title: 'Cyber Monday Flash Sale',
    date: '2024-12-02',
    type: 'campaign',
    channel: ['Meta', 'TikTok', 'SMS'],
    budget: 32000,
    status: 'scheduled',
    color: 'hsl(var(--chart-3))',
    description: '48-hour flash sale with doorbusters',
    expectedROAS: 5.8,
    targetRevenue: 185000,
  },
  {
    id: 4,
    title: 'Holiday Gift Guide Launch',
    date: '2024-12-05',
    type: 'content',
    channel: ['Blog', 'Social', 'Email'],
    budget: 2500,
    status: 'draft',
    color: 'hsl(var(--chart-4))',
    description: 'Curated gift guide content campaign',
    expectedROAS: 8.2,
    targetRevenue: 20500,
  },
  {
    id: 5,
    title: 'Influencer Holiday Collab',
    date: '2024-12-10',
    type: 'influencer',
    channel: ['Instagram', 'TikTok', 'YouTube'],
    budget: 18000,
    status: 'in-progress',
    color: 'hsl(var(--chart-5))',
    description: 'Holiday collection with top 5 influencers',
    expectedROAS: 7.4,
    targetRevenue: 133200,
  },
  {
    id: 6,
    title: 'Year-End Clearance',
    date: '2024-12-26',
    type: 'campaign',
    channel: ['All Channels'],
    budget: 28000,
    status: 'scheduled',
    color: 'hsl(var(--chart-1))',
    description: 'End of year clearance sale up to 60% off',
    expectedROAS: 4.8,
    targetRevenue: 134400,
  },
];

const upcomingDeadlines = [
  { task: 'Submit Black Friday creatives', date: 'Nov 22', priority: 'high', daysLeft: 3 },
  { task: 'Approve influencer contracts', date: 'Nov 24', priority: 'high', daysLeft: 5 },
  { task: 'Set up Cyber Monday tracking', date: 'Nov 28', priority: 'medium', daysLeft: 9 },
  { task: 'Review gift guide content', date: 'Dec 1', priority: 'medium', daysLeft: 12 },
  { task: 'Finalize year-end budget', date: 'Dec 15', priority: 'low', daysLeft: 26 },
];

const seasonalEvents = [
  { name: 'Black Friday', date: 'Nov 29', impact: 'Very High', expectedLift: '+180%' },
  { name: 'Cyber Monday', date: 'Dec 2', impact: 'Very High', expectedLift: '+150%' },
  { name: 'Christmas', date: 'Dec 25', impact: 'High', expectedLift: '+120%' },
  { name: 'New Year', date: 'Jan 1', impact: 'Medium', expectedLift: '+40%' },
  { name: "Valentine's Day", date: 'Feb 14', impact: 'High', expectedLift: '+80%' },
];

const budgetAllocation = {
  total: 180000,
  allocated: 125500,
  remaining: 54500,
  byChannel: [
    { channel: 'Meta Ads', amount: 52000, percentage: 41 },
    { channel: 'Google Ads', amount: 38000, percentage: 30 },
    { channel: 'Email/SMS', amount: 8500, percentage: 7 },
    { channel: 'Influencer', amount: 18000, percentage: 14 },
    { channel: 'TikTok', amount: 9000, percentage: 7 },
  ],
};

const campaignTypes = {
  campaign: { icon: Target, label: 'Campaign' },
  email: { icon: Mail, label: 'Email' },
  content: { icon: FileText, label: 'Content' },
  influencer: { icon: Users, label: 'Influencer' },
  social: { icon: Share2, label: 'Social' },
  video: { icon: Video, label: 'Video' },
};

const months = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export default function MarketingCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date(2024, 10, 1)); // November 2024
  const [selectedEvent, setSelectedEvent] = useState<(typeof calendarEvents)[0] | null>(null);
  const [showEventDialog, setShowEventDialog] = useState(false);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();
    return { daysInMonth, firstDay };
  };

  const { daysInMonth, firstDay } = getDaysInMonth(currentDate);

  const getEventsForDay = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return calendarEvents.filter((e) => e.date === dateStr);
  };

  const navigateMonth = (direction: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + direction, 1));
  };

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Marketing Calendar</h1>
          <p className="text-muted-foreground">Plan, schedule & optimize your marketing campaigns</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Campaign
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Campaign</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Campaign Name</Label>
                  <Input placeholder="Enter campaign name" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input type="date" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Campaign Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="campaign">Full Campaign</SelectItem>
                      <SelectItem value="email">Email Blast</SelectItem>
                      <SelectItem value="content">Content Push</SelectItem>
                      <SelectItem value="influencer">Influencer Campaign</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Budget ($)</Label>
                  <Input type="number" placeholder="Enter budget" />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea placeholder="Campaign description..." />
                </div>
                <div className="flex gap-2 pt-4">
                  <Button className="flex-1">Create Campaign</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Budget Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Q4 Budget</p>
                <p className="text-2xl font-bold">${(budgetAllocation.total / 1000).toFixed(0)}K</p>
              </div>
              <DollarSign className="h-8 w-8 text-chart-1" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Allocated</p>
                <p className="text-2xl font-bold">${(budgetAllocation.allocated / 1000).toFixed(0)}K</p>
              </div>
              <Target className="h-8 w-8 text-chart-2" />
            </div>
            <Progress value={(budgetAllocation.allocated / budgetAllocation.total) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Remaining</p>
                <p className="text-2xl font-bold text-success">${(budgetAllocation.remaining / 1000).toFixed(0)}K</p>
              </div>
              <Zap className="h-8 w-8 text-success" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">30% available</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Scheduled Campaigns</p>
                <p className="text-2xl font-bold">{calendarEvents.length}</p>
              </div>
              <CalendarIcon className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-success">4 this month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Calendar */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" onClick={() => navigateMonth(-1)}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <h2 className="text-xl font-bold">
                    {months[currentDate.getMonth()]} {currentDate.getFullYear()}
                  </h2>
                  <Button variant="outline" size="icon" onClick={() => navigateMonth(1)}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Badge variant="outline" className="gap-1">
                    <div className="h-2 w-2 rounded-full bg-chart-1" /> Campaign
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <div className="h-2 w-2 rounded-full bg-chart-2" /> Email
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <div className="h-2 w-2 rounded-full bg-chart-5" /> Influencer
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
                    {day}
                  </div>
                ))}
                {Array.from({ length: firstDay }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-24 p-1" />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1;
                  const events = getEventsForDay(day);
                  const isToday = day === 19 && currentDate.getMonth() === 10; // Nov 19 as "today"

                  return (
                    <div
                      key={day}
                      className={`h-24 p-1 border border-border/50 rounded-lg transition-colors hover:border-primary/50 ${
                        isToday ? 'bg-primary/5 border-primary' : ''
                      }`}
                    >
                      <div className={`text-sm font-medium ${isToday ? 'text-primary' : ''}`}>{day}</div>
                      <div className="mt-1 space-y-1">
                        {events.slice(0, 2).map((event) => (
                          <div
                            key={event.id}
                            className="text-xs p-1 rounded truncate cursor-pointer hover:opacity-80 transition-opacity"
                            style={{ backgroundColor: event.color, color: 'white' }}
                            onClick={() => {
                              setSelectedEvent(event);
                              setShowEventDialog(true);
                            }}
                          >
                            {event.title}
                          </div>
                        ))}
                        {events.length > 2 && (
                          <div className="text-xs text-muted-foreground">+{events.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Upcoming Deadlines */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Upcoming Deadlines
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingDeadlines.map((deadline, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                  <div
                    className={`mt-1 h-2 w-2 rounded-full ${
                      deadline.priority === 'high'
                        ? 'bg-destructive'
                        : deadline.priority === 'medium'
                          ? 'bg-warning'
                          : 'bg-muted-foreground'
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{deadline.task}</p>
                    <p className="text-xs text-muted-foreground">{deadline.date}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {deadline.daysLeft}d
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Seasonal Events */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Gift className="h-4 w-4" />
                Seasonal Events
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {seasonalEvents.map((event, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium">{event.name}</p>
                    <p className="text-xs text-muted-foreground">{event.date}</p>
                  </div>
                  <Badge className="bg-success/10 text-success text-xs">{event.expectedLift}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* AI Suggestions */}
          <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                AI Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 rounded-lg bg-background/50 text-sm">
                <p className="font-medium">Schedule gap detected</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Consider adding a campaign Dec 15-20 to maintain momentum
                </p>
              </div>
              <div className="p-3 rounded-lg bg-background/50 text-sm">
                <p className="font-medium">Budget optimization</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Reallocate $5K from Email to TikTok for +12% expected ROAS
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Budget Allocation by Channel */}
      <Card>
        <CardHeader>
          <CardTitle>Q4 Budget Allocation by Channel</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-5">
            {budgetAllocation.byChannel.map((channel, i) => (
              <div key={i} className="p-4 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{channel.channel}</span>
                  <span className="text-sm text-muted-foreground">{channel.percentage}%</span>
                </div>
                <p className="text-2xl font-bold">${(channel.amount / 1000).toFixed(0)}K</p>
                <Progress value={channel.percentage} className="mt-2 h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Campaigns */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {calendarEvents.map((event) => (
              <div
                key={event.id}
                className="flex items-center justify-between p-4 rounded-lg border border-border hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => {
                  setSelectedEvent(event);
                  setShowEventDialog(true);
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="h-12 w-1 rounded-full" style={{ backgroundColor: event.color }} />
                  <div>
                    <h3 className="font-medium">{event.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {event.date}
                      </Badge>
                      {event.channel.map((ch, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">
                          {ch}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Budget</p>
                    <p className="font-bold">${event.budget.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Expected ROAS</p>
                    <p className="font-bold text-success">{event.expectedROAS}x</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Target Revenue</p>
                    <p className="font-bold">${(event.targetRevenue / 1000).toFixed(0)}K</p>
                  </div>
                  <Badge
                    className={
                      event.status === 'scheduled'
                        ? 'bg-chart-1/10 text-chart-1'
                        : event.status === 'in-progress'
                          ? 'bg-success/10 text-success'
                          : 'bg-muted text-muted-foreground'
                    }
                  >
                    {event.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Event Detail Dialog */}
      <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedEvent?.title}</DialogTitle>
          </DialogHeader>
          {selectedEvent && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Date</Label>
                  <p className="font-medium">{selectedEvent.date}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <Badge>{selectedEvent.status}</Badge>
                </div>
                <div>
                  <Label className="text-muted-foreground">Budget</Label>
                  <p className="font-medium">${selectedEvent.budget.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Expected ROAS</Label>
                  <p className="font-medium text-success">{selectedEvent.expectedROAS}x</p>
                </div>
              </div>
              <div>
                <Label className="text-muted-foreground">Description</Label>
                <p className="mt-1">{selectedEvent.description}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Channels</Label>
                <div className="flex gap-2 mt-1">
                  {selectedEvent.channel.map((ch, i) => (
                    <Badge key={i} variant="outline">
                      {ch}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <Button className="flex-1">Edit Campaign</Button>
                <Button variant="outline">View Analytics</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
