import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import {
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Target,
  Brain,
  Zap,
  Clock,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Wallet,
  Calculator,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import {
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ComposedChart,
  Area,
} from 'recharts';
import { useState } from 'react';
import { SEOHead } from '@/components/seo';
import {
  BudgetAlertsPanel,
  BudgetForecastingPanel,
  BudgetRulesPanel,
  BudgetOptimizationPanel,
} from '@/components/budget';

const budgetData = {
  totalBudget: 248000,
  spent: 186400,
  remaining: 61600,
  projectedSpend: 252000,
  daysRemaining: 12,
  paceStatus: 'over',
  utilizationRate: 75.2,
};

const channelBudgets = [
  {
    channel: 'Google Ads',
    allocated: 92000,
    spent: 68400,
    remaining: 23600,
    roas: 4.8,
    pace: 'on-track',
    efficiency: 94,
    recommendation: 'increase',
  },
  {
    channel: 'Meta Ads',
    allocated: 78000,
    spent: 62400,
    remaining: 15600,
    roas: 5.2,
    pace: 'over',
    efficiency: 88,
    recommendation: 'maintain',
  },
  {
    channel: 'TikTok Ads',
    allocated: 42000,
    spent: 28800,
    remaining: 13200,
    roas: 6.4,
    pace: 'under',
    efficiency: 96,
    recommendation: 'increase',
  },
  {
    channel: 'LinkedIn Ads',
    allocated: 24000,
    spent: 18400,
    remaining: 5600,
    roas: 3.2,
    pace: 'on-track',
    efficiency: 72,
    recommendation: 'decrease',
  },
  {
    channel: 'Programmatic',
    allocated: 12000,
    spent: 8400,
    remaining: 3600,
    roas: 3.8,
    pace: 'under',
    efficiency: 78,
    recommendation: 'maintain',
  },
];

const pacingData = [
  { day: '1', planned: 8000, actual: 7800, cumPlanned: 8000, cumActual: 7800 },
  { day: '5', planned: 40000, actual: 42400, cumPlanned: 40000, cumActual: 42400 },
  { day: '10', planned: 80000, actual: 88200, cumPlanned: 80000, cumActual: 88200 },
  { day: '15', planned: 120000, actual: 134800, cumPlanned: 120000, cumActual: 134800 },
  { day: '20', planned: 160000, actual: 186400, cumPlanned: 160000, cumActual: 186400 },
  { day: '25', planned: 200000, actual: null, cumPlanned: 200000, cumActual: null },
  { day: '30', planned: 248000, actual: null, cumPlanned: 248000, cumActual: null },
];

const aiRecommendations = [
  {
    id: 1,
    type: 'reallocation',
    title: 'Shift Budget from LinkedIn to TikTok',
    impact: '+$12,400 projected revenue',
    confidence: 94,
    action: 'Move $4,800 from LinkedIn to TikTok based on 6.4x vs 3.2x ROAS',
    urgency: 'high',
    status: 'pending',
  },
  {
    id: 2,
    type: 'pacing',
    title: 'Reduce Meta Spend Rate',
    impact: 'Prevent $8,200 overspend',
    confidence: 88,
    action: 'Decrease daily budget by 15% to stay within monthly allocation',
    urgency: 'medium',
    status: 'pending',
  },
  {
    id: 3,
    type: 'optimization',
    title: 'Increase Google Search Budget',
    impact: '+$18,600 projected revenue',
    confidence: 92,
    action: 'High-performing campaigns have 42% impression share. Increase budget to capture demand.',
    urgency: 'medium',
    status: 'approved',
  },
  {
    id: 4,
    type: 'efficiency',
    title: 'Pause Low-Performing Programmatic Segments',
    impact: 'Save $2,400/month',
    confidence: 86,
    action: '3 segments showing <1.5x ROAS consistently. Recommend pause and reallocate.',
    urgency: 'low',
    status: 'pending',
  },
];

const scenarioData = [
  { scenario: 'Conservative (-10%)', spend: 223200, revenue: 892800, roas: 4.0, risk: 'low' },
  { scenario: 'Current', spend: 248000, revenue: 1042800, roas: 4.2, risk: 'medium' },
  { scenario: 'Aggressive (+15%)', spend: 285200, revenue: 1283400, roas: 4.5, risk: 'medium' },
  { scenario: 'Maximum (+25%)', spend: 310000, revenue: 1426000, roas: 4.6, risk: 'high' },
];

const historicalROAS = [
  { month: 'Jan', google: 4.2, meta: 4.8, tiktok: 5.8, linkedin: 2.8 },
  { month: 'Feb', google: 4.4, meta: 5.0, tiktok: 6.2, linkedin: 3.0 },
  { month: 'Mar', google: 4.6, meta: 5.2, tiktok: 6.4, linkedin: 3.2 },
  { month: 'Apr', google: 4.5, meta: 5.1, tiktok: 6.1, linkedin: 3.1 },
  { month: 'May', google: 4.8, meta: 5.2, tiktok: 6.4, linkedin: 3.2 },
  { month: 'Jun', google: 4.8, meta: 5.2, tiktok: 6.4, linkedin: 3.2 },
];

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function BudgetManagement() {
  const [budgetAllocation, setBudgetAllocation] = useState({
    google: 37,
    meta: 31,
    tiktok: 17,
    linkedin: 10,
    programmatic: 5,
  });

  const handleAllocationChange = (channel: string, value: number[]) => {
    setBudgetAllocation((prev) => ({ ...prev, [channel]: value[0] }));
  };

  return (
    <>
      <SEOHead
        title="Budget Management | AI-Powered Budget Optimization"
        description="Manage and optimize your marketing budget with AI-powered allocation, pacing, and recommendations."
      />
      <div className="space-y-6 p-8">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Budget Management</h1>
            <p className="text-muted-foreground">AI-powered budget allocation, pacing, and optimization</p>
          </div>
          <div className="flex gap-2">
            <Select defaultValue="monthly">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">Weekly View</SelectItem>
                <SelectItem value="monthly">Monthly View</SelectItem>
                <SelectItem value="quarterly">Quarterly View</SelectItem>
              </SelectContent>
            </Select>
            <Button className="gap-2">
              <Calculator className="h-4 w-4" />
              Budget Planner
            </Button>
          </div>
        </div>

        {/* Budget Alert */}
        {budgetData.paceStatus === 'over' && (
          <Card className="border-warning/30 bg-warning/5">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-6 w-6 text-warning" />
                  <div>
                    <p className="font-semibold">Budget Pacing Alert</p>
                    <p className="text-sm text-muted-foreground">
                      You're on track to overspend by $
                      {((budgetData.projectedSpend - budgetData.totalBudget) / 1000).toFixed(1)}K this month.
                      Recommended action: Reduce daily spend by 12%.
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    Dismiss
                  </Button>
                  <Button size="sm" className="gap-1">
                    <Zap className="h-4 w-4" />
                    Auto-Adjust
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* KPI Summary */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Budget</p>
                  <p className="text-3xl font-bold">${(budgetData.totalBudget / 1000).toFixed(0)}K</p>
                </div>
                <Wallet className="h-10 w-10 text-chart-1" />
              </div>
              <p className="mt-2 text-xs text-muted-foreground">Monthly allocation</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Spent to Date</p>
                  <p className="text-3xl font-bold">${(budgetData.spent / 1000).toFixed(0)}K</p>
                </div>
                <DollarSign className="h-10 w-10 text-chart-2" />
              </div>
              <Progress value={budgetData.utilizationRate} className="h-2 mt-2" />
              <p className="mt-1 text-xs text-muted-foreground">{budgetData.utilizationRate}% utilized</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Remaining</p>
                  <p className="text-3xl font-bold">${(budgetData.remaining / 1000).toFixed(0)}K</p>
                </div>
                <Clock className="h-10 w-10 text-chart-3" />
              </div>
              <p className="mt-2 text-xs text-muted-foreground">{budgetData.daysRemaining} days left</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Projected Spend</p>
                  <p className="text-3xl font-bold">${(budgetData.projectedSpend / 1000).toFixed(0)}K</p>
                </div>
                <TrendingUp className="h-10 w-10 text-warning" />
              </div>
              <p className="mt-2 flex items-center gap-1 text-xs text-warning">
                <ArrowUpRight className="h-3 w-3" />
                +$4K over budget
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Blended ROAS</p>
                  <p className="text-3xl font-bold">4.8x</p>
                </div>
                <Target className="h-10 w-10 text-success" />
              </div>
              <p className="mt-2 flex items-center gap-1 text-xs text-success">
                <TrendingUp className="h-3 w-3" />
                +0.4x vs target
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="allocation" className="space-y-6">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="allocation">Budget Allocation</TabsTrigger>
            <TabsTrigger value="pacing">Spend Pacing</TabsTrigger>
            <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
            <TabsTrigger value="scenarios">Scenario Planning</TabsTrigger>
            <TabsTrigger value="history">Historical Analysis</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
            <TabsTrigger value="rules">Automation Rules</TabsTrigger>
            <TabsTrigger value="optimization">AI Optimization</TabsTrigger>
          </TabsList>

          <TabsContent value="allocation" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Channel Allocation
                    <Button size="sm" variant="outline" className="gap-1">
                      <RefreshCw className="h-4 w-4" />
                      Reset
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {Object.entries(budgetAllocation).map(([channel, value]) => (
                    <div key={channel} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="capitalize">{channel}</Label>
                        <span className="text-sm font-medium">
                          {value}% (${((budgetData.totalBudget * value) / 100 / 1000).toFixed(0)}K)
                        </span>
                      </div>
                      <Slider
                        value={[value]}
                        onValueChange={(v) => handleAllocationChange(channel, v)}
                        max={50}
                        step={1}
                      />
                    </div>
                  ))}
                  <Button className="w-full gap-2 mt-4">
                    <Sparkles className="h-4 w-4" />
                    Apply AI-Optimized Allocation
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Current Allocation</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RePieChart>
                      <Pie
                        data={Object.entries(budgetAllocation).map(([name, value]) => ({ name, value }))}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {Object.keys(budgetAllocation).map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Allocation']} />
                    </RePieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Channel Performance & Budget Status</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Channel</TableHead>
                      <TableHead>Allocated</TableHead>
                      <TableHead>Spent</TableHead>
                      <TableHead>Remaining</TableHead>
                      <TableHead>Utilization</TableHead>
                      <TableHead>ROAS</TableHead>
                      <TableHead>Efficiency</TableHead>
                      <TableHead>Pace Status</TableHead>
                      <TableHead>AI Recommendation</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {channelBudgets.map((ch) => (
                      <TableRow key={ch.channel}>
                        <TableCell className="font-medium">{ch.channel}</TableCell>
                        <TableCell>${(ch.allocated / 1000).toFixed(0)}K</TableCell>
                        <TableCell>${(ch.spent / 1000).toFixed(0)}K</TableCell>
                        <TableCell>${(ch.remaining / 1000).toFixed(0)}K</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={(ch.spent / ch.allocated) * 100} className="h-2 w-16" />
                            <span className="text-xs">{((ch.spent / ch.allocated) * 100).toFixed(0)}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-bold">{ch.roas}x</TableCell>
                        <TableCell>
                          <Badge
                            variant={ch.efficiency > 90 ? 'default' : ch.efficiency > 80 ? 'secondary' : 'outline'}
                          >
                            {ch.efficiency}%
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={ch.pace === 'over' ? 'destructive' : ch.pace === 'under' ? 'secondary' : 'default'}
                          >
                            {ch.pace}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              ch.recommendation === 'increase'
                                ? 'default'
                                : ch.recommendation === 'decrease'
                                  ? 'destructive'
                                  : 'secondary'
                            }
                            className="gap-1"
                          >
                            {ch.recommendation === 'increase' ? (
                              <ArrowUpRight className="h-3 w-3" />
                            ) : ch.recommendation === 'decrease' ? (
                              <ArrowDownRight className="h-3 w-3" />
                            ) : null}
                            {ch.recommendation}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pacing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Budget Pacing - Planned vs Actual</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <ComposedChart data={pacingData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="day" className="text-xs" tickFormatter={(v) => `Day ${v}`} />
                    <YAxis className="text-xs" tickFormatter={(v) => `$${v / 1000}K`} />
                    <Tooltip
                      formatter={(value) =>
                        value ? [`$${(Number(value) / 1000).toFixed(1)}K`, ''] : ['Projected', '']
                      }
                    />
                    <Area
                      type="monotone"
                      dataKey="cumPlanned"
                      stroke="hsl(var(--chart-2))"
                      fill="hsl(var(--chart-2))"
                      fillOpacity={0.2}
                      name="Planned Cumulative"
                      strokeDasharray="5 5"
                    />
                    <Line
                      type="monotone"
                      dataKey="cumActual"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={3}
                      name="Actual Cumulative"
                      dot={{ r: 4 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Daily Budget
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">${(budgetData.totalBudget / 30 / 1000).toFixed(1)}K</p>
                  <p className="text-sm text-muted-foreground">Target daily spend</p>
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Today's spend</span>
                      <span className="font-medium">$9.2K</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Variance</span>
                      <span className="font-medium text-warning">+$0.9K</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Pace Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">108%</p>
                  <p className="text-sm text-muted-foreground">of planned pace</p>
                  <Progress value={108} max={150} className="h-3 mt-4" />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Under</span>
                    <span>On Track</span>
                    <span>Over</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    AI Forecast
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">$252K</p>
                  <p className="text-sm text-muted-foreground">Projected month-end spend</p>
                  <div className="mt-4 p-3 rounded-lg bg-warning/10 border border-warning/20">
                    <p className="text-xs text-warning">⚠️ Recommend reducing daily budget by 12% to stay on target</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            <div className="grid gap-4">
              {aiRecommendations.map((rec) => (
                <Card key={rec.id} className={rec.urgency === 'high' ? 'border-warning/30' : ''}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div
                          className={`p-3 rounded-lg ${
                            rec.type === 'reallocation'
                              ? 'bg-chart-1/10'
                              : rec.type === 'pacing'
                                ? 'bg-chart-2/10'
                                : rec.type === 'optimization'
                                  ? 'bg-chart-3/10'
                                  : 'bg-chart-4/10'
                          }`}
                        >
                          {rec.type === 'reallocation' ? (
                            <RefreshCw className="h-6 w-6 text-chart-1" />
                          ) : rec.type === 'pacing' ? (
                            <Clock className="h-6 w-6 text-chart-2" />
                          ) : rec.type === 'optimization' ? (
                            <TrendingUp className="h-6 w-6 text-chart-3" />
                          ) : (
                            <Zap className="h-6 w-6 text-chart-4" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{rec.title}</h3>
                            <Badge
                              variant={
                                rec.urgency === 'high'
                                  ? 'destructive'
                                  : rec.urgency === 'medium'
                                    ? 'default'
                                    : 'secondary'
                              }
                            >
                              {rec.urgency} priority
                            </Badge>
                            {rec.status === 'approved' && (
                              <Badge variant="outline" className="gap-1 text-success border-success">
                                <CheckCircle2 className="h-3 w-3" />
                                Approved
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{rec.action}</p>
                          <div className="flex items-center gap-4 mt-2">
                            <span className="text-sm font-medium text-success">{rec.impact}</span>
                            <span className="text-xs text-muted-foreground">Confidence: {rec.confidence}%</span>
                          </div>
                        </div>
                      </div>
                      {rec.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="gap-1">
                            <XCircle className="h-4 w-4" />
                            Dismiss
                          </Button>
                          <Button size="sm" className="gap-1">
                            <CheckCircle2 className="h-4 w-4" />
                            Apply
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="scenarios" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Budget Scenario Planning</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Scenario</TableHead>
                      <TableHead>Monthly Spend</TableHead>
                      <TableHead>Projected Revenue</TableHead>
                      <TableHead>Expected ROAS</TableHead>
                      <TableHead>Risk Level</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {scenarioData.map((scenario, i) => (
                      <TableRow key={i} className={scenario.scenario === 'Current' ? 'bg-primary/5' : ''}>
                        <TableCell className="font-medium">
                          {scenario.scenario}
                          {scenario.scenario === 'Current' && (
                            <Badge variant="outline" className="ml-2">
                              Active
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>${(scenario.spend / 1000).toFixed(0)}K</TableCell>
                        <TableCell className="font-bold">${(scenario.revenue / 1000).toFixed(0)}K</TableCell>
                        <TableCell>{scenario.roas}x</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              scenario.risk === 'high'
                                ? 'destructive'
                                : scenario.risk === 'medium'
                                  ? 'default'
                                  : 'secondary'
                            }
                          >
                            {scenario.risk}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {scenario.scenario !== 'Current' && (
                            <Button size="sm" variant="outline">
                              Apply Scenario
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Historical ROAS by Channel</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={historicalROAS}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(v) => `${v}x`} />
                    <Tooltip formatter={(value) => [`${value}x`, '']} />
                    <Line type="monotone" dataKey="google" stroke="hsl(var(--chart-1))" strokeWidth={2} name="Google" />
                    <Line type="monotone" dataKey="meta" stroke="hsl(var(--chart-2))" strokeWidth={2} name="Meta" />
                    <Line type="monotone" dataKey="tiktok" stroke="hsl(var(--chart-3))" strokeWidth={2} name="TikTok" />
                    <Line
                      type="monotone"
                      dataKey="linkedin"
                      stroke="hsl(var(--chart-4))"
                      strokeWidth={2}
                      name="LinkedIn"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts">
            <BudgetAlertsPanel />
          </TabsContent>

          <TabsContent value="forecasting">
            <BudgetForecastingPanel />
          </TabsContent>

          <TabsContent value="rules">
            <BudgetRulesPanel />
          </TabsContent>

          <TabsContent value="optimization">
            <BudgetOptimizationPanel />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
