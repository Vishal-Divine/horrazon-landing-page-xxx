import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
  AreaChart,
  Area,
  Sankey,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  TrendingUp,
  Users,
  DollarSign,
  Target,
  Zap,
  Brain,
  BarChart3,
  Shuffle,
  GitBranch,
  Calculator,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Download,
  Settings,
  Lightbulb,
} from 'lucide-react';

const pieData = [
  { name: 'Paid Media', value: 62, color: 'hsl(var(--chart-1))' },
  { name: 'Organic & Earned', value: 28, color: 'hsl(var(--chart-2))' },
  { name: 'Unable to Classify', value: 10, color: 'hsl(var(--muted))' },
];

const channelData = [
  { channel: 'Meta Ads', revenue: 48500, conversions: 1240 },
  { channel: 'TikTok Ads', revenue: 32800, conversions: 890 },
  { channel: 'Google Search', revenue: 28400, conversions: 680 },
  { channel: 'Influencer Marketing', revenue: 24200, conversions: 520 },
  { channel: 'Email', revenue: 19200, conversions: 450 },
  { channel: 'Affiliate', revenue: 15800, conversions: 380 },
];

const attributionModels = [
  { model: 'First Touch', meta: 35, google: 28, influencer: 18, email: 12, affiliate: 7 },
  { model: 'Last Touch', meta: 42, google: 25, influencer: 15, email: 10, affiliate: 8 },
  { model: 'Linear', meta: 30, google: 24, influencer: 20, email: 15, affiliate: 11 },
  { model: 'Time Decay', meta: 38, google: 26, influencer: 17, email: 11, affiliate: 8 },
  { model: 'Position Based', meta: 36, google: 27, influencer: 19, email: 10, affiliate: 8 },
];

const touchPointData = [
  { touchpoint: 1, conversions: 2840, revenue: 142000 },
  { touchpoint: 2, conversions: 1920, revenue: 115200 },
  { touchpoint: 3, conversions: 1240, revenue: 86800 },
  { touchpoint: 4, conversions: 780, revenue: 62400 },
  { touchpoint: 5, conversions: 420, revenue: 37800 },
  { touchpoint: '6+', conversions: 280, revenue: 28400 },
];

const incrementalityData = [
  { channel: 'Meta Ads', incrementalRevenue: 42000, totalRevenue: 48500, incrementality: 87 },
  { channel: 'TikTok Ads', incrementalRevenue: 28500, totalRevenue: 32800, incrementality: 87 },
  { channel: 'Google Search', incrementalRevenue: 19900, totalRevenue: 28400, incrementality: 70 },
  { channel: 'Influencer', incrementalRevenue: 20900, totalRevenue: 24200, incrementality: 86 },
  { channel: 'Email', incrementalRevenue: 9600, totalRevenue: 19200, incrementality: 50 },
];

// NEW: Path Analysis Data
const topPaths = [
  { path: 'Meta → Google → Purchase', conversions: 842, revenue: 58940, avgValue: 70 },
  { path: 'Influencer → Meta → Purchase', conversions: 624, revenue: 49920, avgValue: 80 },
  { path: 'Google → Meta → Email → Purchase', conversions: 418, revenue: 37620, avgValue: 90 },
  { path: 'Direct → Purchase', conversions: 1240, revenue: 62000, avgValue: 50 },
  { path: 'TikTok → Meta → Purchase', conversions: 386, revenue: 30880, avgValue: 80 },
];

// NEW: Model Confidence Scores
const modelConfidence = [
  { model: 'Data-Driven', confidence: 94, accuracy: 92, coverage: 88, recommendation: 'Recommended' },
  { model: 'Markov Chain', confidence: 88, accuracy: 86, coverage: 92, recommendation: 'Good' },
  { model: 'Shapley Value', confidence: 86, accuracy: 84, coverage: 94, recommendation: 'Good' },
  { model: 'Time Decay', confidence: 78, accuracy: 76, coverage: 96, recommendation: 'Basic' },
  { model: 'Linear', confidence: 72, accuracy: 70, coverage: 98, recommendation: 'Basic' },
];

// NEW: Budget Recommendations
const budgetRecommendations = [
  {
    channel: 'Meta Ads',
    current: 42000,
    recommended: 48000,
    change: '+14%',
    reason: 'Highest incremental ROAS',
    impact: '+$8,400 revenue',
  },
  {
    channel: 'TikTok Ads',
    current: 28000,
    recommended: 32000,
    change: '+14%',
    reason: 'Strong new customer acquisition',
    impact: '+$5,200 revenue',
  },
  {
    channel: 'Google Search',
    current: 24000,
    recommended: 22000,
    change: '-8%',
    reason: 'Diminishing returns detected',
    impact: 'Save $2,000',
  },
  {
    channel: 'Email',
    current: 8000,
    recommended: 8000,
    change: '0%',
    reason: 'Optimal spend level',
    impact: 'Maintain',
  },
];

// NEW: Channel Synergy Matrix
const synergyData = [
  { channel: 'Meta', meta: 1, google: 1.24, tiktok: 1.18, influencer: 1.34, email: 1.12 },
  { channel: 'Google', meta: 1.24, google: 1, tiktok: 1.08, influencer: 1.16, email: 1.22 },
  { channel: 'TikTok', meta: 1.18, google: 1.08, tiktok: 1, influencer: 1.28, email: 1.06 },
  { channel: 'Influencer', meta: 1.34, google: 1.16, tiktok: 1.28, influencer: 1, email: 1.14 },
  { channel: 'Email', meta: 1.12, google: 1.22, tiktok: 1.06, influencer: 1.14, email: 1 },
];

// NEW: Conversion Window Analysis
const conversionWindowData = [
  { window: '0-1 days', conversions: 1840, percentage: 32, revenue: 92000 },
  { window: '2-7 days', conversions: 2420, percentage: 42, revenue: 145200 },
  { window: '8-14 days', conversions: 980, percentage: 17, revenue: 68600 },
  { window: '15-30 days', conversions: 520, percentage: 9, revenue: 41600 },
];

export default function Attribution() {
  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Multi-Touch Attribution</h1>
          <p className="text-muted-foreground">Advanced attribution modeling, path analysis & budget optimization</p>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="30d">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button variant="outline" className="gap-2">
            <Settings className="h-4 w-4" />
            Configure
          </Button>
        </div>
      </div>

      {/* KPI Summary */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Attributed Revenue</p>
                <p className="text-2xl font-bold">$168.9K</p>
              </div>
              <DollarSign className="h-8 w-8 text-chart-1" />
            </div>
            <p className="mt-2 text-xs text-success">90% attribution coverage</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Touchpoints</p>
                <p className="text-2xl font-bold">3.2</p>
              </div>
              <GitBranch className="h-8 w-8 text-chart-2" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Before conversion</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Channel Synergy</p>
                <p className="text-2xl font-bold">+24%</p>
              </div>
              <Shuffle className="h-8 w-8 text-chart-3" />
            </div>
            <p className="mt-2 text-xs text-success">Multi-channel lift</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Model Confidence</p>
                <p className="text-2xl font-bold">94%</p>
              </div>
              <Brain className="h-8 w-8 text-chart-4" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Data-driven model</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Optimization Opp.</p>
                <p className="text-2xl font-bold">+$13.6K</p>
              </div>
              <Zap className="h-8 w-8 text-warning" />
            </div>
            <p className="mt-2 text-xs text-success">With budget reallocation</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="models">Attribution Models</TabsTrigger>
          <TabsTrigger value="journey">Customer Journey</TabsTrigger>
          <TabsTrigger value="incrementality">Incrementality</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Attribution Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue by Channel</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={channelData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis
                      type="category"
                      dataKey="channel"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      width={120}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                      }}
                      formatter={(value) => `$${value.toLocaleString()}`}
                    />
                    <Bar dataKey="revenue" fill="hsl(var(--chart-1))" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Channel Overlap & Synergy Analysis</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center p-12">
              <div className="relative h-64 w-full max-w-2xl">
                <div className="absolute left-1/4 top-1/4 flex h-40 w-40 items-center justify-center rounded-full border-4 border-chart-1 bg-chart-1/10">
                  <span className="text-sm font-bold">Meta</span>
                </div>
                <div className="absolute right-1/4 top-1/4 flex h-40 w-40 items-center justify-center rounded-full border-4 border-chart-2 bg-chart-2/10">
                  <span className="text-sm font-bold">Google</span>
                </div>
                <div className="absolute left-1/2 top-1/2 flex h-40 w-40 -translate-x-1/2 items-center justify-center rounded-full border-4 border-chart-3 bg-chart-3/10">
                  <span className="text-sm font-bold">Influencer</span>
                </div>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                  <div className="rounded-lg bg-card p-2 shadow-lg">
                    <p className="text-xs text-muted-foreground">Multi-touch</p>
                    <p className="text-lg font-bold">18%</p>
                    <p className="text-xs text-success">+12% uplift</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Attribution Model Comparison</CardTitle>
              <p className="text-sm text-muted-foreground">
                Compare different attribution methodologies to understand channel value
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {attributionModels.map((model) => (
                  <div key={model.model} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{model.model}</span>
                      <span className="text-xs text-muted-foreground">Total: 100%</span>
                    </div>
                    <div className="flex h-8 w-full overflow-hidden rounded-lg">
                      <div
                        className="bg-chart-1 transition-all hover:opacity-80"
                        style={{ width: `${model.meta}%` }}
                        title={`Meta: ${model.meta}%`}
                      />
                      <div
                        className="bg-chart-2 transition-all hover:opacity-80"
                        style={{ width: `${model.google}%` }}
                        title={`Google: ${model.google}%`}
                      />
                      <div
                        className="bg-chart-3 transition-all hover:opacity-80"
                        style={{ width: `${model.influencer}%` }}
                        title={`Influencer: ${model.influencer}%`}
                      />
                      <div
                        className="bg-chart-4 transition-all hover:opacity-80"
                        style={{ width: `${model.email}%` }}
                        title={`Email: ${model.email}%`}
                      />
                      <div
                        className="bg-chart-5 transition-all hover:opacity-80"
                        style={{ width: `${model.affiliate}%` }}
                        title={`Affiliate: ${model.affiliate}%`}
                      />
                    </div>
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <div className="h-3 w-3 rounded-sm bg-chart-1" />
                        Meta {model.meta}%
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="h-3 w-3 rounded-sm bg-chart-2" />
                        Google {model.google}%
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="h-3 w-3 rounded-sm bg-chart-3" />
                        Influencer {model.influencer}%
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="h-3 w-3 rounded-sm bg-chart-4" />
                        Email {model.email}%
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="h-3 w-3 rounded-sm bg-chart-5" />
                        Affiliate {model.affiliate}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Data-Driven Attribution</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Uses machine learning to assign credit based on actual conversion patterns
                </p>
                <div className="mt-4">
                  <Badge className="bg-success/10 text-success">Recommended</Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Markov Chain Model</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Calculates removal effect - the impact if a channel was removed from the journey
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Shapley Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Game theory approach that fairly distributes credit across all touchpoints
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="journey" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customer Journey Touchpoints</CardTitle>
              <p className="text-sm text-muted-foreground">
                Revenue and conversion impact by number of touchpoints before purchase
              </p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={touchPointData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis
                    dataKey="touchpoint"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    label={{ value: 'Number of Touchpoints', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    label={{ value: 'Revenue ($)', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 'var(--radius)',
                    }}
                    formatter={(value) => `$${value.toLocaleString()}`}
                  />
                  <Line type="monotone" dataKey="revenue" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Average Journey Length
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-3xl font-bold">3.2 touchpoints</p>
                    <p className="text-sm text-muted-foreground">Before first purchase</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>New Customers</span>
                      <span className="font-medium">4.1 touchpoints</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Returning Customers</span>
                      <span className="font-medium">2.3 touchpoints</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-success" />
                  Path Optimization Opportunity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-3xl font-bold text-success">+24% Revenue</p>
                    <p className="text-sm text-muted-foreground">By optimizing journey paths</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3">
                    <p className="text-sm">
                      <strong>Top Insight:</strong> Customers exposed to Influencer + Meta ads convert 34% better than
                      single-channel exposure
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="incrementality" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Incrementality Analysis</CardTitle>
              <p className="text-sm text-muted-foreground">
                True incremental revenue - what you wouldn't have earned without each channel
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {incrementalityData.map((channel) => (
                  <div key={channel.channel} className="space-y-2 rounded-lg border border-border p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{channel.channel}</span>
                      <Badge variant={channel.incrementality >= 70 ? 'default' : 'secondary'}>
                        {channel.incrementality}% Incremental
                      </Badge>
                    </div>
                    <div className="grid gap-4 text-sm md:grid-cols-3">
                      <div>
                        <p className="text-muted-foreground">Total Revenue</p>
                        <p className="font-bold">${channel.totalRevenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Incremental Revenue</p>
                        <p className="font-bold text-success">${channel.incrementalRevenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Organic/Would-be Revenue</p>
                        <p className="font-medium">
                          ${(channel.totalRevenue - channel.incrementalRevenue).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Marketing Efficiency Ratio (MER)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-4xl font-bold">5.2</p>
                    <p className="text-sm text-muted-foreground">Total Revenue / Total Ad Spend</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3">
                    <p className="text-sm">
                      <strong>Insight:</strong> Your blended efficiency ratio is strong. Focus on maintaining while
                      scaling high-performing channels.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Holdout Test Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Meta Ads Holdout</span>
                      <Badge className="bg-success/10 text-success">Completed</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">-28% revenue in test group confirms true impact</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Email Holdout</span>
                      <Badge variant="secondary">In Progress</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">Results expected in 7 days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
