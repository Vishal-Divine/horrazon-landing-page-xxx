import { Toaster } from '@/components/ui/toaster';
import { Toaster as Sonner } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import AddFundsDialog from './components/wallet/AddFundsDialog';
import Layout from './components/Layout';
import Index from './pages/Index';
import NotFound from './pages/NotFound';
import DailyPulse from './pages/DailyPulse';
import Outreach from './pages/Outreach';
import Attribution from './pages/Attribution';
import Merchandise from './pages/Merchandise';
import CLTV from './pages/CLTV';
import InfluencerMarketing from './pages/InfluencerMarketing';
import SEO from './pages/SEO';
import Reports from './pages/Reports';
import Forecasting from './pages/Forecasting';
import CompetitorIntelligence from './pages/CompetitorIntelligence';
import BudgetManagement from './pages/BudgetManagement';
import ActionCenter from './pages/ActionCenter';
import ActionLog from './pages/ActionLog';
import Rules from './pages/Rules';
import CreateRule from './pages/CreateRule';
import Integrations from './pages/Integrations';
import AskPogee from './pages/AskPogee';
import ActSettings from './pages/ActSettings';
import BillingSettings from './pages/BillingSettings';
import GoalsKPI from './pages/GoalsKPI';
import Experiments from './pages/Experiments';
import CustomerSegments from './pages/CustomerSegments';
import PixelTracking from './pages/PixelTracking';
import BrandVoice from './pages/BrandVoice';
import MarketingCalendar from './pages/MarketingCalendar';
import CallTracking from './pages/CallTracking';
import WalletPage from './pages/Wallet';
import MarketingCommandCenter from './pages/MarketingCommandCenter';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <AddFundsDialog />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<DailyPulse />} />
              <Route path="command-center" element={<MarketingCommandCenter />} />
              <Route path="outreach" element={<Outreach />} />
              <Route path="attribution" element={<Attribution />} />
              <Route path="merchandise" element={<Merchandise />} />
              <Route path="cltv" element={<CLTV />} />
              <Route path="influencer-marketing" element={<InfluencerMarketing />} />
              <Route path="seo" element={<SEO />} />
              <Route path="reports" element={<Reports />} />
              <Route path="forecasting" element={<Forecasting />} />
              <Route path="competitor-intelligence" element={<CompetitorIntelligence />} />
              <Route path="budget" element={<BudgetManagement />} />
              <Route path="actions" element={<ActionCenter />} />
              <Route path="action-log" element={<ActionLog />} />
              <Route path="rules" element={<Rules />} />
              <Route path="rules/create" element={<CreateRule />} />
              <Route path="integrations" element={<Integrations />} />
              <Route path="ask" element={<AskPogee />} />
              <Route path="settings" element={<ActSettings />} />
              <Route path="settings/billing" element={<BillingSettings />} />
              <Route path="wallet" element={<WalletPage />} />
              <Route path="goals" element={<GoalsKPI />} />
              <Route path="experiments" element={<Experiments />} />
              <Route path="segments" element={<CustomerSegments />} />
              <Route path="pixel" element={<PixelTracking />} />
              <Route path="brand-voice" element={<BrandVoice />} />
              <Route path="calendar" element={<MarketingCalendar />} />
              <Route path="call-tracking" element={<CallTracking />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AppProvider>
  </QueryClientProvider>
);

export default App;
