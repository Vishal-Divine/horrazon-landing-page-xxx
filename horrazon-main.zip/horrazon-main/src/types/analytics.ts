// ==========================================
// Core Analytics Types
// ==========================================

export interface MetricValue {
  current: number;
  previous: number;
  change: number;
  changePercent: number;
  trend: 'up' | 'down' | 'stable';
  forecast?: number;
  confidence?: number;
}

export interface TimeSeriesDataPoint {
  date: string;
  timestamp: number;
  value: number;
  predicted?: number;
  upperBound?: number;
  lowerBound?: number;
  anomaly?: boolean;
  anomalyScore?: number;
}

export interface DateRange {
  start: Date;
  end: Date;
  label: string;
  comparisonStart?: Date;
  comparisonEnd?: Date;
}

// ==========================================
// Customer Intelligence Types
// ==========================================

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type HealthStatus = 'healthy' | 'at-risk' | 'churning' | 'churned' | 'new';
export type SegmentType =
  | 'champions'
  | 'loyal'
  | 'potential'
  | 'new'
  | 'promising'
  | 'needs-attention'
  | 'about-to-sleep'
  | 'at-risk'
  | 'cant-lose'
  | 'hibernating'
  | 'lost';

export interface CustomerProfile {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  segment: SegmentType;
  healthScore: number;
  healthStatus: HealthStatus;
  churnRisk: RiskLevel;
  churnProbability: number;
  lifetimeValue: number;
  predictedLTV: number;
  avgOrderValue: number;
  totalOrders: number;
  daysSinceLastPurchase: number;
  firstPurchaseDate: Date;
  lastPurchaseDate: Date;
  purchaseFrequency: number;
  engagementScore: number;
  npsScore?: number;
  tags: string[];
}

export interface CohortData {
  cohortMonth: string;
  cohortSize: number;
  retentionRates: number[];
  revenuePerUser: number[];
  avgLTV: number;
  churnRate: number;
}

export interface RFMScore {
  recency: number;
  frequency: number;
  monetary: number;
  combined: number;
  segment: SegmentType;
}

export interface CustomerSegment {
  id: string;
  name: string;
  type: SegmentType;
  color: string;
  customerCount: number;
  percentOfTotal: number;
  avgLTV: number;
  avgOrderValue: number;
  avgPurchaseFrequency: number;
  churnRate: number;
  growthRate: number;
  revenueContribution: number;
}

// ==========================================
// Outreach & Campaign Types
// ==========================================

export type ChannelType = 'email' | 'sms' | 'push' | 'whatsapp' | 'in-app';
export type CampaignStatus = 'draft' | 'scheduled' | 'active' | 'paused' | 'completed' | 'archived';

export interface EngagementMetrics {
  sent: number;
  delivered: number;
  deliveryRate: number;
  opened: number;
  openRate: number;
  clicked: number;
  clickRate: number;
  converted: number;
  conversionRate: number;
  unsubscribed: number;
  unsubscribeRate: number;
  bounced: number;
  bounceRate: number;
  complained: number;
  complaintRate: number;
}

export interface SendTimeOptimization {
  hour: number;
  day: string;
  score: number;
  expectedOpenRate: number;
  expectedClickRate: number;
  confidence: number;
}

export interface ABTestVariant {
  id: string;
  name: string;
  description: string;
  sampleSize: number;
  metrics: EngagementMetrics;
  isWinner: boolean;
  confidence: number;
  lift: number;
}

export interface ABTest {
  id: string;
  name: string;
  type: 'subject' | 'content' | 'sendTime' | 'cta' | 'layout';
  status: 'running' | 'completed' | 'paused';
  startDate: Date;
  endDate?: Date;
  variants: ABTestVariant[];
  winningVariantId?: string;
  statisticalSignificance: number;
}

export interface OutreachCampaign {
  id: string;
  name: string;
  channel: ChannelType;
  status: CampaignStatus;
  type: 'one-time' | 'automated' | 'triggered';
  targetSegment: string;
  metrics: EngagementMetrics;
  revenue: number;
  roas: number;
  cost: number;
  startDate: Date;
  endDate?: Date;
  abTests?: ABTest[];
}

export interface ChannelPerformance {
  channel: ChannelType;
  metrics: EngagementMetrics;
  revenue: number;
  cost: number;
  roas: number;
  trend: TimeSeriesDataPoint[];
  benchmarkComparison: {
    metric: string;
    value: number;
    benchmark: number;
    difference: number;
  }[];
}

export interface SubscriberGrowth {
  date: string;
  newSubscribers: number;
  unsubscribes: number;
  netGrowth: number;
  totalActive: number;
  source: {
    organic: number;
    paid: number;
    referral: number;
    other: number;
  };
}

// ==========================================
// Attribution Types
// ==========================================

export type AttributionModel =
  | 'first-touch'
  | 'last-touch'
  | 'linear'
  | 'time-decay'
  | 'position-based'
  | 'data-driven'
  | 'shapley';

export interface TouchPoint {
  id: string;
  channel: string;
  source: string;
  medium: string;
  campaign: string;
  timestamp: Date;
  sessionDuration: number;
  pagesViewed: number;
  isConversion: boolean;
}

export interface AttributionResult {
  channel: string;
  conversions: number;
  revenue: number;
  cost: number;
  roas: number;
  attributionShare: number;
  modelContribution: {
    [key in AttributionModel]?: number;
  };
}

export interface CustomerJourney {
  customerId: string;
  touchPoints: TouchPoint[];
  totalDuration: number;
  conversionValue: number;
  journeyType: 'linear' | 'complex' | 'short';
  channelPath: string[];
}

// ==========================================
// Forecasting & Predictive Types
// ==========================================

export interface ForecastPoint {
  date: string;
  predicted: number;
  actual?: number;
  upperBound: number;
  lowerBound: number;
  confidence: number;
}

export interface ForecastModel {
  id: string;
  name: string;
  type: 'arima' | 'prophet' | 'lstm' | 'ensemble';
  accuracy: number;
  mape: number;
  rmse: number;
  lastUpdated: Date;
}

export interface AnomalyDetection {
  id: string;
  metric: string;
  timestamp: Date;
  value: number;
  expectedValue: number;
  deviation: number;
  severity: RiskLevel;
  type: 'spike' | 'drop' | 'trend-change' | 'seasonal-anomaly';
  possibleCauses: string[];
  recommendedActions: string[];
}

export interface PredictiveInsight {
  id: string;
  type: 'opportunity' | 'risk' | 'trend' | 'recommendation';
  title: string;
  description: string;
  impact: 'low' | 'medium' | 'high';
  confidence: number;
  affectedMetrics: string[];
  suggestedActions: string[];
  expectedOutcome: string;
  timeframe: string;
}

// ==========================================
// AI & Recommendations Types
// ==========================================

export interface AIRecommendation {
  id: string;
  type: 'optimization' | 'automation' | 'creative' | 'targeting' | 'budget';
  priority: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  expectedImpact: {
    metric: string;
    currentValue: number;
    projectedValue: number;
    improvement: number;
  };
  confidence: number;
  effort: 'low' | 'medium' | 'high';
  implementation: {
    automated: boolean;
    steps: string[];
    estimatedTime: string;
  };
  status: 'pending' | 'applied' | 'dismissed' | 'scheduled';
}

export interface OptimizationScore {
  overall: number;
  categories: {
    targeting: number;
    creative: number;
    timing: number;
    budget: number;
    automation: number;
  };
  improvements: AIRecommendation[];
}

// ==========================================
// Dashboard & Visualization Types
// ==========================================

export interface DashboardWidget {
  id: string;
  type: 'kpi' | 'chart' | 'table' | 'heatmap' | 'funnel' | 'map';
  title: string;
  size: 'small' | 'medium' | 'large' | 'full';
  position: { row: number; col: number };
  config: Record<string, unknown>;
}

export interface ChartConfig {
  type: 'line' | 'bar' | 'area' | 'pie' | 'donut' | 'scatter' | 'heatmap' | 'radar' | 'funnel' | 'sankey';
  data: unknown[];
  xAxisKey?: string;
  yAxisKey?: string;
  colors?: string[];
  showLegend?: boolean;
  showGrid?: boolean;
  animated?: boolean;
}

export interface HeatmapCell {
  x: string | number;
  y: string | number;
  value: number;
  label?: string;
}

export interface FunnelStage {
  name: string;
  value: number;
  conversionRate: number;
  dropoffRate: number;
  benchmarkRate?: number;
}
